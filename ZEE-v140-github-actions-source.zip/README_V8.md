# ZEE v8 — fiabilité CHAT / ACK

Cette version poursuit v7 avec deux corrections de protocole importantes :

- **ACK sur la même liaison TCP** : un destinataire peut maintenant renvoyer l'ACK par le socket qui lui a livré le CHAT. L'ancien `except=session` empêchait l'ACK de revenir lorsque l'expéditeur et le destinataire étaient directement connectés.
- **Reprise événementielle + périodique des messages persistants** : une petite boucle de retry relance les messages restés dans `MeshMessageStore` lorsqu'une route revient ou lorsqu'un envoi a échoué. Un ensemble `inFlightMessageIds` évite les doublons pendant qu'une ligne attend son flush réel.
- Le backoff existant de `MeshMessageStore` reste appliqué après un flush réel.

Le build Android complet n'est pas exécuté dans cet environnement : Gradle/SDK Android ne sont pas disponibles. L'archive doit être vérifiée avec `unzip -t` avant livraison.
