# ZEE v27 — présence Wi‑Fi Direct et visibilité

Cette version part de v25 Business/Job et ajoute une gestion stricte de la présence locale.

## Règles
- Un pair n'est affiché que s'il est retrouvé pendant le cycle de découverte courant.
- Chaque nouveau cycle Wi‑Fi Direct vide la présence précédente avant de rescanner.
- Au retour au premier plan, l'ancienne présence non connectée est vidée.
- Une session Wi‑Fi Direct déjà CONNECTED peut rester affichée car elle constitue une preuve de présence/joignabilité.
- Les sessions Mesh/TCP ne sont pas supprimées par le nettoyage de présence.
- BUSINESS : vendeur et acheteur se voient mutuellement, sous réserve que le pair ait activé sa visibilité BUSINESS.
- JOB : chercheur d'emploi et recruteur se voient mutuellement, sous réserve que le pair ait activé sa visibilité JOB.
- La visibilité est donc un filtre, tandis que le rôle n'est pas un filtre.
- Un pair dont le module n'est pas annoncé n'apparaît pas dans cet onglet.

## Important
La présence est volontairement non persistante. Les données de profil peuvent rester en mémoire, mais elles ne servent pas à recréer artificiellement une présence de proximité après fermeture de l'application.

## Rafraîchissement
`WifiDirectManager.clearNearbyPresence()` efface uniquement le registre des pairs découverts ; `SessionRegistry` et les connexions Mesh ne sont pas touchés.
