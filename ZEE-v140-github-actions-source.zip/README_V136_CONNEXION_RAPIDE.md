# ZEE V136 — pourquoi la connexion n'aboutit pas après la découverte, et correction

Base : `zee-v135-photo-decouverte.zip`.

## Problèmes identifiés (journaux itel / Infinix + documentation Android)
1. **Le pair n'est plus dans la liste au moment de `connect()`** : après `stopPeerDiscovery`, la liste se vide (`P2P_PEERS count=0`) et `connect()` échoue aussitôt avec le code 0 (V131 : vérification du pair, plus d'arrêt manuel de la découverte).
2. **Une invitation à accepter** : une connexion Wi-Fi Direct classique (WPS/PBC) affiche sur l'AUTRE téléphone une boîte « Invitation à se connecter » à accepter (la documentation Android parle d'une boîte de dialogue affichée par le service Wi-Fi ; les guides constructeur disent « sur l'autre appareil, sélectionner Accepter »). ZEE connecte automatiquement : un seul téléphone initiait, l'autre n'avait aucune raison d'accepter, et la connexion n'aboutissait pas.
3. **Faux « connexion perdue » pendant une tentative** : un changement de connexion « pas de groupe » reçu pendant la négociation réinitialisait l'état, relançait la découverte et invalidait les essais en cours.

## Correction : connexion rapide (Android 10 / API 29 et plus)
La documentation Android 10 décrit une « connexion Wi-Fi Direct rapide avec informations prédéterminées » : un appareil crée le groupe avec `createGroup(config)` (nom de réseau + mot de passe), l'autre le rejoint avec `connect(config)` et la même config. Pas de négociation, pas d'invitation.
- Nom de réseau (`DIRECT-xy-ZEE…`) et mot de passe sont dérivés (SHA-256) du nodeId du Group Owner, connu des deux téléphones grâce au nom d'instance de la V132.
- Le téléphone au nodeId le plus grand crée le groupe ; l'autre le rejoint (essais toutes les 1,5 s pendant 18 s). Les deux agissent seuls : aucune validation de l'utilisateur.
- Si personne ne rejoint le groupe en 40 s, il est supprimé et la découverte repart.
- Repli automatique sur la connexion classique : si la connexion rapide échoue (2 échecs avec un même pair, la connexion rapide n'est plus tentée avec lui), ou si le nodeId du pair est inconnu, ou sous Android 9 et moins.
- Garde-fou : pendant les 20 s qui suivent le début d'une tentative, un « pas de groupe » du système n'est plus pris pour une perte de connexion.
- `cancelPendingConnection()` arrête réellement les essais en cours (le délai de 25 s de l'interface les laissait tourner).
- Interrupteur : `FAST_CONNECT_ENABLED = false` dans WifiDirectManager revient à la connexion classique seule.

## Sécurité (à connaître)
Le mot de passe du groupe est dérivé d'un identifiant que le téléphone annonce publiquement à proximité : toute personne proche qui utilise ZEE peut le recalculer. C'est cohérent avec la connexion automatique sans validation, mais le chiffrement Wi-Fi du groupe ne protège pas contre un voisin qui connaît ce calcul. Une clé échangée hors-bande (aujourd'hui impossible sans canal sûr) corrigerait cela.

## Limites
- Connexion rapide entre deux téléphones. Un troisième téléphone qui rejoint un groupe existant passe par la connexion classique (invitation à accepter sur le Group Owner).
- Non testé sur appareil : j'ai vérifié hors appareil la dérivation (mêmes valeurs des deux côtés, SSID de 21 octets, mot de passe de 32 caractères) et l'équilibre du code.

## À vérifier au prochain test (v136 sur les DEUX téléphones, Android 10+)
- Côté plus grand nodeId : `FASTCONNECT start role=GO`, puis `FASTCONNECT group-created`, puis `P2P_CONNECTED isGO=true`.
- Côté plus petit : `FASTCONNECT start role=JOIN`, éventuellement `join failure` pendant quelques secondes (le groupe se crée), puis `P2P_CONNECTED isGO=false`.
- En cas d'échec : `FASTCONNECT failed ... -> connexion classique`, puis les lignes `CONNECT ...` habituelles. Envoyer les deux journaux.

Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).
