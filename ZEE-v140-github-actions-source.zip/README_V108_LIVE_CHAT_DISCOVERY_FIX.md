# ZEE v108 — LIVE CHAT discovery fix

LIVE CHAT now behaves like BUSINESS and JOB for proximity discovery:
- discovered peers with status AVAILABLE or CONNECTED are displayed;
- CHAT visibility and the selected sex filter are respected;
- the real profile name, photo, tag and distance are displayed when announced;
- incompatible LIVE CHAT profiles remain visible but show a lock and cannot start an exchange;
- tapping a compatible AVAILABLE profile calls the existing connectToPeer() flow before opening ChatActivity;
- the nearby count and nearby dialog include AVAILABLE discovered peers, not only CONNECTED sessions.

No fake conversation history, preview text or timestamps are generated for a newly discovered user. Existing conversation history remains handled by the chat activity/store.
