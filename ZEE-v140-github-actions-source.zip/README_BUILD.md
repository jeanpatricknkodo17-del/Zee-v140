# ZEE — correctif compilation

Le journal fourni montre que l'échec n'est pas une erreur Kotlin dans `OnboardingProfileActivity.kt` : le compilateur tente de lire un `R.jar` généré par `processDebugResources`, puis ce fichier disparaît du classpath. Cela provoque l'`Internal compiler error`.

Correctifs appliqués :
- suppression de `kotlin.compiler.execution.strategy=in-process`;
- désactivation du cache Gradle global pour ce prototype;
- désactivation de l'incrémentalité Kotlin afin d'éviter un classpath R périmé;
- `android.nonTransitiveRClass=false` pour utiliser une R transitive et simplifier le classpath Kotlin/K2;
- aucun dossier `build/` ni `.gradle/` n'est inclus dans l'archive.

Après extraction, effectuer une fois `Clean Project` puis `Rebuild Project`. Si Android Studio conserve encore un ancien build, fermer Android Studio et supprimer le dossier `app/build` et le dossier `.gradle` du projet avant de relancer.
