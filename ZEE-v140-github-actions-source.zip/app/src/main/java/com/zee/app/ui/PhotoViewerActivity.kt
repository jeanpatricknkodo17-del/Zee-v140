package com.zee.app.ui

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.ImageView
import androidx.appcompat.app.AppCompatActivity

/**
 * Affiche en plein écran, sur fond noir, n'importe quelle photo de profil
 * de l'app (liste de pairs, en-tête de chat, écran de profil).
 * Se ferme au tap n'importe où sur l'image ou l'arrière-plan.
 */
class PhotoViewerActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_PHOTO_URI = "extra_photo_uri"

        /** photoRef peut être une Uri (content://, file://) ou une simple URL/chemin. */
        fun start(context: Context, photoRef: String) {
            context.startActivity(
                Intent(context, PhotoViewerActivity::class.java).apply {
                    putExtra(EXTRA_PHOTO_URI, photoRef)
                }
            )
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(com.zee.app.R.layout.activity_photo_viewer)
        applyZeeEdgeToEdge(topInsetView = null)

        val photoRef = intent.getStringExtra(EXTRA_PHOTO_URI)
        val imageView = findViewById<ImageView>(com.zee.app.R.id.imgFullPhoto)

        if (!photoRef.isNullOrEmpty()) {
            try {
                imageView.setImageURI(Uri.parse(photoRef))
            } catch (e: Exception) {
                // Référence non lisible (ex. URL distante non gérée ici) : on
                // laisse simplement l'image vide plutôt que de planter.
            }
        }

        findViewById<android.view.View>(com.zee.app.R.id.rootPhotoViewer).setOnClickListener { finish() }
    }

    /** Appelé par le bouton de fermeture (voir android:onClick dans le layout). */
    fun onCloseClicked(view: android.view.View) {
        finish()
    }
}
