package com.zee.app.adapter

import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.zee.app.R
import com.zee.app.model.ChatConversationStore

class ChatConversationAdapter(
    private var items: List<ChatConversationStore.Conversation>,
    private val onClick: (ChatConversationStore.Conversation) -> Unit
) : RecyclerView.Adapter<ChatConversationAdapter.Holder>() {

    fun submitList(newItems: List<ChatConversationStore.Conversation>) {
        items = newItems
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_chat_conversation, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(items[position])
    override fun getItemCount() = items.size

    inner class Holder(itemView: android.view.View) : RecyclerView.ViewHolder(itemView) {
        fun bind(item: ChatConversationStore.Conversation) {
            val avatar = itemView.findViewById<de.hdodenhof.circleimageview.CircleImageView>(R.id.chatAvatar)
            val name = itemView.findViewById<android.widget.TextView>(R.id.chatName)
            val preview = itemView.findViewById<android.widget.TextView>(R.id.chatPreview)
            val time = itemView.findViewById<android.widget.TextView>(R.id.chatTime)
            val unread = itemView.findViewById<android.widget.TextView>(R.id.chatUnread)

            name.text = item.name
            preview.text = item.preview
            time.text = ChatConversationStore.formatTime(item.timestamp)
            if (item.unread > 0) {
                unread.visibility = android.view.View.VISIBLE
                unread.text = if (item.unread > 99) "99+" else item.unread.toString()
            } else unread.visibility = android.view.View.GONE

            avatar.setImageResource(R.drawable.ic_default_avatar)
            item.photoBase64?.takeIf { it.isNotBlank() }?.let {
                runCatching {
                    val bytes = Base64.decode(it, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let(avatar::setImageBitmap)
                }
            }
            itemView.setOnClickListener { onClick(item) }
        }
    }
}
