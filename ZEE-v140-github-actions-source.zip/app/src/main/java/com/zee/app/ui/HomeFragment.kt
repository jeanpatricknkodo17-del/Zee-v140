package com.zee.app.ui

import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import com.zee.app.MainActivity
import com.zee.app.R
import com.zee.app.model.ProfileStore
import com.zee.app.model.VisibilityStore
import com.zee.app.model.ZeeModule
import de.hdodenhof.circleimageview.CircleImageView
import android.content.Intent
import android.provider.Settings

/**
 * Écran d'accueil : point d'entrée direct après le splash.
 * L'accueil conserve sa présentation et ses réglages existants.
 * « Votre nom » et « Vous êtes » sont édités exclusivement dans « Mon profil ».
 * Aucun écran d'onboarding séparé n'est utilisé.
 */
class HomeFragment : Fragment() {
    private var nearbyObserver: ((List<com.zee.app.model.Peer>) -> Unit)? = null
    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        inflater.inflate(R.layout.fragment_home, container, false)

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        // L'âge est maintenant contrôlé avant l'accès à l'application par MainActivity.
        // L'accueil ne contient plus de formulaire/validation d'âge ni de bouton
        // « Enregistrer mon profil ». Les données du profil sont autosauvegardées
        // directement depuis « Mon profil ».
        ThemeBackgrounds.apply(view, isHome = true)
        showMainContent(view)
    }

    override fun onResume() {
        super.onResume()
        view?.let { ThemeBackgrounds.apply(it, isHome = true) }
        // « Mon profil » est une Activity séparée : lorsque l'utilisateur revient
        // ici, relire immédiatement les données permet d'afficher sans redémarrer
        // l'application la photo et l'ACTU qui viennent d'être enregistrées.
        view?.let { showMainContent(it) }
    }

    fun refreshTheme() {
        view?.let { ThemeBackgrounds.apply(it, isHome = true) }
    }

    private fun showMainContent(view: View) {
        val ctx = requireContext()
        view.findViewById<View>(R.id.homeMainContent).visibility = View.VISIBLE

        view.findViewById<TextView>(R.id.homeGreeting).text =
            ProfileStore.getName(ctx).trim().ifBlank { getString(R.string.home_profile_label) }
        val avatar = view.findViewById<CircleImageView>(R.id.homeAvatar)
        avatar.setImageResource(R.drawable.ic_default_avatar)
        ProfileStore.getModulePhotoUri(ctx, ZeeModule.CHAT)?.takeIf { it.isNotBlank() }?.let { value ->
            try {
                val uri = Uri.parse(value)
                ctx.contentResolver.openInputStream(uri)?.use { }
                avatar.setImageURI(uri)
            } catch (_: Exception) {
                avatar.setImageResource(R.drawable.ic_default_avatar)
            }
        }

        // Sur l'accueil, le texte à côté de la photo est désormais l'ACTU
        // renseignée dans « Mon profil » (module RENCONTRES), et non plus
        // le statut Business « Vendeur/Acheteur ».
        view.findViewById<TextView>(R.id.homeRole).text =
            ProfileStore.getModuleActu(ctx, ZeeModule.CHAT)

        val visibleNames = mutableListOf<String>()
        if (VisibilityStore.isVisible(ctx, ZeeModule.MARKET)) visibleNames += "BUSINESS"
        if (VisibilityStore.isVisible(ctx, ZeeModule.JOB)) visibleNames += "JOB"
        if (VisibilityStore.isVisible(ctx, ZeeModule.CHAT)) visibleNames += "RENCONTRES"
        view.findViewById<TextView>(R.id.homeVisibilitySummary).text =
            if (visibleNames.isEmpty()) "Masqué sur tous les services"
            else "Visible sur ${visibleNames.joinToString(" et ")}"
        val visibilitySwitch = view.findViewById<Switch>(R.id.homeVisibilitySwitch)
        visibilitySwitch.isChecked = visibleNames.isNotEmpty()
        visibilitySwitch.setOnClickListener {
            val visible = visibilitySwitch.isChecked
            listOf(ZeeModule.MARKET, ZeeModule.JOB, ZeeModule.CHAT).forEach {
                VisibilityStore.setVisible(ctx, it, visible)
            }
            updateVisibilitySummary()
            (activity as? MainActivity)?.refreshPeers()
        }

        view.findViewById<View>(R.id.homeMenuProfile).setOnClickListener { openProfile() }
        view.findViewById<View>(R.id.homeMenuVisibility).setOnClickListener { showVisibilityDialog() }
        view.findViewById<View>(R.id.homeMenuServices).setOnClickListener { showServicesDialog() }
        view.findViewById<View>(R.id.homeMenuSettings).setOnClickListener { showSettingsDialog() }
        view.findViewById<View>(R.id.homeMenuHelp).setOnClickListener { showHelpDialog() }
        view.findViewById<View>(R.id.homeMenuAbout).setOnClickListener { showAboutDialog() }
    }

    private fun openProfile() {
        val ctx = requireContext()
        startActivity(Intent(ctx, ProfileActivity::class.java).apply {
            putExtra(ProfileActivity.EXTRA_MODULE, ZeeModule.CHAT.name)
        })
    }

    private fun showVisibilityDialog() {
        val ctx = requireContext()
        val box = LinearLayout(ctx).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(24, 8, 24, 0)
        }
        val switches = linkedMapOf(
            ZeeModule.MARKET to Switch(ctx).apply { text = "BUSINESS" },
            ZeeModule.JOB to Switch(ctx).apply { text = "JOB" },
            ZeeModule.CHAT to Switch(ctx).apply { text = "RENCONTRES" }
        )
        switches.forEach { (module, sw) ->
            sw.isChecked = VisibilityStore.isVisible(ctx, module)
            box.addView(sw)
        }
        AlertDialog.Builder(ctx)
            .setTitle(getString(com.zee.app.R.string.kt_visibilit))
            .setMessage(getString(com.zee.app.R.string.kt_choisissez_les_services_sur_lesquels_votre_pr))
            .setView(box)
            .setNegativeButton(getString(com.zee.app.R.string.kt_annuler), null)
            .setPositiveButton(getString(com.zee.app.R.string.kt_enregistrer)) { _, _ ->
                switches.forEach { (module, sw) -> VisibilityStore.setVisible(ctx, module, sw.isChecked) }
                updateVisibilitySummary()
                (activity as? MainActivity)?.refreshPeers()
            }
            .show()
    }

    private fun updateVisibilitySummary() {
        val ctx = requireContext()
        val names = mutableListOf<String>()
        if (VisibilityStore.isVisible(ctx, ZeeModule.MARKET)) names += "BUSINESS"
        if (VisibilityStore.isVisible(ctx, ZeeModule.JOB)) names += "JOB"
        if (VisibilityStore.isVisible(ctx, ZeeModule.CHAT)) names += "RENCONTRES"
        view?.findViewById<TextView>(R.id.homeVisibilitySummary)?.text =
            if (names.isEmpty()) "Masqué sur tous les services" else "Visible sur ${names.joinToString(" et ")}"
        view?.findViewById<Switch>(R.id.homeVisibilitySwitch)?.isChecked = names.isNotEmpty()
    }

    private fun showServicesDialog() {
        val ctx = requireContext()
        val labels = arrayOf("BUSINESS", "JOB", "RENCONTRES")
        val positions = intArrayOf(
            TabsPagerAdapter.BUSINESS_POSITION,
            TabsPagerAdapter.JOB_POSITION,
            TabsPagerAdapter.CHAT_POSITION
        )
        AlertDialog.Builder(ctx)
            .setTitle(getString(com.zee.app.R.string.kt_mes_services))
            .setItems(labels) { _, which ->
                (activity as? MainActivity)?.openTab(positions[which])
            }
            .setNegativeButton(getString(com.zee.app.R.string.kt_fermer), null)
            .show()
    }

    private fun showSettingsDialog() {
        val ctx = requireContext()
        AlertDialog.Builder(ctx)
            .setTitle(R.string.settings_title)
            .setItems(R.array.home_settings_items) { _, which ->
                when (which) {
                    0 -> ThemeBackgrounds.showPicker(requireActivity()) {
                        view?.let { ThemeBackgrounds.apply(it, isHome = true) }
                        (activity as? MainActivity)?.refreshPageThemes()
                    }
                    1 -> LanguageSettings.showPicker(ctx)
                    2 -> try {
                        startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, ctx.packageName)
                        })
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                    3 -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                }
            }
            .setNegativeButton(R.string.settings_close, null)
            .show()
    }

    private fun showHelpDialog() {
        val ctx = requireContext()
        AlertDialog.Builder(ctx)
            .setTitle(getString(com.zee.app.R.string.kt_aide_support))
            .setMessage(getString(com.zee.app.R.string.kt_help_support_message))
            .setNegativeButton(getString(com.zee.app.R.string.kt_fermer), null)
            .setPositiveButton(getString(com.zee.app.R.string.kt_contacter_le_support)) { _, _ ->
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/237653888264")))
                } catch (_: Exception) {
                    Toast.makeText(ctx, getString(com.zee.app.R.string.kt_impossible_d_ouvrir_whatsapp), Toast.LENGTH_SHORT).show()
                }
            }
            .show()
    }

    private fun showAboutDialog() {
        AlertDialog.Builder(requireContext())
            .setTitle(getString(com.zee.app.R.string.kt_propos_de_zee))
            .setMessage(getString(com.zee.app.R.string.about_message))
            .setPositiveButton("OK", null)
            .show()
    }

    override fun onDestroyView() {
        nearbyObserver?.let { (activity as? MainActivity)?.removeNearbyObserver(it) }
        nearbyObserver = null
        super.onDestroyView()
    }
}
