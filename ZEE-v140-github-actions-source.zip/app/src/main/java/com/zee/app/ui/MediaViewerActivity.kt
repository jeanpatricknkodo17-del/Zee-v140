package com.zee.app.ui

import android.content.ClipData
import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.net.Uri
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.zee.app.R
import java.io.File

/**
 * Visionneuse unique pour les médias/fichiers reçus.
 * L'Uri est locale et persistante dans files/zee_media/.
 */
class MediaViewerActivity : AppCompatActivity() {
    private var player: MediaPlayer? = null

    companion object {
        private const val EXTRA_URI = "uri"
        private const val EXTRA_MIME = "mime"

        fun start(context: Context, uri: String, mime: String? = null) {
            context.startActivity(Intent(context, MediaViewerActivity::class.java).apply {
                putExtra(EXTRA_URI, uri)
                putExtra(EXTRA_MIME, mime ?: "")
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_media_viewer)
        applyZeeEdgeToEdge(topInsetView = null)

        val rawUri = intent.getStringExtra(EXTRA_URI)?.let(Uri::parse) ?: run { finish(); return }
        val uri = if (rawUri.scheme == "file") {
            runCatching { FileProvider.getUriForFile(this, "$packageName.fileprovider", File(rawUri.path!!)) }.getOrDefault(rawUri)
        } else rawUri
        val mime = intent.getStringExtra(EXTRA_MIME).orEmpty().ifBlank {
            contentResolver.getType(uri).orEmpty()
        }

        val image = findViewById<ImageView>(R.id.mediaImage)
        val video = findViewById<VideoView>(R.id.mediaVideo)
        val audio = findViewById<View>(R.id.mediaAudio)
        val btnAudio = findViewById<View>(R.id.btnMediaAudio)
        val btnShare = findViewById<View>(R.id.btnMediaShare)
        val btnCopy = findViewById<View>(R.id.btnMediaCopy)

        when {
            mime.startsWith("image/") -> {
                image.visibility = View.VISIBLE
                image.setImageURI(uri)
            }
            mime.startsWith("video/") -> {
                video.visibility = View.VISIBLE
                video.setVideoURI(uri)
                video.setOnPreparedListener { it.isLooping = false; video.start() }
            }
            mime.startsWith("audio/") -> {
                audio.visibility = View.VISIBLE
                btnAudio.visibility = View.VISIBLE
                btnAudio.setOnClickListener {
                    player?.release()
                    player = MediaPlayer().apply {
                        setDataSource(this@MediaViewerActivity, uri)
                        prepare()
                        start()
                    }
                }
            }
            else -> {
                runCatching {
                    startActivity(Intent(Intent.ACTION_VIEW).apply {
                        setDataAndType(uri, mime.ifBlank { "*/*" })
                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    })
                }.onFailure {
                    android.widget.Toast.makeText(this, "Aucune application ne peut ouvrir ce fichier.", android.widget.Toast.LENGTH_SHORT).show()
                }
            }
        }

        btnShare.setOnClickListener {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = mime.ifBlank { "*/*" }
                putExtra(Intent.EXTRA_STREAM, uri)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }, "Partager"))
        }

        btnCopy.setOnClickListener {
            val clip = ClipData.newUri(contentResolver, "ZEE", uri)
            val clipboard = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            clipboard.setPrimaryClip(clip)
            android.widget.Toast.makeText(this, "Média copié.", android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    override fun onDestroy() {
        player?.release()
        player = null
        super.onDestroy()
    }
}
