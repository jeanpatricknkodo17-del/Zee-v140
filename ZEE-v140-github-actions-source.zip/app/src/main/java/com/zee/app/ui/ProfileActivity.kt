package com.zee.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.CountDownTimer
import android.provider.OpenableColumns
import android.provider.Settings
import android.view.View
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import com.zee.app.R
import com.zee.app.model.MyAdState
import com.zee.app.model.VisibilityStore
import com.zee.app.model.ZeeModule
import com.zee.app.network.AdCodeCategory
import com.zee.app.network.AdCodeCheckResult
import com.zee.app.network.AdCodeValidator
import java.io.File
import java.io.FileOutputStream

/**
 * Type de la pièce jointe actuellement sélectionnée pour la pub, utilisé
 * pour vérifier la compatibilité avec la catégorie du code saisi (voir
 * AdCodeValidator : codes 1-3 = texte/image/document, code 4 = audio,
 * code 5 = vidéo).
 */
private enum class AdAttachmentKind { IMAGE, AUDIO, VIDEO, DOCUMENT, OTHER }

/**
 * Écran de configuration du profil local, partagé par les 3 modules
 * (les libellés de statut deviennent "Vendeur/Acheteur" pour BUSINESS
 * et "Cherche emploi/Recrute" pour JOB ; SEXE/RENCONTRER reste réservé
 * à RENCONTRES).
 * d'origine, transmis via EXTRA_MODULE).
 *
 * Le code pub est disponible pour les trois modules et les deux statuts de
 * BUSINESS/JOB. Chaque onglet possède son propre état publicitaire.
 *
 * Les données saisies ici (nom, ACTU, photo, critères) constituent le
 * "ProfilePayload" diffusé aux pairs à la connexion Wi-Fi Direct, pour que
 * chaque appareil affiche le profil de l'autre sans jamais passer par un
 * serveur distant.
 */
class ProfileActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_MODULE = "extra_module"
        const val EXTRA_OPEN_AD = "extra_open_ad"
    }

    private var adAttachmentUri: Uri? = null
    private var adAttachmentKind: AdAttachmentKind? = null
    private var adCountdownTimer: CountDownTimer? = null

    private val pickAdAttachment = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            adAttachmentUri = uri
            findViewById<android.widget.TextView>(R.id.txtAdImageName).text = queryFileName(uri)
            // TODO: à l'activation du code pub, copier/encoder ce média dans
            // AdPayload.imageBase64 (ou un champ dédié selon le type) et
            // programmer son expiration à +24h (voir MyAdState.activate).
        }
    }

    // Photo de profil : sélection depuis la galerie.
    //
    // CORRECTIF : conserver directement l'Uri externe rendu par le
    // sélecteur (même avec OpenDocument()+takePersistableUriPermission)
    // ne suffit pas sur tous les fournisseurs de galerie/fichiers — certains
    // ne supportent pas réellement l'octroi persistant, et
    // takePersistableUriPermission échoue alors silencieusement (le
    // SecurityException était juste ignoré ci-dessous). La lecture
    // redevenait alors impossible dès que le provider expirait sa
    // permission temporaire — parfois en quelques secondes, ce qui donnait
    // l'impression que la photo « disparaissait dès qu'on quitte l'onglet ».
    // On copie donc immédiatement les octets dans le stockage propre à
    // l'app (voir persistProfilePhotoLocally) : ce fichier nous appartient
    // et ne dépend plus jamais d'une permission externe.
    private var currentProfilePhotoUri: Uri? = null
    private val pickProfilePhoto = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            val localUri = persistProfilePhotoLocally(photoSaveModule) { out ->
                contentResolver.openInputStream(uri)?.use { it.copyTo(out) }
                    ?: throw java.io.IOException("Lecture de la photo sélectionnée impossible")
            }
            if (localUri != null) {
                currentProfilePhotoUri = localUri
                findViewById<de.hdodenhof.circleimageview.CircleImageView>(R.id.imgProfilePhoto).setImageURI(localUri)
                com.zee.app.model.ProfileStore.setModulePhotoUri(this, photoSaveModule, localUri.toString())
            } else {
                Toast.makeText(this, getString(com.zee.app.R.string.kt_impossible_d_enregistrer_cette_photo), Toast.LENGTH_SHORT).show()
            }
        }
    }

    // Photo de profil : prise directe avec l'appareil photo. Le fichier de
    // capture (dans le cache, voir takeProfilePhoto ci-dessous) nous
    // appartient déjà, mais on le copie quand même dans le même stockage
    // durable (filesDir) que la photo de galerie, par cohérence et parce
    // que le cache peut être vidé par le système sous pression de stockage.
    private var pendingProfilePhotoUri: Uri? = null
    private val takeProfilePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success && pendingProfilePhotoUri != null) {
            val captured = pendingProfilePhotoUri!!
            val localUri = persistProfilePhotoLocally(photoSaveModule) { out ->
                contentResolver.openInputStream(captured)?.use { it.copyTo(out) }
                    ?: throw java.io.IOException("Lecture de la photo capturée impossible")
            }
            if (localUri != null) {
                currentProfilePhotoUri = localUri
                findViewById<de.hdodenhof.circleimageview.CircleImageView>(R.id.imgProfilePhoto).setImageURI(localUri)
                com.zee.app.model.ProfileStore.setModulePhotoUri(this, photoSaveModule, localUri.toString())
            } else {
                Toast.makeText(this, getString(com.zee.app.R.string.kt_impossible_d_enregistrer_cette_photo), Toast.LENGTH_SHORT).show()
            }
        }
    }

    /**
     * Copie le contenu fourni dans un fichier propre à l'app
     * (filesDir/profile_photos/<MODULE>.jpg, un seul fichier par module —
     * la nouvelle photo remplace toujours l'ancienne), puis retourne un Uri
     * FileProvider stable vers ce fichier. Ce fichier nous appartient
     * entièrement : plus aucune dépendance à une permission de lecture
     * accordée par un fournisseur de galerie externe, donc plus de risque
     * qu'elle expire et fasse « disparaître » la photo.
     */
    private fun persistProfilePhotoLocally(module: ZeeModule, copyFrom: (java.io.OutputStream) -> Unit): Uri? {
        return try {
            val dir = File(filesDir, "profile_photos").apply { if (!exists()) mkdirs() }
            val dest = File(dir, "${module.name}.jpg")
            FileOutputStream(dest).use { out -> copyFrom(out) }
            FileProvider.getUriForFile(this, "$packageName.fileprovider", dest)
        } catch (e: Exception) {
            null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_profile)

        findViewById<android.widget.ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<android.widget.ImageButton>(R.id.btnChangePhoto).setOnClickListener { showProfilePhotoPicker() }
        findViewById<de.hdodenhof.circleimageview.CircleImageView>(R.id.imgProfilePhoto).setOnClickListener {
            currentProfilePhotoUri?.let { uri -> PhotoViewerActivity.start(this, uri.toString()) }
        }

        val module = ZeeModule.valueOf(intent.getStringExtra(EXTRA_MODULE) ?: ZeeModule.CHAT.name)
        val openAdRequested = intent.getBooleanExtra(EXTRA_OPEN_AD, false)
        MyAdState.clearIfExpired(this, module)
        applyModuleLabels(module, openAdRequested)
        setupVisibilitySwitch(module)
        setupWhatsAppLink()
        setupEditIconShortcuts()
        loadModuleProfile(module)
        setupModuleProfileAutosave(module)

        applyZeeEdgeToEdge(
            topInsetView = findViewById(R.id.profileHeader),
            bottomInsetView = findViewById(R.id.profileScroll)
        )

        if (openAdRequested) {
            findViewById<View>(R.id.sectionAdCode).post {
                findViewById<android.widget.ScrollView>(R.id.profileScroll)
                    .smoothScrollTo(0, findViewById<View>(R.id.sectionAdCode).top)
            }
        }
    }

    /**
     * Charge les informations propres à CE module (ACTU, statut/critère, photo).
     * SEXE/RENCONTRER n'est présenté que dans RENCONTRES. — indépendantes des deux autres onglets.
     * Le nom reste partagé (même personne partout).
     */
    private fun loadModuleProfile(module: ZeeModule) {
        val profile = com.zee.app.model.ProfileStore

        findViewById<android.widget.EditText>(R.id.editName).setText(profile.getName(this))
        findViewById<android.widget.EditText>(R.id.editActu).setText(profile.getModuleActu(this, module))

        // BUSINESS/JOB utilisent ce groupe pour leur statut.
        // RENCONTRES n'a plus de sélection RENCONTRER ici : le choix se fait
        // exclusivement via les trois filtres placés au-dessus de RENCONTRES.
        if (module != ZeeModule.CHAT) {
            val radioGroup = findViewById<RadioGroup>(R.id.radioGroupMeet)
            val radioA = findViewById<RadioButton>(R.id.radioHommes)
            val radioB = findViewById<RadioButton>(R.id.radioFemmes)
            if (profile.getModuleMeetChoice(this, module)) radioB.isChecked = true else radioA.isChecked = true
        }

        // SEXE est une donnée globale du profil (et non une donnée propre à
        // BUSINESS/JOB). On la recharge uniquement dans RENCONTRES afin que
        // le choix reste réellement mémorisé entre deux ouvertures.
        if (module == ZeeModule.CHAT) {
            val savedSex = profile.getSexe(this).trim()
            val sexHomme = findViewById<RadioButton>(R.id.radioSexeHomme)
            val sexFemme = findViewById<RadioButton>(R.id.radioSexeFemme)
            when {
                savedSex.equals("Femme", ignoreCase = true) || savedSex.equals("Femmes", ignoreCase = true) -> {
                    sexFemme.isChecked = true
                    sexHomme.isChecked = false
                }
                savedSex.equals("Homme", ignoreCase = true) || savedSex.equals("Hommes", ignoreCase = true) -> {
                    sexHomme.isChecked = true
                    sexFemme.isChecked = false
                }
            }
        }

        // Photo STRICTEMENT propre à l'onglet courant.
        // RENCONTRES, BUSINESS et JOB possèdent chacun leur propre slot.
        // Une ancienne photo globale n'est utilisée qu'une seule fois pour
        // initialiser un slot qui n'existait pas encore (migration).
        profile.getModulePhotoUri(this, module)?.let { uriString ->
            try {
                val uri = Uri.parse(uriString)
                // Vérifie que la photo est réellement lisible AVANT de la
                // confier à CircleImageView : cette bibliothèque peut
                // différer la lecture réelle jusqu'à l'affichage (onDraw),
                // hors de portée d'un try/catch classique — une permission
                // expirée y provoquait donc un plantage non rattrapé.
                contentResolver.openInputStream(uri)?.close()
                currentProfilePhotoUri = uri
                findViewById<de.hdodenhof.circleimageview.CircleImageView>(R.id.imgProfilePhoto).setImageURI(uri)
            } catch (e: Exception) {
                // Uri invalide, cache vidé, ou permission de lecture expirée
                // (ancienne photo de galerie choisie avant ce correctif) :
                // on garde simplement la photo par défaut, sans planter.
            }
        }
    }

    /**
     * Sauvegarde en direct, à chaque modification, TOUJOURS pour CE module
     * précis — jamais les deux autres, qui gardent leurs propres valeurs
     * indépendamment (voir ProfileStore.setModule*).
     */
    private fun setupModuleProfileAutosave(module: ZeeModule) {
        val profile = com.zee.app.model.ProfileStore

        findViewById<android.widget.EditText>(R.id.editName).addTextChangedListener(
            simpleWatcher { text -> profile.setName(this, text) }
        )
        findViewById<android.widget.EditText>(R.id.editActu).addTextChangedListener(
            simpleWatcher { text -> profile.setModuleActu(this, module, text) }
        )

        // Le groupe ci-dessous sert uniquement de STATUT pour BUSINESS/JOB.
        // RENCONTRES n'a plus de RENCONTRER dans cet écran : son choix est
        // piloté par les filtres Tous/Hommes/Femmes de l'onglet Rencontres.
        if (module != ZeeModule.CHAT) {
            findViewById<RadioGroup>(R.id.radioGroupMeet).setOnCheckedChangeListener { _, checkedId ->
                profile.setModuleMeetChoice(this, module, checkedId == R.id.radioFemmes)
            }
        }

        // Le sexe n'est pas un réglage BUSINESS/JOB : il reste uniquement
        // dans RENCONTRES et est sauvegardé immédiatement. Il ne peut donc
        // plus revenir à sa valeur par défaut à la réouverture de l'écran.
        if (module == ZeeModule.CHAT) {
            findViewById<RadioGroup>(R.id.radioGroupSexe).setOnCheckedChangeListener { _, checkedId ->
                when (checkedId) {
                    R.id.radioSexeHomme -> profile.setSexe(this, "Homme")
                    R.id.radioSexeFemme -> profile.setSexe(this, "Femme")
                }
            }
        }

        // La photo est sauvegardée dès qu'elle change (voir pickProfilePhoto
        // / takeProfilePhoto ci-dessus) — appliqué juste après leur callback.
        // Sauvegardée uniquement dans le slot du module courant : aucune
        // modification de photo ne doit contaminer les autres onglets.
        photoSaveModule = module
    }

    /** Retenu pour que les callbacks de sélection de photo sachent pour quel module sauvegarder. */
    private var photoSaveModule: ZeeModule = ZeeModule.CHAT

    private fun simpleWatcher(onChanged: (String) -> Unit) = object : android.text.TextWatcher {
        override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
        override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
        override fun afterTextChanged(s: android.text.Editable?) { onChanged(s?.toString() ?: "") }
    }

    /**
     * Nom et ACTU sont déjà éditables directement au tap (comportement
     * natif d'un EditText). Ces icônes crayon offrent en plus un raccourci
     * visible (fidèle à la maquette d'origine) qui donne le focus au champ
     * et ouvre le clavier.
     */
    /**
     * Achat du code pub : un seul canal, WhatsApp, en un clic
     * (https://wa.me/237653888264 ouvre directement une conversation
     * WhatsApp avec ce numéro — aucun site web séparé).
     */
    private fun setupWhatsAppLink() {
        findViewById<android.widget.Button>(R.id.txtServiceClientLink).setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/237653888264")))
            } catch (e: Exception) {
                Toast.makeText(this, getString(com.zee.app.R.string.kt_impossible_d_ouvrir_whatsapp), Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setupEditIconShortcuts() {
        fun wire(buttonId: Int, fieldId: Int) {
            findViewById<android.widget.ImageButton>(buttonId).setOnClickListener {
                val field = findViewById<android.widget.EditText>(fieldId)
                field.requestFocus()
                field.setSelection(field.text.length)
                val imm = getSystemService(android.content.Context.INPUT_METHOD_SERVICE) as android.view.inputmethod.InputMethodManager
                imm.showSoftInput(field, android.view.inputmethod.InputMethodManager.SHOW_IMPLICIT)
            }
        }
        wire(R.id.btnEditName, R.id.editName)
        wire(R.id.btnEditActu, R.id.editActu)
    }

    /**
     * "Visible à proximité" / "Masqué" : contrôle si notre appareil annonce
     * son propre service Wi-Fi Direct aux autres utilisateurs ZEE, pour LE
     * MODULE ACTUEL uniquement (voir VisibilityStore +
     * WifiDirectManager.startDiscovery). Se masquer sur un onglet ne nous
     * empêche jamais de voir les autres, seulement d'être vu par eux sur
     * cet onglet précis — les deux autres modules restent inchangés.
     */
    private fun setupVisibilitySwitch(module: ZeeModule) {
        val switchVisible = findViewById<android.widget.Switch>(R.id.switchVisible)
        switchVisible.isChecked = VisibilityStore.isVisible(this, module)
        switchVisible.setOnCheckedChangeListener { _, isChecked ->
            // N'affecte QUE ce module précis : se masquer sur JOB par
            // exemple n'a aucun effet sur la visibilité en BUSINESS ou
            // RENCONTRES, qui restent réglées indépendamment.
            VisibilityStore.setVisible(this, module, isChecked)
            // L'effet réel (annoncer ou non le service ZEE pour ce module)
            // est appliqué au prochain wifiDirectManager.startDiscovery(),
            // relancé automatiquement quand MainActivity repasse au premier
            // plan (voir MainActivity.onResume).
        }
    }

    private fun queryFileName(uri: Uri): String {        var name = "Fichier sélectionné"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }

    private fun applyModuleLabels(module: ZeeModule, openAdRequested: Boolean = false) {
        val radioGroup = findViewById<RadioGroup>(R.id.radioGroupMeet)
        val radioA = findViewById<RadioButton>(R.id.radioHommes)
        val radioB = findViewById<RadioButton>(R.id.radioFemmes)
        val sectionAdCode = findViewById<View>(R.id.sectionAdCode)

        val txtMeetLabel = findViewById<android.widget.TextView>(R.id.txtMeetLabel)
        val sexLabel = findViewById<View>(R.id.txtSexeLabel)
        val sexGroup = findViewById<View>(R.id.radioGroupSexe)
        val sexDivider = findViewById<View>(R.id.sexSectionDivider)
        val showSex = module == ZeeModule.CHAT
        sexLabel.visibility = if (showSex) View.VISIBLE else View.GONE
        sexGroup.visibility = if (showSex) View.VISIBLE else View.GONE
        sexDivider.visibility = if (showSex) View.VISIBLE else View.GONE

        // RENCONTRER a été déplacé dans RENCONTRES : les trois filtres
        // Tous/Hommes/Femmes sont désormais l'unique interface de sélection.
        val showModuleStatus = module != ZeeModule.CHAT
        txtMeetLabel.visibility = if (showModuleStatus) View.VISIBLE else View.GONE
        radioGroup.visibility = if (showModuleStatus) View.VISIBLE else View.GONE

        when (module) {
            ZeeModule.MARKET -> { radioA.text = getString(com.zee.app.R.string.kt_vendeur); radioB.text = getString(com.zee.app.R.string.kt_acheteur); radioB.isChecked = false; radioA.isChecked = true; txtMeetLabel.text = getString(com.zee.app.R.string.kt_statut) }
            ZeeModule.JOB -> { radioA.text = getString(com.zee.app.R.string.kt_cherche_emploi); radioB.text = getString(com.zee.app.R.string.kt_recrute); radioB.isChecked = true; radioA.isChecked = false; txtMeetLabel.text = getString(com.zee.app.R.string.kt_statut) }
            ZeeModule.CHAT -> { /* aucune sélection RENCONTRER dans le profil */ }
        }

        // Tous les modules et tous les profils sont éligibles à la diffusion publicitaire :
        // BUSINESS (Vendeur ou Acheteur), JOB (Chercheur d'emploi ou Recruteur)
        // et RENCONTRES (tout utilisateur).
        fun isAdEligible(): Boolean = true

        fun updateAdSectionVisibility() {
            // La section Publicité est toujours disponible dans le module courant.
            // L'activation reste contrôlée uniquement par les validations du formulaire
            // et par le code publicitaire valide.
            sectionAdCode.visibility = View.VISIBLE
        }
        updateAdSectionVisibility()
        radioGroup.setOnCheckedChangeListener { _, _ -> updateAdSectionVisibility() }

        findViewById<android.widget.ImageButton>(R.id.btnAttachAdImage).setOnClickListener {
            showAdAttachmentPicker()
        }

        setupCodeVisibilityToggle()

        findViewById<android.widget.Button?>(R.id.btnActivateAd)?.setOnClickListener {
            val code = findViewById<android.widget.EditText>(R.id.editAdCode).text.toString().trim()
            val adText = findViewById<android.widget.EditText>(R.id.editAdText).text.toString().trim()

            if (code.length != 6 || code.toIntOrNull() == null) {
                Toast.makeText(this, getString(com.zee.app.R.string.kt_entrez_un_code_6_chiffres), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            if (adText.isEmpty() && adAttachmentUri == null) {
                Toast.makeText(this, getString(com.zee.app.R.string.kt_ajoutez_un_texte_ou_une_pi_ce_jointe_publier), Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val validator = AdCodeValidator(this)
            when (val result = validator.check(code)) {
                is AdCodeCheckResult.Valid -> {
                    // Le code correspond bien à un code du jour ET n'a encore
                    // jamais été utilisé. Reste à vérifier que le contenu
                    // (texte/image/document, audio, ou vidéo) correspond bien
                    // à la catégorie autorisée par ce code précis.
                    if (!contentMatchesCategory(result.category, adText)) {
                        Toast.makeText(this, categoryMismatchMessage(result.category), Toast.LENGTH_LONG).show()
                        return@setOnClickListener
                    }

                    // Une publicité encore active ne doit jamais être écrasée
                    // silencieusement : le nouveau code ne sera consommé qu'après
                    // confirmation explicite de l'utilisateur.
                    val continueActivation = {
                        // Persiste d'abord la publicité. Le code n'est consommé
                        // qu'après une activation locale réussie : une erreur
                        // d'écriture ne brûle donc pas inutilement le code.
                        val payload = MyAdState.activate(this, module, adText, adAttachmentUri, code)
                        if (payload == null || !MyAdState.isActive(this, module)) {
                            Toast.makeText(this, getString(com.zee.app.R.string.kt_impossible_d_activer_cette_publicit), Toast.LENGTH_LONG).show()
                        } else {
                            validator.markUsed(code)
                            showAdActivated(MyAdState.getExpiresAt(this, module)!! - System.currentTimeMillis())
                        }
                    }

                    if (MyAdState.isActive(this, module)) {
                        val remaining = MyAdState.getExpiresAt(this, module)?.minus(System.currentTimeMillis()) ?: 0L
                        val hours = (remaining / 3_600_000L).coerceAtLeast(0)
                        AlertDialog.Builder(this)
                            .setTitle(getString(com.zee.app.R.string.kt_publicit_d_j_active))
                            .setMessage(getString(com.zee.app.R.string.active_ad_replace_message, hours))
                            .setNegativeButton(getString(com.zee.app.R.string.kt_annuler), null)
                            .setPositiveButton(getString(com.zee.app.R.string.kt_remplacer)) { _, _ -> continueActivation() }
                            .show()
                    } else {
                        continueActivation()
                    }
                }
                AdCodeCheckResult.AlreadyUsed -> {
                    Toast.makeText(
                        this,
                        "Ce code a déjà été utilisé pour une publicité sur cet appareil.",
                        Toast.LENGTH_LONG
                    ).show()
                }
                AdCodeCheckResult.NoCodeForToday, AdCodeCheckResult.InvalidCode -> {
                    // Message unifié : le code peut être faux, ou la date du
                    // téléphone peut être erronée (les deux produisent le
                    // même symptôme — aucune correspondance dans le fichier
                    // de codes du jour) — avec un raccourci unique vers le
                    // réglage automatique de la date/heure.
                    showCodeErrorDialog()
                }
            }
        }

        // Si une pub est déjà active (activée depuis un précédent passage
        // sur cet écran), on reprend directement l'affichage "activée" +
        // la minuterie à son temps restant réel, plutôt que de repartir de
        // 24:00 à chaque ouverture de l'écran.
        if (MyAdState.isActive(this, module)) {
            showAdActivated(MyAdState.getExpiresAt(this, module)!! - System.currentTimeMillis())
        }
    }

    /**
     * Vérifie que le contenu préparé (texte/pièce jointe) correspond bien à
     * la catégorie autorisée par le code saisi :
     *   - TEXT_IMAGE_DOCUMENT : texte seul, image, ou document — jamais
     *     audio/vidéo.
     *   - AUDIO : uniquement une pièce jointe audio.
     *   - VIDEO : uniquement une pièce jointe vidéo.
     */
    private fun contentMatchesCategory(category: AdCodeCategory, text: String): Boolean {
        return when (category) {
            AdCodeCategory.TEXT_IMAGE_DOCUMENT ->
                adAttachmentKind == null || adAttachmentKind == AdAttachmentKind.IMAGE ||
                    adAttachmentKind == AdAttachmentKind.DOCUMENT
            AdCodeCategory.AUDIO ->
                text.isBlank() && adAttachmentKind == AdAttachmentKind.AUDIO
            AdCodeCategory.VIDEO ->
                text.isBlank() && adAttachmentKind == AdAttachmentKind.VIDEO
        }
    }

    private fun categoryMismatchMessage(category: AdCodeCategory): String = when (category) {
        AdCodeCategory.TEXT_IMAGE_DOCUMENT -> "Ce code n'autorise que la publicité de texte, image ou document."
        AdCodeCategory.AUDIO -> "Ce code n'autorise que la publicité d'un fichier audio."
        AdCodeCategory.VIDEO -> "Ce code n'autorise que la publicité d'un fichier vidéo."
    }

    /**
     * Message "Publicité activée" + minuterie visible sous le bouton,
     * comptant à rebours de 24:00 jusqu'à 00:00. À l'expiration, l'écran
     * repasse à l'état normal (nouveau code requis, champs réactivés).
     */
    private fun showAdActivated(remainingMs: Long) {
        val btn = findViewById<android.widget.Button>(R.id.btnActivateAd)
        val sectionCountdown = findViewById<View>(R.id.sectionAdCountdown)
        val txtCountdown = findViewById<android.widget.TextView>(R.id.txtAdCountdown)
        val editCode = findViewById<android.widget.EditText>(R.id.editAdCode)
        val editText = findViewById<android.widget.EditText>(R.id.editAdText)
        val btnAttach = findViewById<android.widget.ImageButton>(R.id.btnAttachAdImage)

        btn.text = getString(com.zee.app.R.string.kt_publicit_activ_e)
        btn.isEnabled = false
        editCode.isEnabled = false
        editText.isEnabled = false
        btnAttach.isEnabled = false
        sectionCountdown.visibility = View.VISIBLE

        adCountdownTimer?.cancel()
        adCountdownTimer = object : CountDownTimer(remainingMs.coerceAtLeast(0), 1000) {
            override fun onTick(msLeft: Long) {
                val totalMinutes = (msLeft + 59_999) / 60_000 // arrondi supérieur, comme "24:00" plein au départ
                val h = (totalMinutes / 60).coerceAtMost(24)
                val m = totalMinutes % 60
                txtCountdown.text = String.format("%02d:%02d", h, m)
            }

            override fun onFinish() {
                txtCountdown.text = "00:00"
                resetAdSection()
            }
        }.start()
    }

    /** Publicité expirée : réactive le formulaire pour une nouvelle saisie (nouveau code requis). */
    private fun resetAdSection() {
        val btn = findViewById<android.widget.Button>(R.id.btnActivateAd)
        val sectionCountdown = findViewById<View>(R.id.sectionAdCountdown)
        val editCode = findViewById<android.widget.EditText>(R.id.editAdCode)
        val editText = findViewById<android.widget.EditText>(R.id.editAdText)
        val btnAttach = findViewById<android.widget.ImageButton>(R.id.btnAttachAdImage)

        btn.text = getString(com.zee.app.R.string.kt_activer_ma_pub_24h)
        btn.isEnabled = true
        editCode.isEnabled = true
        editCode.text.clear()
        editText.isEnabled = true
        btnAttach.isEnabled = true
        sectionCountdown.visibility = View.GONE
        adAttachmentUri = null
        adAttachmentKind = null
        findViewById<android.widget.TextView>(R.id.txtAdImageName).text = getString(com.zee.app.R.string.kt_joindre_un_m_dia_image_audio_document)
    }

    /**
     * L'app déclare android.permission.CAMERA dans le manifeste, donc
     * Android exige qu'elle soit accordée à l'exécution AVANT de lancer
     * l'appareil photo — sans cette demande, l'app plante à l'ouverture
     * de la caméra sur de nombreux téléphones.
     */
    private val requestCameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            launchProfileCamera()
        } else {
            Toast.makeText(this, getString(com.zee.app.R.string.kt_autorisation_cam_ra_refus_e), Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchProfileCamera() {
        val photoFile = java.io.File(cacheDir, "zee_profile_${System.currentTimeMillis()}.jpg")
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", photoFile)
        pendingProfilePhotoUri = uri
        takeProfilePhoto.launch(uri)
    }

    /**
     * Icône caméra sur la photo de profil : propose de prendre une photo
     * directement ou d'en choisir une depuis la galerie.
     */
    private fun showProfilePhotoPicker() {
        AlertDialog.Builder(this)
            .setItems(arrayOf("Prendre une photo", "Choisir depuis la galerie")) { _, which ->
                if (which == 0) {
                    val alreadyGranted = androidx.core.content.ContextCompat.checkSelfPermission(
                        this, android.Manifest.permission.CAMERA
                    ) == android.content.pm.PackageManager.PERMISSION_GRANTED
                    if (alreadyGranted) {
                        launchProfileCamera()
                    } else {
                        requestCameraPermission.launch(android.Manifest.permission.CAMERA)
                    }
                } else {
                    pickProfilePhoto.launch(arrayOf("image/*"))
                }
            }
            .show()
    }

    /**
     * Menu de sélection de la pièce jointe à publier avec la pub : image,
     * audio, vidéo, document, ou tout autre fichier — chaque option ouvre
     * le sélecteur système Android filtré sur le bon type MIME, et
     * enregistre la catégorie choisie (utilisée ensuite pour vérifier la
     * compatibilité avec le code pub saisi).
     */
    private fun showAdAttachmentPicker() {
        val options = arrayOf("Image", "Audio", "Vidéo", "Document", "Autre fichier")
        AlertDialog.Builder(this)
            .setTitle(getString(com.zee.app.R.string.kt_joindre_un_m_dia))
            .setItems(options) { _, which ->
                val (mime, kind) = when (which) {
                    0 -> "image/*" to AdAttachmentKind.IMAGE
                    1 -> "audio/*" to AdAttachmentKind.AUDIO
                    2 -> "video/*" to AdAttachmentKind.VIDEO
                    3 -> "*/*" to AdAttachmentKind.DOCUMENT
                    else -> "*/*" to AdAttachmentKind.OTHER
                }
                adAttachmentKind = kind
                pickAdAttachment.launch(mime)
            }
            .show()
    }

    /**
     * Le code pub est masqué par des points au fur et à mesure de la saisie
     * (inputType numberPassword). Ce bouton bascule vers un affichage en
     * clair et inversement, comme un champ mot de passe classique.
     */
    private fun setupCodeVisibilityToggle() {
        val editCode = findViewById<android.widget.EditText>(R.id.editAdCode)
        val btnToggle = findViewById<android.widget.ImageButton>(R.id.btnToggleCodeVisibility)
        var visible = false

        btnToggle.setOnClickListener {
            visible = !visible
            val selectionStart = editCode.selectionStart
            val selectionEnd = editCode.selectionEnd
            editCode.inputType = if (visible) {
                android.text.InputType.TYPE_CLASS_NUMBER
            } else {
                android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD
            }
            btnToggle.setImageResource(
                if (visible) android.R.drawable.ic_menu_close_clear_cancel else android.R.drawable.ic_menu_view
            )
            // Remet le curseur à sa position (changer l'inputType déplace le curseur en fin de champ sinon)
            editCode.setSelection(selectionStart.coerceIn(0, editCode.text.length), selectionEnd.coerceIn(0, editCode.text.length))
        }
    }

    /**
     * Message unique : le code pub peut être faux, ou la date/heure du
     * téléphone peut être erronée — dans les deux cas la conséquence est la
     * même (aucune correspondance dans le fichier de codes du jour), donc on
     * ne cherche pas à deviner laquelle des deux causes est la bonne. Un
     * seul raccourci mène directement au réglage automatique de la date.
     */
    private fun showCodeErrorDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(com.zee.app.R.string.kt_code_pub_incorrect_ou_date_du_t_l_phone_erron))
            .setPositiveButton(getString(com.zee.app.R.string.kt_r_gler_automatiquement_la_date_heure)) { _, _ ->
                try {
                    startActivity(Intent(Settings.ACTION_DATE_SETTINGS))
                } catch (e: Exception) {
                    Toast.makeText(this, getString(com.zee.app.R.string.kt_ouvrez_manuellement_param_tres_syst_me_date_e), Toast.LENGTH_LONG).show()
                }
            }
            .setNegativeButton(getString(com.zee.app.R.string.kt_r_essayer), null)
            .show()
    }

    override fun onDestroy() {
        super.onDestroy()
        adCountdownTimer?.cancel()
    }
}
