package com.zee.app.network

import android.annotation.SuppressLint
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.net.wifi.p2p.WifiP2pInfo
import android.net.wifi.p2p.WifiP2pManager

/**
 * Écoute les diffusions système liées au Wi-Fi Direct et relaie les
 * changements pertinents à WifiDirectManager. Séparé dans sa propre
 * classe pour rester proche du modèle officiel Android (voir doc
 * WifiP2pManager) et faciliter la maintenance.
 *
 * Écoute aussi WIFI_P2P_PEERS_CHANGED_ACTION. Cette liste est la couche de
 * détection radio brute : elle confirme que le téléphone voit physiquement
 * des pairs Wi-Fi Direct. Elle ne suffit pas à déclarer un utilisateur ZEE ;
 * seuls les services DNS-SD ZEE restent admissibles aux profils.
 */
class WifiDirectBroadcastReceiver(
    private val manager: WifiP2pManager,
    private val channel: WifiP2pManager.Channel,
    private val onPeersAvailable: (List<android.net.wifi.p2p.WifiP2pDevice>) -> Unit,
    private val onConnectionChanged: (WifiP2pInfo) -> Unit,
    private val onStateChanged: (Boolean) -> Unit
) : BroadcastReceiver() {

    @SuppressLint("MissingPermission")
    override fun onReceive(context: Context, intent: Intent) {
        when (intent.action) {
            WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION -> {
                ZeeDiagnostic.log(context, "P2P_STATE action reçu")
                val state = intent.getIntExtra(WifiP2pManager.EXTRA_WIFI_STATE, -1)
                val enabled = state == WifiP2pManager.WIFI_P2P_STATE_ENABLED
                ZeeDiagnostic.log(context, "P2P radio état=$enabled (raw=$state)")
                onStateChanged(enabled)
            }

            WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION -> {
                ZeeDiagnostic.log(context, "P2P_CONNECTION_CHANGED reçu")
                manager.requestConnectionInfo(channel) { info ->
                    ZeeDiagnostic.log(context, "CONNECTION_INFO groupFormed=${info.groupFormed} isGO=${info.isGroupOwner} owner=${info.groupOwnerAddress?.hostAddress}")
                    onConnectionChanged(info)
                }
            }

            WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION -> {
                ZeeDiagnostic.log(context, "P2P_PEERS_CHANGED reçu; requestPeers()")
                manager.requestPeers(channel) { list ->
                    val peers = list.deviceList.toList()
                    fun statusName(status: Int) = when (status) {
                        android.net.wifi.p2p.WifiP2pDevice.CONNECTED -> "CONNECTED"
                        android.net.wifi.p2p.WifiP2pDevice.INVITED -> "INVITED"
                        android.net.wifi.p2p.WifiP2pDevice.FAILED -> "FAILED"
                        android.net.wifi.p2p.WifiP2pDevice.AVAILABLE -> "AVAILABLE"
                        android.net.wifi.p2p.WifiP2pDevice.UNAVAILABLE -> "UNAVAILABLE"
                        else -> "UNKNOWN($status)"
                    }
                    ZeeDiagnostic.log(context, "P2P_PEERS count=${peers.size} -> ${peers.joinToString { it.deviceName + ":" + statusName(it.status) }}")
                    onPeersAvailable(peers)
                }
            }

            WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION -> {
                ZeeDiagnostic.log(context, "P2P_THIS_DEVICE_CHANGED reçu")
                // L'utilisateur peut vouloir afficher son propre nom d'appareil ici
            }
        }
    }
}
