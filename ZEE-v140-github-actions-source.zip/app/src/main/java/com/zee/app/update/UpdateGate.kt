package com.zee.app.update

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import java.util.concurrent.TimeUnit

/**
 * Verrouille l'app et exige une mise à jour 30 jours après l'installation.
 *
 * On s'appuie sur PackageManager.firstInstallTime — une date fournie par le
 * système Android lui-même au moment de l'installation, donc plus fiable et
 * plus difficile à contourner qu'une date stockée par l'app (qui serait
 * effacée en cas de réinstallation, contrairement à ce que l'on veut ici).
 */
object UpdateGate {

    private const val LOCK_AFTER_DAYS = 30

    fun isUpdateRequired(context: Context): Boolean {
        val installedAt = firstInstallTime(context) ?: return false
        val daysSinceInstall = TimeUnit.MILLISECONDS.toDays(System.currentTimeMillis() - installedAt)
        return daysSinceInstall >= LOCK_AFTER_DAYS
    }

    private fun firstInstallTime(context: Context): Long? = try {
        context.packageManager.getPackageInfo(context.packageName, 0).firstInstallTime
    } catch (e: PackageManager.NameNotFoundException) {
        null
    }

    /** Ouvre la fiche Google Play de l'app ; retombe sur le navigateur si le Play Store n'est pas installé. */
    fun openPlayStore(context: Context) {
        val packageName = context.packageName
        try {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=$packageName")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
        } catch (e: android.content.ActivityNotFoundException) {
            context.startActivity(
                Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=$packageName")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
            )
        }
    }
}
