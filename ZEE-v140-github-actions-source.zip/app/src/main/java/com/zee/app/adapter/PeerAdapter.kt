package com.zee.app.adapter

import android.content.Context
import android.util.Base64
import android.view.LayoutInflater
import android.graphics.BitmapFactory
import android.view.View
import android.view.ViewGroup
import android.os.Handler
import android.os.Looper
import android.widget.Toast
import androidx.core.content.FileProvider
import androidx.recyclerview.widget.RecyclerView
import com.zee.app.R
import com.zee.app.model.Peer
import com.zee.app.model.ZeeModule
import de.hdodenhof.circleimageview.CircleImageView
import java.io.File
import java.io.FileOutputStream

class PeerAdapter(
    private var peers: List<Peer>,
    private val onPeerClick: (Peer) -> Unit,
    private val module: ZeeModule = ZeeModule.CHAT
) : RecyclerView.Adapter<PeerAdapter.PeerViewHolder>() {

    // RENCONTRES : les profils incompatibles restent visibles mais non
    // contactables. Un cadenas est affiché sur leur photo.
    private var restrictedPeers: Map<String, Boolean> = emptyMap()

    fun submitList(newPeers: List<Peer>) {
        peers = newPeers
        notifyDataSetChanged()
    }

    fun setRestrictedPeers(restricted: Map<String, Boolean>) {
        restrictedPeers = restricted
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): PeerViewHolder {
        val view = LayoutInflater.from(parent.context).inflate(R.layout.item_peer, parent, false)
        return PeerViewHolder(view)
    }

    override fun onBindViewHolder(holder: PeerViewHolder, position: Int) {
        holder.bind(peers[position], restrictedPeers[peers[position].nodeId ?: peers[position].deviceAddress] == true)
    }

    override fun getItemCount() = peers.size

    override fun onViewRecycled(holder: PeerViewHolder) {
        holder.recycle()
        super.onViewRecycled(holder)
    }

    inner class PeerViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val photo: CircleImageView = itemView.findViewById(R.id.imgPeerPhoto)
        private val name: android.widget.TextView = itemView.findViewById(R.id.txtPeerName)
        private val tag: android.widget.TextView = itemView.findViewById(R.id.txtPeerTag)
        private val role: android.widget.TextView = itemView.findViewById(R.id.txtPeerRole)
        private val status: android.widget.TextView = itemView.findViewById(R.id.txtPeerStatus)
        private val dist: android.widget.TextView = itemView.findViewById(R.id.txtPeerDistance)
        private val adBadge: android.widget.ImageView = itemView.findViewById(R.id.imgLock)
        private val unreadBadge: android.widget.TextView = itemView.findViewById(R.id.txtUnreadBadge)
        private val lockBadge: android.widget.ImageView = itemView.findViewById(R.id.imgProfileLockBadge)
        private val statusHandler = Handler(Looper.getMainLooper())
        private var dots = 0
        private val connectionAnimation = object : Runnable {
            override fun run() {
                if (status.tag == "connecting") {
                    status.text = "Connexion en cours" + ".".repeat(dots)
                    dots = (dots + 1) % 4
                    statusHandler.postDelayed(this, 450L)
                }
            }
        }

        fun bind(peer: Peer, restrictedSameSex: Boolean) {
            // Le nom ZEE et la photo de profil sont prioritaires sur le nom
            // système du téléphone. Le nom système reste seulement un secours
            // tant que le handshake PROFILE n'est pas encore reçu.
            val moduleName = peer.displayNamesByModule[module]?.takeIf { it.isNotBlank() }
                ?: peer.displayName?.takeIf { it.isNotBlank() }
            name.text = moduleName ?: peer.deviceName
            tag.text = peer.actusByModule[module] ?: peer.actu ?: ""
            dist.text = peer.distanceMeters?.let { "$it m" } ?: "--"

            val roleInfo = when (module) {
                ZeeModule.MARKET -> when (peer.criteriaByModule[ZeeModule.MARKET]) {
                    "A" -> "Vendeur"
                    "B" -> "Acheteur"
                    else -> ""
                }
                ZeeModule.JOB -> when (peer.criteriaByModule[ZeeModule.JOB]) {
                    "A" -> "Chercheur d'emploi"
                    "B" -> "Recruteur"
                    else -> ""
                }
                else -> ""
            }
            role.visibility = if (roleInfo.isBlank()) View.GONE else View.VISIBLE
            role.text = roleInfo
            role.setBackgroundResource(when (module) {
                ZeeModule.MARKET -> if (roleInfo == "Acheteur") R.drawable.bg_role_orange else R.drawable.bg_role_green
                ZeeModule.JOB -> R.drawable.bg_role_purple
                else -> R.drawable.bg_pill_muted
            })

            statusHandler.removeCallbacks(connectionAnimation)
            if (peer.status == com.zee.app.model.PeerStatus.CONNECTED) {
                status.tag = "connected"
                status.text = "● En ligne"
                status.setTextColor(itemView.context.getColor(R.color.zee_green))
            } else {
                status.tag = "connecting"
                status.setTextColor(itemView.context.getColor(R.color.zee_text_muted))
                dots = 0
                status.text = "Connexion en cours"
                statusHandler.post(connectionAnimation)
            }

            photo.setImageResource(R.drawable.bg_circle_cyan)
            val modulePhoto = peer.photosByModule[module] ?: peer.photoBase64
            modulePhoto?.takeIf { it.isNotBlank() }?.let { base64 ->
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { photo.setImageBitmap(it) }
                } catch (_: Exception) {
                    // Photo invalide : on conserve l'avatar par défaut.
                }
            }

            // "imgLock" est réutilisé comme badge "PUB" quand ce vendeur/recruteur
            // a un code pub actif — toutes les boutiques restent visibles pour
            // tout le monde, il n'y a plus de déblocage côté acheteur.
            adBadge.visibility = if (peer.adActive) View.VISIBLE else View.GONE
            adBadge.setImageResource(com.zee.app.R.drawable.ic_pub_white)

            // Pastille bleue des messages non lus : elle est positionnée à droite
            // de la ligne, comme dans la maquette. Le compteur est commun aux
            // trois modules : un message reçu d'un contact reste donc visible
            // comme non lu dans RENCONTRES, BUSINESS et JOB. L'ouverture de la
            // conversation remet ce compteur à 0 comme avant.
            if (peer.unreadCount > 0) {
                unreadBadge.visibility = View.VISIBLE
                unreadBadge.text = if (peer.unreadCount > 9) "9+" else peer.unreadCount.toString()
            } else {
                unreadBadge.visibility = View.GONE
            }

            // Petit cadenas au bas de la photo : profil visible mais non
            // contactable (voir en-tête de classe).
            lockBadge.visibility = if (restrictedSameSex) View.VISIBLE else View.GONE

            itemView.setOnClickListener { onPeerClick(peer) }

            // La photo s'agrandit en plein écran au tap, séparément du reste
            // de la ligne (qui ouvre le chat). TODO: peer.photoBase64 n'est
            // alimenté qu'une fois l'échange de profil via le handshake
            // Wi-Fi Direct implémenté (voir MainActivity/WifiDirectManager).
            photo.setOnClickListener {
                val base64 = peer.photosByModule[module] ?: peer.photoBase64
                if (base64.isNullOrEmpty()) {
                    Toast.makeText(it.context, it.context.getString(com.zee.app.R.string.kt_aucune_photo_disponible_pour_ce_profil), Toast.LENGTH_SHORT).show()
                    return@setOnClickListener
                }
                openPhotoFromBase64(it.context, base64)
            }
        }

        fun recycle() {
            statusHandler.removeCallbacks(connectionAnimation)
            status.tag = null
        }

        private fun openPhotoFromBase64(context: Context, base64: String) {
            try {
                val bytes = Base64.decode(base64, Base64.DEFAULT)
                val file = File(context.cacheDir, "zee_peer_photo_${System.currentTimeMillis()}.jpg")
                FileOutputStream(file).use { it.write(bytes) }
                val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                com.zee.app.ui.PhotoViewerActivity.start(context, uri.toString())
            } catch (e: Exception) {
                Toast.makeText(context, context.getString(com.zee.app.R.string.kt_impossible_d_afficher_cette_photo), Toast.LENGTH_SHORT).show()
            }
        }
    }
}
