package com.zee.app.model

import android.content.Context

/**
 * Mémorise si l'utilisateur souhaite être visible par les autres appareils
 * ZEE à proximité — INDÉPENDAMMENT PAR MODULE ("Visible à proximité" /
 * "Masqué" sur l'écran de profil, propre à chaque onglet RENCONTRES /
 * BUSINESS / JOB).
 *
 * Exemple : un utilisateur qui ne veut faire que du BUSINESS peut se
 * masquer sur RENCONTRES et JOB tout en restant visible sur BUSINESS —
 * les trois réglages sont totalement indépendants les uns des autres.
 *
 * Ce réglage contrôle uniquement si NOUS diffusons notre propre service
 * Wi-Fi Direct pour CE module (voir WifiDirectManager.startDiscovery()) —
 * pas si on peut voir les autres, qui reste toujours actif : se masquer,
 * c'est disparaître des listes des autres sur cet onglet précis, pas
 * s'aveugler soi-même.
 */
object VisibilityStore {
    private const val PREFS = "zee_visibility"

    private fun key(module: ZeeModule) = "is_visible_${module.name}"

    fun isVisible(context: Context, module: ZeeModule): Boolean =
        prefs(context).getBoolean(key(module), true)

    fun setVisible(context: Context, module: ZeeModule, visible: Boolean) {
        prefs(context).edit().putBoolean(key(module), visible).apply()
    }

    /** Modules sur lesquels l'utilisateur est actuellement visible, à inclure dans l'annonce du service Wi-Fi Direct. */
    fun getVisibleModules(context: Context): Set<ZeeModule> =
        ZeeModule.values().filter { isVisible(context, it) }.toSet()

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
