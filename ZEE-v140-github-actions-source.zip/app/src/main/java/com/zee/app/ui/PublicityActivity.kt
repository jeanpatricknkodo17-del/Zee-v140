package com.zee.app.ui

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.media.MediaPlayer
import android.net.Uri
import android.view.View
import com.zee.app.model.AdRelayStore
import androidx.appcompat.app.AppCompatActivity
import com.zee.app.R
import com.zee.app.model.AdPayload

/**
 * Écran plein écran affiché à TOUT utilisateur ZEE (quel que soit son
 * module actif — RENCONTRES, BUSINESS ou JOB) lorsqu'une pub à proximité
 * est reçue — que ce soit directement du diffuseur d'origine, ou relayée
 * par un autre appareil ZEE entre-temps devenu diffuseur à son tour (voir
 * AdRelay — propagation virale). Fermeture manuelle uniquement (bouton X).
 * Toujours affichée au plus une fois par pub (voir AdRelayStore.hasSeen).
 */
class PublicityActivity : AppCompatActivity() {

    companion object {
        private const val EXTRA_SELLER = "extra_seller"
        private const val EXTRA_HEADLINE = "extra_headline"
        private const val EXTRA_SUB = "extra_sub"
        private const val EXTRA_AD_ID = "extra_ad_id"

        fun start(context: Context, ad: AdPayload) {
            val intent = Intent(context, PublicityActivity::class.java).apply {
                putExtra(EXTRA_SELLER, ad.sellerName)
                putExtra(EXTRA_HEADLINE, ad.headline)
                putExtra(EXTRA_SUB, ad.subtext)
                putExtra(EXTRA_AD_ID, ad.id)
            }
            context.startActivity(intent)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_publicity)

        findViewById<android.widget.TextView>(R.id.txtAdSeller).text =
            intent.getStringExtra(EXTRA_SELLER)?.uppercase() ?: ""
        findViewById<android.widget.TextView>(R.id.txtAdHeadline).text =
            intent.getStringExtra(EXTRA_HEADLINE) ?: ""
        findViewById<android.widget.TextView>(R.id.txtAdSub).text =
            intent.getStringExtra(EXTRA_SUB) ?: ""

        findViewById<android.widget.ImageButton>(R.id.btnCloseAd).setOnClickListener { finish() }

        val adId = intent.getStringExtra(EXTRA_AD_ID)
        if (!adId.isNullOrBlank()) {
            AdRelayStore.get(this, adId)?.let { ad ->
                val path = ad.mediaPath
                val mime = ad.mediaMimeType.orEmpty()
                if (!path.isNullOrBlank()) {
                    val file = java.io.File(path)
                    if (file.isFile) {
                        val container = findViewById<View>(R.id.adMediaContainer)
                        val image = findViewById<android.widget.ImageView>(R.id.adImage)
                        val video = findViewById<android.widget.VideoView>(R.id.adVideo)
                        val audio = findViewById<android.widget.Button>(R.id.btnAdAudio)
                        container.visibility = View.VISIBLE
                        when {
                            mime.startsWith("image/") -> {
                                image.visibility = View.VISIBLE
                                image.setImageURI(Uri.fromFile(file))
                            }
                            mime.startsWith("video/") -> {
                                video.visibility = View.VISIBLE
                                video.setVideoURI(Uri.fromFile(file))
                                video.setMediaController(android.widget.MediaController(this))
                                video.start()
                            }
                            mime.startsWith("audio/") -> {
                                audio.visibility = View.VISIBLE
                                audio.setOnClickListener {
                                    val player = MediaPlayer()
                                    try {
                                        player.setDataSource(file.absolutePath)
                                        player.setOnCompletionListener { it.release() }
                                        player.prepare()
                                        player.start()
                                    } catch (_: Exception) {
                                        player.release()
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        applyZeeEdgeToEdge(topInsetView = findViewById(R.id.adTopRow), bottomInsetView = findViewById(R.id.adFooterText))
    }
}
