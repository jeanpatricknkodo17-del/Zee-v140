package com.zee.app.network

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.aware.AttachCallback
import android.net.wifi.aware.DiscoverySession
import android.net.wifi.aware.DiscoverySessionCallback
import android.net.wifi.aware.PublishDiscoverySession
import android.net.wifi.aware.SubscribeDiscoverySession
import android.net.wifi.aware.PeerHandle
import android.net.wifi.aware.PublishConfig
import android.net.wifi.aware.SubscribeConfig
import android.net.wifi.aware.WifiAwareManager
import android.net.wifi.aware.WifiAwareNetworkInfo
import android.net.wifi.aware.WifiAwareNetworkSpecifier
import android.net.wifi.aware.WifiAwareSession
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.util.Log
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.net.Inet6Address
import java.net.ServerSocket
import java.net.Socket
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap
import com.zee.app.model.ProfileStore
import com.zee.app.model.VisibilityStore
import com.zee.app.model.ZeeModule

/**
 * Transport Wi-Fi Aware pour ZEE Mesh.
 *
 * Wi-Fi Aware (NAN) permet de découvrir les téléphones ZEE sans point d'accès,
 * puis d'établir un data-path IPv6 direct. Le protocole ZEE reste au-dessus :
 * ZeeSocketSession, ACK, TTL et store-and-forward ne changent pas.
 *
 * La classe est volontairement un transport optionnel : si le matériel Aware
 * n'est pas disponible, ZEE continue à fonctionner avec Wi-Fi Direct.
 */
class WifiAwareMeshManager(
    private val context: Context,
    private val scope: CoroutineScope,
    private val localNodeIdProvider: () -> String,
    private val onSessionReady: (nodeId: String, session: ZeeSocketSession) -> Unit,
    private val onLine: (session: ZeeSocketSession, line: String) -> Unit,
    private val onPeerSeen: (nodeId: String, visibleModules: Set<ZeeModule>, criteria: Map<ZeeModule, String>) -> Unit = { _, _, _ -> },
    private val onError: (Throwable) -> Unit = {}
) {
    companion object {
        private const val TAG = "WifiAwareMesh"
        private const val SERVICE_NAME = "zee-mesh-v2"
        private const val HELLO = "ZEE_HELLO|"
        private const val PORT = "ZEE_PORT|"
    }

    private val awareManager: WifiAwareManager? =
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
            context.getSystemService(Context.WIFI_AWARE_SERVICE) as? WifiAwareManager
        else null
    private val connectivity = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private val handler = Handler(Looper.getMainLooper())

    private var awareSession: WifiAwareSession? = null
    private var publish: DiscoverySession? = null
    private var subscribe: DiscoverySession? = null
    private var running = false

    private val peerHandles = ConcurrentHashMap<String, PeerHandle>()
    private val callbacks = ConcurrentHashMap<String, ConnectivityManager.NetworkCallback>()
    private val sockets = ConcurrentHashMap<String, Socket>()

    fun isSupported(): Boolean =
        Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q && awareManager?.isAvailable == true

    fun start() {
        if (running || Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) return
        if (!isSupported()) return
        if (!hasPermission()) {
            onError(SecurityException("Permission Wi-Fi Aware manquante"))
            return
        }
        running = true
        try {
            awareManager?.attach(object : AttachCallback() {
                override fun onAttached(session: WifiAwareSession) {
                    if (!running) {
                        session.close()
                        return
                    }
                    awareSession = session
                    startPublish(session)
                    startSubscribe(session)
                }

                override fun onAttachFailed() {
                    running = false
                    onError(IllegalStateException("Impossible d'attacher Wi-Fi Aware"))
                }
            }, handler)
        } catch (e: Exception) {
            running = false
            onError(e)
        }
    }

    fun stop() {
        running = false
        callbacks.values.forEach { runCatching { connectivity.unregisterNetworkCallback(it) } }
        callbacks.clear()
        sockets.values.forEach { runCatching { it.close() } }
        sockets.clear()
        publish?.close()
        subscribe?.close()
        publish = null
        subscribe = null
        awareSession?.close()
        awareSession = null
        peerHandles.clear()
    }

    private fun hasPermission(): Boolean {
        val permission = if (Build.VERSION.SDK_INT >= 33)
            Manifest.permission.NEARBY_WIFI_DEVICES
        else
            Manifest.permission.ACCESS_FINE_LOCATION
        return ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED
    }

    private fun startPublish(session: WifiAwareSession) {
        val node = localNodeIdProvider()
        try {
            val visibleModules = VisibilityStore.getVisibleModules(context)
            val criteria = visibleModules.joinToString(",") { module ->
                val value = when (module) {
                    ZeeModule.CHAT -> ProfileStore.getLiveChatCriteria(context)
                    ZeeModule.MARKET, ZeeModule.JOB ->
                        if (ProfileStore.getModuleMeetChoice(context, module)) "B" else "A"
                }
                "${module.name}:$value"
            }
            val serviceInfo = listOf(node, visibleModules.joinToString(",") { it.name }, criteria)
                .joinToString("\n")
            val config = PublishConfig.Builder()
                .setServiceName(SERVICE_NAME)
                .setServiceSpecificInfo(serviceInfo.toByteArray(StandardCharsets.UTF_8))
                .build()
            session.publish(config, object : DiscoverySessionCallback() {
                override fun onPublishStarted(session: PublishDiscoverySession) {
                    publish = session
                    Log.d(TAG, "ZEE Mesh: publication Aware active")
                }

                override fun onMessageReceived(peerHandle: PeerHandle, message: ByteArray) {
                    val discoverySession = publish ?: return
                    handlePublisherMessage(discoverySession, peerHandle, String(message, StandardCharsets.UTF_8))
                }

                override fun onSessionConfigFailed() {
                    onError(IllegalStateException("Publication Wi-Fi Aware échouée"))
                }
            }, handler)
        } catch (e: Exception) {
            onError(e)
        }
    }

    private fun startSubscribe(session: WifiAwareSession) {
        try {
            val config = SubscribeConfig.Builder()
                .setServiceName(SERVICE_NAME)
                .build()
            session.subscribe(config, object : DiscoverySessionCallback() {
                override fun onSubscribeStarted(session: SubscribeDiscoverySession) {
                    subscribe = session
                    Log.d(TAG, "ZEE Mesh: abonnement Aware actif")
                }

                override fun onServiceDiscovered(
                    peerHandle: PeerHandle,
                    serviceSpecificInfo: ByteArray,
                    matchFilter: List<ByteArray>
                ) {
                    val info = String(serviceSpecificInfo, StandardCharsets.UTF_8).split('\n')
                    val remoteNodeId = info.getOrNull(0)?.trim().orEmpty()
                    if (remoteNodeId.isBlank() || remoteNodeId == localNodeIdProvider()) return
                    val modules = info.getOrNull(1).orEmpty().split(',')
                        .mapNotNull { runCatching { ZeeModule.valueOf(it.trim()) }.getOrNull() }
                        .toSet()
                    val criteria = info.getOrNull(2).orEmpty().split(',')
                        .mapNotNull { pair ->
                            val parts = pair.split(':', limit = 2)
                            if (parts.size != 2) return@mapNotNull null
                            val module = runCatching { ZeeModule.valueOf(parts[0].trim()) }.getOrNull() ?: return@mapNotNull null
                            module to parts[1].trim()
                        }.toMap()
                    peerHandles[remoteNodeId] = peerHandle
                    onPeerSeen(remoteNodeId, modules, criteria)

                    // Un seul initiateur par paire : cela évite les doubles
                    // data-paths quand les deux appareils publient et s'abonnent.
                    if (localNodeIdProvider() < remoteNodeId) {
                        val hello = (HELLO + localNodeIdProvider()).toByteArray(StandardCharsets.UTF_8)
                        runCatching { subscribe?.sendMessage(peerHandle, 1, hello) }
                            .onFailure { onError(it) }
                    }
                }

                override fun onMessageReceived(peerHandle: PeerHandle, message: ByteArray) {
                    val discoverySession = subscribe ?: return
                    handleSubscriberMessage(discoverySession, peerHandle, String(message, StandardCharsets.UTF_8))
                }

                override fun onSessionConfigFailed() {
                    onError(IllegalStateException("Abonnement Wi-Fi Aware échoué"))
                }
            }, handler)
        } catch (e: Exception) {
            onError(e)
        }
    }

    /** Côté publisher : reçoit HELLO, ouvre un serveur et réserve le data-path. */
    private fun handlePublisherMessage(session: DiscoverySession, peerHandle: PeerHandle, text: String) {
        if (!text.startsWith(HELLO)) return
        val remoteNodeId = text.removePrefix(HELLO).trim()
        if (remoteNodeId.isBlank() || remoteNodeId == localNodeIdProvider()) return
        if (sockets.containsKey(remoteNodeId)) return
        onPeerSeen(remoteNodeId, ZeeModule.values().toSet(), emptyMap())

        scope.launch(Dispatchers.IO) {
            val server = runCatching { ServerSocket(0) }.getOrElse {
                onError(it)
                return@launch
            }
            val port = server.localPort
            try {
                val specifier = WifiAwareNetworkSpecifier.Builder(session, peerHandle)
                    .setPskPassphrase(derivePsk(localNodeIdProvider(), remoteNodeId))
                    .setPort(port)
                    .build()
                val request = NetworkRequest.Builder()
                    .addTransportType(NetworkCapabilities.TRANSPORT_WIFI_AWARE)
                    .setNetworkSpecifier(specifier)
                    .build()

                val callback = object : ConnectivityManager.NetworkCallback() {
                    override fun onAvailable(network: Network) {
                        val response = (PORT + localNodeIdProvider() + "|" + port)
                            .toByteArray(StandardCharsets.UTF_8)
                        handler.post { runCatching { session.sendMessage(peerHandle, 2, response) } }

                        scope.launch(Dispatchers.IO) {
                            try {
                                val socket = server.accept()
                                sockets[remoteNodeId] = socket
                                createSession(remoteNodeId, socket)
                            } catch (e: Exception) {
                                if (running) onError(e)
                            } finally {
                                runCatching { server.close() }
                            }
                        }
                    }

                    override fun onLost(network: Network) {
                        sockets.remove(remoteNodeId)?.close()
                    }
                }
                callbacks[remoteNodeId] = callback
                connectivity.requestNetwork(request, callback)
            } catch (e: Exception) {
                runCatching { server.close() }
                onError(e)
            }
        }
    }

    /** Côté subscriber : reçoit le port du publisher et ouvre le client Aware. */
    private fun handleSubscriberMessage(session: DiscoverySession, peerHandle: PeerHandle, text: String) {
        if (!text.startsWith(PORT)) return
        val parts = text.split('|')
        if (parts.size != 3) return
        val remoteNodeId = parts[1].trim()
        val port = parts[2].toIntOrNull() ?: return
        if (remoteNodeId.isBlank() || port !in 1..65535 || sockets.containsKey(remoteNodeId)) return
        peerHandles[remoteNodeId] = peerHandle
        onPeerSeen(remoteNodeId, ZeeModule.values().toSet(), emptyMap())
        requestClientPath(session, peerHandle, remoteNodeId, port)
    }

    private fun requestClientPath(
        discoverySession: DiscoverySession,
        peerHandle: PeerHandle,
        remoteNodeId: String,
        port: Int
    ) {
        if (callbacks.containsKey(remoteNodeId)) return
        try {
            val specifier = WifiAwareNetworkSpecifier.Builder(discoverySession, peerHandle)
                .setPskPassphrase(derivePsk(localNodeIdProvider(), remoteNodeId))
                .build()
            val request = NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI_AWARE)
                .setNetworkSpecifier(specifier)
                .build()
            val callback = object : ConnectivityManager.NetworkCallback() {
                override fun onCapabilitiesChanged(network: Network, capabilities: NetworkCapabilities) {
                    val info = capabilities.transportInfo as? WifiAwareNetworkInfo ?: return
                    val address = info.peerIpv6Addr ?: return
                    val actualPort = info.port
                    if (actualPort > 0) openClientSocket(network, remoteNodeId, address, actualPort) else openClientSocket(network, remoteNodeId, address, port)
                }

                override fun onLost(network: Network) {
                    sockets.remove(remoteNodeId)?.close()
                }
            }
            callbacks[remoteNodeId] = callback
            connectivity.requestNetwork(request, callback)
        } catch (e: Exception) {
            onError(e)
        }
    }

    private fun openClientSocket(network: Network, remoteNodeId: String, address: Inet6Address, port: Int) {
        if (sockets.containsKey(remoteNodeId)) return
        scope.launch(Dispatchers.IO) {
            try {
                val socket = network.socketFactory.createSocket(address, port)
                sockets[remoteNodeId] = socket
                createSession(remoteNodeId, socket)
            } catch (e: Exception) {
                Log.w(TAG, "Connexion Aware vers $remoteNodeId impossible", e)
                callbacks.remove(remoteNodeId)
            }
        }
    }

    private fun createSession(remoteNodeId: String, socket: Socket) {
        lateinit var session: ZeeSocketSession
        session = ZeeSocketSession(
            scope = scope,
            onMessageReceived = { line -> onLine(session, line) },
            onSessionReady = {},
            onSessionError = { onError(it) }
        )
        session.onClosed = {
            sockets.remove(remoteNodeId, socket)
            callbacks.remove(remoteNodeId)?.let { cb ->
                runCatching { connectivity.unregisterNetworkCallback(cb) }
            }
        }
        session.startWithSocket(socket)
        onSessionReady(remoteNodeId, session)
    }

    private fun derivePsk(a: String, b: String): String {
        val sorted = listOf(a, b).sorted()
        val digest = MessageDigest.getInstance("SHA-256")
            .digest((sorted[0] + ":" + sorted[1]).toByteArray(StandardCharsets.UTF_8))
        return digest.joinToString("") { "%02x".format(it) }.take(63).padEnd(8, '0')
    }
}
