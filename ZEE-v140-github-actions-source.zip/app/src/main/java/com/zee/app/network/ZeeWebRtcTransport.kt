package com.zee.app.network

import android.content.Context
import android.util.Log
import org.json.JSONObject
import java.nio.ByteOrder
import org.webrtc.DataChannel
import org.webrtc.IceCandidate
import org.webrtc.MediaConstraints
import org.webrtc.MediaStream
import org.webrtc.PeerConnection
import org.webrtc.PeerConnectionFactory
import org.webrtc.RtpReceiver
import org.webrtc.RtpTransceiver
import org.webrtc.SdpObserver
import org.webrtc.SessionDescription
import java.nio.ByteBuffer
import java.nio.charset.StandardCharsets
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.CompletableFuture
import java.util.concurrent.TimeUnit

/**
 * Transport P2P inspiré du moteur réseau de Snapdrop :
 * - WebRTC DataChannel chiffré (DTLS/SRTP) pour le chemin de données ;
 * - le canal ZEE TCP existant sert uniquement à la signalisation OFFER/ANSWER/ICE ;
 * - aucun serveur Snapdrop, STUN ou TURN n'est requis pour le chemin Wi-Fi Direct :
 *   les ICE host candidates du réseau P2P local sont privilégiés.
 *
 * Le transport est volontairement optionnel. Si WebRTC échoue, ZEE conserve son
 * canal TCP/mesh actuel. Cette classe ne remplace donc pas le moteur Wi-Fi Direct.
 */
class ZeeWebRtcTransport(
    private val context: Context,
    private val localNodeIdProvider: () -> String,
    private val signalSender: (remoteNodeId: String, signal: String) -> Boolean,
    private val onReady: (remoteNodeId: String) -> Unit = {},
    private val onClosed: (remoteNodeId: String) -> Unit = {},
    private val onData: (remoteNodeId: String, packet: Packet) -> Unit = { _, _ -> }
) {
    companion object {
        private const val TAG = "ZeeWebRtc"
        private const val CHANNEL = "zee-data-v1"
        private const val READY = "ZEE_RTC_READY"
        private const val MAGIC = 0x5A454501 // ZEE + version
        private const val MAX_CHUNK = 16 * 1024
        private const val MAX_BUFFERED_BYTES = 512L * 1024L
        private const val MAX_HEADER_BYTES = 64 * 1024
        private const val MAX_PACKET_BYTES = MAX_HEADER_BYTES + MAX_CHUNK + 64
        private const val INITIAL_CONGESTION_WINDOW = 512L * 1024L
        private const val MIN_CONGESTION_WINDOW = 256L * 1024L
        private const val MAX_CONGESTION_WINDOW = 4L * 1024L * 1024L
        private const val CONGESTION_STEP = 256L * 1024L
        private const val ACK_TIMEOUT_MS = 3_000L
        private const val MAX_RESUME_ATTEMPTS = 4
        private const val KIND_LINE: Byte = 1
        private const val KIND_FILE_START: Byte = 2
        private const val KIND_FILE_CHUNK: Byte = 3
        private const val KIND_FILE_END: Byte = 4
        private const val KIND_FILE_RESUME_ACK: Byte = 5
        @Volatile private var factoryInitialized = false
        private val initLock = Any()
    }

    private data class Link(
        val remoteNodeId: String,
        val pc: PeerConnection,
        var channel: DataChannel? = null,
        val pendingCandidates: MutableList<IceCandidate> = mutableListOf(),
        val resumeAcks: ConcurrentHashMap<String, CompletableFuture<Long>> = ConcurrentHashMap()
    )

    sealed class Packet {
        data class Line(val json: String) : Packet()
        data class FileStart(
            val messageId: String, val fromNodeId: String, val toNodeId: String,
            val ttl: Int, val fileName: String, val mimeType: String, val fileSize: Long,
            val kind: String, val resumeOffset: Long
        ) : Packet()
        data class FileChunk(val messageId: String, val sequence: Int, val offset: Long, val end: Boolean, val data: ByteArray) : Packet()
        data class FileEnd(val messageId: String) : Packet()
        data class FileResumeAck(val messageId: String, val offset: Long) : Packet()
    }

    private val links = ConcurrentHashMap<String, Link>()
    private val factory: PeerConnectionFactory

    init {
        synchronized(initLock) {
            if (!factoryInitialized) {
                PeerConnectionFactory.initialize(
                    PeerConnectionFactory.InitializationOptions
                        .builder(context.applicationContext)
                        .createInitializationOptions()
                )
                factoryInitialized = true
            }
        }
        factory = PeerConnectionFactory.builder().createPeerConnectionFactory()
    }

    /** Le node ayant l'ID lexicalement le plus petit initie le WebRTC offer. */
    fun start(remoteNodeId: String) {
        if (remoteNodeId.isBlank() || remoteNodeId == localNodeIdProvider()) return
        if (links.containsKey(remoteNodeId)) return
        if (localNodeIdProvider() >= remoteNodeId) return

        val link = createLink(remoteNodeId)
        val channel = link.pc.createDataChannel(CHANNEL, DataChannel.Init())
        link.channel = channel
        observeChannel(link, channel)

        link.pc.createOffer(object : SdpObserverAdapter() {
            override fun onCreateSuccess(desc: SessionDescription) {
                link.pc.setLocalDescription(object : SdpObserverAdapter() {
                    override fun onSetSuccess() {
                        signalSender(remoteNodeId, ZeeMessageCodec.encodeWebRtcOffer(
                            localNodeIdProvider(), desc.description
                        ))
                    }
                }, desc)
            }
            override fun onCreateFailure(error: String) {
                Log.w(TAG, "Offer impossible pour $remoteNodeId: $error")
                close(remoteNodeId)
            }
        }, MediaConstraints())
    }

    fun handle(signal: ZeeMessageCodec.Decoded.WebRtcSignal) {
        val remoteNodeId = signal.nodeId
        if (remoteNodeId.isBlank() || remoteNodeId == localNodeIdProvider()) return

        when (signal.signalType) {
            "OFFER" -> handleOffer(remoteNodeId, signal.sdp.orEmpty())
            "ANSWER" -> handleAnswer(remoteNodeId, signal.sdp.orEmpty())
            "ICE" -> signal.candidate?.let {
                val candidate = IceCandidate(signal.sdpMid, signal.sdpMLineIndex ?: 0, it)
                val link = links[remoteNodeId] ?: return
                synchronized(link.pendingCandidates) {
                    if (link.pc.remoteDescription == null) {
                        link.pendingCandidates += candidate
                    } else {
                        link.pc.addIceCandidate(candidate)
                    }
                }
            }
        }
    }

    fun send(remoteNodeId: String, data: ByteArray): Boolean {
        val channel = links[remoteNodeId]?.channel ?: return false
        if (channel.state() != DataChannel.State.OPEN) return false
        return channel.send(DataChannel.Buffer(ByteBuffer.wrap(data), false))
    }

    /** Envoie une ligne JSON (CHAT/ATTACHMENT/ACK) sur le DataChannel. */
    fun sendLine(remoteNodeId: String, jsonLine: String): Boolean =
        sendPacket(remoteNodeId, KIND_LINE, JSONObject().put("line", jsonLine).toString().toByteArray(StandardCharsets.UTF_8))

    /**
     * Envoi de gros fichiers avec contrôle de congestion applicatif et reprise.
     * Le DataChannel reste sous des messages modestes; on limite aussi la
     * quantité mise en file dans WebRTC puis on attend un ACK cumulatif du
     * récepteur à chaque fenêtre. En cas de coupure, on réessaie depuis le
     * dernier offset confirmé par le pair.
     */
    fun sendFile(
        remoteNodeId: String, messageId: String, fromNodeId: String, toNodeId: String,
        ttl: Int, fileName: String, mimeType: String, fileSize: Long, kind: String,
        input: java.io.InputStream, onProgress: (Long) -> Unit = {}
    ): Boolean {
        if (!isReady(remoteNodeId) || fileSize < 0) return false
        val link = links[remoteNodeId] ?: return false
        var confirmedOffset = 0L
        var attempt = 0
        var congestionWindow = INITIAL_CONGESTION_WINDOW

        while (attempt < MAX_RESUME_ATTEMPTS && confirmedOffset < fileSize) {
            if (!isReady(remoteNodeId)) {
                if (!waitForReady(remoteNodeId, 1_500L)) { attempt++; continue }
            }
            try {
                val start = JSONObject().apply {
                    put("messageId", messageId); put("fromNodeId", fromNodeId); put("toNodeId", toNodeId)
                    put("ttl", ttl); put("fileName", fileName); put("mimeType", mimeType)
                    put("fileSize", fileSize); put("kind", kind); put("resumeOffset", confirmedOffset)
                }.toString().toByteArray(StandardCharsets.UTF_8)

                val ackKey = ackKey(messageId, confirmedOffset)
                val startAck = CompletableFuture<Long>()
                link.resumeAcks[ackKey] = startAck
                if (!sendPacket(remoteNodeId, KIND_FILE_START, start)) {
                    link.resumeAcks.remove(ackKey)
                    attempt++
                    continue
                }
                val receiverOffset = startAck.get(ACK_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                    .coerceIn(0L, fileSize)
                link.resumeAcks.remove(ackKey)
                if (receiverOffset > confirmedOffset) {
                    confirmedOffset = receiverOffset
                    onProgress(confirmedOffset)
                }
                seekInput(input, confirmedOffset)

                var sent = confirmedOffset
                var sequence = 0
                while (sent < fileSize) {
                    val windowStart = sent
                    val windowEnd = minOf(fileSize, windowStart + congestionWindow)
                    val waitKey = ackKey(messageId, windowEnd)
                    val waiter = CompletableFuture<Long>()
                    link.resumeAcks[waitKey] = waiter
                    while (sent < windowEnd) {
                        if (!isReady(remoteNodeId)) throw java.io.IOException("WebRTC interrompu")
                        awaitSendCapacity(link.channel ?: throw java.io.IOException("DataChannel absent"))
                        val remaining = minOf(MAX_CHUNK.toLong(), windowEnd - sent).toInt()
                        val buffer = ByteArray(remaining)
                        var read = 0
                        while (read < remaining) {
                            val n = input.read(buffer, read, remaining - read)
                            if (n < 0) throw java.io.EOFException("Lecture du fichier interrompue")
                            read += n
                        }
                        val header = JSONObject().apply {
                            put("messageId", messageId); put("sequence", sequence++); put("end", sent + read >= fileSize)
                            put("offset", sent)
                        }.toString().toByteArray(StandardCharsets.UTF_8)
                        if (!sendPacket(remoteNodeId, KIND_FILE_CHUNK, header, buffer)) {
                            throw java.io.IOException("DataChannel send() refusé")
                        }
                        sent += read
                        onProgress(sent)
                    }

                    val acked = try {
                        waiter.get(ACK_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                    } finally {
                        link.resumeAcks.remove(waitKey)
                    }
                    confirmedOffset = acked.coerceIn(confirmedOffset, fileSize)
                    if (confirmedOffset < windowEnd) throw java.io.IOException("ACK de fenêtre incomplet")
                    congestionWindow = minOf(MAX_CONGESTION_WINDOW, congestionWindow + CONGESTION_STEP)
                }

                // Le dernier chunk est marqué `end=true` et acquitté après
                // synchronisation disque côté réception. FILE_END sert uniquement
                // de signal de finition; son absence ne doit donc pas transformer
                // un transfert déjà intégralement reçu en faux échec.
                sendPacket(remoteNodeId, KIND_FILE_END, JSONObject()
                    .put("messageId", messageId).put("offset", fileSize)
                    .toString().toByteArray(StandardCharsets.UTF_8))
                return confirmedOffset == fileSize
            } catch (e: Exception) {
                congestionWindow = maxOf(MIN_CONGESTION_WINDOW, congestionWindow / 2L)
                Log.w(TAG, "Transfert WebRTC interrompu, reprise offset=$confirmedOffset cwnd=$congestionWindow", e)
                // Le fichier local est repositionné au prochain tour et le
                // pair conserve son fichier partiel; le TCP reste le fallback
                // final si aucune nouvelle liaison RTC ne revient.
            }
            attempt++
        }
        return confirmedOffset == fileSize
    }

    private fun ackKey(messageId: String, offset: Long): String = "$messageId:$offset"

    private fun seekInput(input: java.io.InputStream, offset: Long) {
        if (input is java.io.FileInputStream) {
            input.channel.position(offset)
            return
        }
        if (offset <= 0) return
        var remaining = offset
        while (remaining > 0) {
            val skipped = input.skip(remaining)
            if (skipped > 0) { remaining -= skipped; continue }
            if (input.read() < 0) throw java.io.EOFException("Offset de reprise hors fichier")
            remaining--
        }
    }

    private fun awaitSendCapacity(channel: DataChannel) {
        var stable = 0
        while (channel.state() == DataChannel.State.OPEN && channel.bufferedAmount() > MAX_BUFFERED_BYTES) {
            Thread.sleep(8L)
            if (++stable > 375) throw java.io.IOException("DataChannel saturé")
        }
    }

    private fun waitForReady(remoteNodeId: String, timeoutMs: Long): Boolean {
        val deadline = System.currentTimeMillis() + timeoutMs
        while (System.currentTimeMillis() < deadline) {
            if (isReady(remoteNodeId)) return true
            Thread.sleep(25L)
        }
        return isReady(remoteNodeId)
    }

    /** ACK cumulatif de réception utilisé par le contrôle de fenêtre/reprise. */
    fun sendFileResumeAck(remoteNodeId: String, messageId: String, offset: Long): Boolean =
        sendPacket(
            remoteNodeId, KIND_FILE_RESUME_ACK,
            JSONObject().put("messageId", messageId).put("offset", offset)
                .toString().toByteArray(StandardCharsets.UTF_8)
        )

    fun isReady(remoteNodeId: String): Boolean =
        links[remoteNodeId]?.channel?.state() == DataChannel.State.OPEN

    fun close(remoteNodeId: String) {
        val link = links.remove(remoteNodeId) ?: return
        runCatching { link.channel?.unregisterObserver() }
        runCatching { link.channel?.close() }
        runCatching { link.pc.close() }
        onClosed(remoteNodeId)
    }

    fun closeAll() {
        links.keys.toList().forEach(::close)
        runCatching { factory.dispose() }
    }

    private fun handleOffer(remoteNodeId: String, sdp: String) {
        val link = links[remoteNodeId] ?: createLink(remoteNodeId)
        link.pc.setRemoteDescription(object : SdpObserverAdapter() {
            override fun onSetSuccess() {
                flushCandidates(link)
                link.pc.createAnswer(object : SdpObserverAdapter() {
                    override fun onCreateSuccess(desc: SessionDescription) {
                        link.pc.setLocalDescription(object : SdpObserverAdapter() {
                            override fun onSetSuccess() {
                                signalSender(remoteNodeId, ZeeMessageCodec.encodeWebRtcAnswer(
                                    localNodeIdProvider(), desc.description
                                ))
                            }
                        }, desc)
                    }
                    override fun onCreateFailure(error: String) {
                        Log.w(TAG, "Answer impossible pour $remoteNodeId: $error")
                        close(remoteNodeId)
                    }
                }, MediaConstraints())
            }
            override fun onSetFailure(error: String) {
                Log.w(TAG, "Offer distante refusée pour $remoteNodeId: $error")
                close(remoteNodeId)
            }
        }, SessionDescription(SessionDescription.Type.OFFER, sdp))
    }

    private fun handleAnswer(remoteNodeId: String, sdp: String) {
        val link = links[remoteNodeId] ?: return
        link.pc.setRemoteDescription(object : SdpObserverAdapter() {
            override fun onSetSuccess() {
                flushCandidates(link)
            }
            override fun onSetFailure(error: String) {
                Log.w(TAG, "Answer distante refusée pour $remoteNodeId: $error")
                close(remoteNodeId)
            }
        }, SessionDescription(SessionDescription.Type.ANSWER, sdp))
    }

    private fun createLink(remoteNodeId: String): Link {
        val observer = object : PeerConnection.Observer {
            override fun onSignalingChange(state: PeerConnection.SignalingState) {}
            override fun onIceConnectionChange(state: PeerConnection.IceConnectionState) {
                Log.d(TAG, "ICE $remoteNodeId = $state")
                if (state == PeerConnection.IceConnectionState.FAILED ||
                    state == PeerConnection.IceConnectionState.CLOSED) {
                    close(remoteNodeId)
                }
            }
            override fun onIceConnectionReceivingChange(receiving: Boolean) {}
            override fun onIceGatheringChange(state: PeerConnection.IceGatheringState) {}
            override fun onIceCandidate(candidate: IceCandidate) {
                signalSender(remoteNodeId, ZeeMessageCodec.encodeWebRtcIce(
                    localNodeIdProvider(), candidate.sdp, candidate.sdpMid, candidate.sdpMLineIndex
                ))
            }
            override fun onIceCandidatesRemoved(candidates: Array<out IceCandidate>) {}
            override fun onAddStream(stream: MediaStream) {}
            override fun onRemoveStream(stream: MediaStream) {}
            override fun onDataChannel(channel: DataChannel) {
                val link = links[remoteNodeId] ?: return
                link.channel = channel
                observeChannel(link, channel)
            }
            override fun onRenegotiationNeeded() {}
            override fun onAddTrack(receiver: RtpReceiver, streams: Array<out MediaStream>) {}
            override fun onTrack(transceiver: RtpTransceiver) {}
        }

        // Liste ICE vide : pour ZEE de proximité, on utilise les host candidates
        // disponibles sur l'interface Wi-Fi Direct/Aware. Aucun trafic STUN/TURN
        // n'est déclenché par défaut.
        val config = PeerConnection.RTCConfiguration(emptyList())
        config.sdpSemantics = PeerConnection.SdpSemantics.UNIFIED_PLAN
        val pc = factory.createPeerConnection(config, observer)
            ?: throw IllegalStateException("Création PeerConnection impossible")

        return Link(remoteNodeId, pc).also { links[remoteNodeId] = it }
    }

    private fun observeChannel(link: Link, channel: DataChannel) {
        channel.registerObserver(object : DataChannel.Observer {
            override fun onBufferedAmountChange(previousAmount: Long) {
                Log.v(TAG, "bufferedAmount ${link.remoteNodeId}: $previousAmount -> ${runCatching { channel.bufferedAmount() }.getOrDefault(-1L)}")
            }
            override fun onStateChange() {
                val state = channel.state()
                Log.d(TAG, "DataChannel ${link.remoteNodeId} = $state")
                if (state == DataChannel.State.OPEN) {
                    onReady(link.remoteNodeId)
                    sendReady(link)
                } else if (state == DataChannel.State.CLOSING ||
                    state == DataChannel.State.CLOSED) {
                    onClosed(link.remoteNodeId)
                }
            }
            override fun onMessage(buffer: DataChannel.Buffer) {
                if (buffer.binary) {
                    val bytes = ByteArray(buffer.data.remaining())
                    buffer.data.get(bytes)
                    decodePacket(bytes)?.let { packet ->
                        if (packet is Packet.FileResumeAck) {
                            val key = ackKey(packet.messageId, packet.offset)
                            link.resumeAcks.remove(key)?.complete(packet.offset)
                            // Un ACK plus avancé peut aussi valider une fenêtre
                            // déjà dépassée après une reconnexion.
                            link.resumeAcks.entries
                                .filter { it.key.startsWith(packet.messageId + ":") }
                                .forEach { (k, future) ->
                                    val expected = k.substringAfterLast(':').toLongOrNull()
                                    if (expected != null && expected <= packet.offset) {
                                        link.resumeAcks.remove(k)?.complete(packet.offset)
                                    }
                                }
                        } else onData(link.remoteNodeId, packet)
                    }
                } else {
                    val bytes = ByteArray(buffer.data.remaining())
                    buffer.data.get(bytes)
                    if (bytes.toString(StandardCharsets.UTF_8) == READY) return
                    decodePacket(bytes)?.let { packet ->
                        if (packet is Packet.FileResumeAck) {
                            val key = ackKey(packet.messageId, packet.offset)
                            link.resumeAcks.remove(key)?.complete(packet.offset)
                            // Un ACK plus avancé peut aussi valider une fenêtre
                            // déjà dépassée après une reconnexion.
                            link.resumeAcks.entries
                                .filter { it.key.startsWith(packet.messageId + ":") }
                                .forEach { (k, future) ->
                                    val expected = k.substringAfterLast(':').toLongOrNull()
                                    if (expected != null && expected <= packet.offset) {
                                        link.resumeAcks.remove(k)?.complete(packet.offset)
                                    }
                                }
                        } else onData(link.remoteNodeId, packet)
                    }
                }
            }
        })
    }

    private fun sendPacket(remoteNodeId: String, kind: Byte, header: ByteArray, payload: ByteArray = ByteArray(0)): Boolean {
        val channel = links[remoteNodeId]?.channel ?: return false
        if (channel.state() != DataChannel.State.OPEN) return false
        val out = ByteBuffer.allocate(4 + 1 + 4 + header.size + payload.size).order(ByteOrder.BIG_ENDIAN)
        out.putInt(MAGIC).put(kind).putInt(header.size).put(header).put(payload)
        out.flip()
        return channel.send(DataChannel.Buffer(out, true))
    }

    private fun decodePacket(bytes: ByteArray): Packet? {
        if (bytes.size < 9) return null
        val input = ByteBuffer.wrap(bytes).order(ByteOrder.BIG_ENDIAN)
        if (input.int != MAGIC) return null
        val kind = input.get()
        val headerLen = input.int
        if (headerLen < 0 || headerLen > MAX_HEADER_BYTES || headerLen > input.remaining()) return null
        val payloadLen = input.remaining()
        if (payloadLen > MAX_CHUNK || bytes.size > MAX_PACKET_BYTES) return null
        val header = ByteArray(headerLen); input.get(header)
        val payload = ByteArray(payloadLen); input.get(payload)
        return runCatching {
            val o = JSONObject(String(header, StandardCharsets.UTF_8))
            when (kind) {
                KIND_LINE -> Packet.Line(o.optString("line"))
                KIND_FILE_START -> Packet.FileStart(
                    o.optString("messageId"), o.optString("fromNodeId"), o.optString("toNodeId"),
                    o.optInt("ttl", 8), o.optString("fileName", "fichier"),
                    o.optString("mimeType", "application/octet-stream"), o.optLong("fileSize", -1),
                    o.optString("kind", "CHAT"), o.optLong("resumeOffset", 0L)
                )
                KIND_FILE_CHUNK -> Packet.FileChunk(o.optString("messageId"), o.optInt("sequence"), o.optLong("offset", -1L), o.optBoolean("end"), payload)
                KIND_FILE_END -> Packet.FileEnd(o.optString("messageId"))
                KIND_FILE_RESUME_ACK -> Packet.FileResumeAck(o.optString("messageId"), o.optLong("offset", 0L))
                else -> null
            }
        }.getOrNull()
    }

    private fun sendReady(link: Link) {
        link.channel?.takeIf { it.state() == DataChannel.State.OPEN }?.send(
            DataChannel.Buffer(
                ByteBuffer.wrap(READY.toByteArray(StandardCharsets.UTF_8)),
                false
            )
        )
    }

    private fun flushCandidates(link: Link) {
        val copy = synchronized(link.pendingCandidates) {
            link.pendingCandidates.toList().also { link.pendingCandidates.clear() }
        }
        copy.forEach { link.pc.addIceCandidate(it) }
    }

    private abstract class SdpObserverAdapter : SdpObserver {
        override fun onCreateSuccess(desc: SessionDescription) {}
        override fun onSetSuccess() {}
        override fun onCreateFailure(error: String) {}
        override fun onSetFailure(error: String) {}
    }
}
