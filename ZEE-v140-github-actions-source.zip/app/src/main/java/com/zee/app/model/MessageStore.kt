package com.zee.app.model

import android.content.Context
import android.net.Uri
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.util.UUID

/**
 * Persistance locale des messages ZEE.
 *
 * Le store est indépendant de l'écran actuellement affiché. Un message reçu
 * est écrit avant toute notification/UI. Les pièces jointes finales sont
 * conservées dans files/zee_media/<channel>/ et jamais uniquement dans cache/.
 */
object MessageStore {
    data class StoredMessage(
        val id: String,
        val conversationId: String,
        val channel: String,
        val senderId: String,
        val fromMe: Boolean,
        val type: MessageType,
        val text: String?,
        val localFilePath: String?,
        val fileName: String?,
        val mimeType: String?,
        val timestamp: Long
    )

    private const val PREFS = "zee_message_store_v140"
    private const val KEY = "messages"
    private const val MAX_MESSAGES = 5000

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun mediaDir(context: Context, channel: String): File =
        File(context.filesDir, "zee_media/${MessageChannels.normalize(channel).lowercase()}").apply { mkdirs() }

    fun copyUriToPersistent(context: Context, uri: Uri, channel: String, fileName: String): File? =
        runCatching {
            val safe = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "media" }.take(180)
            val out = File(mediaDir(context, channel), "${System.currentTimeMillis()}_${UUID.randomUUID()}_$safe")
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(out).use { output -> input.copyTo(output, 64 * 1024) }
            } ?: return null
            if (out.length() <= 0L) { out.delete(); return null }
            out
        }.getOrNull()

    fun copyFileToPersistent(context: Context, source: File, channel: String, fileName: String = source.name): File? =
        runCatching {
            val safe = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_").ifBlank { "media" }.take(180)
            val out = File(mediaDir(context, channel), "${System.currentTimeMillis()}_${UUID.randomUUID()}_$safe")
            source.inputStream().use { input -> out.outputStream().use { output -> input.copyTo(output, 64 * 1024) } }
            if (out.length() <= 0L) { out.delete(); return null }
            out
        }.getOrNull()

    @Synchronized
    fun save(
        context: Context,
        id: String,
        conversationId: String,
        channel: String,
        senderId: String,
        fromMe: Boolean,
        type: MessageType,
        text: String?,
        localFilePath: String?,
        fileName: String?,
        mimeType: String?,
        timestamp: Long = System.currentTimeMillis()
    ) {
        val items = read(context).filterNot { it.id == id }.toMutableList()
        items.add(StoredMessage(id, conversationId, MessageChannels.normalize(channel), senderId, fromMe,
            type, text, localFilePath, fileName, mimeType, timestamp))
        if (items.size > MAX_MESSAGES) {
            items.subList(0, items.size - MAX_MESSAGES).clear()
        }
        write(context, items)
    }

    fun list(context: Context, channel: String, conversationId: String): List<StoredMessage> =
        read(context).filter {
            MessageChannels.normalize(it.channel) == MessageChannels.normalize(channel) &&
            it.conversationId == conversationId
        }.sortedBy { it.timestamp }

    fun contains(context: Context, id: String): Boolean =
        read(context).any { it.id == id }

    private fun read(context: Context): MutableList<StoredMessage> {
        val raw = prefs(context).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val a = JSONArray(raw)
            buildList {
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    add(StoredMessage(
                        id = o.optString("id"),
                        conversationId = o.optString("conversationId"),
                        channel = MessageChannels.normalize(o.optString("channel")),
                        senderId = o.optString("senderId"),
                        fromMe = o.optBoolean("fromMe"),
                        type = runCatching { MessageType.valueOf(o.optString("type", "TEXT")) }.getOrDefault(MessageType.TEXT),
                        text = o.optString("text").ifBlank { null },
                        localFilePath = o.optString("localFilePath").ifBlank { null },
                        fileName = o.optString("fileName").ifBlank { null },
                        mimeType = o.optString("mimeType").ifBlank { null },
                        timestamp = o.optLong("timestamp", 0L)
                    ))
                }
            }.toMutableList()
        }.getOrDefault(mutableListOf())
    }

    private fun write(context: Context, items: List<StoredMessage>) {
        val a = JSONArray()
        items.forEach { m ->
            a.put(JSONObject().apply {
                put("id", m.id); put("conversationId", m.conversationId)
                put("channel", m.channel); put("senderId", m.senderId)
                put("fromMe", m.fromMe); put("type", m.type.name)
                put("text", m.text ?: JSONObject.NULL)
                put("localFilePath", m.localFilePath ?: JSONObject.NULL)
                put("fileName", m.fileName ?: JSONObject.NULL)
                put("mimeType", m.mimeType ?: JSONObject.NULL)
                put("timestamp", m.timestamp)
            })
        }
        prefs(context).edit().putString(KEY, a.toString()).apply()
    }
}
