package com.zee.app.ui

import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentActivity
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.zee.app.model.ZeeModule

/**
 * Navigation principale ZEE : Accueil + trois modules fonctionnels.
 * BUSINESS/JOB/RENCONTRES conservent PeerListFragment et donc toute la logique
 * réseau/visibilité existante ; seul l'habillage/navigation est modernisé.
 */
class TabsPagerAdapter(activity: FragmentActivity) : FragmentStateAdapter(activity) {

    companion object {
        val MODULES = listOf(ZeeModule.CHAT, ZeeModule.MARKET, ZeeModule.JOB)
        const val HOME_POSITION = 0
        const val BUSINESS_POSITION = 1
        const val JOB_POSITION = 2
        const val CHAT_POSITION = 3

        fun moduleAt(position: Int): ZeeModule? = when (position) {
            BUSINESS_POSITION -> ZeeModule.MARKET
            JOB_POSITION -> ZeeModule.JOB
            CHAT_POSITION -> ZeeModule.CHAT
            else -> null
        }
    }

    override fun getItemCount() = 4

    override fun createFragment(position: Int): Fragment = when (position) {
        HOME_POSITION -> HomeFragment()
        BUSINESS_POSITION -> PeerListFragment.newInstance(ZeeModule.MARKET)
        JOB_POSITION -> PeerListFragment.newInstance(ZeeModule.JOB)
        CHAT_POSITION -> PeerListFragment.newInstance(ZeeModule.CHAT)
        else -> HomeFragment()
    }
}
