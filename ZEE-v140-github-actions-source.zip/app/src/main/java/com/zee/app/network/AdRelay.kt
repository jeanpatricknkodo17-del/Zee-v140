package com.zee.app.network

import android.content.Context
import com.zee.app.model.AdPayload
import com.zee.app.model.AdRelayStore
import com.zee.app.ui.PublicityActivity

object AdRelay {
    /**
     * Une pub reçue est enregistrée une seule fois puis affichée une seule
     * fois. Le voisin source est marqué comme déjà servi afin d'éviter le
     * renvoi en boucle. Les autres voisins seront servis opportunistement
     * par AdBroadcastScheduler.
     */
    fun onAdReceived(
        context: Context,
        ad: AdPayload,
        fromNodeId: String? = null
    ): Boolean {
        if (ad.expiresAt <= System.currentTimeMillis()) return false
        val added = AdRelayStore.addOrRelay(context, ad)
        if (!added) return false

        if (!fromNodeId.isNullOrBlank()) {
            AdRelayStore.markSentToNeighbor(context, ad.id, fromNodeId)
        }
        // Une pub texte/image sans média binaire est affichable immédiatement.
        // Pour un média, on attend que le canal binaire l'ait effectivement
        // reçu afin de ne plus présenter une pub amputée de son contenu.
        if (ad.mediaMimeType.isNullOrBlank() || !ad.mediaPath.isNullOrBlank()) {
            PublicityActivity.start(context, ad)
        }
        return true
    }

    fun onAdMediaReceived(context: Context, adId: String, file: java.io.File, mimeType: String, fileName: String) {
        val dir = java.io.File(context.filesDir, "ad_media_received").apply { mkdirs() }
        val stable = java.io.File(dir, "${adId}_${fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")}")
        runCatching {
            val existing = AdRelayStore.get(context, adId)?.mediaPath
            if (!existing.isNullOrBlank() && java.io.File(existing).isFile) {
                file.delete()
                return@runCatching
            }
            file.copyTo(stable, overwrite = true)
            file.delete()
            AdRelayStore.attachMedia(context, adId, stable.absolutePath, mimeType, fileName)
            AdRelayStore.get(context, adId)?.let { ad ->
                PublicityActivity.start(context, ad)
            }
        }
    }
}
