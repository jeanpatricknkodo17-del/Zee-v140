package com.zee.app.network

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ConcurrentHashMap

/**
 * Relais maillé applicatif ZEE.
 *
 * Le Group Owner peut accepter plusieurs téléphones ZEE simultanément.
 * Chaque client s'identifie avec son nodeId et les messages CHAT sont
 * acheminés vers le destinataire; si le destinataire n'est pas une liaison
 * directe, le TTL permet un relais par les autres liaisons disponibles.
 * Cela transforme un groupe Wi-Fi Direct en réseau ZEE multi-utilisateurs.
 */
class ZeeMeshServer(
    private val scope: CoroutineScope,
    private val onLine: (ZeeSocketSession, String) -> Unit,
    private val onReady: (ZeeSocketSession) -> Unit,
    private val onClosed: (ZeeSocketSession) -> Unit,
    private val onError: (Throwable) -> Unit
) {
    private var serverSocket: ServerSocket? = null
    private val sessions = ConcurrentHashMap.newKeySet<ZeeSocketSession>()
    private val nodes = ConcurrentHashMap<String, ZeeSocketSession>()
    private val profileLines = ConcurrentHashMap<String, String>()

    fun start(port: Int = WifiDirectManager.ZEE_PORT) {
        scope.launch(Dispatchers.IO) {
            try {
                val server = ServerSocket(port)
                serverSocket = server
                while (!server.isClosed) {
                    val socket = server.accept().apply {
                        tcpNoDelay = true
                        keepAlive = true
                        sendBufferSize = 64 * 1024
                        receiveBufferSize = 64 * 1024
                    }
                    val session = newSession(socket)
                    sessions += session
                    session.startWithSocket(socket)
                }
            } catch (e: Exception) {
                if (serverSocket?.isClosed != true) onError(e)
            }
        }
    }

    private fun newSession(socket: Socket): ZeeSocketSession {
        lateinit var created: ZeeSocketSession
        created = ZeeSocketSession(
            scope = scope,
            onMessageReceived = { line -> onLine(created, line) },
            onSessionReady = { onReady(created) },
            onSessionError = { error -> onError(error) }
        )
        created.onClosed = {
            sessions.remove(created)
            nodes.entries.removeIf { it.value === created }
            onClosed(created)
        }
        return created
    }

    fun notifyReady(session: ZeeSocketSession) = onReady(session)

    fun registerNode(nodeId: String, session: ZeeSocketSession) {
        if (nodeId.isBlank()) return
        val previous = nodes.put(nodeId, session)
        // Un même nodeId qui se reconnecte doit abandonner l'ancien transport.
        // On ne ferme pas ici le socket précédent si d'autres routes peuvent
        // encore l'utiliser ; SessionRegistry gère sa suppression lors du
        // remplacement de route.
        if (previous != null && previous !== session) {
            Log.d("ZeeMeshServer", "Route remplacée pour $nodeId")
            // Un nodeId est une identité unique dans le maillage. Fermer
            // l'ancien socket évite qu'une reconnexion laisse deux transports
            // concurrents capables de recevoir le même message privé.
            // La fermeture est volontaire : son callback onClosed nettoiera
            // aussi toutes les routes restantes qui pointent vers ce transport.
            runCatching { previous.close() }
        }
    }

    fun cacheProfile(nodeId: String, line: String) {
        if (nodeId.isNotBlank()) profileLines[nodeId] = line
    }

    fun sendKnownProfiles(to: ZeeSocketSession) {
        // Ces profils sont des copies relayées : le client ne doit pas
        // prendre l'un d'eux pour l'identité du socket TCP direct.
        profileLines.values.forEach { to.send(asRelayedProfile(it)) }
    }

    private fun asRelayedProfile(line: String): String = runCatching {
        JSONObject(line).apply { put("direct", false) }.toString()
    }.getOrDefault(line)

    fun sendTo(nodeId: String, line: String): Boolean {
        val target = nodes[nodeId] ?: return false
        return target.send(line)
    }

    /** Diffuse un profil aux autres appareils du groupe. */
    fun broadcast(line: String, except: ZeeSocketSession? = null) {
        sessions.forEach { if (it !== except) it.send(line) }
    }

    /** Relais d'un paquet vers toutes les liaisons sauf sa source. */
    fun relay(line: String, except: ZeeSocketSession?) {
        sessions.forEach { if (it !== except) it.send(line) }
    }

    fun stop() {
        serverSocket?.close()
        serverSocket = null
        sessions.forEach { it.close() }
        sessions.clear()
        nodes.clear()
        profileLines.clear()
    }
}
