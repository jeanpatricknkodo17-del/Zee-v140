package com.zee.app.network

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import org.json.JSONObject
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.DataInputStream
import java.io.DataOutputStream
import java.io.EOFException
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.Executors

/**
 * Fast Wi-Fi lane inspired by AnExplorer's local direct-transfer model.
 *
 * We do NOT copy AnExplorer source code. The reusable idea is architectural:
 * once ZEE has already discovered/connected a ZEE peer over the local Wi-Fi
 * link, keep the control plane small and stream the file directly over the
 * local network with a dedicated server socket, large buffers and no cloud.
 *
 * Priority in ZEE becomes:
 *   WebRTC DataChannel -> this direct Wi-Fi lane -> legacy routed TCP.
 *
 * This lane is intentionally direct-peer only. Relay traffic keeps using the
 * existing routed FileTransferManager so mesh semantics are unchanged.
 */
object ZeeFastWifiTransfer {
    const val PORT = WifiDirectManager.ZEE_PORT + 2
    private const val MAGIC = 0x5A464153 // "ZFAS"
    private const val VERSION = 1
    private const val BUFFER_SIZE = 256 * 1024
    private const val SOCKET_BUFFER = 1024 * 1024
    private const val CONNECT_TIMEOUT_MS = 3000
    private const val MAX_FILE_SIZE = 2L * 1024L * 1024L * 1024L

    data class Meta(
        val messageId: String,
        val fromNodeId: String,
        val toNodeId: String,
        val ttl: Int,
        val fileName: String,
        val mimeType: String,
        val fileSize: Long,
        val kind: String
    ) {
        fun toJson(): ByteArray = JSONObject().apply {
            put("messageId", messageId)
            put("fromNodeId", fromNodeId)
            put("toNodeId", toNodeId)
            put("ttl", ttl)
            put("fileName", fileName)
            put("mimeType", mimeType)
            put("fileSize", fileSize)
            put("kind", kind)
        }.toString().toByteArray(Charsets.UTF_8)

        companion object {
            fun fromJson(bytes: ByteArray): Meta {
                val o = JSONObject(String(bytes, Charsets.UTF_8))
                return Meta(
                    o.getString("messageId"), o.getString("fromNodeId"),
                    o.getString("toNodeId"), o.getInt("ttl"),
                    safeName(o.getString("fileName")), o.optString("mimeType", "application/octet-stream"),
                    o.getLong("fileSize"), o.optString("kind", "CHAT")
                )
            }
        }
    }

    interface Listener {
        fun onProgress(sentBytes: Long, totalBytes: Long) {}
        fun onComplete(file: File, meta: Meta)
        fun onError(error: Exception) {}
    }

    @Volatile private var server: ServerSocket? = null
    private val executor = Executors.newCachedThreadPool { r ->
        Thread(r, "zee-fast-wifi").apply { isDaemon = true }
    }

    @Synchronized
    fun startServer(scope: CoroutineScope, destinationDir: File, localNodeId: String, listener: Listener): ServerSocket? {
        if (server?.isClosed == false) return server
        val created = runCatching { ServerSocket(PORT) }.getOrNull() ?: return null
        server = created
        destinationDir.mkdirs()
        scope.launch(Dispatchers.IO) {
            while (created.isClosed.not()) {
                val socket = runCatching { created.accept() }.getOrNull() ?: break
                executor.execute {
                    receive(socket, destinationDir, localNodeId, listener)
                }
            }
        }
        return created
    }

    fun stop() {
        runCatching { server?.close() }
        server = null
    }

    fun send(
        hostAddress: String,
        meta: Meta,
        file: File
    ): Boolean {
        var socket: Socket? = null
        return try {
            require(file.isFile) { "Fichier source introuvable" }
            require(meta.fileSize in 0..MAX_FILE_SIZE) { "Taille de fichier invalide" }
            require(file.length() == meta.fileSize) { "Taille source modifiée pendant l'envoi" }

            socket = Socket().apply {
                tcpNoDelay = false
                keepAlive = true
                sendBufferSize = SOCKET_BUFFER
                receiveBufferSize = SOCKET_BUFFER
                connect(InetSocketAddress(hostAddress, PORT), CONNECT_TIMEOUT_MS)
            }
            val out = DataOutputStream(BufferedOutputStream(socket.getOutputStream(), BUFFER_SIZE))
            val metaBytes = meta.toJson()
            out.writeInt(MAGIC)
            out.writeInt(VERSION)
            out.writeInt(metaBytes.size)
            out.write(metaBytes)
            out.flush()

            FileInputStream(file).use { input ->
                val buffer = ByteArray(BUFFER_SIZE)
                var sent = 0L
                while (sent < meta.fileSize) {
                    val n = input.read(buffer, 0, minOf(buffer.size.toLong(), meta.fileSize - sent).toInt())
                    if (n < 0) throw EOFException("Lecture du fichier interrompue")
                    out.write(buffer, 0, n)
                    sent += n
                }
            }
            out.flush()
            true
        } catch (_: Exception) {
            false
        } finally {
            runCatching { socket?.close() }
        }
    }

    private fun receive(socket: Socket, destinationDir: File, localNodeId: String, listener: Listener) {
        try {
            socket.tcpNoDelay = false
            socket.keepAlive = true
            socket.sendBufferSize = SOCKET_BUFFER
            socket.receiveBufferSize = SOCKET_BUFFER
            val input = DataInputStream(BufferedInputStream(socket.getInputStream(), BUFFER_SIZE))
            require(input.readInt() == MAGIC) { "Protocole ZEE Fast Wi-Fi invalide" }
            require(input.readInt() == VERSION) { "Version Fast Wi-Fi inconnue" }
            val metaSize = input.readInt()
            require(metaSize in 1..64 * 1024) { "En-tête Fast Wi-Fi invalide" }
            val metaBytes = ByteArray(metaSize)
            input.readFully(metaBytes)
            val meta = Meta.fromJson(metaBytes)
            require(meta.fileSize in 0..MAX_FILE_SIZE) { "Taille de fichier invalide" }
            require(meta.fromNodeId.isNotBlank()) { "Expéditeur invalide" }
            require(meta.toNodeId == localNodeId) { "Destinataire Fast Wi-Fi incorrect" }

            val dest = File(destinationDir, "${meta.messageId}_${safeName(meta.fileName)}")
            FileOutputStream(dest).use { fos ->
                val out = BufferedOutputStream(fos, BUFFER_SIZE)
                val buffer = ByteArray(BUFFER_SIZE)
                var received = 0L
                while (received < meta.fileSize) {
                    val n = input.read(buffer, 0, minOf(buffer.size.toLong(), meta.fileSize - received).toInt())
                    if (n < 0) throw EOFException("Transfert Fast Wi-Fi interrompu")
                    out.write(buffer, 0, n)
                    received += n
                    listener.onProgress(received, meta.fileSize)
                }
                out.flush()
            }
            if (dest.length() != meta.fileSize) {
                dest.delete()
                throw IOException("Fichier Fast Wi-Fi incomplet")
            }
            listener.onComplete(dest, meta)
        } catch (e: Exception) {
            listener.onError(e)
        } finally {
            runCatching { socket.close() }
        }
    }

    private fun safeName(name: String): String =
        name.replace('\\', '_').replace('/', '_').trim().ifBlank { "fichier" }.take(180)
}
