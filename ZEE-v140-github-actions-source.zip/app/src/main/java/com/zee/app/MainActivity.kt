package com.zee.app

import android.Manifest
import android.content.Intent
import android.graphics.BitmapFactory
import android.graphics.Bitmap
import android.util.Base64
import java.io.ByteArrayOutputStream
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.tabs.TabLayout
import com.google.android.material.tabs.TabLayoutMediator
import androidx.viewpager2.widget.ViewPager2
import com.zee.app.model.Peer
import com.zee.app.model.ZeeModule
import com.zee.app.model.BusinessActivityStore
import com.zee.app.network.AdBroadcastScheduler
import com.zee.app.network.AdRelay
import com.zee.app.model.AdRelayStore
import com.zee.app.network.FileTransferManager
import com.zee.app.network.LocationEnabler
import com.zee.app.network.SessionRegistry
import com.zee.app.network.ChatLatencyTracker
import com.zee.app.network.WifiDirectManager
import com.zee.app.network.ZeeDiagnostic
import com.zee.app.network.WifiEnabler
import com.zee.app.network.ZeeMessageCodec
import com.zee.app.network.ZeeSocketSession
import com.zee.app.network.ZeeMeshServer
import com.zee.app.notification.NotificationHelper
import com.zee.app.ui.ProfileActivity
import com.zee.app.ui.TabsPagerAdapter
import com.zee.app.ui.HomeFragment
import com.zee.app.ui.PeerListFragment
import com.zee.app.ui.ThemeBackgrounds
import com.zee.app.ui.applyZeeEdgeToEdge
import kotlinx.coroutines.MainScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    companion object {
        private const val REQUEST_ENABLE_WIFI = 4821
        private const val REQUEST_ENABLE_LOCATION = 4822
    }

    private lateinit var wifiDirectManager: WifiDirectManager
    private val adScheduler = AdBroadcastScheduler(this)
    private val scope = MainScope()
    private var fileServerSocket: java.net.ServerSocket? = null
    private var fastWifiServerSocket: java.net.ServerSocket? = null
    // deviceAddress du pair vers lequel une connexion vient d'être demandée
    // (voir connectToPeer) — utilisé dans onConnected pour savoir à quel
    // pair associer la session qui vient de s'établir.
    private var pendingPeerAddress: String? = null
    private var meshServer: ZeeMeshServer? = null
    private lateinit var wifiAwareMeshManager: com.zee.app.network.WifiAwareMeshManager
    private lateinit var zeeWebRtcTransport: com.zee.app.network.ZeeWebRtcTransport
    private val seenMessageIds = java.util.Collections.synchronizedSet(mutableSetOf<String>())
    // IMPORTANT : android.os.Looper.getMainLooper() (statique) et non
    // "mainLooper" (hérité de Context) — cette propriété s'initialise
    // avant que l'activité soit attachée à son contexte système, et
    // "mainLooper" y provoquait une NullPointerException immédiate à
    // chaque lancement, avant l'accès aux onglets.
    private val reconnectHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var reconnectRunnable: Runnable? = null
    private var lastConnectedNodeId: String? = null
    private var lastConnectedDeviceAddress: String? = null
    @Volatile private var clientSession: ZeeSocketSession? = null
    @Volatile private var clientReconnectScheduled = false
    private val discoveryHeartbeat = object : Runnable {
        override fun run() {
            if (isFinishing || isDestroyed) return
            if (WifiEnabler.isWifiEnabled(this@MainActivity) && hasZeePermissions() &&
                SessionRegistry.active == null && !wifiDirectManager.isConnecting &&
                !wifiDirectManager.isDiscoveryRunning
            ) {
                // Relance seulement si le cycle est réellement arrêté (échec de
                // discoverServices, annonce perdue) : évite le bruit « already-active ».
                startDiscoveryIfReady()
            }
            reconnectHandler.postDelayed(this, 12_000L)
        }
    }

    private var connectionTimeoutRunnable: Runnable? = null
    // Évite de rouvrir en boucle les réglages de localisation lorsque l'utilisateur
    // revient avec le bouton Précédent sans avoir activé la localisation.
    private var locationSettingsOpened = false
    private var locationPromptDismissed = false

    // Callbacks enregistrés par les fragments d'onglet pour recevoir les mises
    // à jour de la liste de pairs (un simple pub/sub en mémoire, à remplacer
    // par un ViewModel partagé si le projet grossit).
    private val peerObservers = mutableMapOf<ZeeModule, (List<Peer>) -> Unit>()
    private val nearbyObservers = mutableListOf<(List<Peer>) -> Unit>()
    private var lastPeers: List<Peer> = emptyList()

    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { results ->
        ZeeDiagnostic.log(this, "PERMISSION_RESULT " + results.entries.joinToString { "${it.key}=${it.value}" })
        if (results.values.all { it }) {
            startDiscoveryIfReady()
        } else {
            ZeeDiagnostic.log(this, "PERMISSION_DENIED: Wi-Fi Direct diagnostic impossible tant que les permissions requises ne sont pas accordées")
        }
    }

    /**
     * Point d'entrée unique pour lancer la découverte : vérifie d'abord que
     * la localisation système est activée si nécessaire (voir
     * LocationEnabler — obligatoire sur Android 10 à 12 pour que la
     * découverte Wi-Fi Direct fonctionne, sans quoi aucun appareil n'est
     * jamais trouvé). Si elle est désactivée, ouvre directement l'écran de
     * réglage au lieu de lancer une recherche qui ne trouvera jamais rien.
     */
    private fun startDiscoveryIfReady(forceRestart: Boolean = false) {
        ZeeDiagnostic.log(this, "DISCOVERY_IF_READY wifi=${WifiEnabler.isWifiEnabled(this)} locationRequired=${LocationEnabler.isRequired()} locationEnabled=${LocationEnabler.isLocationEnabled(this)} perms=${hasZeePermissionsSafe()}")
        if (LocationEnabler.isRequired() && !LocationEnabler.isLocationEnabled(this)) {
            if (!locationPromptDismissed && !locationSettingsOpened) {
                locationSettingsOpened = true
                LocationEnabler.ensureEnabledIfRequired(this, REQUEST_ENABLE_LOCATION)
            }
            return
        }
        locationPromptDismissed = false
        locationSettingsOpened = false
        if (::wifiDirectManager.isInitialized && wifiDirectManager.isConnecting) return
        wifiDirectManager.startDiscovery(forceRestart)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        setContentView(R.layout.activity_main)

        setupTabs()
        enforceAgeGate()
        SessionRegistry.initialize(applicationContext)
        setupWebRtcTransport()
        setupWifiDirect()
        setupWifiAware()
        requestZeePermissions()
        NotificationHelper.ensureChannel(this)
        applyZeeEdgeToEdge(topInsetView = findViewById(R.id.headerContainer))
        // Active le Wi-Fi automatiquement au lancement de ZEE, condition
        // indispensable au fonctionnement de l'app (voir WifiEnabler.kt
        // pour le détail des restrictions Android 10+).
        WifiEnabler.ensureWifiEnabled(this, REQUEST_ENABLE_WIFI)
        // Diffuse périodiquement les pubs des vendeurs à proximité ayant un
        // code actif — "ils ont droit à une pub, mais plein de temps".
        adScheduler.start(
            peersProvider = { lastPeers },
            broadcaster = { ad, neighborNodeId -> sendAdToNode(ad, neighborNodeId) }
        )

        findViewById<android.widget.ImageButton>(R.id.btnProfileMenu).setOnClickListener {
            val currentPosition = findViewById<ViewPager2>(R.id.viewPager).currentItem
            if (currentPosition == TabsPagerAdapter.HOME_POSITION) {
                showHomeSettings()
            } else {
                val currentModule = TabsPagerAdapter.moduleAt(currentPosition) ?: ZeeModule.CHAT
                startActivity(Intent(this, ProfileActivity::class.java).apply {
                    putExtra(ProfileActivity.EXTRA_MODULE, currentModule.name)
                })
            }
        }

        findViewById<android.widget.ImageButton>(R.id.btnChatBack).setOnClickListener {
            findViewById<androidx.viewpager2.widget.ViewPager2>(R.id.viewPager).currentItem = TabsPagerAdapter.HOME_POSITION
        }
        findViewById<android.widget.ImageButton>(R.id.btnChatShare).setOnClickListener {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Rejoignez-moi sur ZEE Rencontres.")
            }, "Partager"))
        }
        findViewById<android.widget.ImageButton>(R.id.btnChatFavorite).setOnClickListener { button ->
            val prefs = getSharedPreferences("zee_chat_ui", MODE_PRIVATE)
            val favorite = !prefs.getBoolean("favorite", false)
            prefs.edit().putBoolean("favorite", favorite).apply()
            (button as android.widget.ImageButton).setImageResource(if (favorite) R.drawable.ic_star_filled_white else R.drawable.ic_star_outline_white)
            android.widget.Toast.makeText(this, getString(if (favorite) com.zee.app.R.string.favorite_added_chat else com.zee.app.R.string.favorite_removed_chat), android.widget.Toast.LENGTH_SHORT).show()
        }
        findViewById<android.widget.ImageButton>(R.id.btnChatMore).setOnClickListener { anchor ->
            androidx.appcompat.widget.PopupMenu(this, anchor).apply {
                menu.add(getString(com.zee.app.R.string.kt_actualiser)).setOnMenuItemClickListener { refreshPeers(); true }
                menu.add(getString(com.zee.app.R.string.kt_param_tres_du_profil)).setOnMenuItemClickListener {
                    openModuleProfileSettings(ZeeModule.CHAT)
                    true
                }
                menu.add(getString(com.zee.app.R.string.kt_publicit)).setOnMenuItemClickListener {
                    openModuleAdSettings(ZeeModule.CHAT)
                    true
                }
                menu.add(getString(com.zee.app.R.string.kt_param_tres_r_seau)).setOnMenuItemClickListener { showHomeSettings(); true }
                show()
            }
        }
        val chatFav = getSharedPreferences("zee_chat_ui", MODE_PRIVATE).getBoolean("favorite", false)
        findViewById<android.widget.ImageButton>(R.id.btnChatFavorite).setImageResource(
            if (chatFav) R.drawable.ic_star_filled_white else R.drawable.ic_star_outline_white
        )

        findViewById<android.widget.ImageButton>(R.id.btnBusinessBack).setOnClickListener {
            findViewById<ViewPager2>(R.id.viewPager).setCurrentItem(TabsPagerAdapter.HOME_POSITION, true)
        }
        findViewById<android.widget.ImageButton>(R.id.btnBusinessShare).setOnClickListener {
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Découvrez ZEE Business : connectez-vous, échangez et développez vos opportunités à proximité.")
            }
            startActivity(Intent.createChooser(share, "Partager ZEE Business"))
        }
        findViewById<android.widget.ImageButton>(R.id.btnBusinessFavorite).setOnClickListener { button ->
            val prefs = getSharedPreferences("zee_business_ui", MODE_PRIVATE)
            val favorite = !prefs.getBoolean("favorite", false)
            prefs.edit().putBoolean("favorite", favorite).apply()
            (button as android.widget.ImageButton).setImageResource(if (favorite) R.drawable.ic_star_filled_white else R.drawable.ic_star_outline_white)
            android.widget.Toast.makeText(this, getString(if (favorite) com.zee.app.R.string.favorite_added_business else com.zee.app.R.string.favorite_removed_business), android.widget.Toast.LENGTH_SHORT).show()
        }
        findViewById<android.widget.ImageButton>(R.id.btnBusinessMore).setOnClickListener { anchor ->
            androidx.appcompat.widget.PopupMenu(this, anchor).apply {
                menu.add(getString(com.zee.app.R.string.kt_actualiser_les_activit_s)).setOnMenuItemClickListener {
                    refreshPeers()
                    findViewById<ViewPager2>(R.id.viewPager).adapter?.notifyDataSetChanged()
                    true
                }
                menu.add(getString(com.zee.app.R.string.kt_param_tres_du_profil_business)).setOnMenuItemClickListener {
                    openModuleProfileSettings(ZeeModule.MARKET)
                    true
                }
                menu.add(getString(com.zee.app.R.string.kt_publicit_business)).setOnMenuItemClickListener {
                    openModuleAdSettings(ZeeModule.MARKET)
                    true
                }
                menu.add(getString(com.zee.app.R.string.kt_param_tres_r_seau)).setOnMenuItemClickListener { showHomeSettings(); true }
                show()
            }
        }

        val fav = getSharedPreferences("zee_business_ui", MODE_PRIVATE).getBoolean("favorite", false)
        findViewById<android.widget.ImageButton>(R.id.btnBusinessFavorite).setImageResource(
            if (fav) R.drawable.ic_star_filled_white else R.drawable.ic_star_outline_white
        )

        findViewById<android.widget.ImageButton>(R.id.btnJobBack).setOnClickListener {
            findViewById<ViewPager2>(R.id.viewPager).setCurrentItem(TabsPagerAdapter.HOME_POSITION, true)
        }
        findViewById<android.widget.ImageButton>(R.id.btnJobShare).setOnClickListener {
            val share = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, "Découvrez ZEE Job : chercheurs d'emploi et recruteurs visibles à proximité.")
            }
            startActivity(Intent.createChooser(share, "Partager ZEE Job"))
        }
        findViewById<android.widget.ImageButton>(R.id.btnJobFavorite).setOnClickListener { button ->
            val prefs = getSharedPreferences("zee_job_ui", MODE_PRIVATE)
            val favorite = !prefs.getBoolean("favorite", false)
            prefs.edit().putBoolean("favorite", favorite).apply()
            (button as android.widget.ImageButton).setImageResource(if (favorite) R.drawable.ic_star_filled_white else R.drawable.ic_star_outline_white)
            android.widget.Toast.makeText(this, getString(if (favorite) com.zee.app.R.string.favorite_added_job else com.zee.app.R.string.favorite_removed_job), android.widget.Toast.LENGTH_SHORT).show()
        }
        findViewById<android.widget.ImageButton>(R.id.btnJobMore).setOnClickListener { anchor ->
            androidx.appcompat.widget.PopupMenu(this, anchor).apply {
                menu.add(getString(com.zee.app.R.string.kt_actualiser)).setOnMenuItemClickListener { refreshPeers(); true }
                menu.add(getString(com.zee.app.R.string.kt_param_tres_du_profil_job)).setOnMenuItemClickListener {
                    openModuleProfileSettings(ZeeModule.JOB)
                    true
                }
                menu.add(getString(com.zee.app.R.string.kt_publicit_job)).setOnMenuItemClickListener {
                    openModuleAdSettings(ZeeModule.JOB)
                    true
                }
                menu.add(getString(com.zee.app.R.string.kt_param_tres_r_seau)).setOnMenuItemClickListener { showHomeSettings(); true }
                show()
            }
        }
        val jobFav = getSharedPreferences("zee_job_ui", MODE_PRIVATE).getBoolean("favorite", false)
        findViewById<android.widget.ImageButton>(R.id.btnJobFavorite).setImageResource(
            if (jobFav) R.drawable.ic_star_filled_white else R.drawable.ic_star_outline_white
        )
    }

    /**
     * Initialise le transport WebRTC DataChannel inspiré de Snapdrop.
     *
     * La découverte reste Wi-Fi Direct/Aware. Le canal TCP ZEE sert de
     * signalisation OFFER/ANSWER/ICE, puis WebRTC tente un chemin P2P chiffré
     * directement sur le réseau local. En cas d'échec, le chat continue sur
     * TCP/mesh sans changement d'UX.
     */
    private fun setupWebRtcTransport() {
        zeeWebRtcTransport = com.zee.app.network.ZeeWebRtcTransport(
            context = this,
            localNodeIdProvider = { SessionRegistry.localNodeId },
            signalSender = { remoteNodeId, signal ->
                SessionRegistry.routeTo(remoteNodeId, signal)
            },
            onReady = { remoteNodeId ->
                ZeeDiagnostic.log(this, "WEBRTC_READY node=$remoteNodeId")
                android.util.Log.d("ZeeWebRtc", "Canal P2P WebRTC ZEE prêt pour $remoteNodeId")
            },
            onClosed = { remoteNodeId ->
                ZeeDiagnostic.log(this, "WEBRTC_CLOSED node=$remoteNodeId")
                SessionRegistry.onWebRtcClosed(remoteNodeId)
            },
            onData = { remoteNodeId, packet ->
                when (packet) {
                    is com.zee.app.network.ZeeWebRtcTransport.Packet.Line -> {
                        handleIncomingMessageForWebRtc(remoteNodeId, packet.json)
                    }
                    is com.zee.app.network.ZeeWebRtcTransport.Packet.FileStart -> {
                        com.zee.app.network.FileTransferManager.onWebRtcFileStart(
                            context = this,
                            remoteNodeId = remoteNodeId,
                            messageId = packet.messageId,
                            fromNodeId = packet.fromNodeId,
                            toNodeId = packet.toNodeId,
                            ttl = packet.ttl,
                            fileName = packet.fileName,
                            mimeType = packet.mimeType,
                            fileSize = packet.fileSize,
                            kind = packet.kind,
                            requestedOffset = packet.resumeOffset
                        ).also { resumeOffset ->
                            zeeWebRtcTransport.sendFileResumeAck(remoteNodeId, packet.messageId, resumeOffset)
                        }
                    }
                    is com.zee.app.network.ZeeWebRtcTransport.Packet.FileChunk -> {
                        com.zee.app.network.FileTransferManager.onWebRtcFileChunk(
                            context = this, remoteNodeId = remoteNodeId,
                            messageId = packet.messageId, sequence = packet.sequence,
                            offset = packet.offset, end = packet.end, data = packet.data
                        ).also { ackOffset ->
                            if (ackOffset >= 0L) {
                                zeeWebRtcTransport.sendFileResumeAck(remoteNodeId, packet.messageId, ackOffset)
                            }
                        }
                    }
                    is com.zee.app.network.ZeeWebRtcTransport.Packet.FileEnd -> {
                        com.zee.app.network.FileTransferManager.onWebRtcFileEnd(
                            context = this, remoteNodeId = remoteNodeId, messageId = packet.messageId
                        )
                    }
                    // FileResumeAck est consommé en interne par ZeeWebRtcTransport
                    // pour réveiller l'émetteur de fichier; il ne remonte donc pas
                    // normalement jusqu'à ce callback. La branche est néanmoins
                    // requise car Packet est un sealed class exhaustif.
                    is com.zee.app.network.ZeeWebRtcTransport.Packet.FileResumeAck -> Unit
                }
            }
        )
        SessionRegistry.registerWebRtcTransport(
            ready = { nodeId -> zeeWebRtcTransport.isReady(nodeId) },
            sendLine = { nodeId, line -> zeeWebRtcTransport.sendLine(nodeId, line) },
            sendFile = { nodeId, file, messageId, fromNodeId, toNodeId, fileName, fileSize, mimeType, ttl, kind ->
                runCatching {
                    java.io.FileInputStream(file).use { input ->
                        zeeWebRtcTransport.sendFile(
                            remoteNodeId = nodeId, messageId = messageId, fromNodeId = fromNodeId,
                            toNodeId = toNodeId, ttl = ttl, fileName = fileName, mimeType = mimeType,
                            fileSize = fileSize, kind = kind, input = input
                        )
                    }
                }.getOrDefault(false)
            }
        )
        com.zee.app.network.FileTransferManager.webRtcCompletionListener = { file, meta ->
            if (meta.kind == "AD_MEDIA") {
                com.zee.app.network.AdRelay.onAdMediaReceived(this, meta.messageId, file, meta.mimeType, meta.fileName)
            } else {
                val channel = com.zee.app.model.MessageChannels.normalize(meta.kind)
                val type = when {
                    meta.mimeType.startsWith("image/") -> com.zee.app.model.MessageType.IMAGE
                    meta.mimeType.startsWith("video/") -> com.zee.app.model.MessageType.VIDEO
                    meta.mimeType.startsWith("audio/") -> com.zee.app.model.MessageType.AUDIO
                    else -> com.zee.app.model.MessageType.DOCUMENT
                }
                val persistent = com.zee.app.model.MessageStore.copyFileToPersistent(this, file, channel, meta.fileName)
                val finalPath = persistent?.absolutePath ?: file.absolutePath
                com.zee.app.model.MessageStore.save(
                    this, meta.messageId, meta.fromNodeId, channel, meta.fromNodeId, false,
                    type, meta.fileName, finalPath, meta.fileName, meta.mimeType
                )
                if (SessionRegistry.activeChatNodeId == meta.fromNodeId &&
                    SessionRegistry.activeChatChannel == channel) {
                    runOnUiThread {
                        SessionRegistry.activeAttachmentListener?.invoke(persistent ?: file, meta.mimeType, meta.fileName, meta.fromNodeId)
                    }
                } else {
                val peer = lastPeers.firstOrNull { it.nodeId == meta.fromNodeId }
                runOnUiThread {
                    NotificationHelper.showMessageNotification(
                        this, peer?.deviceAddress ?: meta.fromNodeId,
                        peer?.displayName ?: "ZEE", "Nouvelle pièce jointe : ${meta.fileName}"
                    )
                }
            }
        }
    }

        }

/** Initialise le transport Wi-Fi Aware en complément de Wi-Fi Direct.
     *  Aware est automatique : dès qu'un voisin ZEE compatible est découvert,
     *  un data-path est établi et branché sur le même routeur de messages.
     */
    private fun setupWifiAware() {
        wifiAwareMeshManager = com.zee.app.network.WifiAwareMeshManager(
            context = this,
            scope = scope,
            localNodeIdProvider = {
                SessionRegistry.localNodeId.ifBlank {
                    com.zee.app.model.ProfileStore.getNodeId(this)
                }
            },
            onSessionReady = { nodeId, session ->
                SessionRegistry.registerSession(nodeId, session)
                sendAwareHandshake(session)
                android.util.Log.d("MainActivity", "Lien Wi-Fi Aware ZEE établi avec $nodeId")
            },
            onLine = { session, line -> handleIncomingMessage(session, line) },
            onPeerSeen = { nodeId, visibleModules, criteria ->
                runOnUiThread { addAwarePeerIfMissing(nodeId, visibleModules, criteria) }
            },
            onError = { error ->
                android.util.Log.w("MainActivity", "Wi-Fi Aware indisponible/erreur: ${error.message}")
            }
        )
    }

    private fun sendAllModuleProfiles(session: ZeeSocketSession) {
        val name = com.zee.app.model.ProfileStore.getDisplayName(this)
        ZeeModule.values().forEach { module ->
            if (!com.zee.app.model.VisibilityStore.isVisible(this, module)) return@forEach
            val actu = com.zee.app.model.ProfileStore.getModuleActu(this, module)
            val photo = encodeProfilePhoto(com.zee.app.model.ProfileStore.getModulePhotoUri(this, module))
            session.send(
                ZeeMessageCodec.encodeProfile(
                    SessionRegistry.localNodeId, name, actu, photo,
                    direct = true, module = module
                )
            )
        }
    }

    private fun sendAwareHandshake(session: ZeeSocketSession) {
        session.send(ZeeMessageCodec.encodeHello(SessionRegistry.localNodeId))
        sendAllModuleProfiles(session)
        AdRelayStore.getActiveAds(this).forEach { ad ->
            val target = session.remoteAddress?.let { addr -> lastPeers.firstOrNull { it.deviceAddress == addr }?.nodeId }
            if (!target.isNullOrBlank()) sendAdToNode(ad, target) else session.send(ZeeMessageCodec.encodeAd(ad))
        }
        SessionRegistry.flushPendingChatMessages()
    }

    private fun addAwarePeerIfMissing(nodeId: String, visibleModules: Set<ZeeModule>, criteria: Map<ZeeModule, String>) {
        if (nodeId.isBlank() || nodeId == SessionRegistry.localNodeId) return
        val existing = lastPeers.firstOrNull { it.nodeId == nodeId }
        if (existing != null) return
        val awarePeer = Peer(
            deviceAddress = "aware:$nodeId",
            deviceName = "ZEE",
            nodeId = nodeId,
            displayName = null,
            visibleModules = visibleModules,
            criteriaByModule = criteria
        )
        lastPeers = lastPeers + awarePeer
        peerObservers.values.forEach { it(lastPeers) }
    }

    /**
     * Accès à ZEE conditionné par une confirmation explicite 21+.
     * Tant que la réponse n'est pas « Oui », les pages de l'application restent
     * bloquées. « Non » ferme immédiatement l'application.
     */
    private fun enforceAgeGate() {
        if (com.zee.app.model.ProfileStore.isAgeConfirmed(this)) return

        val viewPager = findViewById<androidx.viewpager2.widget.ViewPager2>(R.id.viewPager)
        val tabLayout = findViewById<com.google.android.material.tabs.TabLayout>(R.id.tabLayout)
        viewPager.visibility = View.INVISIBLE
        tabLayout.visibility = View.INVISIBLE

        val gateView = layoutInflater.inflate(R.layout.dialog_age_gate, null, false)
        val dialog = androidx.appcompat.app.AlertDialog.Builder(this)
            .setView(gateView)
            .setCancelable(false)
            .create()

        gateView.findViewById<android.widget.Button>(R.id.btnAgeConfirm).setOnClickListener {
            com.zee.app.model.ProfileStore.setAgeConfirmed(this, true)
            viewPager.visibility = View.VISIBLE
            tabLayout.visibility = View.VISIBLE
            dialog.dismiss()
        }
        gateView.findViewById<android.widget.TextView>(R.id.btnAgeDecline).setOnClickListener {
            dialog.dismiss()
            finishAndRemoveTask()
        }
        dialog.setOnShowListener {
            dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)
            dialog.window?.setLayout(
                (resources.displayMetrics.widthPixels * 0.90f).toInt(),
                android.view.WindowManager.LayoutParams.WRAP_CONTENT
            )
        }
        dialog.show()
    }

    private fun setupTabs() {
        val viewPager = findViewById<ViewPager2>(R.id.viewPager)
        val tabLayout = findViewById<TabLayout>(R.id.tabLayout)
        viewPager.adapter = TabsPagerAdapter(this)
        viewPager.offscreenPageLimit = 3
        viewPager.isUserInputEnabled = true

        val titles = listOf(
            R.string.tab_home,
            R.string.tab_market,
            R.string.tab_job,
            R.string.tab_chat
        )
        val icons = listOf(
            R.drawable.ic_home_white,
            R.drawable.ic_business_handshake_white,
            R.drawable.ic_job_briefcase_white,
            R.drawable.ic_live_chat_people_white
        )

        TabLayoutMediator(tabLayout, viewPager) { tab, position ->
            val custom = layoutInflater.inflate(R.layout.item_bottom_tab, tabLayout, false)
            val icon = custom.findViewById<android.widget.ImageView>(R.id.tabIcon)
            val text = custom.findViewById<android.widget.TextView>(R.id.tabText)
            icon.setImageResource(icons[position])
            // Le PNG du porte-documents occupe davantage son canevas que les autres icônes.
            // Réduire légèrement son rendu sans modifier la taille de la zone tactile.
            val jobIconScale = if (position == TabsPagerAdapter.JOB_POSITION) 0.88f else 1f
            icon.scaleX = jobIconScale
            icon.scaleY = jobIconScale
            icon.imageTintList = ContextCompat.getColorStateList(this, R.color.tab_icon_tint)
            text.text = getString(titles[position])
            text.setTextColor(ContextCompat.getColorStateList(this, R.color.tab_text_state))
            custom.alpha = 1f
            tab.customView = custom
        }.attach()

        fun updateBottomTabState(position: Int, selected: Boolean) {
            tabLayout.getTabAt(position)?.customView?.let { custom ->
                custom.isSelected = selected
                custom.findViewById<android.widget.ImageView>(R.id.tabIcon)?.let { icon ->
                    icon.isSelected = selected
                    // Toutes les icônes de la barre suivent le même état sélectionné/non sélectionné.
                    icon.imageTintList = android.content.res.ColorStateList.valueOf(
                        ContextCompat.getColor(this, if (selected) R.color.zee_blue else R.color.zee_text_muted)
                    )
                }
                custom.findViewById<android.widget.TextView>(R.id.tabText)?.isSelected = selected
                custom.alpha = 1f
                custom.findViewById<android.widget.TextView>(R.id.tabText)
                    ?.setTypeface(null, if (selected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL)
            }
        }

        viewPager.registerOnPageChangeCallback(object : ViewPager2.OnPageChangeCallback() {
            override fun onPageSelected(position: Int) {
                for (i in 0 until tabLayout.tabCount) updateBottomTabState(i, i == position)
                updateHeaderForPosition(position)
                if (position == TabsPagerAdapter.HOME_POSITION) startDiscoveryIfReady()
            }
        })
        for (i in 0 until tabLayout.tabCount) updateBottomTabState(i, i == viewPager.currentItem)
        updateHeaderForPosition(viewPager.currentItem)
    }

    private fun updateHeaderForPosition(position: Int) {
        val isBusiness = position == TabsPagerAdapter.BUSINESS_POSITION
        val isJob = position == TabsPagerAdapter.JOB_POSITION
        val isChat = position == TabsPagerAdapter.CHAT_POSITION
        findViewById<View>(R.id.headerBusiness)?.visibility = if (isBusiness) View.VISIBLE else View.GONE
        findViewById<View>(R.id.headerJob)?.visibility = if (isJob) View.VISIBLE else View.GONE
        findViewById<View>(R.id.headerChat)?.visibility = if (isChat) View.VISIBLE else View.GONE
        findViewById<View>(R.id.headerStandard)?.visibility = if (isBusiness || isJob || isChat) View.GONE else View.VISIBLE

        if (!isBusiness && !isJob && !isChat) {
            findViewById<android.widget.ImageView>(R.id.imgHeaderSectionStandard)?.apply {
                setImageResource(when (position) {
                    TabsPagerAdapter.CHAT_POSITION -> R.drawable.ic_live_chat_people_white
                    TabsPagerAdapter.JOB_POSITION -> R.drawable.ic_job_briefcase_white
                    else -> R.drawable.ic_home_white
                })
                visibility = if (position == TabsPagerAdapter.HOME_POSITION) View.GONE else View.VISIBLE
            }
            findViewById<android.widget.TextView>(R.id.txtHeaderSectionStandard)?.apply {
                visibility = if (position == TabsPagerAdapter.HOME_POSITION) View.GONE else View.VISIBLE
                text = when (position) {
                    TabsPagerAdapter.CHAT_POSITION -> getString(R.string.tab_chat)
                    TabsPagerAdapter.JOB_POSITION -> getString(R.string.tab_job)
                    else -> getString(R.string.tab_home)
                }
            }
            findViewById<android.widget.ImageButton>(R.id.btnProfileMenu)?.apply {
                setImageResource(if (position == TabsPagerAdapter.HOME_POSITION) R.drawable.ic_settings_white else R.drawable.ic_person_white)
                contentDescription = if (position == TabsPagerAdapter.HOME_POSITION) "Paramètres" else getString(R.string.profile_title)
            }
        }
    }

    /** Ouvre les réglages du profil du module sélectionné, sans toucher aux deux autres modules. */
    private fun openModuleProfileSettings(module: ZeeModule) {
        startActivity(Intent(this, ProfileActivity::class.java).apply {
            putExtra(ProfileActivity.EXTRA_MODULE, module.name)
            putExtra(ProfileActivity.EXTRA_OPEN_AD, false)
        })
    }

    /** Ouvre directement la section publicité du module courant. Les champs, achat WhatsApp,
     * choix du média et validation du code sont ainsi accessibles indépendamment par onglet. */
    private fun openModuleAdSettings(module: ZeeModule) {
        startActivity(Intent(this, ProfileActivity::class.java).apply {
            putExtra(ProfileActivity.EXTRA_MODULE, module.name)
            putExtra(ProfileActivity.EXTRA_OPEN_AD, true)
        })
    }

    /** Réapplique le thème choisi aux quatre pages déjà conservées par le ViewPager. */
    fun refreshPageThemes() {
        supportFragmentManager.fragments.forEach { fragment ->
            when (fragment) {
                is HomeFragment -> fragment.refreshTheme()
                is PeerListFragment -> fragment.refreshTheme()
            }
        }
    }

    /** Sélecteur de paramètres affiché par l'engrenage de l'accueil. */
    private fun showHomeSettings() {
        androidx.appcompat.app.AlertDialog.Builder(this)
            .setTitle(R.string.settings_title)
            .setItems(R.array.main_settings_items) { _, which ->
                when (which) {
                    0 -> ThemeBackgrounds.showPicker(this) { refreshPageThemes() }
                    1 -> com.zee.app.ui.LanguageSettings.showPicker(this)
                    2 -> startActivity(Intent(this, com.zee.app.ui.NetworkDiagnosticActivity::class.java))
                    3 -> try {
                        startActivity(Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).apply {
                            putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
                        })
                    } catch (_: Exception) {
                        startActivity(Intent(Settings.ACTION_SETTINGS))
                    }
                    4 -> startActivity(Intent(Settings.ACTION_WIFI_SETTINGS))
                }
            }
            .setNegativeButton(R.string.settings_close, null)
            .show()
    }

    /** Ouvre le canal TCP ZEE vers le Group Owner. Après une perte TCP,
     * on recrée uniquement le socket : inutile de renégocier Wi-Fi Direct
     * tant que le groupe P2P existe encore. Cela évite les boucles
     * connect()/disconnect() qui peuvent laisser Android dans un état
     * CONNECTED sans canal applicatif. */
    private fun openClientSession(groupOwnerAddress: String) {
        if (groupOwnerAddress.isBlank() || isFinishing || isDestroyed) return
        if (clientSession != null) return
        lateinit var session: ZeeSocketSession
        session = ZeeSocketSession(
            scope = scope,
            onMessageReceived = { line -> handleIncomingMessage(session, line) },
            onSessionReady = {
                clientSession = session
                SessionRegistry.registerSession(lastConnectedNodeId?.takeIf { it.isNotBlank() }, session)
                SessionRegistry.peerRemoteAddress = session.remoteAddress
                android.util.Log.d("ZeeProtocol", "TCP_CLIENT_CONNECTED remote=${SessionRegistry.peerAddress(session)}")
                sendClientHandshake(session)
            },
            onSessionError = { e ->
                android.util.Log.w("MainActivity", "Canal TCP ZEE perdu: ${e.message ?: e.javaClass.simpleName}")
                if (clientSession === session) clientSession = null
                scheduleClientReconnect(groupOwnerAddress)
            }
        )
        session.onClosed = {
            removePeersForClosedSession(session)
            if (clientSession === session) clientSession = null
            SessionRegistry.removeSession(lastConnectedNodeId, session)
            scheduleClientReconnect(groupOwnerAddress)
        }
        clientSession = session
        session.startAsClient(groupOwnerAddress)
    }

    private fun sendClientHandshake(session: ZeeSocketSession) {
        session.send(ZeeMessageCodec.encodeHello(SessionRegistry.localNodeId))
        sendAllModuleProfiles(session)
        android.util.Log.d("ZeeProtocol", "MODULE_PROFILES_SENT nodeId=${SessionRegistry.localNodeId} remote=${SessionRegistry.peerAddress(session)}")
        scope.launch(Dispatchers.IO) {
            kotlinx.coroutines.delay(700L)
            sendAllModuleProfiles(session)
        }
        AdRelayStore.getActiveAds(this).forEach { ad ->
            val target = session.remoteAddress?.let { addr -> lastPeers.firstOrNull { it.deviceAddress == addr }?.nodeId }
            if (!target.isNullOrBlank()) sendAdToNode(ad, target) else session.send(ZeeMessageCodec.encodeAd(ad))
        }
        SessionRegistry.flushPendingChatMessages()
    }

    /** Envoie une publicité complète : métadonnées JSON + média binaire éventuel. */
    private fun sendAdToNode(ad: com.zee.app.model.AdPayload, neighborNodeId: String): Boolean {
        val mediaFile = ad.mediaPath?.let { java.io.File(it) }?.takeIf { it.isFile && it.length() > 0L }
        val mediaMime = ad.mediaMimeType.orEmpty()
        if (mediaFile != null && mediaMime.isNotBlank()) {
            val host = SessionRegistry.nextHopAddress(neighborNodeId)
            if (host != null) {
                val meta = FileTransferManager.TransferMeta(
                    messageId = ad.id,
                    fromNodeId = SessionRegistry.localNodeId,
                    toNodeId = neighborNodeId,
                    ttl = 8,
                    fileName = ad.mediaFileName?.ifBlank { mediaFile.name } ?: mediaFile.name,
                    mimeType = mediaMime,
                    fileSize = mediaFile.length(),
                    kind = "AD_MEDIA"
                )
                FileTransferManager.sendLocalFile(
                    scope, host, meta, mediaFile,
                    object : FileTransferManager.ProgressListener {
                        override fun onProgress(sentBytes: Long, totalBytes: Long) {}
                        override fun onComplete(file: java.io.File, meta: FileTransferManager.TransferMeta) {}
                        override fun onError(error: Exception) {
                            android.util.Log.e("ZeeAds", "Échec média pub ${ad.id}: ${error.message}")
                        }
                    }
                )
            }
        }
        // Le JSON est routé indépendamment du binaire : le récepteur sait
        // attendre le fichier si celui-ci arrive avant ou après.
        return SessionRegistry.routeTo(neighborNodeId, ZeeMessageCodec.encodeAd(ad))
    }


    private fun scheduleClientReconnect(groupOwnerAddress: String) {
        if (isFinishing || isDestroyed || groupOwnerAddress.isBlank()) return
        if (clientReconnectScheduled) return
        clientReconnectScheduled = true
        reconnectHandler.postDelayed({
            clientReconnectScheduled = false
            if (!isFinishing && !isDestroyed && SessionRegistry.active?.isGroupOwner == false) {
                openClientSession(groupOwnerAddress)
            }
        }, 1500L)
    }

    private fun setupWifiDirect() {
        ZeeDiagnostic.log(this, "SETUP_WIFI_DIRECT")
        wifiDirectManager = WifiDirectManager(
            context = this,
            onPeersChanged = { peers ->
                lastPeers = mergeDiscoveredPeers(peers)
                // Diffuse à l'onglet actuellement observé ; en pratique, on
                // enrichirait chaque Peer avec son "module" déclaré (échangé
                // au moment du handshake applicatif) pour filtrer proprement.
                peerObservers.values.forEach { it(lastPeers) }
                nearbyObservers.toList().forEach { it(lastPeers) }
            },
            onConnected = { groupOwnerAddress, isGroupOwner, connectedPeerAddress ->
                connectionTimeoutRunnable?.let { reconnectHandler.removeCallbacks(it) }
                connectionTimeoutRunnable = null
                SessionRegistry.active = SessionRegistry.ConnectionInfo(groupOwnerAddress, isGroupOwner)
                // En mode Group Owner, requestGroupInfo() peut retourner le
                // premier client du groupe alors que l'utilisateur vient d
                // ouvrir un autre pair. Pour le chat courant, la cible est
                // toujours le pair explicitement sélectionné.
                SessionRegistry.connectedPeerAddress = if (isGroupOwner) {
                    pendingPeerAddress ?: connectedPeerAddress
                } else {
                    connectedPeerAddress ?: pendingPeerAddress
                }
                SessionRegistry.localNodeId = com.zee.app.model.ProfileStore.getNodeId(this)
                SessionRegistry.initialize(applicationContext)
                lastConnectedDeviceAddress = SessionRegistry.connectedPeerAddress
                lastConnectedNodeId = lastConnectedDeviceAddress?.let { addr -> lastPeers.firstOrNull { it.deviceAddress == addr }?.nodeId }
                reconnectRunnable?.let { reconnectHandler.removeCallbacks(it) }

                runOnUiThread {
                    android.widget.Toast.makeText(
                        this,
                        "Wi-Fi Direct connecté (${if (isGroupOwner) "réseau ZEE / hôte" else "réseau ZEE / relais"}) — canal maillé…",
                        android.widget.Toast.LENGTH_LONG
                    ).show()
                }

                if (fileServerSocket == null) {
                    fileServerSocket = FileTransferManager.startListening(
                        scope = scope,
                        destinationDir = com.zee.app.model.MessageStore.mediaDir(this@MainActivity, "CHAT"),
                        localNodeId = SessionRegistry.localNodeId,
                        nextHopAddress = { target -> SessionRegistry.nextHopAddress(target) },
                        listener = object : FileTransferManager.ProgressListener {
                            override fun onProgress(sentBytes: Long, totalBytes: Long) {}
                            override fun onComplete(file: java.io.File, meta: FileTransferManager.TransferMeta) {
                                if (meta.kind == "AD_MEDIA") {
                                    com.zee.app.network.AdRelay.onAdMediaReceived(
                                        this@MainActivity, meta.messageId, file, meta.mimeType, meta.fileName
                                    )
                                    return
                                }
                                val channel = com.zee.app.model.MessageChannels.normalize(meta.kind)
                                val messageType = when {
                                    meta.mimeType.startsWith("image/") -> com.zee.app.model.MessageType.IMAGE
                                    meta.mimeType.startsWith("video/") -> com.zee.app.model.MessageType.VIDEO
                                    meta.mimeType.startsWith("audio/") -> com.zee.app.model.MessageType.AUDIO
                                    else -> com.zee.app.model.MessageType.DOCUMENT
                                }
                                val persistent = com.zee.app.model.MessageStore.copyFileToPersistent(
                                    this@MainActivity, file, channel, meta.fileName
                                )
                                val finalPath = persistent?.absolutePath ?: file.absolutePath
                                com.zee.app.model.MessageStore.save(
                                    this@MainActivity,
                                    meta.messageId,
                                    meta.fromNodeId,
                                    channel,
                                    meta.fromNodeId,
                                    false,
                                    messageType,
                                    meta.fileName,
                                    finalPath,
                                    meta.fileName,
                                    meta.mimeType
                                )
                                if (SessionRegistry.activeChatNodeId == meta.fromNodeId &&
                                    SessionRegistry.activeChatChannel == channel) {
                                    runOnUiThread {
                                        SessionRegistry.activeAttachmentListener?.invoke(
                                            persistent ?: file, meta.mimeType, meta.fileName, meta.fromNodeId
                                        )
                                    }
                                }
                                runOnUiThread {
                                    val addr = SessionRegistry.connectedPeerAddress
                                    if (addr != null && SessionRegistry.activeChatPeerAddress != addr) {
                                        val peer = lastPeers.find { it.deviceAddress == addr }
                                        NotificationHelper.showMessageNotification(
                                            this@MainActivity, addr,
                                            peer?.displayName ?: peer?.deviceName ?: "ZEE",
                                            "Pièce jointe reçue"
                                        )
                                    }
                                }
                            }
                            override fun onError(error: Exception) {
                                android.util.Log.e("MainActivity", "Échec de réception de fichier", error)
                            }
                        }
                    )
                }

                if (fastWifiServerSocket == null) {
                    fastWifiServerSocket = com.zee.app.network.ZeeFastWifiTransfer.startServer(
                        scope = scope,
                        destinationDir = com.zee.app.model.MessageStore.mediaDir(this@MainActivity, "CHAT"),
                        localNodeId = SessionRegistry.localNodeId,
                        listener = object : com.zee.app.network.ZeeFastWifiTransfer.Listener {
                            override fun onComplete(file: java.io.File, meta: com.zee.app.network.ZeeFastWifiTransfer.Meta) {
                                if (meta.kind == "AD_MEDIA") {
                                    com.zee.app.network.AdRelay.onAdMediaReceived(
                                        this@MainActivity, meta.messageId, file, meta.mimeType, meta.fileName
                                    )
                                    return
                                }
                                val channel = com.zee.app.model.MessageChannels.normalize(meta.kind)
                                val messageType = when {
                                    meta.mimeType.startsWith("image/") -> com.zee.app.model.MessageType.IMAGE
                                    meta.mimeType.startsWith("video/") -> com.zee.app.model.MessageType.VIDEO
                                    meta.mimeType.startsWith("audio/") -> com.zee.app.model.MessageType.AUDIO
                                    else -> com.zee.app.model.MessageType.DOCUMENT
                                }
                                val persistent = com.zee.app.model.MessageStore.copyFileToPersistent(
                                    this@MainActivity, file, channel, meta.fileName
                                )
                                val finalPath = persistent?.absolutePath ?: file.absolutePath
                                com.zee.app.model.MessageStore.save(
                                    this@MainActivity,
                                    meta.messageId,
                                    meta.fromNodeId,
                                    channel,
                                    meta.fromNodeId,
                                    false,
                                    messageType,
                                    meta.fileName,
                                    finalPath,
                                    meta.fileName,
                                    meta.mimeType
                                )
                                if (SessionRegistry.activeChatNodeId == meta.fromNodeId &&
                                    SessionRegistry.activeChatChannel == channel) {
                                    runOnUiThread {
                                        SessionRegistry.activeAttachmentListener?.invoke(
                                            persistent ?: file, meta.mimeType, meta.fileName, meta.fromNodeId
                                        )
                                    }
                                }
                                runOnUiThread {
                                    val addr = SessionRegistry.connectedPeerAddress
                                    if (addr != null && SessionRegistry.activeChatPeerAddress != addr) {
                                        val peer = lastPeers.find { it.deviceAddress == addr }
                                        NotificationHelper.showMessageNotification(
                                            this@MainActivity, addr,
                                            peer?.displayName ?: peer?.deviceName ?: "ZEE",
                                            "Pièce jointe reçue"
                                        )
                                    }
                                }
                                ZeeDiagnostic.log(this@MainActivity, "FAST_WIFI_FILE_RECEIVED node=${meta.fromNodeId} bytes=${meta.fileSize}")
                            }
                            override fun onError(error: Exception) {
                                android.util.Log.w("ZeeFastWifi", "Réception Fast Wi-Fi refusée/échouée: ${error.message}")
                            }
                        }
                    )
                    ZeeDiagnostic.log(this, if (fastWifiServerSocket != null) "FAST_WIFI_SERVER_READY port=${com.zee.app.network.ZeeFastWifiTransfer.PORT}" else "FAST_WIFI_SERVER_UNAVAILABLE")
                }

                fun sendHandshake(session: ZeeSocketSession) {
                    android.util.Log.d("ZeeProtocol", "HANDSHAKE_START localNodeId=${SessionRegistry.localNodeId} remote=${SessionRegistry.peerAddress(session)}")
                    session.send(ZeeMessageCodec.encodeHello(SessionRegistry.localNodeId))
                    android.util.Log.d("ZeeProtocol", "HELLO_SENT nodeId=${SessionRegistry.localNodeId} remote=${SessionRegistry.peerAddress(session)}")
                    val profileLines = ZeeModule.values().filter { com.zee.app.model.VisibilityStore.isVisible(this, it) }.map { module ->
                        ZeeMessageCodec.encodeProfile(
                            SessionRegistry.localNodeId,
                            com.zee.app.model.ProfileStore.getDisplayName(this),
                            com.zee.app.model.ProfileStore.getModuleActu(this, module),
                            encodeProfilePhoto(com.zee.app.model.ProfileStore.getModulePhotoUri(this, module)),
                            direct = true, module = module
                        )
                    }
                    // PROFILE est idempotent. On le renvoie après l'établissement
                    // du socket pour couvrir les appareils où le groupe P2P est
                    // déclaré prêt avant que la pile réseau soit totalement stable.
                    profileLines.forEach(session::send)
                    android.util.Log.d("ZeeProtocol", "MODULE_PROFILES_SENT nodeId=${SessionRegistry.localNodeId} remote=${SessionRegistry.peerAddress(session)}")
                    scope.launch(Dispatchers.IO) {
                        kotlinx.coroutines.delay(700L)
                        profileLines.forEach(session::send)
                        // Si le pair n'a jamais confirmé READY, les messages
                        // privés restent volontairement en attente dans le store.
                        // Ce log rend ce cas immédiatement visible dans Logcat.
                        kotlinx.coroutines.delay(2500L)
                        if (!SessionRegistry.isProtocolReady(session)) {
                            android.util.Log.w("ZeeProtocol", "HANDSHAKE_TIMEOUT remote=${SessionRegistry.peerAddress(session)} : canal TCP ouvert mais READY non confirmé")
                        }
                    }
                    AdRelayStore.getActiveAds(this).forEach { ad ->
            val target = session.remoteAddress?.let { addr -> lastPeers.firstOrNull { it.deviceAddress == addr }?.nodeId }
            if (!target.isNullOrBlank()) sendAdToNode(ad, target) else session.send(ZeeMessageCodec.encodeAd(ad))
        }
                    SessionRegistry.flushPendingChatMessages()
                }

                if (isGroupOwner) {
                    // Un seul serveur TCP accepte désormais plusieurs clients ZEE.
                    // Le GO devient le relais local du réseau maillé.
                    meshServer?.stop()
                    meshServer = ZeeMeshServer(
                        scope = scope,
                        onLine = { session, line -> handleIncomingMessage(session, line) },
                        onReady = { session ->
                            // Le GO accepte plusieurs clients. Enregistrer chaque
                            // socket comme transport avant le premier PROFILE permet
                            // au routeur/latence de connaître immédiatement la session.
                            SessionRegistry.registerSession(null, session)
                            sendHandshake(session)
                        },
                        onClosed = { session ->
                            // Supprime toutes les routes qui pointaient vers
                            // ce socket. Un GO peut avoir plusieurs clients :
                            // il ne faut surtout pas conserver une route morte.
                            SessionRegistry.removeSession(null, session)
                            android.util.Log.d("MainActivity", "Client ZEE déconnecté: ${session.remoteAddress}")
                        },
                        onError = { e -> android.util.Log.e("MainActivity", "Serveur maillé ZEE", e) }
                    ).also { it.start() }
                } else {
                    openClientSession(groupOwnerAddress)
                }
            },

            onConnectedStateLost = {
                clientSession?.let { removePeersForClosedSession(it); it.close() }
                clientSession = null
                clientReconnectScheduled = false
                reconnectRunnable?.let { reconnectHandler.removeCallbacks(it) }
                SessionRegistry.active = null
                SessionRegistry.connectedPeerAddress = null
                SessionRegistry.peerRemoteAddress = null
                if (!isFinishing && !isDestroyed && WifiEnabler.isWifiEnabled(this)) {
                    startDiscoveryIfReady()
                }
            },
            onStateChanged = { enabled ->
                if (!enabled) {
                    // Wi-Fi désactivé : ZEE ne fonctionne pas sans le module
                    // Wi-Fi Direct du téléphone. On relance la même logique
                    // qu'au lancement pour réafficher le panneau de réglage
                    // si l'utilisateur l'a désactivé en cours d'utilisation.
                    WifiEnabler.ensureWifiEnabled(this, REQUEST_ENABLE_WIFI)
                } else {
                    startDiscoveryIfReady()
                }
            },
            onRawPeersAvailable = { peers ->
                // Diagnostic radio uniquement. Les appareils bruts ne sont
                // jamais injectés dans les listes Business/Job/Rencontres.
                ZeeDiagnostic.log(this, "RADIO_LAYER peers=${peers.size}")
            }
        )
    }

    /** Appelé par PeerListFragment pour s'abonner aux mises à jour de pairs. */
    fun observePeers(module: ZeeModule, callback: (List<Peer>) -> Unit) {
        peerObservers[module] = callback
        callback(lastPeers)
    }

    /** Observe la présence brute de proximité pour l'écran Accueil. */
    fun observeNearbyPeers(callback: (List<Peer>) -> Unit) {
        if (!nearbyObservers.contains(callback)) nearbyObservers += callback
        callback(lastPeers)
    }

    fun removeNearbyObserver(callback: (List<Peer>) -> Unit) {
        nearbyObservers.remove(callback)
    }

    /**
     * BUG CORRIGÉ : le callback onPeersChanged de WifiDirectManager remplaçait
     * intégralement `lastPeers` par sa propre liste interne (discoveredPeers).
     * Or WifiDirectManager ignore tout ce qui vient du handshake applicatif —
     * nom réel, ACTU, PHOTO — puisque ce handshake (PROFILE) passe par
     * ZeeSocketSession et met à jour `lastPeers` directement dans
     * MainActivity, jamais la map interne de WifiDirectManager. Résultat :
     * dès que la découverte de service se redéclenche (changement d'onglet,
     * tirer-pour-rafraîchir, heartbeat périodique de la découverte Wi-Fi
     * Direct), WifiDirectManager renvoyait sa propre version — toujours sans
     * photo — qui écrasait purement et simplement celle enrichie par le
     * handshake. D'où les photos de profil qui disparaissaient dès qu'on
     * quittait puis revenait sur un onglet (l'ACTU et le nom pouvaient être
     * touchés de la même façon, juste moins visible).
     *
     * Fusionne désormais la liste "fraîche" (adresse, nom système, statut,
     * modules visibles, critère, nodeId) avec les champs propres au
     * handshake applicatif déjà connus (displayName, actu, photoBase64,
     * unreadCount, pub active) conservés depuis `lastPeers`. Conserve aussi
     * les pairs Wi-Fi Aware (préfixe "aware:") qui ne remontent jamais de
     * WifiDirectManager et disparaissaient purement et simplement à chaque
     * rafraîchissement.
     */
    private fun removePeersForClosedSession(session: ZeeSocketSession) {
        val remoteAddress = SessionRegistry.peerAddress(session)
        val affectedNodeIds = lastPeers.mapNotNull { peer ->
            val node = peer.nodeId ?: return@mapNotNull null
            if (SessionRegistry.sessionFor(node) === session) node else null
        }.toSet()
        lastPeers = lastPeers.filterNot { peer ->
            (remoteAddress != null && peer.deviceAddress == remoteAddress) ||
                (peer.nodeId != null && peer.nodeId in affectedNodeIds)
        }
        peerObservers.values.forEach { it(lastPeers) }
        nearbyObservers.toList().forEach { it(lastPeers) }
    }

    /**
     * Les aperçus reçus par nom d'instance sont tronqués à 30 octets : un texte complet déjà
     * connu (TXT ou handshake PROFILE) ne doit pas être remplacé par son début tronqué.
     */
    private fun fuller(fresh: String?, existing: String?): String? {
        val f = fresh?.takeIf { it.isNotBlank() }
        val e = existing?.takeIf { it.isNotBlank() }
        val looksTruncated = f != null && f.toByteArray(Charsets.UTF_8).size >= 26
        return if (f != null && e != null && looksTruncated && e.length > f.length && e.startsWith(f)) e else f ?: e
    }

    private fun mergeDiscoveredPeers(discovered: List<Peer>): List<Peer> {
        val existingByAddress = lastPeers.associateBy { it.deviceAddress }
        val existingByNodeId = lastPeers.mapNotNull { p -> p.nodeId?.let { it to p } }.toMap()
        val merged = discovered.map { fresh ->
            val existing = existingByAddress[fresh.deviceAddress]
                ?: fresh.nodeId?.let { existingByNodeId[it] }
            if (existing == null) fresh else fresh.copy(
                // Pair sans critères annoncés (ni nom d'instance V2 ni TXT, ex. ancienne version) :
                // WifiDirectManager n'expose alors que CHAT à titre provisoire. On conserve les
                // modules déjà appris par le handshake PROFILE, sinon BUSINESS et JOB redeviennent
                // vides à chaque rafraîchissement de la découverte.
                visibleModules = if (fresh.criteriaByModule.isEmpty()) fresh.visibleModules + existing.visibleModules else fresh.visibleModules,
                displayName = fuller(fresh.displayName, existing.displayName),
                actu = fuller(fresh.actu, existing.actu),
                // L'aperçu de découverte est une miniature 96x96 : une photo complète déjà reçue
                // par handshake (beaucoup plus longue en Base64) n'est jamais remplacée par elle.
                photoBase64 = run {
                    val f = fresh.photoBase64?.takeIf { it.isNotBlank() }
                    val e = existing.photoBase64?.takeIf { it.isNotBlank() }
                    if (f != null && e != null && e.length > f.length) e else f ?: e
                },
                // Les données PROFILE sont applicatives et doivent survivre à
                // chaque rafraîchissement de la découverte Wi-Fi Direct.
                // Sinon les photos/noms JOB et BUSINESS disparaissent dès que
                // P2P_PEERS_CHANGED reconstruit la liste des pairs.
                displayNamesByModule = if (existing.displayNamesByModule.isNotEmpty())
                    existing.displayNamesByModule + fresh.displayNamesByModule
                else fresh.displayNamesByModule,
                actusByModule = if (existing.actusByModule.isNotEmpty()) {
                    val out = existing.actusByModule.toMutableMap()
                    for ((module, text) in fresh.actusByModule) out[module] = fuller(text, existing.actusByModule[module]) ?: text
                    out.toMap()
                } else fresh.actusByModule,
                photosByModule = if (existing.photosByModule.isNotEmpty())
                    existing.photosByModule + fresh.photosByModule
                else fresh.photosByModule,
                unreadCount = existing.unreadCount,
                adActive = existing.adActive,
                adExpiresAt = existing.adExpiresAt,
                status = if (existing.status == com.zee.app.model.PeerStatus.CONNECTED) existing.status else fresh.status
            )
        }
        // Une nouvelle recherche représente la présence actuelle. Seules les
        // sessions DIRECT déjà connectées sont conservées : une session active
        // prouve que le pair est encore joignable. Les anciennes présences non
        // connectées ne sont jamais conservées.
        val connected = lastPeers.filter {
            it.status == com.zee.app.model.PeerStatus.CONNECTED &&
                !it.deviceAddress.startsWith("aware:")
        }
        return (merged + connected).distinctBy { it.deviceAddress }
    }

    /** Appelé par PeerListFragment lors du tirer-pour-rafraîchir. */
    /** Permet aux raccourcis de l'accueil d'ouvrir directement un service. */
    fun openTab(position: Int) {
        findViewById<ViewPager2>(R.id.viewPager).currentItem = position
    }

    fun refreshPeers() {
        // Une action explicite de l'utilisateur permet de redemander la localisation
        // si elle avait été refusée précédemment.
        locationPromptDismissed = false
        // Ne vide pas la liste pendant la fenêtre de redécouverte : Android/OEM
        // peut temporairement retourner zéro pair pendant la relance P2P.
        // Les entrées sont ensuite mises à jour/fusionnées par DNS-SD sans
        // faire disparaître les profils à l'écran. Les sessions CONNECTED sont
        // naturellement conservées jusqu'à leur fermeture réelle.
        startDiscoveryIfReady(forceRestart = true)
    }

    /**
     * Appelé par PeerListFragment quand l'utilisateur tape sur un pair pour
     * ouvrir une conversation : lance la connexion Wi-Fi Direct P2P vers
     * lui (voir WifiDirectManager.connectTo). Une fois établie (onConnected
     * ci-dessus), la session texte s'ouvre automatiquement et échange
     * profil + pubs actives avec ce pair précis.
     */
    fun connectToPeer(peer: Peer) {
        // Les pairs découverts par Wi-Fi Aware sont déjà reliés automatiquement
        // par le transport mesh. Il n'est donc pas nécessaire de déclencher
        // une seconde négociation Wi-Fi Direct.
        if (peer.deviceAddress.startsWith("aware:")) {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_r_seau_zee_mesh_connexion_wi_fi_aware_automat), android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        pendingPeerAddress = peer.deviceAddress
        android.widget.Toast.makeText(this, getString(com.zee.app.R.string.connection_in_progress, peer.displayName?.takeIf { it.isNotBlank() } ?: getString(com.zee.app.R.string.app_name)), android.widget.Toast.LENGTH_SHORT).show()

        connectionTimeoutRunnable?.let { reconnectHandler.removeCallbacks(it) }
        val timeoutRunnable = Runnable {
            if (SessionRegistry.active == null) {
                wifiDirectManager.cancelPendingConnection()
                pendingPeerAddress = null
                android.widget.Toast.makeText(
                    this,
                    "Connexion Wi-Fi Direct trop longue, échec probable. Nouvel essai…",
                    android.widget.Toast.LENGTH_LONG
                ).show()
                startDiscoveryIfReady()
            }
        }
        connectionTimeoutRunnable = timeoutRunnable
        reconnectHandler.postDelayed(timeoutRunnable, 25_000L)

        wifiDirectManager.connectTo(peer) { reasonCode ->
            connectionTimeoutRunnable?.let { reconnectHandler.removeCallbacks(it) }
            connectionTimeoutRunnable = null
            runOnUiThread {
                android.widget.Toast.makeText(this, getString(com.zee.app.R.string.connection_failed_code, reasonCode), android.widget.Toast.LENGTH_LONG).show()
            }
        }
    }

    /** Diffuse une publicité aux liaisons maillées actuellement connues. */
    private fun broadcastAdToConnectedPeers(line: String, except: ZeeSocketSession? = null) {
        SessionRegistry.broadcast(line, except)
        if (SessionRegistry.active?.isGroupOwner == true) {
            // Couvre aussi les sockets encore en cours de handshake, avant
            // qu'un nodeId soit enregistré dans SessionRegistry.
            meshServer?.broadcast(line, except)
        }
    }

    /**
     * Décode et route un message entrant (voir ZeeMessageCodec) :
     *   - PROFILE : met à jour le nom/l'actu affichés pour ce pair.
     *   - AD      : rejoint AdRelay (propagation virale + affichage +
     *               déduplication — voir AdRelay.onAdReceived).
     *   - CHAT    : transmis directement à l'écran de chat s'il est ouvert
     *               pour ce pair, sinon pastille non lue + notification.
     */
    private fun handleIncomingMessageForWebRtc(remoteNodeId: String, line: String) {
        // Le WebRTC est toujours un lien direct. On fabrique une identité de
        // session virtuelle uniquement pour réutiliser le routeur de réception
        // existant sans dupliquer toute la logique CHAT/ACK.
        val session = SessionRegistry.sessionFor(remoteNodeId) ?: return
        handleIncomingMessage(session, line)
    }

    private fun handleIncomingMessage(session: ZeeSocketSession, line: String) {
        val decoded = ZeeMessageCodec.decode(line) ?: return
        when (decoded) {
            is ZeeMessageCodec.Decoded.Hello -> {
                if (decoded.nodeId.isBlank() || decoded.nodeId == SessionRegistry.localNodeId) return
                android.util.Log.d("ZeeProtocol", "HELLO_RECEIVED nodeId=${decoded.nodeId} remote=${SessionRegistry.peerAddress(session)}")
                // READY est la confirmation du canal applicatif. Il peut être
                // envoyé avant PROFILE : les deux messages sont indépendants.
                session.send(ZeeMessageCodec.encodeReady(SessionRegistry.localNodeId))
                android.util.Log.d("ZeeProtocol", "READY_SENT nodeId=${SessionRegistry.localNodeId} remote=${SessionRegistry.peerAddress(session)}")
            }
            is ZeeMessageCodec.Decoded.Ready -> {
                if (decoded.nodeId.isBlank() || decoded.nodeId == SessionRegistry.localNodeId) return
                SessionRegistry.markProtocolReady(session, decoded.nodeId)
                // Une fois le canal ZEE de signalisation confirmé, le node
                // gagnant (ID lexical minimal) démarre l'offre WebRTC.
                runCatching { zeeWebRtcTransport.start(decoded.nodeId) }
                    .onFailure { android.util.Log.w("ZeeWebRtc", "Démarrage WebRTC impossible", it) }
                android.util.Log.d("ZeeProtocol", "READY_RECEIVED nodeId=${decoded.nodeId} remote=${SessionRegistry.peerAddress(session)}")
            }
            is ZeeMessageCodec.Decoded.Profile -> {
                if (decoded.nodeId.isBlank() || decoded.nodeId == SessionRegistry.localNodeId) return
                SessionRegistry.registerRoute(decoded.nodeId, session)
                if (decoded.direct) {
                    SessionRegistry.registerDirectPeer(decoded.nodeId, session)
                }
                if (SessionRegistry.active?.isGroupOwner == true) {
                    meshServer?.registerNode(decoded.nodeId, session)
                    meshServer?.cacheProfile(decoded.nodeId, line)
                    // Le nouveau client reçoit aussi les profils déjà connus.
                    meshServer?.sendKnownProfiles(session)
                    // Le profil devient visible pour tous les membres du groupe,
                    // mais il est explicitement marqué relayé afin que le client
                    // ne confonde pas ce profil avec le voisin TCP direct.
                    val relayedProfile = runCatching {
                        org.json.JSONObject(line).apply { put("direct", false) }.toString()
                    }.getOrDefault(line)
                    meshServer?.broadcast(relayedProfile, except = session)
                }
                // Le nodeId reçu dans le PROFILE est l'identité ZEE fiable.
                // Il peut arriver après l'ouverture du chat : dans ce cas on
                // rattache immédiatement la conversation à ce nodeId.
                // Chaque module peut être le premier (ou le seul) profil visible
                // reçu. Ne conditionne pas l'identité/photo distante à CHAT :
                // un pair qui masque CHAT doit tout de même apparaître dans ZEE.
                SessionRegistry.updateProfile(
                    decoded.nodeId, decoded.name, decoded.actu, decoded.photoBase64, session, decoded.direct
                )
                android.util.Log.d(
                    "ZeeProtocol",
                    "PROFILE_RECEIVED nodeId=${decoded.nodeId} direct=${decoded.direct} remote=${SessionRegistry.peerAddress(session)} name=${decoded.name.ifBlank { "<vide>" }} photo=${!decoded.photoBase64.isNullOrBlank()}"
                )

                // Pour un Group Owner, la session TCP est la source de vérité
                // pour l'adresse du client qui vient d'envoyer ce PROFILE.
                // Ne pas utiliser une adresse globale, sinon deux clients
                // simultanés peuvent être associés au mauvais profil.
                val sessionAddress = SessionRegistry.peerAddress(session)
                val selectedAddress = SessionRegistry.connectedPeerAddress ?: pendingPeerAddress
                val directAddress = sessionAddress ?: selectedAddress
                val matching = lastPeers.firstOrNull {
                    it.nodeId == decoded.nodeId ||
                        (directAddress != null && it.deviceAddress == directAddress)
                }
                val addr = matching?.deviceAddress ?: directAddress
                lastPeers = lastPeers.map { p ->
                    if (p.nodeId == decoded.nodeId || (addr != null && p.deviceAddress == addr)) {
                        val names = p.displayNamesByModule.toMutableMap().apply {
                            if (decoded.name.isNotBlank()) put(decoded.module, decoded.name)
                        }
                        val actus = p.actusByModule.toMutableMap().apply {
                            put(decoded.module, decoded.actu)
                        }
                        val photos = p.photosByModule.toMutableMap().apply {
                            decoded.photoBase64?.takeIf { it.isNotBlank() }?.let { put(decoded.module, it) }
                        }
                        p.copy(
                            nodeId = decoded.nodeId,
                            displayName = names[ZeeModule.CHAT] ?: p.displayName,
                            actu = actus[ZeeModule.CHAT] ?: p.actu,
                            photoBase64 = photos[ZeeModule.CHAT] ?: p.photoBase64,
                            displayNamesByModule = names,
                            actusByModule = actus,
                            photosByModule = photos,
                            // Un PROFILE n'est envoyé que pour les modules que l'émetteur a rendus
                            // visibles : le recevoir prouve que ce module est visible chez lui.
                            visibleModules = p.visibleModules + decoded.module,
                            status = if (decoded.direct) com.zee.app.model.PeerStatus.CONNECTED else p.status
                        )
                    } else p
                }

                // Si le chat était déjà ouvert avec le placeholder "Profil ZEE",
                // le PROFILE remplace immédiatement ce placeholder par le vrai
                // nom/photo et fournit la cible exacte du routage des messages.
                if (decoded.module == ZeeModule.CHAT && (decoded.direct || SessionRegistry.activeChatNodeId == decoded.nodeId)) {
                    SessionRegistry.bindActiveChatNode(decoded.nodeId)
                }
                if (decoded.module == ZeeModule.CHAT && decoded.direct) {
                    BusinessActivityStore.add(
                        this,
                        decoded.name.ifBlank { "Profil ZEE" },
                        "Nouveau contact",
                        "Vous êtes maintenant connecté !"
                    )
                }
                runOnUiThread {
                    peerObservers.values.forEach { it(lastPeers) }
                    nearbyObservers.toList().forEach { it(lastPeers) }
                    if (decoded.direct && decoded.module == ZeeModule.CHAT && addr != null) {
                        SessionRegistry.updateLatestProfile(addr, decoded.name, decoded.actu, decoded.photoBase64)
                    }
                }
            }
            is ZeeMessageCodec.Decoded.Ad -> {
                BusinessActivityStore.add(
                    this,
                    decoded.payload.sellerName.ifBlank { "Utilisateur ZEE" },
                    "Nouvelle publicité",
                    decoded.payload.headline.ifBlank { "Nouvelle publicité à proximité" },
                    com.zee.app.R.drawable.ic_default_avatar,
                    com.zee.app.R.drawable.bg_activity_badge_blue
                )
                // Une nouvelle pub continue sa propagation depuis ce nœud vers
                // toutes ses autres liaisons, même sans être Group Owner.
                val sourceNodeId = SessionRegistry.nodeFor(session)
                if (AdRelay.onAdReceived(this, decoded.payload, sourceNodeId)) {
                    // Le scheduler prendra ensuite en charge chaque voisin
                    // non encore servi. On évite ici tout broadcast aveugle.
                    SessionRegistry.activeNodeIds().forEach { nodeId ->
                        if (nodeId != sourceNodeId &&
                            nodeId != SessionRegistry.localNodeId &&
                            !AdRelayStore.wasSentToNeighbor(this, decoded.payload.id, nodeId)
                        ) {
                            if (SessionRegistry.routeTo(nodeId, line, except = session)) {
                                AdRelayStore.markSentToNeighbor(this, decoded.payload.id, nodeId)
                            }
                        }
                    }
                }
            }
            is ZeeMessageCodec.Decoded.WebRtcSignal -> {
                if (decoded.nodeId.isBlank() || decoded.nodeId == SessionRegistry.localNodeId) return
                // Une signalisation WebRTC n'est acceptée que depuis une route
                // ZEE connue; elle ne crée jamais une identité ou une connexion
                // en dehors du maillage.
                if (SessionRegistry.sessionFor(decoded.nodeId) == null) return
                runCatching { zeeWebRtcTransport.handle(decoded) }
                    .onFailure { android.util.Log.w("ZeeWebRtc", "Signalisation rejetée", it) }
            }
            is ZeeMessageCodec.Decoded.Attachment -> {
                val localId = SessionRegistry.localNodeId
                if (decoded.toNodeId != localId && decoded.toNodeId.isNotBlank()) {
                    if (decoded.ttl > 0) {
                        val next = ZeeMessageCodec.encodeAttachment(
                            decoded.messageId, decoded.fromNodeId, decoded.toNodeId,
                            decoded.fileName, decoded.mimeType, decoded.fileSize, decoded.ttl - 1,
                            decoded.channel
                        )
                        if (!SessionRegistry.routeTo(decoded.toNodeId, next, session)) {
                            if (!(meshServer?.sendTo(decoded.toNodeId, next) ?: false)) {
                                android.util.Log.d("ZeeProtocol", "ATTACHMENT_DEFERRED target=${decoded.toNodeId} reason=no-ready-route")
                            }
                        }
                    }
                    return
                }
            }
            is ZeeMessageCodec.Decoded.Ack -> {
                android.util.Log.d("ZeeProtocol", "ACK_RECEIVED messageId=${decoded.messageId} toNodeId=${decoded.toNodeId} ttl=${decoded.ttl} remote=${SessionRegistry.peerAddress(session)}")
                // Chaque relais qui a conservé une copie du message doit la
                // supprimer dès que l'ACK passe. Le nœud d'origine sera lui
                // aussi nettoyé lorsque l'ACK arrivera à sa destination.
                val localId = SessionRegistry.localNodeId
                // Capturer le chemin inverse AVANT onDelivered(), qui nettoie
                // volontairement les métadonnées temporaires du message.
                val returnSession = SessionRegistry.returnSessionFor(decoded.messageId)
                SessionRegistry.onDelivered(decoded.messageId, finalForLocal = decoded.toNodeId == localId)
                if (decoded.toNodeId == localId) {
                    return
                } else if (decoded.ttl > 0) {
                    val next = ZeeMessageCodec.encodeAck(decoded.messageId, decoded.toNodeId, decoded.ttl - 1)
                    if (returnSession?.send(next) != true) {
                        android.util.Log.d(
                            "ZeeProtocol",
                            "ACK_DEFERRED messageId=${decoded.messageId} reason=return-session-unavailable"
                        )
                    }
                }
            }
            is ZeeMessageCodec.Decoded.Chat -> {
                android.util.Log.d("ZeeProtocol", "CHAT_RECEIVED messageId=${decoded.messageId} from=${decoded.fromNodeId} to=${decoded.toNodeId} ttl=${decoded.ttl} remote=${SessionRegistry.peerAddress(session)}")
                val localId = SessionRegistry.localNodeId
                val forMe = decoded.toNodeId == localId
                // Le chemin inverse est déterminé par la session d'arrivée,
                // jamais par une recherche de route arbitraire. Cela permet à
                // un relais de retourner l'ACK vers le précédent saut.
                SessionRegistry.rememberReturnSession(decoded.messageId, session)
                // Un message final déjà livré peut revenir après une reconnexion.
                // On renvoie l'ACK sans réafficher le texte. Pour un relais, la
                // déduplication reste en mémoire afin qu'un redémarrage puisse
                // reprendre sa copie persistante dans MeshMessageStore.
                if (forMe && SessionRegistry.wasDelivered(decoded.messageId)) {
                    val ack = ZeeMessageCodec.encodeAck(decoded.messageId, decoded.fromNodeId, 8)
                    SessionRegistry.returnSessionFor(decoded.messageId)?.send(ack)
                    return
                }
                if (!seenMessageIds.add(decoded.messageId) || !SessionRegistry.markSeen(decoded.messageId)) return
                if (!forMe && decoded.toNodeId.isNotBlank()) {
                    // Chaque relais conserve une copie persistante tant que le
                    // destinataire final n'a pas confirmé la livraison. Cela
                    // permet le store-and-forward lorsque le prochain nœud
                    // disparaît temporairement.
                    val next = if (decoded.ttl > 0) ZeeMessageCodec.encodeChat(
                        decoded.text, decoded.fromNodeId, decoded.toNodeId, decoded.ttl - 1, decoded.messageId,
                        decoded.channel
                    ) else line
                    SessionRegistry.queueRelay(decoded.toNodeId, next, decoded.messageId)
                    if (decoded.ttl > 0) {
                        ChatLatencyTracker.markRelayQueued(decoded.messageId)
                        val routed = SessionRegistry.routeTo(decoded.toNodeId, next, session)
                        val meshRouted = if (!routed) (meshServer?.sendTo(decoded.toNodeId, next) ?: false) else false
                        if (!routed && !meshRouted) {
                            android.util.Log.d(
                                "ZeeProtocol",
                                "CHAT_DEFERRED messageId=${decoded.messageId} target=${decoded.toNodeId} reason=no-ready-route"
                            )
                        }
                    }
                    return
                }
                if (forMe || decoded.toNodeId.isBlank()) {
                    // Accusé de livraison final : l'expéditeur supprime le
                    // message de sa file persistante uniquement après cet ACK.
                    if (forMe && decoded.fromNodeId.isNotBlank()) {
                        SessionRegistry.markDelivered(decoded.messageId)
                        val ack = ZeeMessageCodec.encodeAck(decoded.messageId, decoded.fromNodeId, 8)
                        // L'ACK doit pouvoir revenir par le même socket que le CHAT.
                        // Le paramètre `except` est utile pour les CHAT relayés afin
                        // d'éviter les boucles, mais il est incorrect pour l'ACK :
                        // sur une liaison directe, le prochain saut est précisément
                        // la session qui vient de livrer le message.
                        SessionRegistry.returnSessionFor(decoded.messageId)?.send(ack)
                    }
                    val addr = lastPeers.firstOrNull { it.nodeId == decoded.fromNodeId }?.deviceAddress
                        ?: SessionRegistry.connectedPeerAddress
                    val channel = com.zee.app.model.MessageChannels.normalize(decoded.channel)
                    val peerForStore = lastPeers.firstOrNull { it.nodeId == decoded.fromNodeId }
                    val conversationId = decoded.fromNodeId.ifBlank { addr ?: "" }
                    com.zee.app.model.MessageStore.save(
                        this,
                        decoded.messageId,
                        conversationId,
                        channel,
                        decoded.fromNodeId,
                        false,
                        com.zee.app.model.MessageType.TEXT,
                        decoded.text,
                        null,
                        null,
                        "text/plain"
                    )
                    if (SessionRegistry.activeChatNodeId == decoded.fromNodeId &&
                        SessionRegistry.activeChatChannel == channel) {
                        runOnUiThread { SessionRegistry.activeChatListener?.invoke(decoded.text) }
                    } else {
                        val peer = lastPeers.firstOrNull { it.nodeId == decoded.fromNodeId || (addr != null && it.deviceAddress == addr) }
                        lastPeers = lastPeers.map { p -> if (p.nodeId == decoded.fromNodeId || (addr != null && p.deviceAddress == addr)) p.also { it.unreadCount++ } else p }
                        val sender = lastPeers.firstOrNull { it.nodeId == decoded.fromNodeId || (addr != null && it.deviceAddress == addr) }
                        val senderName = sender?.displayName?.takeIf { it.isNotBlank() } ?: "Profil ZEE"
                        com.zee.app.model.ChatConversationStore.recordIncoming(
                            this,
                            "${channel}:${decoded.fromNodeId.ifBlank { addr ?: "" }}",
                            senderName,
                            decoded.text,
                            sender?.photoBase64
                        )
                        BusinessActivityStore.add(this, senderName, "Nouveau message", decoded.text, com.zee.app.R.drawable.ic_default_avatar, com.zee.app.R.drawable.bg_activity_badge_blue)
                        runOnUiThread {
                            peerObservers.values.forEach { it(lastPeers) }
                            NotificationHelper.showMessageNotification(this, addr ?: decoded.fromNodeId, peer?.displayName?.takeIf { it.isNotBlank() } ?: "Profil ZEE", decoded.text)
                        }
                    }
                }
            }
        }
    }

    private fun scheduleReconnect() {
        if (isFinishing || isDestroyed) return
        val address = lastConnectedDeviceAddress ?: pendingPeerAddress ?: return
        reconnectRunnable?.let { reconnectHandler.removeCallbacks(it) }
        val task = Runnable {
            val peer = lastPeers.firstOrNull { it.deviceAddress == address || it.nodeId == lastConnectedNodeId }
            if (peer != null) {
                pendingPeerAddress = peer.deviceAddress
                wifiDirectManager.connectTo(peer) {
                    scheduleReconnect()
                }
            } else {
                startDiscoveryIfReady()
                scheduleReconnect()
            }
        }
        reconnectRunnable = task
        // Un délai fixe identique des deux côtés fait converger les deux
        // téléphones vers des tentatives de reconnexion synchronisées : ils
        // rappellent connectTo() l'un vers l'autre au même instant, ce qui
        // fait échouer manager.connect() des deux côtés avec le code 0
        // générique (négociation P2P simultanée). Une petite marge aléatoire
        // désynchronise les essais sans changer le délai perçu.
        reconnectHandler.postDelayed(task, 3_000L + (0..1200L).random())
    }

    /** Lit la photo locale et l'envoie en JPEG compact dans le handshake PROFILE. */
    private fun encodeProfilePhoto(uriString: String?): String? {
        if (uriString.isNullOrBlank()) return null
        return try {
            val input = contentResolver.openInputStream(android.net.Uri.parse(uriString)) ?: return null
            input.use {
                val source = BitmapFactory.decodeStream(it) ?: return null
                val maxSide = 512
                val scale = minOf(1f, maxSide.toFloat() / maxOf(source.width, source.height))
                val bitmap = if (scale < 1f) Bitmap.createScaledBitmap(
                    source, (source.width * scale).toInt(), (source.height * scale).toInt(), true
                ) else source
                val out = ByteArrayOutputStream()
                bitmap.compress(Bitmap.CompressFormat.JPEG, 80, out)
                if (bitmap !== source) bitmap.recycle()
                source.recycle()
                Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
            }
        } catch (_: Exception) {
            null
        }
    }

    private fun requestZeePermissions() {
        ZeeDiagnostic.log(this, "PERMISSION_REQUEST API=${Build.VERSION.SDK_INT}")
        val permissions = mutableListOf(
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            permissions.add(Manifest.permission.NEARBY_WIFI_DEVICES)
            permissions.add(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            permissions.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        permissionLauncher.launch(permissions.toTypedArray())
    }

    override fun onResume() {
        super.onResume()
        wifiDirectManager.register()
        SessionRegistry.initialize(applicationContext)
        SessionRegistry.flushPendingChatMessages()
        // Relance systématiquement au retour au premier plan (ex. après
        // avoir modifié le réglage "Visible à proximité" sur l'écran de
        // profil), pour que le changement soit pris en compte immédiatement.
        // Protégé par hasZeePermissions() : sans ça, un premier appel ici
        // pouvait survenir avant que l'utilisateur ait répondu à la demande
        // de permissions, provoquant une SecurityException silencieuse.
        if (WifiEnabler.isWifiEnabled(this) && hasZeePermissions()) {
            startDiscoveryIfReady()
            if (::wifiAwareMeshManager.isInitialized) wifiAwareMeshManager.start()
        }
        // Le heartbeat était défini mais jamais lancé : il n'a donc jamais tourné.
        reconnectHandler.removeCallbacks(discoveryHeartbeat)
        reconnectHandler.postDelayed(discoveryHeartbeat, 12_000L)
    }

    private fun hasZeePermissionsSafe(): Boolean = runCatching { hasZeePermissions() }.getOrDefault(false)

    private fun hasZeePermissions(): Boolean {
        val required = mutableListOf(
            Manifest.permission.ACCESS_WIFI_STATE,
            Manifest.permission.CHANGE_WIFI_STATE
        )
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            required.add(Manifest.permission.NEARBY_WIFI_DEVICES)
        } else {
            required.add(Manifest.permission.ACCESS_FINE_LOCATION)
        }
        return required.all {
            androidx.core.content.ContextCompat.checkSelfPermission(this, it) ==
                android.content.pm.PackageManager.PERMISSION_GRANTED
        }
    }

    override fun onPause() {
        super.onPause()
        reconnectRunnable?.let { reconnectHandler.removeCallbacks(it) }
        reconnectHandler.removeCallbacks(discoveryHeartbeat)
        connectionTimeoutRunnable?.let { reconnectHandler.removeCallbacks(it) }
        connectionTimeoutRunnable = null
        if (::wifiAwareMeshManager.isInitialized) wifiAwareMeshManager.stop()
        wifiDirectManager.clearNearbyPresence()
        lastPeers = lastPeers.filter { it.status == com.zee.app.model.PeerStatus.CONNECTED }
        peerObservers.values.forEach { it(lastPeers) }
        wifiDirectManager.unregister()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_ENABLE_WIFI && WifiEnabler.isWifiEnabled(this)) {
            startDiscoveryIfReady()
        }
        if (requestCode == REQUEST_ENABLE_LOCATION) {
            locationSettingsOpened = false
            if (LocationEnabler.isLocationEnabled(this)) {
                locationPromptDismissed = false
                startDiscoveryIfReady()
            } else {
                // L'utilisateur a appuyé sur Précédent sans activer la localisation.
                // On reste dans ZEE au lieu de rouvrir immédiatement les réglages.
                locationPromptDismissed = true
            }
        }
    }

    override fun onDestroy() {
        runCatching { zeeWebRtcTransport.closeAll() }
        reconnectRunnable?.let { reconnectHandler.removeCallbacks(it) }
        reconnectHandler.removeCallbacks(discoveryHeartbeat)
        adScheduler.stop()
        fileServerSocket?.close()
        fastWifiServerSocket?.close()
        com.zee.app.network.ZeeFastWifiTransfer.stop()
        if (::wifiAwareMeshManager.isInitialized) wifiAwareMeshManager.stop()
        meshServer?.stop()
        meshServer = null
        SessionRegistry.session?.close()
        SessionRegistry.session = null
        super.onDestroy()
    }
}

