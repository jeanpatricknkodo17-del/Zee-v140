package com.zee.app.model

import android.content.Context
import android.net.Uri
import java.io.File
import java.io.FileOutputStream

/**
 * État de publicité propre à CHAQUE onglet. Une pub BUSINESS ne remplace
 * donc jamais une pub JOB ou RENCONTRES sur le même téléphone.
 */
object MyAdState {
    private const val PREFS = "zee_my_ad_state"

    private fun key(module: ZeeModule, field: String) = "${module.name}_$field"
    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun getText(context: Context, module: ZeeModule): String? = prefs(context).getString(key(module, "text"), null)
    fun getImageUri(context: Context, module: ZeeModule): Uri? =
        prefs(context).getString(key(module, "image_uri"), null)?.let { Uri.parse(it) }
    fun getValidatedCode(context: Context, module: ZeeModule): String? = prefs(context).getString(key(module, "validated_code"), null)
    fun getAdId(context: Context, module: ZeeModule): String? = prefs(context).getString(key(module, "ad_id"), null)

    fun getExpiresAt(context: Context, module: ZeeModule): Long? {
        val v = prefs(context).getLong(key(module, "expires_at"), -1L)
        return if (v == -1L) null else v
    }

    fun isActive(context: Context, module: ZeeModule): Boolean {
        val expiresAt = getExpiresAt(context, module) ?: return false
        return expiresAt > System.currentTimeMillis()
    }

    fun activate(context: Context, module: ZeeModule, text: String, imageUri: Uri?, code: String): AdPayload? {
        val expires = System.currentTimeMillis() + 24L * 60L * 60L * 1000L

        var mediaPath: String? = null
        var mediaMimeType: String? = null
        var mediaFileName: String? = null
        if (imageUri != null) {
            try {
                val dir = File(context.filesDir, "ad_media").apply { mkdirs() }
                val ext = imageUri.toString().substringAfterLast('.', "bin").take(8)
                val file = File(dir, "${module.name}_${System.currentTimeMillis()}.$ext")
                context.contentResolver.openInputStream(imageUri)?.use { input ->
                    FileOutputStream(file).use { output -> input.copyTo(output, 64 * 1024) }
                } ?: return null
                mediaPath = file.absolutePath
                mediaMimeType = context.contentResolver.getType(imageUri) ?: "application/octet-stream"
                mediaFileName = imageUri.lastPathSegment?.substringAfterLast('/') ?: file.name
            } catch (_: Exception) {
                return null
            }
        }

        val payload = AdPayload(
            module = module,
            sellerName = ProfileStore.getName(context).ifBlank { ProfileStore.getDisplayName(context) },
            headline = text,
            subtext = null,
            imageBase64 = null,
            adCode = code,
            expiresAt = expires,
            mediaPath = mediaPath,
            mediaMimeType = mediaMimeType,
            mediaFileName = mediaFileName
        )

        prefs(context).edit()
            .putString(key(module, "text"), text)
            .putString(key(module, "image_uri"), imageUri?.toString())
            .putString(key(module, "validated_code"), code)
            .putLong(key(module, "expires_at"), expires)
            .putString(key(module, "ad_id"), payload.id)
            .apply()

        AdRelayStore.addOrRelay(context, payload)
        return payload
    }

    fun clearIfExpired(context: Context, module: ZeeModule) {
        if (!isActive(context, module)) {
            prefs(context).edit()
                .remove(key(module, "text"))
                .remove(key(module, "image_uri"))
                .remove(key(module, "validated_code"))
                .remove(key(module, "expires_at"))
                .remove(key(module, "ad_id"))
                .apply()
        }
    }
}
