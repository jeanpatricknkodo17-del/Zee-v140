package com.zee.app.model

/**
 * Représente un appareil ZEE détecté à proximité via Wi-Fi Direct.
 * `deviceAddress` est l'adresse MAC du pair, fournie par WifiP2pManager —
 * c'est l'identifiant utilisé pour lancer une connexion P2P.
 */
data class Peer(
    val deviceAddress: String,
    val deviceName: String, // Nom système Android : ne jamais utiliser comme identité utilisateur.
    /** Identifiant ZEE stable, annoncé dans le service Wi-Fi Direct. */
    var nodeId: String? = null,
    var status: PeerStatus = PeerStatus.AVAILABLE,
    // Champs "profil" échangés une fois la connexion établie (voir ProfilePayload)
    var displayName: String? = null,
    var actu: String? = null,
    var module: ZeeModule = ZeeModule.CHAT,
    var photoBase64: String? = null,
    // Profil réellement échangé, séparément pour chaque onglet. Les champs
    // historiques ci-dessus restent pour compatibilité avec les anciennes
    // versions/profils CHAT.
    var displayNamesByModule: Map<ZeeModule, String> = emptyMap(),
    var actusByModule: Map<ZeeModule, String> = emptyMap(),
    var photosByModule: Map<ZeeModule, String> = emptyMap(),
    var distanceMeters: Int? = null, // estimée via RSSI, voir WifiDirectManager.estimateDistance
    // MARKET (vendeur) ou JOB (recruteur) uniquement : ce pair a-t-il un code
    // pub actif ? Si oui, son AdPayload (voir AdPayload.kt) est rediffusé
    // périodiquement à tous les pairs connectés sous forme d'écran plein
    // écran (voir PublicityActivity), quel que soit leur module actif.
    var adActive: Boolean = false,
    // Horodatage (millis epoch) d'expiration de la pub active — 24h après
    // l'activation du code pub. Passé ce délai, adActive doit repasser à
    // false et ne plus être rediffusé (voir AdBroadcastScheduler).
    var adExpiresAt: Long? = null,
    // Nombre de messages non lus reçus de ce pair. Affiché sous forme de
    // pastille verte à côté de sa photo dans la liste ; remis à 0 dès que
    // l'utilisateur ouvre la conversation (voir PeerListFragment.openChat).
    var unreadCount: Int = 0,
    // Modules (onglets) sur lesquels CE pair a choisi d'être visible —
    // reçu via le TXT record de son service Wi-Fi Direct (voir
    // WifiDirectManager). Un pair masqué sur JOB par exemple n'apparaîtra
    // pas dans l'onglet JOB de cet appareil, même s'il est visible ailleurs.
    var visibleModules: Set<ZeeModule> = emptySet(),
    // Critère de CE pair par module, reçu via le TXT record, utilisé pour
    // le filtrage croisé des listes (voir PeerListFragment) :
    //   - RENCONTRES : son propre SEXE ("Homme"/"Femme") + sa préférence
    //     Tous/Hommes/Femmes. Ces critères servent à autoriser l'échange
    //     réciproque, pas à masquer le profil.
    //   - BUSINESS/JOB : son propre STATUT ("A"=Vendeur/Cherche emploi,
    //     "B"=Acheteur/Recrute), comparé au mien — je ne vois que les
    //     pairs au statut OPPOSÉ du mien (un vendeur ne voit que des
    //     acheteurs, et réciproquement).
    var criteriaByModule: Map<ZeeModule, String> = emptyMap()
)

enum class PeerStatus { AVAILABLE, CONNECTING, CONNECTED, FAILED }

enum class ZeeModule { CHAT, MARKET, JOB }
