package com.zee.app.model

enum class MessageType { TEXT, IMAGE, VIDEO, AUDIO, DOCUMENT, LOCATION, CONTACT }

/**
 * Canal fonctionnel du message. Le canal est persistant et voyage dans le
 * protocole réseau afin qu'un message reçu hors écran ne puisse pas être
 * redistribué dans un autre onglet.
 */
object MessageChannels {
    const val CHAT = "CHAT"
    const val JOBS = "JOBS"
    const val BUSINESS = "BUSINESS"
    const val RENCONTRES = "RENCONTRES"

    fun normalize(value: String?): String = when (value?.uppercase()) {
        JOBS -> JOBS
        BUSINESS, "MARKET" -> BUSINESS
        RENCONTRES, "DATING", "RENCONTRE" -> RENCONTRES
        else -> CHAT
    }

    fun fromModuleName(module: String?): String = when (module?.uppercase()) {
        "JOB", "JOBS" -> JOBS
        "MARKET", "BUSINESS" -> BUSINESS
        "RENCONTRES", "DATING" -> RENCONTRES
        else -> CHAT
    }
}

data class ChatMessage(
    val id: Long = System.currentTimeMillis(),
    val fromMe: Boolean,
    val type: MessageType,
    val text: String? = null,
    val filePath: String? = null,
    val timestamp: Long = System.currentTimeMillis(),
    val channel: String = MessageChannels.CHAT,
    val conversationId: String = ""
)
