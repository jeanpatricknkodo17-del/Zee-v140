package com.zee.app.network

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

/**
 * Catégorie de contenu autorisée par un code pub, selon sa colonne dans le
 * fichier source (codes_pub_zee.xlsx) :
 *   - Colonnes C, D, E (codes 1, 2, 3) -> TEXT_IMAGE_DOCUMENT
 *   - Colonne F (code 4)               -> AUDIO
 *   - Colonne G (code 5)               -> VIDEO
 */
enum class AdCodeCategory { TEXT_IMAGE_DOCUMENT, AUDIO, VIDEO }

/** Résultat de la vérification d'un code pub. */
sealed class AdCodeCheckResult {
    data class Valid(val category: AdCodeCategory) : AdCodeCheckResult()
    object AlreadyUsed : AdCodeCheckResult()
    object NoCodeForToday : AdCodeCheckResult()
    object InvalidCode : AdCodeCheckResult()
}

/**
 * Vérifie les codes pub saisis par l'utilisateur contre le fichier
 * `assets/ad_codes.csv` embarqué dans l'application (5 codes à 6 chiffres
 * par jour, du 01/09/2026 au 01/01/2028).
 *
 * L'app ZEE fonctionnant sans internet, il n'y a pas de serveur à
 * interroger : le fichier de codes est livré À L'INTÉRIEUR de l'APK et
 * vérifié entièrement en local, en comparant le code saisi à la date
 * *du téléphone* (Calendar système), pas à une date serveur.
 *
 * Un code n'est valide QUE le jour exact auquel il est associé dans le
 * fichier — un code du 02/09/2026 ne fonctionne pas le 03/09/2026.
 *
 * RESTRICTIONS DE CONTENU (par colonne) :
 *   - Codes 1, 2, 3 (colonnes C, D, E) : uniquement texte, image, et tous
 *     types de documents.
 *   - Code 4 (colonne F) : uniquement fichiers audio.
 *   - Code 5 (colonne G) : uniquement fichiers vidéo.
 *
 * USAGE UNIQUE LOCAL : un code pub ne donne accès qu'à UNE seule publicité
 * sur cet appareil. Sans serveur central ou autorité de synchronisation, une
 * application entièrement hors-ligne ne peut pas garantir mathématiquement
 * qu'un même code n'est jamais consommé simultanément sur deux téléphones.
 * La synchronisation P2P peut éventuellement informer les pairs déjà connectés,
 * mais elle ne constitue pas une garantie globale en cas d'usage concurrent.
 */
class AdCodeValidator(private val context: Context) {

    companion object {
        private const val ASSET_FILE = "ad_codes.csv"
        private const val PREFS = "zee_ad_codes"
        private const val KEY_USED_CODES = "used_codes"
    }

    private val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.FRANCE)

    // date (dd/MM/yyyy) -> liste des 5 codes valides ce jour-là, dans l'ordre
    // des colonnes C,D,E,F,G (index 0..4)
    private val codesByDate: Map<String, List<String>> by lazy { loadCodes() }

    private fun loadCodes(): Map<String, List<String>> {
        val map = mutableMapOf<String, List<String>>()
        context.assets.open(ASSET_FILE).bufferedReader(Charsets.UTF_8).useLines { lines ->
            lines.drop(1).forEach { line -> // ignore l'en-tête "date;code1;..."
                val parts = line.trim().split(";")
                if (parts.size == 6) {
                    map[parts[0]] = parts.subList(1, 6)
                }
            }
        }
        return map
    }

    private fun categoryForColumn(index: Int): AdCodeCategory = when (index) {
        0, 1, 2 -> AdCodeCategory.TEXT_IMAGE_DOCUMENT // colonnes C, D, E
        3 -> AdCodeCategory.AUDIO                      // colonne F
        else -> AdCodeCategory.VIDEO                   // colonne G
    }

    /**
     * Vérifie le code saisi : date du jour, présence dans le fichier, et
     * s'il n'a pas déjà été consommé par une précédente publicité.
     */
    fun check(code: String): AdCodeCheckResult {
        val trimmed = code.trim()
        val todayKey = dateFormat.format(Date())
        val todaysCodes = codesByDate[todayKey] ?: return AdCodeCheckResult.NoCodeForToday

        val columnIndex = todaysCodes.indexOf(trimmed)
        if (columnIndex == -1) return AdCodeCheckResult.InvalidCode
        if (isUsed(trimmed)) return AdCodeCheckResult.AlreadyUsed

        return AdCodeCheckResult.Valid(categoryForColumn(columnIndex))
    }

    /** Utile pour l'UI (ex. distinguer "code invalide" de "aucun code prévu ce jour"). */
    fun hasCodesForToday(): Boolean {
        val todayKey = dateFormat.format(Date())
        return codesByDate.containsKey(todayKey)
    }

    private fun isUsed(code: String): Boolean =
        prefs().getStringSet(KEY_USED_CODES, emptySet())?.contains(code) ?: false

    /**
     * Marque ce code comme consommé localement : il ne pourra plus être
     * réutilisé sur cet appareil pour une autre publicité.
     */
    fun markUsed(code: String) {
        val current = prefs().getStringSet(KEY_USED_CODES, emptySet())?.toMutableSet() ?: mutableSetOf()
        current.add(code.trim())
        prefs().edit().putStringSet(KEY_USED_CODES, current).apply()
    }

    private fun prefs() = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
