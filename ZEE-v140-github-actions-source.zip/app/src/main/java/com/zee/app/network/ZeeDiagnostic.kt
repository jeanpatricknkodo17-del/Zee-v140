package com.zee.app.network

import android.content.Context
import android.os.Build
import android.os.Environment
import android.net.wifi.WifiManager
import android.net.wifi.p2p.WifiP2pManager
import android.provider.Settings
import androidx.core.content.ContextCompat
import android.content.pm.PackageManager
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Journal persistant minimal du transport ZEE, destiné au diagnostic sur deux téléphones. */
object ZeeDiagnostic {
    private const val PREFS = "zee_network_diagnostic"
    private const val KEY = "events"
    private const val MAX_EVENTS = 400

    @Synchronized
    fun log(context: Context, event: String) {
        val clean = event.replace("\n", " ").take(500)
        val stamp = SimpleDateFormat("HH:mm:ss.SSS", Locale.US).format(Date())
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val old = prefs.getString(KEY, "") ?: ""
        val lines = old.split("\n").filter { it.isNotBlank() }.takeLast(MAX_EVENTS - 1)
        prefs.edit().putString(KEY, (lines + "$stamp | $clean").joinToString("\n")).apply()
        android.util.Log.d("ZeeDiag", clean)
    }

    fun text(context: Context): String =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(KEY, "") ?: ""

    fun clear(context: Context) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().remove(KEY).apply()
    }

    fun snapshot(context: Context): String {
        val wifi = context.getSystemService(Context.WIFI_SERVICE) as WifiManager
        val p2p = context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
        val nearbyText = if (Build.VERSION.SDK_INT >= 33) {
            (ContextCompat.checkSelfPermission(context, "android.permission.NEARBY_WIFI_DEVICES") == PackageManager.PERMISSION_GRANTED).toString()
        } else "non applicable (Android ${Build.VERSION.SDK_INT} < 13)"
        val locationPermission =
            ContextCompat.checkSelfPermission(context, "android.permission.ACCESS_FINE_LOCATION") == PackageManager.PERMISSION_GRANTED
        val locationMode = runCatching {
            Settings.Secure.getInt(context.contentResolver, Settings.Secure.LOCATION_MODE) != Settings.Secure.LOCATION_MODE_OFF
        }.getOrDefault(true)
        return buildString {
            appendLine("ZEE — diagnostic réseau")
            appendLine("Android ${Build.VERSION.SDK_INT} / ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Wi-Fi activé : ${wifi.isWifiEnabled}")
            appendLine("NEARBY_WIFI_DEVICES : $nearbyText")
            appendLine("ACCESS_FINE_LOCATION : $locationPermission")
            appendLine("Localisation système : $locationMode")
            appendLine("Journal :")
            appendLine(text(context).ifBlank { "(aucun événement)" })
        }
    }
}
