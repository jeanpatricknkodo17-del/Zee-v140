package com.zee.app.network

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.net.wifi.WifiManager
import android.os.Build
import android.provider.Settings

/**
 * S'assure que le Wi-Fi est activé au lancement de ZEE — condition
 * indispensable puisque toute la communication de l'app passe par
 * Wi-Fi Direct.
 *
 * IMPORTANT : depuis Android 10 (API 29), Google interdit aux applications
 * d'activer le Wi-Fi silencieusement en arrière-plan (WifiManager.
 * setWifiEnabled() ne fonctionne plus pour les apps ciblant l'API 29+ —
 * c'est une restriction système, pas une limite de ZEE). Sur ces versions,
 * on ouvre donc le panneau de réglage rapide Wi-Fi par-dessus l'app
 * (Settings.Panel.ACTION_WIFI), qui permet de l'activer en un seul tap
 * sans quitter ZEE — le plus proche possible d'un vrai "automatique".
 *
 * Sur Android 9 et versions antérieures, l'activation reste silencieuse et
 * totalement automatique.
 */
object WifiEnabler {

    fun isWifiEnabled(context: Context): Boolean {
        val wifiManager = context.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
        return wifiManager.isWifiEnabled
    }

    /**
     * @return true si le Wi-Fi était déjà actif ou vient d'être activé
     * silencieusement ; false si l'utilisateur doit encore confirmer via le
     * panneau de réglage (Android 10+), auquel cas [requestCode] identifie
     * le résultat dans onActivityResult de l'activité appelante.
     */
    fun ensureWifiEnabled(activity: Activity, requestCode: Int): Boolean {
        if (isWifiEnabled(activity)) return true

        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
            @Suppress("DEPRECATION")
            val wifiManager = activity.applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            @Suppress("DEPRECATION")
            wifiManager.setWifiEnabled(true)
            return true
        }

        // Android 10+ : ouvre le panneau système Wi-Fi par-dessus ZEE.
        activity.startActivityForResult(Intent(Settings.Panel.ACTION_WIFI), requestCode)
        return false
    }
}
