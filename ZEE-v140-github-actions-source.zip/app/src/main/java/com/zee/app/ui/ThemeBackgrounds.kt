package com.zee.app.ui

import android.app.Activity
import android.content.Context
import android.graphics.Color
import androidx.core.content.ContextCompat
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import com.zee.app.R

/** Choix de fond des pages principales. Le thème blanc reste le comportement par défaut. */
object ThemeBackgrounds {
    private const val PREFS = "zee_appearance"
    private const val KEY_THEME = "page_background_theme"

    const val DEFAULT = 0
    private val labels = arrayOf(
        "Blanc (par défaut)",
        "Ville au coucher du soleil",
        "Dégradé épuré",
        "Messages — Lumière douce",
        "Vagues élégantes",
        "Rubans lumineux"
    )
    private val backgrounds = intArrayOf(
        0,
        R.drawable.theme_city_sunset,
        R.drawable.theme_clean_gradient,
        R.drawable.theme_messages_softlight,
        R.drawable.theme_elegant_waves,
        R.drawable.theme_luminous_ribbons
    )

    fun selected(context: Context): Int = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        .getInt(KEY_THEME, DEFAULT).coerceIn(0, labels.lastIndex)

    fun showPicker(activity: Activity, onChanged: () -> Unit) {
        val current = selected(activity)
        AlertDialog.Builder(activity)
            .setTitle(activity.getString(com.zee.app.R.string.kt_th_me_des_pages))
            .setSingleChoiceItems(labels, current) { dialog, which ->
                activity.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                    .edit().putInt(KEY_THEME, which).apply()
                onChanged()
                Toast.makeText(activity, activity.getString(com.zee.app.R.string.theme_toast, labels[which]), Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
            .setNegativeButton(activity.getString(com.zee.app.R.string.kt_fermer), null)
            .show()
    }

    /** Applique le fond au conteneur de page, en laissant les cartes et contenus intacts. */
    fun apply(root: View, isHome: Boolean) {
        val context = root.context
        val theme = selected(context)
        val first = (root as? ViewGroup)?.getChildAt(0)
        val second = (first as? ViewGroup)?.getChildAt(0)

        if (theme == DEFAULT) {
            if (isHome) {
                root.setBackgroundColor(ContextCompat.getColor(context, R.color.zee_bg))
                first?.setBackgroundColor(Color.TRANSPARENT)
            } else {
                root.setBackgroundColor(Color.TRANSPARENT)
                first?.setBackgroundColor(Color.WHITE)
                second?.setBackgroundColor(Color.WHITE)
            }
            return
        }

        root.setBackgroundResource(backgrounds[theme])
        first?.setBackgroundColor(Color.TRANSPARENT)
        second?.setBackgroundColor(Color.TRANSPARENT)
    }
}
