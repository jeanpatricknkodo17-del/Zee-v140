package com.zee.app.model

import java.util.UUID

/**
 * Publicité diffusée par un vendeur (BUSINESS), un recruteur (JOB), ou
 * tout utilisateur RENCONTRES ayant acheté un code pub — soit sur
 * en un clic via WhatsApp (https://wa.me/237653888264).
 *
 * PROPAGATION VIRALE : une fois reçue par un appareil (voir AdRelay), la
 * pub est automatiquement rediffusée par CET appareil à son tour aux
 * autres utilisateurs ZEE à proximité — comme un virus qui se propage de
 * proche en proche, et pas seulement depuis l'appareil d'origine. Voir
 * AdRelayStore pour la liste des pubs actuellement relayées par cet
 * appareil (les siennes + celles reçues d'autrui).
 *
 * [id] identifie la publicité de façon unique à travers toute sa
 * propagation : généré une seule fois par l'appareil d'origine et jamais
 * modifié en cours de relais. Il sert à garantir qu'un même utilisateur ne
 * reçoit/affiche jamais deux fois la même publicité (voir SeenAdsStore).
 *
 * [expiresAt] est fixé une seule fois, à l'activation par l'appareil
 * d'origine (diffuseur), et JAMAIS recalculé par les appareils relais :
 * toute la chaîne de propagation s'éteint donc ensemble, exactement 24 h
 * après l'activation d'origine.
 */
data class AdPayload(
    val id: String = UUID.randomUUID().toString(),
    val module: ZeeModule = ZeeModule.CHAT,
    val sellerName: String,
    val headline: String,
    val subtext: String? = null,
    val imageBase64: String? = null,
    val adCode: String, // code du jour validé par AdCodeValidator, sert de preuve de validité
    val expiresAt: Long,
    /** Chemin local du média joint. Jamais transmis dans le JSON réseau. */
    val mediaPath: String? = null,
    /** MIME du média joint, conservé localement pour l'affichage/transfert. */
    val mediaMimeType: String? = null,
    /** Nom original du média joint. */
    val mediaFileName: String? = null
)


