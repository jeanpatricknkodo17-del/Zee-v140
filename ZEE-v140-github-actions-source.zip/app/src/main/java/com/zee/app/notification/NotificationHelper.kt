package com.zee.app.notification

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.media.AudioAttributes
import android.media.RingtoneManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import com.zee.app.R
import com.zee.app.ui.ChatActivity

/**
 * Notifie l'utilisateur à la réception d'un message.
 *
 * IMPORTANT : on ne déclenche jamais nous-mêmes Vibrator.vibrate() ou la
 * lecture d'un son de façon inconditionnelle — cela ignorerait le mode
 * silencieux / vibreur / "Ne pas déranger" choisi par l'utilisateur.
 *
 * À la place, on poste une Notification standard sur un NotificationChannel
 * configuré avec enableVibration(true) + setSound(...). C'est ensuite
 * Android lui-même qui décide, au moment de l'affichage, si ça doit
 * vibrer / sonner / rester silencieux, en fonction des réglages système
 * du téléphone (sonnerie, vibreur seul, silencieux, Ne pas déranger,
 * réglages de notification propres à l'app). C'est le comportement demandé :
 * "en fonction de comment il a paramétré son téléphone".
 */
object NotificationHelper {

    private const val CHANNEL_ID = "zee_messages"
    private const val CHANNEL_NAME = "Messages ZEE"

    fun ensureChannel(context: Context) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (manager.getNotificationChannel(CHANNEL_ID) != null) return

        val soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
        val audioAttributes = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_NOTIFICATION_EVENT)
            .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
            .build()

        val channel = NotificationChannel(CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH).apply {
            description = "Notifications de nouveaux messages reçus sur ZEE"
            enableVibration(true)                       // le système vibrera SI le mode du téléphone l'autorise
            vibrationPattern = longArrayOf(0, 250, 150, 250)
            setSound(soundUri, audioAttributes)          // le système jouera ce son SI le mode du téléphone l'autorise
            enableLights(true)
        }
        manager.createNotificationChannel(channel)
    }

    /**
     * À appeler dès qu'un message arrive via ZeeSocketSession et que l'écran
     * de chat correspondant n'est pas déjà ouvert au premier plan.
     */
    fun showMessageNotification(
        context: Context,
        peerAddress: String,
        peerName: String,
        messagePreview: String,
        notificationId: Int = peerAddress.hashCode()
    ) {
        ensureChannel(context)

        val openChatIntent = Intent(context, ChatActivity::class.java).apply {
            putExtra(ChatActivity.EXTRA_PEER_ADDRESS, peerAddress)
            putExtra(ChatActivity.EXTRA_PEER_NAME, peerName)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
        }
        val pendingIntent = PendingIntent.getActivity(
            context, notificationId, openChatIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification_zee) // icône ZEE (Z dans un cercle blanc) affichée dans la barre de statut
            .setContentTitle(peerName)
            .setContentText(messagePreview)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(pendingIntent)
            // Ne PAS appeler setSound()/setVibrate() ici : c'est le
            // NotificationChannel ci-dessus qui porte cette configuration
            // sur Android 8+, afin que le système respecte les réglages
            // du téléphone. Sur Android < 8 (pas de channel), on retombe
            // sur les réglages par défaut du système via DEFAULT_ALL.
            .setDefaults(NotificationCompat.DEFAULT_ALL)
            .build()

        NotificationManagerCompat.from(context).notify(notificationId, notification)
    }
}
