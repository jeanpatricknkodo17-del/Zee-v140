package com.zee.app.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

/**
 * Stockage persistant des publicités relayées et de leur état de diffusion.
 *
 * Une publicité reste connue jusqu'à son expiration. La diffusion est suivie
 * indépendamment pour chaque voisin : adId -> nodeId du voisin déjà servi.
 * Ainsi, l'arrivée d'un nouveau voisin ne dépend pas du fait que la pub ait
 * déjà été envoyée à d'autres voisins.
 */
object AdRelayStore {
    private const val PREFS = "zee_ad_relay"
    private const val KEY_ACTIVE_ADS = "active_ads"
    private const val KEY_SEEN_IDS = "seen_ad_ids"
    private const val KEY_SENT_BY_NEIGHBOR = "sent_by_neighbor"
    private const val KEY_SCHEMA = "schema"
    private const val KEY_PENDING_MEDIA = "pending_media"
    private const val SCHEMA_VERSION = 3

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun ensureSchema(context: Context) {
        val p = prefs(context)
        if (p.getInt(KEY_SCHEMA, 0) != SCHEMA_VERSION) {
            // Migration additive : les anciennes pubs restent valides. Les
            // nouveaux champs média sont facultatifs et relus comme null.
            p.edit().putInt(KEY_SCHEMA, SCHEMA_VERSION).apply()
        }
    }

    @Synchronized
    fun getActiveAds(context: Context): List<AdPayload> {
        ensureSchema(context)
        val now = System.currentTimeMillis()
        val all = readAll(context)
        val active = all.filter { it.expiresAt > now }
        if (active.size != all.size) {
            writeAll(context, active)
            pruneState(context, active.mapTo(hashSetOf()) { it.id })
        }
        return active
    }

    @Synchronized
    fun hasSeen(context: Context, adId: String): Boolean {
        ensureSchema(context)
        return prefs(context).getStringSet(KEY_SEEN_IDS, emptySet())?.contains(adId) == true
    }

    @Synchronized
    fun addOrRelay(context: Context, ad: AdPayload): Boolean {
        ensureSchema(context)
        if (ad.expiresAt <= System.currentTimeMillis()) return false
        if (hasSeen(context, ad.id)) return false

        val seen = prefs(context).getStringSet(KEY_SEEN_IDS, emptySet())
            ?.toMutableSet() ?: mutableSetOf()
        seen.add(ad.id)

        val all = readAll(context).toMutableList()
        val pending = readPendingMedia(context)[ad.id]
        val enriched = if (pending != null && ad.mediaPath.isNullOrBlank()) {
            ad.copy(mediaPath = pending.path, mediaMimeType = pending.mimeType, mediaFileName = pending.fileName)
        } else ad
        if (all.none { it.id == ad.id }) all.add(enriched)

        prefs(context).edit().putStringSet(KEY_SEEN_IDS, seen).apply()
        writeAll(context, all)
        if (pending != null) {
            val pendingMap = readPendingMedia(context).toMutableMap()
            pendingMap.remove(ad.id)
            writePendingMedia(context, pendingMap)
        }
        return true
    }

    /** Associe le fichier binaire d'une publicité reçue à son payload.
     * Si le fichier arrive avant le JSON AD, il est conservé temporairement
     * jusqu'à l'arrivée du payload.
     */
    @Synchronized
    fun attachMedia(context: Context, adId: String, path: String, mimeType: String, fileName: String) {
        ensureSchema(context)
        val all = readAll(context).toMutableList()
        val index = all.indexOfFirst { it.id == adId }
        if (index >= 0) {
            all[index] = all[index].copy(mediaPath = path, mediaMimeType = mimeType, mediaFileName = fileName)
            writeAll(context, all)
        } else {
            val pending = readPendingMedia(context).toMutableMap()
            pending[adId] = PendingMedia(path, mimeType, fileName)
            writePendingMedia(context, pending)
        }
    }

    @Synchronized
    fun get(context: Context, adId: String): AdPayload? =
        getActiveAds(context).firstOrNull { it.id == adId }

    data class PendingMedia(val path: String, val mimeType: String, val fileName: String)

    private fun readPendingMedia(context: Context): Map<String, PendingMedia> {
        val raw = prefs(context).getString(KEY_PENDING_MEDIA, null) ?: return emptyMap()
        return try {
            val root = JSONObject(raw)
            root.keys().asSequence().associateWith { id ->
                val o = root.getJSONObject(id)
                PendingMedia(o.getString("path"), o.getString("mimeType"), o.getString("fileName"))
            }
        } catch (_: Exception) { emptyMap() }
    }

    private fun writePendingMedia(context: Context, map: Map<String, PendingMedia>) {
        val root = JSONObject()
        map.forEach { (id, media) ->
            root.put(id, JSONObject().apply {
                put("path", media.path)
                put("mimeType", media.mimeType)
                put("fileName", media.fileName)
            })
        }
        prefs(context).edit().putString(KEY_PENDING_MEDIA, root.toString()).apply()
    }

    /**
     * Le voisin source possède déjà cette publicité. On le marque donc comme
     * déjà servi afin que le scheduler ne la lui renvoie pas au tick suivant.
     */
    @Synchronized
    fun markSentToNeighbor(context: Context, adId: String, neighborNodeId: String) {
        ensureSchema(context)
        if (adId.isBlank() || neighborNodeId.isBlank()) return
        val current = readSentState(context).toMutableMap()
        val neighbors = current[adId]?.toMutableSet() ?: mutableSetOf()
        neighbors.add(neighborNodeId)
        current[adId] = neighbors
        writeSentState(context, current)
    }

    @Synchronized
    fun wasSentToNeighbor(context: Context, adId: String, neighborNodeId: String): Boolean {
        ensureSchema(context)
        return readSentState(context)[adId]?.contains(neighborNodeId) == true
    }

    @Synchronized
    fun clearNeighborState(context: Context, neighborNodeId: String) {
        ensureSchema(context)
        if (neighborNodeId.isBlank()) return
        val state = readSentState(context).mapValues { (_, ids) ->
            ids.filterNot { it == neighborNodeId }.toSet()
        }.filterValues { it.isNotEmpty() }
        writeSentState(context, state)
    }

    private fun readSentState(context: Context): Map<String, Set<String>> {
        val raw = prefs(context).getString(KEY_SENT_BY_NEIGHBOR, null) ?: return emptyMap()
        return try {
            val root = JSONObject(raw)
            root.keys().asSequence().associateWith { adId ->
                val arr = root.optJSONArray(adId) ?: JSONArray()
                (0 until arr.length()).map { arr.getString(it) }.toSet()
            }
        } catch (_: Exception) {
            emptyMap()
        }
    }

    private fun writeSentState(context: Context, state: Map<String, Set<String>>) {
        val root = JSONObject()
        state.forEach { (adId, neighbors) ->
            val arr = JSONArray()
            neighbors.forEach { arr.put(it) }
            root.put(adId, arr)
        }
        prefs(context).edit().putString(KEY_SENT_BY_NEIGHBOR, root.toString()).apply()
    }

    private fun pruneState(context: Context, activeIds: Set<String>) {
        val state = readSentState(context).filterKeys { it in activeIds }
        writeSentState(context, state)
        val seen = prefs(context).getStringSet(KEY_SEEN_IDS, emptySet())
            ?.filterTo(mutableSetOf()) { it in activeIds } ?: mutableSetOf()
        prefs(context).edit().putStringSet(KEY_SEEN_IDS, seen).apply()
    }

    private fun readAll(context: Context): List<AdPayload> {
        val raw = prefs(context).getString(KEY_ACTIVE_ADS, null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            (0 until arr.length()).map { i ->
                val o = arr.getJSONObject(i)
                AdPayload(
                    id = o.getString("id"),
                    module = runCatching { ZeeModule.valueOf(o.optString("module", ZeeModule.CHAT.name)) }.getOrDefault(ZeeModule.CHAT),
                    sellerName = o.getString("sellerName"),
                    headline = o.getString("headline"),
                    subtext = if (o.isNull("subtext")) null else o.getString("subtext"),
                    imageBase64 = if (o.isNull("imageBase64")) null else o.getString("imageBase64"),
                    adCode = o.getString("adCode"),
                    expiresAt = o.getLong("expiresAt"),
                    mediaPath = o.optString("mediaPath").ifBlank { null },
                    mediaMimeType = o.optString("mediaMimeType").ifBlank { null },
                    mediaFileName = o.optString("mediaFileName").ifBlank { null }
                )
            }
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun writeAll(context: Context, ads: List<AdPayload>) {
        val arr = JSONArray()
        ads.forEach { ad ->
            arr.put(JSONObject().apply {
                put("id", ad.id)
                put("module", ad.module.name)
                put("sellerName", ad.sellerName)
                put("headline", ad.headline)
                put("subtext", ad.subtext)
                put("imageBase64", ad.imageBase64)
                put("adCode", ad.adCode)
                put("expiresAt", ad.expiresAt)
                put("mediaPath", ad.mediaPath)
                put("mediaMimeType", ad.mediaMimeType)
                put("mediaFileName", ad.mediaFileName)
            })
        }
        prefs(context).edit().putString(KEY_ACTIVE_ADS, arr.toString()).apply()
    }
}
