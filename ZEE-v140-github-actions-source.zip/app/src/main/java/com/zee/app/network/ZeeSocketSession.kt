package com.zee.app.network

import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.BufferedReader
import java.io.BufferedWriter
import java.io.InputStreamReader
import java.io.OutputStreamWriter
import java.net.ServerSocket
import java.net.Socket
import java.util.concurrent.ArrayBlockingQueue

/**
 * Canal TCP simple par-dessus le groupe Wi-Fi Direct.
 *
 * Le "group owner" (décidé automatiquement par Android lors de connectTo())
 * fait office de petit serveur local ; l'autre appareil s'y connecte en
 * client. Les deux rôles utilisent le même port ZEE_PORT.
 *
 * Le protocole applicatif est volontairement minimal : chaque message est
 * une ligne JSON terminée par \n (voir ZeeMessageCodec). Pour les pièces
 * jointes volumineuses (photo/vidéo/audio), n'envoyer que les métadonnées
 * ici et transférer le fichier via un flux binaire séparé
 * (à implémenter : FileTransferServer, sur ZEE_PORT + 1).
 */
class ZeeSocketSession(
    private val scope: CoroutineScope,
    var onMessageReceived: (String) -> Unit,
    var onSessionReady: () -> Unit,
    var onSessionError: (Throwable) -> Unit
) {
    private var socket: Socket? = null
    private var writer: BufferedWriter? = null
    private val outbound = ArrayBlockingQueue<String>(1024)
    @Volatile private var writerRunning = false
    @Volatile private var closed = false
    private var writerThread: Thread? = null
    private var serverSocket: ServerSocket? = null

    @Volatile
    var onClosed: (() -> Unit)? = null

    /** Appelé uniquement après que la ligne a réellement été écrite et flushée sur le socket. */
    @Volatile
    var onLineFlushed: ((String) -> Unit)? = null

    /**
     * Adresse IP réelle de l'autre bout de la connexion, valable côté
     * serveur (le socket accepté révèle l'IP du client) ET côté client
     * (l'IP qu'on a explicitement composée) — utile pour que le "group
     * owner" sache où envoyer un fichier à son client (voir
     * SessionRegistry.peerRemoteAddress), ce que WifiP2pInfo seul ne
     * fournit pas (il ne donne que l'adresse du group owner).
     */
    var remoteAddress: String? = null
        private set

    /** À appeler côté "group owner". */
    fun startAsServer(port: Int = WifiDirectManager.ZEE_PORT) {
        scope.launch(Dispatchers.IO) {
            try {
                val server = ServerSocket(port)
                serverSocket = server
                val client = server.accept() // compatibilité ancien mode mono-client
                attach(client)
            } catch (e: Exception) {
                onSessionError(e)
            }
        }
    }

    /**
     * À appeler côté client, avec l'adresse IP du group owner.
     *
     * Réessaie automatiquement plusieurs fois avant d'abandonner : côté
     * "group owner", le serveur (ServerSocket) n'est pas forcément encore
     * prêt à accepter des connexions à l'instant précis où ce côté-ci tente
     * de s'y connecter (les deux appareils reçoivent la notification de
     * connexion Wi-Fi Direct à des instants légèrement différents) — sans
     * cette nouvelle tentative, une seule "connexion refusée" suffisait à
     * empêcher tout échange de message pour le reste de la session.
     */
    fun startAsClient(hostAddress: String, port: Int = WifiDirectManager.ZEE_PORT) {
        scope.launch(Dispatchers.IO) {
            val maxAttempts = 15
            val delayMs = 800L
            for (attempt in 1..maxAttempts) {
                try {
                    val s = Socket()
                    s.tcpNoDelay = true
                    s.keepAlive = true
                    s.sendBufferSize = 64 * 1024
                    s.receiveBufferSize = 64 * 1024
                    s.connect(java.net.InetSocketAddress(hostAddress, port), 3000)
                    attach(s)
                    return@launch
                } catch (e: Exception) {
                    Log.d("ZeeSocketSession", "Connexion au pair échouée (essai $attempt/$maxAttempts), nouvelle tentative...")
                    if (attempt == maxAttempts) {
                        onSessionError(e)
                    } else {
                        kotlinx.coroutines.delay(delayMs)
                    }
                }
            }
        }
    }

    private fun attach(s: Socket) {
        closed = false
        socket = s
        s.tcpNoDelay = true
        s.keepAlive = true
        s.sendBufferSize = 64 * 1024
        s.receiveBufferSize = 64 * 1024
        remoteAddress = s.inetAddress?.hostAddress
        writer = BufferedWriter(OutputStreamWriter(s.getOutputStream(), Charsets.UTF_8))
        startWriterLoop()
        onSessionReady()
        listenLoop(s)
    }

    /** Un seul writer persistant par socket : aucun lancement de coroutine par message. */
    private fun startWriterLoop() {
        if (writerRunning) return
        writerRunning = true
        writerThread = Thread({
            try {
                while (writerRunning) {
                    val line = outbound.take()
                    val w = writer ?: break
                    w.write(line)
                    w.newLine()
                    w.flush()
                    onLineFlushed?.invoke(line)
                }
            } catch (e: InterruptedException) {
                // fermeture normale
            } catch (e: Exception) {
                if (writerRunning) {
                    Log.e("ZeeSocketSession", "Écriture réseau interrompue", e)
                    onSessionError(e)
                }
            } finally {
                writerRunning = false
            }
        }, "ZeeChatWriter-${remoteAddress ?: "peer"}").apply { isDaemon = true }
        writerThread?.start()
    }

    /** Attache un socket déjà accepté par le serveur maillé. */
    fun startWithSocket(s: Socket) {
        attach(s)
    }

    private fun listenLoop(s: Socket) {
        scope.launch(Dispatchers.IO) {
            try {
                val reader = BufferedReader(InputStreamReader(s.getInputStream()))
                while (true) {
                    val line = reader.readLine() ?: break
                    onMessageReceived(line)
                }
            } catch (e: Exception) {
                if (!closed) {
                    Log.e("ZeeSocketSession", "Connexion perdue avec le pair", e)
                    onSessionError(e)
                }
            } finally {
                onClosed?.invoke()
            }
        }
    }

    /** Envoie une ligne JSON encodée (voir ZeeMessageCodec.encode). */
    fun send(jsonLine: String): Boolean {
        if (!writerRunning || jsonLine.isBlank()) return false
        // offer() ne bloque jamais le thread UI/routeur. Si la file est pleine,
        // le message reste dans MeshMessageStore et sera repris à la prochaine route.
        if (!outbound.offer(jsonLine)) {
            Log.w("ZeeSocketSession", "File d'envoi pleine; message différé")
            return false
        }
        return true
    }

    fun close() {
        closed = true
        writerRunning = false
        writerThread?.interrupt()
        writerThread = null
        outbound.clear()
        runCatching { writer?.close() }
        runCatching { socket?.close() }
        runCatching { serverSocket?.close() }
    }
}
