package com.zee.app.adapter

import android.media.MediaPlayer
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.zee.app.R
import com.zee.app.model.ChatMessage
import com.zee.app.model.MessageType

class MessageAdapter(private var messages: MutableList<ChatMessage>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    companion object {
        private const val TYPE_ME = 0
        private const val TYPE_THEM = 1
    }

    // Un seul lecteur actif à la fois, comme les apps de messagerie
    // classiques ; on le libère à chaque changement de piste.
    private var activePlayer: MediaPlayer? = null
    private var activePlayButton: ImageButton? = null

    fun addMessage(message: ChatMessage) {
        messages.add(message)
        notifyItemInserted(messages.size - 1)
    }

    override fun getItemViewType(position: Int) =
        if (messages[position].fromMe) TYPE_ME else TYPE_THEM

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val layout = if (viewType == TYPE_ME) R.layout.item_message_me else R.layout.item_message_them
        val view = LayoutInflater.from(parent.context).inflate(layout, parent, false)
        return object : RecyclerView.ViewHolder(view) {}
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val msg = messages[position]
        val txt = holder.itemView.findViewById<TextView>(R.id.txtMessage)
        val img = holder.itemView.findViewById<ImageView>(R.id.imgMessage)
        val audioContainer = holder.itemView.findViewById<View>(R.id.audioContainer)
        val btnPlay = holder.itemView.findViewById<ImageButton>(R.id.btnPlayAudio)

        txt.visibility = View.GONE
        img.visibility = View.GONE
        audioContainer.visibility = View.GONE

        when {
            (msg.type == MessageType.IMAGE || msg.type == MessageType.VIDEO) && msg.filePath != null -> {
                img.visibility = View.VISIBLE
                // Les ViewHolder sont recyclés : on repart du gabarit par défaut (250dp) avant
                // de recalculer le ratio, sinon la taille de l'image précédente reste affichée.
                val defaultSide = (250f * img.resources.displayMetrics.density).toInt()
                img.layoutParams = img.layoutParams.apply { width = defaultSide; height = defaultSide }

                if (msg.type == MessageType.IMAGE) {
                    img.setImageURI(Uri.parse(msg.filePath))
                }
                img.setOnClickListener {
                    com.zee.app.ui.MediaViewerActivity.start(
                        holder.itemView.context,
                        msg.filePath!!,
                        guessMime(msg)
                    )
                }
                if (msg.type == MessageType.VIDEO) {
                    val retriever = MediaMetadataRetriever()
                    try {
                        retriever.setDataSource(holder.itemView.context, Uri.parse(msg.filePath))
                        img.setImageBitmap(retriever.getFrameAtTime(0))
                    } catch (_: Exception) {
                        img.setImageResource(android.R.drawable.ic_media_play)
                    } finally {
                        retriever.release()
                    }
                }

                // Format média inspiré de WhatsApp :
                // largeur maximale 250dp, hauteur maximale 300dp,
                // tout en conservant le ratio original de la photo/vidéo.
                img.post {
                    val drawable = img.drawable ?: return@post
                    val sourceWidth = drawable.intrinsicWidth
                    val sourceHeight = drawable.intrinsicHeight
                    if (sourceWidth <= 0 || sourceHeight <= 0) return@post

                    val density = img.resources.displayMetrics.density
                    val maxWidth = (250f * density).toInt()
                    val maxHeight = (300f * density).toInt()

                    val ratio = sourceWidth.toFloat() / sourceHeight.toFloat()
                    var width = maxWidth
                    var height = (width / ratio).toInt()

                    if (height > maxHeight) {
                        height = maxHeight
                        width = (height * ratio).toInt()
                    }

                    // Évite les dimensions minuscules pour les images très verticales/horizontales.
                    width = width.coerceAtLeast((120f * density).toInt())
                    height = height.coerceAtLeast((120f * density).toInt())

                    val lp = img.layoutParams
                    lp.width = width
                    lp.height = height
                    img.layoutParams = lp
                }
            }
            msg.type == MessageType.AUDIO && msg.filePath != null -> {
                audioContainer.visibility = View.VISIBLE
                btnPlay.setImageResource(android.R.drawable.ic_media_play)
                btnPlay.setOnClickListener { toggleAudio(msg.filePath!!, btnPlay) }
            }
            else -> {
                txt.visibility = View.VISIBLE
                txt.text = msg.text ?: "[pièce jointe]"
                if (msg.type == MessageType.DOCUMENT && msg.filePath != null) {
                    txt.setOnClickListener {
                        com.zee.app.ui.MediaViewerActivity.start(
                            holder.itemView.context, msg.filePath!!, guessMime(msg)
                        )
                    }
                } else if (msg.type == MessageType.LOCATION) {
                    txt.setOnClickListener {
                        val url = msg.text?.substringAfter("https://", "").takeIf { !it.isNullOrBlank() }?.let { "https://$it" }
                        if (url != null) {
                            runCatching { holder.itemView.context.startActivity(android.content.Intent(android.content.Intent.ACTION_VIEW, Uri.parse(url))) }
                        }
                    }
                } else {
                    txt.setOnClickListener(null)
                }
            }
        }
    }

    /** Joue/pause le message vocal sur lequel on vient de taper. */
    private fun toggleAudio(filePath: String, button: ImageButton) {
        if (activePlayButton === button && activePlayer != null) {
            // Même piste déjà en cours -> pause/arrêt
            activePlayer?.stop()
            activePlayer?.release()
            activePlayer = null
            button.setImageResource(android.R.drawable.ic_media_play)
            activePlayButton = null
            return
        }

        // Une autre piste jouait -> on l'arrête d'abord
        activePlayer?.stop()
        activePlayer?.release()
        activePlayButton?.setImageResource(android.R.drawable.ic_media_play)

        val player = MediaPlayer()
        try {
            player.setDataSource(button.context, Uri.parse(filePath))
            player.setOnCompletionListener {
                button.setImageResource(android.R.drawable.ic_media_play)
                activePlayer = null
                activePlayButton = null
            }
            player.prepare()
            player.start()
            button.setImageResource(android.R.drawable.ic_media_pause)
            activePlayer = player
            activePlayButton = button
        } catch (e: Exception) {
            button.setImageResource(android.R.drawable.ic_media_play)
        }
    }

    private fun guessMime(msg: ChatMessage): String = when (msg.type) {
        MessageType.IMAGE -> "image/*"
        MessageType.VIDEO -> "video/*"
        MessageType.AUDIO -> "audio/*"
        MessageType.DOCUMENT -> "application/octet-stream"
        else -> "text/plain"
    }

    /** À appeler quand l'écran de chat se ferme, pour libérer le lecteur audio. */
    fun releasePlayer() {
        activePlayer?.release()
        activePlayer = null
        activePlayButton = null
    }

    override fun getItemCount() = messages.size
}
