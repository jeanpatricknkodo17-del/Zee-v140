package com.zee.app.adapter

import android.graphics.BitmapFactory
import android.util.Base64
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.zee.app.R
import com.zee.app.model.Peer
import com.zee.app.model.PeerStatus

/** Présentation dédiée à l'onglet JOB, fidèle à la maquette de référence. */
class JobAdapter(
    private var rows: List<JobRow>,
    private val onClick: (JobRow) -> Unit
) : RecyclerView.Adapter<JobAdapter.Holder>() {

    data class JobRow(
        val name: String,
        val role: String,
        val online: Boolean,
        val minutesAgo: Int? = null,
        val distance: Int?,
        val avatar: Int,
        val peer: Peer? = null
    )

    fun submitList(value: List<JobRow>) {
        rows = value
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder =
        Holder(LayoutInflater.from(parent.context).inflate(R.layout.item_job_peer, parent, false))

    override fun onBindViewHolder(holder: Holder, position: Int) = holder.bind(rows[position])
    override fun getItemCount(): Int = rows.size

    inner class Holder(view: View) : RecyclerView.ViewHolder(view) {
        private val root = view
        private val avatar = view.findViewById<de.hdodenhof.circleimageview.CircleImageView>(R.id.jobAvatar)
        private val name = view.findViewById<TextView>(R.id.jobName)
        private val role = view.findViewById<TextView>(R.id.jobRole)
        private val status = view.findViewById<TextView>(R.id.jobStatus)
        private val dot = view.findViewById<View>(R.id.jobStatusDot)
        private val distance = view.findViewById<TextView>(R.id.jobDistance)

        fun bind(row: JobRow) {
            name.text = row.name
            role.text = row.role
            role.setBackgroundResource(if (row.role == "Recruteur") R.drawable.bg_job_role_cyan else R.drawable.bg_job_role_purple)
            status.text = if (row.online) "En ligne" else "Hors ligne"
            dot.setBackgroundResource(if (row.online) R.drawable.bg_online_dot else R.drawable.bg_job_offline_dot)
            distance.text = row.distance?.let { "$it m" } ?: "--"
            avatar.setImageResource(row.avatar)

            // La photo JOB est prioritaire ; si elle n'est pas encore reçue,
            // utiliser la photo générale du profil. Cela garantit qu'un profil
            // détecté garde sa photo dans le cercle JOB comme dans RENCONTRES
            // et BUSINESS.
            val base64Photo = row.peer?.photosByModule[com.zee.app.model.ZeeModule.JOB]
                ?.takeIf { it.isNotBlank() }
                ?: row.peer?.photoBase64?.takeIf { it.isNotBlank() }
            base64Photo?.let { base64 ->
                try {
                    val bytes = Base64.decode(base64, Base64.DEFAULT)
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size)?.let { avatar.setImageBitmap(it) }
                } catch (_: Exception) { }
            }

            root.setOnClickListener { onClick(row) }
        }
    }
}
