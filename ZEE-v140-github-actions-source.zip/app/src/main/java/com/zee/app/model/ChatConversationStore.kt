package com.zee.app.model

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Résumé réel des conversations. Aucun contenu de démonstration n'est créé.
 * Une ligne n'existe qu'après qu'un vrai message a été envoyé/reçu ou qu'un
 * pair réellement connecté a été identifié.
 */
object ChatConversationStore {
    data class Conversation(
        val key: String,
        val name: String,
        val preview: String,
        val timestamp: Long,
        val unread: Int,
        val photoBase64: String?
    )

    private const val PREFS = "zee_chat_conversations"
    private const val KEY = "items"
    private const val KEY_SCHEMA = "schema"
    private const val SCHEMA_VERSION = 2

    private fun prefs(context: Context) = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    private fun ensureSchema(context: Context) {
        val p = prefs(context)
        if (p.getInt(KEY_SCHEMA, 0) != SCHEMA_VERSION) {
            // Les versions précédentes pouvaient contenir des conversations
            // de maquette. Elles ne sont pas des échanges réels : on les
            // supprime une seule fois lors de la migration.
            p.edit().clear().putInt(KEY_SCHEMA, SCHEMA_VERSION).apply()
        }
    }

    @Synchronized
    fun recordIncoming(context: Context, key: String, name: String, text: String, photoBase64: String? = null) {
        ensureSchema(context)
        upsert(context, key, name, text, System.currentTimeMillis(), incrementUnread = true, photoBase64 = photoBase64)
    }

    @Synchronized
    fun recordOutgoing(context: Context, key: String, name: String, text: String, photoBase64: String? = null) {
        ensureSchema(context)
        upsert(context, key, name, text, System.currentTimeMillis(), incrementUnread = false, photoBase64 = photoBase64)
    }

    @Synchronized
    fun markRead(context: Context, key: String) {
        ensureSchema(context)
        val map = read(context).associateBy { it.key }.toMutableMap()
        val old = map[key] ?: return
        map[key] = old.copy(unread = 0)
        write(context, map.values.toList())
    }

    @Synchronized
    fun list(context: Context): List<Conversation> {
        ensureSchema(context)
        return read(context).sortedByDescending { it.timestamp }
    }

    private fun upsert(context: Context, key: String, name: String, text: String, timestamp: Long, incrementUnread: Boolean, photoBase64: String?) {
        if (key.isBlank()) return
        val map = read(context).associateBy { it.key }.toMutableMap()
        val old = map[key]
        map[key] = Conversation(
            key = key,
            name = name.ifBlank { old?.name ?: "Profil ZEE" },
            preview = text,
            timestamp = timestamp,
            unread = if (incrementUnread) (old?.unread ?: 0) + 1 else (old?.unread ?: 0),
            photoBase64 = photoBase64 ?: old?.photoBase64
        )
        write(context, map.values.toList())
    }

    private fun read(context: Context): List<Conversation> {
        val raw = prefs(context).getString(KEY, "[]") ?: "[]"
        return runCatching {
            val array = JSONArray(raw)
            buildList {
                for (i in 0 until array.length()) {
                    val o = array.getJSONObject(i)
                    add(Conversation(
                        key = o.optString("key"),
                        name = o.optString("name"),
                        preview = o.optString("preview"),
                        timestamp = o.optLong("timestamp", 0L),
                        unread = o.optInt("unread", 0),
                        photoBase64 = o.optString("photo", "").ifBlank { null }
                    ))
                }
            }.filter { it.key.isNotBlank() }
        }.getOrDefault(emptyList())
    }

    private fun write(context: Context, items: List<Conversation>) {
        val array = JSONArray()
        items.forEach { item ->
            array.put(JSONObject().apply {
                put("key", item.key)
                put("name", item.name)
                put("preview", item.preview)
                put("timestamp", item.timestamp)
                put("unread", item.unread)
                put("photo", item.photoBase64 ?: "")
            })
        }
        prefs(context).edit().putString(KEY, array.toString()).apply()
    }

    fun formatTime(timestamp: Long): String {
        if (timestamp <= 0L) return ""
        val now = System.currentTimeMillis()
        val today = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(now))
        val date = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(timestamp))
        if (today == date) return SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(timestamp))
        val yesterday = now - 24L * 60L * 60L * 1000L
        val yesterdayDate = SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date(yesterday))
        if (date == yesterdayDate) return "Hier"
        return SimpleDateFormat("dd/MM", Locale.getDefault()).format(Date(timestamp))
    }
}
