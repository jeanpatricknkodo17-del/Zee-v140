package com.zee.app.ui

import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat

/**
 * Gestion plein écran ZEE avec prise en charge explicite du clavier (IME).
 * Quand le clavier s'ouvre, la vue passée en bottomInsetView reçoit la
 * hauteur du clavier afin que la zone de saisie ou le formulaire reste
 * visible et que le champ actif puisse être remonté par le ScrollView.
 */
fun AppCompatActivity.applyZeeEdgeToEdge(topInsetView: View?, bottomInsetView: View? = null) {
    WindowCompat.setDecorFitsSystemWindows(window, false)
    window.setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE)

    val topBase = topInsetView?.let {
        intArrayOf(it.paddingLeft, it.paddingTop, it.paddingRight, it.paddingBottom)
    }
    val bottomBase = bottomInsetView?.let {
        intArrayOf(it.paddingLeft, it.paddingTop, it.paddingRight, it.paddingBottom)
    }

    val rootView = findViewById<View>(android.R.id.content)
    ViewCompat.setOnApplyWindowInsetsListener(rootView) { _, insets ->
        val system = insets.getInsets(
            WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.displayCutout()
        )
        val ime = insets.getInsets(WindowInsetsCompat.Type.ime())

        topInsetView?.let { view ->
            val base = topBase!!
            view.setPadding(
                maxOf(base[0], system.left),
                base[1] + system.top,
                maxOf(base[2], system.right),
                base[3]
            )
        }

        bottomInsetView?.let { view ->
            val base = bottomBase!!
            // Le clavier doit primer sur la barre de navigation.
            val bottom = maxOf(system.bottom, ime.bottom)
            view.setPadding(
                base[0],
                base[1],
                base[2],
                base[3] + bottom
            )
        }

        insets
    }
    ViewCompat.requestApplyInsets(rootView)
}
