package com.zee.app.model

import android.content.Context
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** Historique local des interventions affichées dans BUSINESS. */
object BusinessActivityStore {
    data class Activity(
        val id: Long,
        val name: String,
        val title: String,
        val comment: String,
        val timestamp: Long,
        val avatar: Int,
        val badge: Int
    )

    private const val PREFS = "zee_business_activities"
    private const val KEY = "items"
    private val format = SimpleDateFormat("HH:mm", Locale.getDefault())

    private const val KEY_SCHEMA = "schema"
    private const val SCHEMA_VERSION = 2

    fun list(context: Context): List<Activity> {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        // v2 supprime les activités de démonstration de la version précédente.
        // Après migration, seules les activités créées par de vraies interactions
        // de l'application sont conservées.
        if (prefs.getInt(KEY_SCHEMA, 0) != SCHEMA_VERSION) {
            prefs.edit().clear().putInt(KEY_SCHEMA, SCHEMA_VERSION).apply()
            return emptyList()
        }
        val raw = prefs.getString(KEY, null)
        if (raw.isNullOrBlank()) return emptyList()
        return raw.split("\\n").mapNotNull { line ->
            val p = line.split("|", limit = 7)
            if (p.size != 7) return@mapNotNull null
            runCatching {
                Activity(p[0].toLong(), p[1], p[2], p[3], p[4].toLong(), p[5].toInt(), p[6].toInt())
            }.getOrNull()
        }.sortedByDescending { it.timestamp }
    }

    fun add(context: Context, name: String, title: String, comment: String, avatar: Int = com.zee.app.R.drawable.ic_default_avatar, badge: Int = com.zee.app.R.drawable.bg_activity_badge_blue) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        if (prefs.getInt(KEY_SCHEMA, 0) != SCHEMA_VERSION) {
            prefs.edit().clear().putInt(KEY_SCHEMA, SCHEMA_VERSION).apply()
        }
        val items = list(context).toMutableList()
        items.add(0, Activity(System.currentTimeMillis(), name, title, comment, System.currentTimeMillis(), avatar, badge))
        save(context, items.distinctBy { "${it.name}|${it.title}|${it.comment}" }.take(20))
    }

    fun time(timestamp: Long): String = format.format(Date(timestamp))

    private fun save(context: Context, items: List<Activity>) {
        val raw = items.joinToString("\\n") {
            listOf(it.id, it.name.replace("|", " "), it.title.replace("|", " "), it.comment.replace("|", " "), it.timestamp, it.avatar, it.badge).joinToString("|")
        }
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit().putString(KEY, raw).apply()
    }
}
