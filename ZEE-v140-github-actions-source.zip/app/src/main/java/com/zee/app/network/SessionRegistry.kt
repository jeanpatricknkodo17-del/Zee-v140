package com.zee.app.network
import java.io.File

import android.content.Context
import com.zee.app.model.ProfileStore
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.ConcurrentLinkedQueue
import java.util.concurrent.Executors
import java.util.concurrent.TimeUnit

/**
 * Registre des voisins et point d'entrée du routeur ZEE.
 * Une conversation n'est plus limitée à une session unique : chaque liaison
 * TCP vivante peut devenir un prochain saut. Cela permet au protocole de
 * fonctionner avec Wi-Fi Direct aujourd'hui et avec plusieurs transports
 * simultanés (Wi-Fi Aware, futur transport) demain.
 */
object SessionRegistry {
    data class ConnectionInfo(val hostAddress: String, val isGroupOwner: Boolean)

    @Volatile var active: ConnectionInfo? = null
    @Volatile var session: ZeeSocketSession? = null
    @Volatile var connectedPeerAddress: String? = null
    @Volatile var peerRemoteAddress: String? = null
    @Volatile var activeChatPeerAddress: String? = null
    @Volatile var activeChatNodeId: String? = null
    @Volatile var activeChatChannel: String = com.zee.app.model.MessageChannels.CHAT
    @Volatile var activeChatListener: ((String) -> Unit)? = null
    @Volatile var activeAttachmentListener: ((File, String, String, String) -> Unit)? = null
    @Volatile var activeProfileListener: ((String, String, String?) -> Unit)? = null
    @Volatile var latestProfilePeerAddress: String? = null
    @Volatile var latestProfileName: String = ""
    @Volatile var latestProfileActu: String = ""
    @Volatile var latestProfilePhotoBase64: String? = null
    @Volatile var localNodeId: String = ""

    /** Route logique : une destination peut être derrière un relais. */
    private val sessionsByNodeId = ConcurrentHashMap<String, ZeeSocketSession>()
    /** Identité du voisin TCP réellement connecté sur chaque socket.
     * Un socket peut transporter plusieurs nodeId relayés : on ne doit donc
     * jamais écraser cette valeur avec un profil distant relayé. */
    private val peerNodeIdBySession = ConcurrentHashMap<ZeeSocketSession, String>()
    /** Adresse du voisin TCP direct pour chaque socket. Indispensable côté GO,
     * où plusieurs clients partagent le même processus et le même routeur. */
    private val peerAddressBySession = ConcurrentHashMap<ZeeSocketSession, String>()
    private val profilesByNodeId = ConcurrentHashMap<String, ProfileSnapshot>()
    /** État du protocole ZEE sur chaque socket : READY signifie que les deux
     * extrémités ont confirmé le canal applicatif, pas seulement le socket TCP. */
    private val protocolReadyBySession = ConcurrentHashMap<ZeeSocketSession, Boolean>()

    data class ProfileSnapshot(val name: String, val actu: String, val photoBase64: String?)
    private var store: MeshMessageStore? = null
    private val pendingActiveChatTexts = ConcurrentLinkedQueue<String>()
    /** Messages already accepted by a socket writer; prevents the periodic
     * retry pass from enqueueing the same line twice before its flush callback. */
    private val inFlightMessageIds = ConcurrentHashMap.newKeySet<String>()
    /** Session qui a accepté chaque message. Permet de libérer un in-flight
     * si le socket meurt avant le callback onLineFlushed. */
    private val inFlightSessionByMessageId = ConcurrentHashMap<String, ZeeSocketSession>()
    private val inFlightSinceByMessageId = ConcurrentHashMap<String, Long>()
    /** Retour du CHAT : chaque relais mémorise le socket par lequel le message
     * est arrivé afin que l'ACK reparte exactement sur le chemin inverse. */
    private val returnSessionByMessageId = ConcurrentHashMap<String, ZeeSocketSession>()
    private val retryExecutor = Executors.newSingleThreadScheduledExecutor { r ->
        Thread(r, "zee-chat-retry").apply { isDaemon = true }
    }
    @Volatile private var retryStarted = false
    @Volatile private var webRtcReady: ((String) -> Boolean)? = null
    @Volatile private var webRtcSendLine: ((String, String) -> Boolean)? = null
    @Volatile private var webRtcSendFile: ((String, File, String, String, String, String, Long, String, Int, String) -> Boolean)? = null

    fun initialize(context: Context) {
        if (localNodeId.isBlank()) localNodeId = ProfileStore.getNodeId(context)
        if (store == null) store = MeshMessageStore(context.applicationContext)
        if (!retryStarted) {
            synchronized(this) {
                if (!retryStarted) {
                    retryStarted = true
                    retryExecutor.scheduleWithFixedDelay({
                        runCatching {
                            releaseExpiredInFlight()
                            flushPendingChatMessages()
                        }
                    }, 2L, 2L, TimeUnit.SECONDS)
                }
            }
        }
    }

    fun registerActiveChat(peerAddress: String, nodeId: String?, channel: String = com.zee.app.model.MessageChannels.CHAT, onChat: (String) -> Unit, onProfile: (String, String, String?) -> Unit, onAttachment: ((File, String, String, String) -> Unit)? = null) {
        activeChatPeerAddress = peerAddress
        activeChatNodeId = nodeId?.takeIf { it.isNotBlank() }
        activeChatChannel = com.zee.app.model.MessageChannels.normalize(channel)
        activeChatListener = onChat
        activeProfileListener = onProfile
        activeAttachmentListener = onAttachment
        nodeId?.let { profilesByNodeId[it] }?.let { p -> onProfile(p.name, p.actu, p.photoBase64) }
        if (latestProfilePeerAddress == peerAddress) onProfile(latestProfileName, latestProfileActu, latestProfilePhotoBase64)
    }

    fun updateLatestProfile(peerAddress: String, name: String, actu: String, photoBase64: String?) {
        latestProfilePeerAddress = peerAddress
        latestProfileName = name
        latestProfileActu = actu
        latestProfilePhotoBase64 = photoBase64
        if (activeChatPeerAddress == peerAddress) activeProfileListener?.invoke(name, actu, photoBase64)
    }

    fun updateProfile(nodeId: String, name: String, actu: String, photoBase64: String?, sourceSession: ZeeSocketSession? = null, direct: Boolean = true) {
        if (nodeId.isBlank() || nodeId == localNodeId) return
        profilesByNodeId[nodeId] = ProfileSnapshot(name, actu, photoBase64)

        // Le nodeId n'est pas forcément connu au moment où ChatActivity est
        // ouverte : la découverte DNS-SD peut n'avoir fourni que l'adresse du
        // pair. Le PROFILE reçu sur la session est l'autorité pour associer
        // cette conversation à son nodeId ZEE.
        if (direct && activeChatNodeId.isNullOrBlank()) {
            // Seul un PROFILE direct peut initialiser une conversation dont
            // le nodeId n'était pas encore connu. Un profil relayé peut
            // traverser le même socket que le voisin sélectionné et ne doit
            // jamais prendre sa place.
            val sourceAddress = sourceSession?.let { peerAddressBySession[it] ?: it.remoteAddress }
            val selectedAddressMatches = activeChatPeerAddress != null && sourceAddress == activeChatPeerAddress
            if (selectedAddressMatches) activeChatNodeId = nodeId
        }

        if (activeChatNodeId == nodeId) {
            // Dès que l'identité réelle est connue, les messages saisis avant
            // le handshake peuvent partir immédiatement.
            flushPendingChatMessages()
            activeProfileListener?.invoke(name, actu, photoBase64)
        }
    }

    /** Associe explicitement la conversation ouverte au nodeId après le handshake. */
    fun bindActiveChatNode(nodeId: String) {
        if (nodeId.isBlank() || nodeId == localNodeId) return
        activeChatNodeId = nodeId
        profilesByNodeId[nodeId]?.let { p ->
            activeProfileListener?.invoke(p.name, p.actu, p.photoBase64)
        }
        // Un utilisateur peut appuyer sur Envoyer avant la fin du handshake.
        // On ne perd pas ce texte : il est converti en message ZEE dès que le
        // nodeId réel du correspondant est connu.
        while (true) {
            val text = pendingActiveChatTexts.poll() ?: break
            if (text.isNotBlank()) sendChat(text)
        }
    }

    fun profileFor(nodeId: String): ProfileSnapshot? = profilesByNodeId[nodeId]

    /** Enregistre l'identité du voisin TCP réellement connecté.
     * Contrairement à registerRoute(), cette méthode ne doit être appelée
     * que pour un PROFILE marqué direct=true. Un profil relayé ne peut jamais
     * changer l'identité physique du socket.
     */
    fun registerDirectPeer(nodeId: String?, session: ZeeSocketSession) {
        if (nodeId.isNullOrBlank() || nodeId == localNodeId) return
        peerNodeIdBySession[session] = nodeId
        val previous = sessionsByNodeId.put(nodeId, session)
        session.remoteAddress?.let { peerAddressBySession[session] = it }
        protocolReadyBySession[session] = protocolReadyBySession[session] == true
        if (previous != null && previous !== session) {
            // Le même nodeId ne doit jamais rester attaché à deux transports :
            // sinon un ACK ou un CHAT peut partir sur une ancienne connexion.
            removeAllRoutesForSession(previous)
            runCatching { previous.close() }
        }
        flushPendingChatMessages()
    }

    fun registerSession(nodeId: String?, session: ZeeSocketSession) {
        if (!nodeId.isNullOrBlank()) {
            val old = sessionsByNodeId.put(nodeId, session)
            // nodeId correspond ici au pair TCP direct. Les profils relayés
            // doivent être enregistrés via registerRoute(), jamais ici.
            peerNodeIdBySession[session] = nodeId
            if (old != null && old !== session) {
                removeAllRoutesForSession(old)
                runCatching { old.close() }
            }
        }
        this.session = session
        protocolReadyBySession.putIfAbsent(session, false)
        session.remoteAddress?.let { peerAddressBySession[session] = it }
        // Ne pas écraser l'adresse du chat sélectionné lorsqu'un GO accepte
        // un autre client. L'adresse globale reste réservée au transport
        // actuellement sélectionné côté non-GO / ChatActivity.
        if (connectedPeerAddress == null || activeChatPeerAddress == session.remoteAddress) {
            peerRemoteAddress = session.remoteAddress
        }
        // La latence commence au moment où le writer a réellement flushé la ligne,
        // pas au moment où elle entre dans la file mémoire.
        session.onLineFlushed = { line ->
            val id = extractMessageId(line)
            if (id != null) {
                // Un paquet reçu puis relayé est mesuré séparément; un paquet
                // créé localement démarre ici son RTT de bout en bout.
                // Un flush TCP ne signifie PAS livraison finale. L'ID reste
                // in-flight jusqu'à l'ACK ou à l'expiration du délai de retry.
                ChatLatencyTracker.markRelayFlushed(id)
                if (org.json.JSONObject(line).optString("type") == "CHAT") {
                    ChatLatencyTracker.markSent(id)
                    store?.markAttempt(id)
                }
            }
        }
        flushPendingChatMessages()
    }

    /** Enregistre une destination derrière un relais sans modifier l'identité
     * du voisin TCP direct de la session. */
    fun registerRoute(nodeId: String?, session: ZeeSocketSession) {
        if (nodeId.isNullOrBlank() || nodeId == localNodeId) return
        sessionsByNodeId[nodeId] = session
        // Une route peut apparaître après que sendChat() a déjà placé le
        // message dans MeshMessageStore. Le handshake PROFILE doit donc
        // déclencher immédiatement la reprise des messages en attente.
        flushPendingChatMessages()
        // IMPORTANT : ne jamais déduire l'identité du voisin TCP à partir
        // d'une route logique. Sur un relais, plusieurs nodeId différents
        // peuvent traverser le même socket. L'identité physique est définie
        // uniquement par registerDirectPeer().
    }

    fun peerAddress(session: ZeeSocketSession): String? = peerAddressBySession[session] ?: session.remoteAddress

    fun removeSession(nodeId: String?, session: ZeeSocketSession) {
        clearInFlightForSession(session)
        if (!nodeId.isNullOrBlank()) sessionsByNodeId.remove(nodeId, session)
        removeAllRoutesForSession(session)
        peerNodeIdBySession.remove(session)
        peerAddressBySession.remove(session)
        protocolReadyBySession.remove(session)
        returnSessionByMessageId.entries.removeIf { it.value === session }
        if (this.session === session) this.session = sessionsByNodeId.values.firstOrNull()
        if (this.session == null) peerRemoteAddress = null
    }

    private fun clearInFlightForSession(session: ZeeSocketSession) {
        val ids = inFlightSessionByMessageId.entries
            .filter { it.value === session }
            .map { it.key }
        ids.forEach { id ->
            inFlightSessionByMessageId.remove(id, session)
            inFlightSinceByMessageId.remove(id)
            inFlightMessageIds.remove(id)
        }
    }

    private fun removeAllRoutesForSession(session: ZeeSocketSession) {
        clearInFlightForSession(session)
        sessionsByNodeId.entries.removeIf { it.value === session }
        peerNodeIdBySession.remove(session)
        peerAddressBySession.remove(session)
    }

    fun rememberReturnSession(messageId: String, session: ZeeSocketSession) {
        if (messageId.isNotBlank()) returnSessionByMessageId[messageId] = session
    }

    fun returnSessionFor(messageId: String): ZeeSocketSession? = returnSessionByMessageId[messageId]

    fun clearReturnSession(messageId: String) {
        if (messageId.isNotBlank()) returnSessionByMessageId.remove(messageId)
    }

    fun markProtocolReady(session: ZeeSocketSession, remoteNodeId: String? = null) {
        protocolReadyBySession[session] = true
        if (!remoteNodeId.isNullOrBlank() && remoteNodeId != localNodeId) {
            // HELLO/READY confirme le voisin direct, sans jamais créer une
            // route relayée à partir d'un simple contrôle.
            peerNodeIdBySession.putIfAbsent(session, remoteNodeId)
            // Si aucun PROFILE n'est encore arrivé, on connaît déjà le
            // prochain saut physique. Le PROFILE viendra ensuite compléter
            // le nom/photo et enregistrer la route logique.
        }
        flushPendingChatMessages()
    }

    fun isProtocolReady(session: ZeeSocketSession): Boolean = protocolReadyBySession[session] == true

    fun nodeFor(session: ZeeSocketSession): String? = peerNodeIdBySession[session]
    fun sessionFor(nodeId: String): ZeeSocketSession? = sessionsByNodeId[nodeId]

    /** NodeIds des voisins dont la session TCP est actuellement vivante. */
    fun activeNodeIds(): Set<String> = sessionsByNodeId.keys.toSet()
    fun hasRouteTo(nodeId: String): Boolean = sessionsByNodeId.containsKey(nodeId)

    /** Vrai uniquement si le nodeId est le voisin physique du socket.
     * Le Fast Wi-Fi ne doit jamais être utilisé pour un nodeId relayé. */
    fun isDirectNode(nodeId: String): Boolean {
        val s = sessionsByNodeId[nodeId] ?: return false
        return peerNodeIdBySession[s] == nodeId && isProtocolReady(s)
    }

    fun sendFileFastWifi(
        nodeId: String, file: File, messageId: String, fromNodeId: String, toNodeId: String,
        ttl: Int, fileName: String, mimeType: String, fileSize: Long, kind: String,
        sender: (String, ZeeFastWifiTransfer.Meta, File) -> Boolean
    ): Boolean {
        if (!isDirectNode(nodeId)) return false
        val host = nextHopAddress(nodeId) ?: return false
        val meta = ZeeFastWifiTransfer.Meta(
            messageId, fromNodeId, toNodeId, ttl, fileName, mimeType, fileSize, kind
        )
        return runCatching { sender(host, meta, file) }.getOrDefault(false)
    }

    /** Diffuse un paquet à toutes les liaisons connues, sauf éventuellement sa source. */
    fun broadcast(line: String, except: ZeeSocketSession? = null) {
        sessionsByNodeId.values.toSet().forEach { session ->
            if (session !== except) session.send(line)
        }
    }

    /** Branche le transport WebRTC. Le registre choisit WebRTC uniquement
     * lorsqu'il est réellement OPEN; sinon il conserve le prochain saut TCP. */
    fun registerWebRtcTransport(
        ready: (String) -> Boolean,
        sendLine: (String, String) -> Boolean,
        sendFile: (String, File, String, String, String, String, Long, String, Int, String) -> Boolean
    ) {
        webRtcReady = ready
        webRtcSendLine = sendLine
        webRtcSendFile = sendFile
        flushPendingChatMessages()
    }

    fun sendFilePreferred(
        nodeId: String, file: File, messageId: String, fromNodeId: String, toNodeId: String,
        ttl: Int, fileName: String, mimeType: String, fileSize: Long, kind: String
    ): Boolean {
        if (nodeId.isBlank() || !runCatching { webRtcReady?.invoke(nodeId) == true }.getOrDefault(false)) return false
        return runCatching {
            webRtcSendFile?.invoke(nodeId, file, messageId, fromNodeId, toNodeId, fileName, fileSize, mimeType, ttl, kind) == true
        }.getOrDefault(false)
    }

    fun onWebRtcClosed(remoteNodeId: String) {
        // Libère les messages qui avaient été confiés au chemin RTC afin que
        // le prochain passage les reprenne via TCP si ce chemin est disponible.
        val ids = inFlightSessionByMessageId.entries
            .filter { entry -> peerNodeIdBySession[entry.value] == remoteNodeId }
            .map { it.key }
        ids.forEach { id ->
            inFlightSessionByMessageId.remove(id)?.let { _ -> }
            inFlightSinceByMessageId.remove(id)
            inFlightMessageIds.remove(id)
        }
        flushPendingChatMessages()
    }

    /** Retourne le prochain saut connu. */
    fun routeTo(nodeId: String, line: String, except: ZeeSocketSession? = null): Boolean {
        if (nodeId.isBlank()) return false
        val direct = sessionsByNodeId[nodeId]
        if (direct != null && direct !== except && isProtocolReady(direct)) {
            // Le DataChannel devient le chemin préféré dès qu'il est READY.
            // Si l'envoi échoue (canal fermé/saturé), le même paquet repart
            // immédiatement par TCP : le changement de transport est donc
            // transparent pour le reste du protocole ZEE.
            val rtcReady = runCatching { webRtcReady?.invoke(nodeId) == true }.getOrDefault(false)
            if (rtcReady) {
                val rtcSent = runCatching { webRtcSendLine?.invoke(nodeId, line) == true }.getOrDefault(false)
                if (rtcSent) return true
            }
            return direct.send(line)
        }
        // IMPORTANT : aucun fallback vers une session arbitraire. Un chat
        // privé ne doit jamais pouvoir partir vers le mauvais téléphone.
        return false
    }

    fun sendChat(text: String, channel: String = com.zee.app.model.MessageChannels.CHAT): String {
        val target = activeChatNodeId
        if (text.isBlank() || localNodeId.isBlank()) return ""
        if (target.isNullOrBlank()) {
            pendingActiveChatTexts.offer(text)
            return ""
        }
        val id = java.util.UUID.randomUUID().toString()
        val json = ZeeMessageCodec.encodeChat(text, localNodeId, target, ttl = 8, messageId = id, channel = channel)
        store?.enqueue(target, json, id)
        // Armer l'état in-flight AVANT l'offre au writer : le flush peut
        // être exécuté immédiatement sur un autre thread. Cela évite une
        // fenêtre de course où le retry considère à tort le message comme
        // non envoyé et le remet dans le socket une seconde fois.
        inFlightMessageIds.add(id)
        val route = sessionsByNodeId[target]
        if (route == null || !isProtocolReady(route)) {
            inFlightMessageIds.remove(id)
            // Le message reste durablement en attente. La mesure de latence
            // ne démarre qu'au véritable envoi, jamais pendant l'attente.
            return id
        }
        inFlightSessionByMessageId[id] = route
        inFlightSinceByMessageId[id] = System.currentTimeMillis()
        if (!routeTo(target, json)) {
            inFlightSessionByMessageId.remove(id, route)
            inFlightSinceByMessageId.remove(id)
            inFlightMessageIds.remove(id)
        } else {
            // Le premier markSent/markAttempt est effectué par onLineFlushed,
            // uniquement après écriture + flush réels sur le socket.
        }
        return id
    }

    fun onDelivered(messageId: String, finalForLocal: Boolean = false) {
        val target = store?.pendingTarget(messageId) ?: activeChatNodeId ?: ""
        ChatLatencyTracker.markAck(messageId, target)
        store?.ack(messageId)
        inFlightMessageIds.remove(messageId)
        inFlightSessionByMessageId.remove(messageId)
        inFlightSinceByMessageId.remove(messageId)
        returnSessionByMessageId.remove(messageId)
    }

    fun markSeen(messageId: String): Boolean = store?.markSeen(messageId) ?: true

    fun markDelivered(messageId: String): Boolean = store?.markDelivered(messageId) ?: true
    fun wasDelivered(messageId: String): Boolean = store?.wasDelivered(messageId) ?: false

    private fun releaseExpiredInFlight(timeoutMs: Long = 10_000L) {
        val now = System.currentTimeMillis()
        inFlightSinceByMessageId.entries.toList().forEach { (id, started) ->
            if (now - started >= timeoutMs) {
                inFlightSinceByMessageId.remove(id, started)
                inFlightSessionByMessageId.remove(id)
                inFlightMessageIds.remove(id)
            }
        }
    }

    /** Retransmet tous les messages persistants pour lesquels une route existe. */
    fun flushPendingChatMessages() {
        val s = store ?: return
        s.pendingFor().forEach { pending ->
            if (inFlightMessageIds.contains(pending.messageId)) return@forEach
            // Armer l'in-flight AVANT l'offre au writer, exactement comme
            // pour sendChat(). Le writer peut flush immédiatement sur un autre
            // thread : si on arme après routeTo(), son callback peut déjà avoir
            // retiré l'ID puis le retry le réinsère, provoquant un doublon.
            val route = sessionsByNodeId[pending.targetNodeId]
            if (route != null && isProtocolReady(route)) {
                inFlightMessageIds.add(pending.messageId)
                inFlightSessionByMessageId[pending.messageId] = route
                inFlightSinceByMessageId[pending.messageId] = System.currentTimeMillis()
                if (!routeTo(pending.targetNodeId, pending.line)) {
                    inFlightMessageIds.remove(pending.messageId)
                    inFlightSessionByMessageId.remove(pending.messageId, route)
                    inFlightSinceByMessageId.remove(pending.messageId)
                } else {
                    // onLineFlushed devient l'unique source de vérité pour
                    // comptabiliser une tentative réellement écrite.
                }
            }
            // Le tracker et le backoff sont déclenchés par onLineFlushed.
            // En cas d'échec de queue, le prochain passage retentera.
        }
    }

    fun queueRelay(targetNodeId: String, line: String, messageId: String) {
        store?.enqueue(targetNodeId, line, messageId)
    }

    fun pendingCount(): Int = store?.pendingCount() ?: 0

    fun nextHopAddress(targetNodeId: String): String? =
        sessionsByNodeId[targetNodeId]?.remoteAddress

    private fun extractMessageId(line: String): String? = runCatching {
        org.json.JSONObject(line).optString("messageId").ifBlank { null }
    }.getOrNull()

    fun unregisterActiveChat(peerAddress: String) {
        if (activeChatPeerAddress == peerAddress) {
            activeChatPeerAddress = null
            activeChatListener = null
            activeProfileListener = null
            activeAttachmentListener = null
            activeChatNodeId = null
        }
    }
}
