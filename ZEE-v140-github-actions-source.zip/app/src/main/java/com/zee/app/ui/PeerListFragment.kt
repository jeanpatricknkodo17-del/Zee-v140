package com.zee.app.ui

import android.content.Intent
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import android.widget.ImageView
import android.graphics.Typeface
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zee.app.MainActivity
import com.zee.app.R
import com.zee.app.adapter.PeerAdapter
import com.zee.app.adapter.JobAdapter
import com.zee.app.model.Peer
import com.zee.app.model.PeerStatus
import com.zee.app.model.ZeeModule
import com.zee.app.model.BusinessActivityStore
import com.zee.app.model.ChatConversationStore
import android.widget.Toast

/** Liste de proximité commune aux trois modules. L'UI applique uniquement
 * le filtre choisi par l'utilisateur; la visibilité annoncée par le pair
 * reste toujours obligatoire. Le moteur Wi-Fi Direct/Mesh n'est pas touché. */
    /**
     * Affiche la photo de profil du module dans le cercle de bienvenue.
     * Si aucune photo valide n'est disponible, conserve le pictogramme du module.
     */
private fun setWelcomePhoto(context: Context, imageView: ImageView, module: ZeeModule, fallbackRes: Int) {
    imageView.background = context.getDrawable(R.drawable.bg_circle_cyan)

    val photo = try {
        com.zee.app.model.ProfileStore.getModulePhotoUri(context, module)
    } catch (_: Exception) {
        null
    }

    if (!photo.isNullOrBlank()) {
        try {
            val uri = Uri.parse(photo)
            // Les photos sont stockées dans les fichiers privés de ZEE puis
            // exposées par FileProvider. On décode une miniature réelle au lieu
            // de déléguer le rendu à setImageURI(), afin que le cercle soit
            // fiable après un retour depuis ProfileActivity.
            val bounds = android.graphics.BitmapFactory.Options().apply {
                inJustDecodeBounds = true
            }
            context.contentResolver.openInputStream(uri)?.use { input ->
                android.graphics.BitmapFactory.decodeStream(input, null, bounds)
            }
            if (bounds.outWidth > 0 && bounds.outHeight > 0) {
                val sample = calculatePhotoSample(bounds.outWidth, bounds.outHeight, 256)
                val options = android.graphics.BitmapFactory.Options().apply {
                    inSampleSize = sample
                    inPreferredConfig = android.graphics.Bitmap.Config.ARGB_8888
                }
                context.contentResolver.openInputStream(uri)?.use { input ->
                    android.graphics.BitmapFactory.decodeStream(input, null, options)?.let { bitmap ->
                        imageView.imageTintList = null
                        imageView.setPadding(0, 0, 0, 0)
                        imageView.scaleType = ImageView.ScaleType.CENTER_CROP
                        imageView.clipToOutline = true
                        imageView.setImageBitmap(bitmap)
                        return
                    }
                }
            }
        } catch (_: Exception) {
            // Photo invalide ou inaccessible : on garde l'icône du module.
        }
    }

    imageView.setPadding(13, 13, 13, 13)
    imageView.scaleType = ImageView.ScaleType.CENTER_INSIDE
    imageView.clipToOutline = true
    imageView.setImageResource(fallbackRes)
    imageView.imageTintList = android.content.res.ColorStateList.valueOf(
        androidx.core.content.ContextCompat.getColor(context, R.color.zee_white)
    )
}

private fun calculatePhotoSample(width: Int, height: Int, target: Int): Int {
    var sample = 1
    var largest = maxOf(width, height)
    while (largest / (sample * 2) >= target) sample *= 2
    return sample
}



class PeerListFragment : Fragment() {
    companion object {
        private const val ARG_MODULE = "arg_module"
        private const val ROLE_ALL = 0
        private const val ROLE_FIRST = 1
        private const val ROLE_SECOND = 2

        fun newInstance(module: ZeeModule): PeerListFragment = PeerListFragment().apply {
            arguments = Bundle().apply { putString(ARG_MODULE, module.name) }
        }
    }

    private lateinit var adapter: PeerAdapter
    private var selectedRoleFilter = ROLE_ALL
    /** BUSINESS : la liste s'ouvre toute seule dès qu'un profil est visible, tant que l'utilisateur n'a pas touché à la ligne « utilisateurs détectés ». */
    private var businessUserToggled = false
    private var selectedChatSexFilter = ROLE_ALL
    private var currentPeers: List<Peer> = emptyList()
    private val module: ZeeModule by lazy {
        ZeeModule.valueOf(requireArguments().getString(ARG_MODULE) ?: ZeeModule.CHAT.name)
    }

    private val photoPreferenceListener =
        android.content.SharedPreferences.OnSharedPreferenceChangeListener { _, key ->
            if (key == "${ZeeModule.MARKET.name}_photo_uri" ||
                key == "${ZeeModule.JOB.name}_photo_uri" ||
                key == "${ZeeModule.CHAT.name}_photo_uri") {
                // Le listener peut être déclenché depuis le callback de
                // sélection de photo. On revient explicitement sur le thread
                // UI afin de remplacer la miniature affichée immédiatement.
                view?.post { refreshWelcomePhoto() }
            }
        }

    fun refreshTheme() {
        view?.let { ThemeBackgrounds.apply(it, isHome = false) }
    }

    private fun refreshWelcomePhoto() {
        val root = view ?: return
        when (module) {
            ZeeModule.MARKET -> root.findViewById<ImageView>(R.id.imgModuleWelcome)?.let {
                setWelcomePhoto(requireContext(), it, ZeeModule.MARKET, R.drawable.ic_business_handshake_white)
            }
            ZeeModule.JOB -> root.findViewById<ImageView>(R.id.imgJobWelcome)?.let {
                setWelcomePhoto(requireContext(), it, ZeeModule.JOB, R.drawable.ic_job_briefcase_white)
            }
            ZeeModule.CHAT -> root.findViewById<ImageView>(R.id.imgChatWelcome)?.let {
                setWelcomePhoto(requireContext(), it, ZeeModule.CHAT, R.drawable.ic_live_chat_people_white)
            }
        }
    }

    override fun onStart() {
        super.onStart()
        com.zee.app.model.ProfileStore.registerPhotoChangeListener(requireContext(), photoPreferenceListener)
        refreshWelcomePhoto()
    }

    override fun onStop() {
        com.zee.app.model.ProfileStore.unregisterPhotoChangeListener(requireContext(), photoPreferenceListener)
        super.onStop()
    }

    override fun onResume() {
        super.onResume()
        view?.let { ThemeBackgrounds.apply(it, isHome = false) }
        // Filet de sécurité pour les changements effectués pendant que le
        // fragment était arrêté. Le listener couvre le cas instantané ;
        // onResume couvre aussi une modification externe sans notification.
        refreshWelcomePhoto()
    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View =
        when (module) {
            ZeeModule.JOB -> inflater.inflate(R.layout.fragment_job_list, container, false)
            ZeeModule.CHAT -> inflater.inflate(R.layout.fragment_chat_list, container, false)
            else -> inflater.inflate(R.layout.fragment_peer_list, container, false)
        }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        ThemeBackgrounds.apply(view, isHome = false)
        if (module == ZeeModule.JOB) {
            setupJobPage(view)
            return
        }
        if (module == ZeeModule.CHAT) {
            setupChatPage(view)
            return
        }
        val recycler = view.findViewById<RecyclerView>(R.id.recyclerPeers)
        recycler.layoutManager = LinearLayoutManager(requireContext())

        val moduleIcon = view.findViewById<android.widget.ImageView>(R.id.imgModuleWelcome)
        val moduleTitle = view.findViewById<TextView>(R.id.txtModuleWelcome)
        val moduleHint = view.findViewById<TextView>(R.id.txtModuleHint)
        val nearbyTitle = view.findViewById<TextView>(R.id.txtNearbyTitle)
        val businessContent = view.findViewById<View>(R.id.businessContent)
        val standardNearbyHeader = view.findViewById<View>(R.id.standardNearbyHeader)
        val businessActivitiesContainer = view.findViewById<android.widget.LinearLayout>(R.id.businessActivitiesContainer)
        val businessPeersSection = view.findViewById<View>(R.id.businessPeersSection)
        val filterScroll = view.findViewById<View>(R.id.filterScroll)
        val filterAll = view.findViewById<TextView>(R.id.filterAll)
        val filterFirst = view.findViewById<TextView>(R.id.filterFirst)
        val filterSecond = view.findViewById<TextView>(R.id.filterSecond)

        when (module) {
            ZeeModule.MARKET -> {
                setWelcomePhoto(requireContext(), moduleIcon, ZeeModule.MARKET, R.drawable.ic_business_handshake_white)
                moduleTitle.text = "BUSINESS"
                moduleHint.text = getString(com.zee.app.R.string.kt_vendeurs_et_acheteurs_visibles_proximit)
                nearbyTitle.text = getString(com.zee.app.R.string.kt_profils_business_proximit)
                filterScroll.visibility = View.VISIBLE
                businessContent.visibility = View.VISIBLE
                standardNearbyHeader.visibility = View.GONE
                recycler.visibility = View.GONE
                filterFirst.text = getString(com.zee.app.R.string.kt_vendeurs)
                filterSecond.text = getString(com.zee.app.R.string.kt_acheteurs)
            }
            ZeeModule.JOB -> {
                setWelcomePhoto(requireContext(), moduleIcon, ZeeModule.JOB, R.drawable.ic_job_briefcase_white)
                moduleTitle.text = "JOB"
                moduleHint.text = getString(com.zee.app.R.string.kt_chercheurs_d_emploi_et_recruteurs_visibles_pr)
                nearbyTitle.text = getString(com.zee.app.R.string.kt_profils_job_proximit)
                filterScroll.visibility = View.VISIBLE
                businessContent.visibility = View.GONE
                standardNearbyHeader.visibility = View.VISIBLE
                filterFirst.text = getString(com.zee.app.R.string.kt_chercheurs_d_emploi)
                filterSecond.text = getString(com.zee.app.R.string.kt_recruteurs)
            }
            ZeeModule.CHAT -> {
                moduleIcon.setImageResource(R.drawable.ic_live_chat_people_white)
                moduleTitle.text = "RENCONTRES"
                moduleHint.text = getString(com.zee.app.R.string.kt_conversations_et_utilisateurs_visibles_proxim)
                nearbyTitle.text = getString(com.zee.app.R.string.kt_conversations_proximit)
                businessContent.visibility = View.GONE
                standardNearbyHeader.visibility = View.VISIBLE
            }
        }

        if (module == ZeeModule.MARKET) {
            renderBusinessActivities(businessActivitiesContainer)
            view.findViewById<View>(R.id.businessNearbyRow).setOnClickListener {
                businessUserToggled = true
                val showing = recycler.visibility == View.VISIBLE
                recycler.visibility = if (showing) View.GONE else View.VISIBLE
                businessPeersSection.visibility = if (showing) View.GONE else View.VISIBLE
                if (!showing) refreshDisplayedPeers()
            }
        }

        adapter = PeerAdapter(
            peers = emptyList(),
            onPeerClick = { peer -> openChat(peer) },
            module = module
        )
        recycler.adapter = adapter

        fun updateFilterVisuals() {
            listOf(filterAll, filterFirst, filterSecond).forEachIndexed { index, button ->
                val selected = selectedRoleFilter == index
                button.setBackgroundResource(
                    if (selected) R.drawable.bg_filter_selected else R.drawable.bg_filter_unselected
                )
                button.setTextColor(
                    requireContext().getColor(
                        if (selected) R.color.zee_white else R.color.zee_text_dark
                    )
                )
                button.setTypeface(
                    null,
                    if (selected) android.graphics.Typeface.BOLD else android.graphics.Typeface.NORMAL
                )
                button.isSelected = selected
                button.alpha = if (selected) 1f else 0.94f
                button.contentDescription = when {
                    module == ZeeModule.MARKET && index == ROLE_ALL -> "Afficher tous les profils Business"
                    module == ZeeModule.MARKET && index == ROLE_FIRST -> "Afficher les vendeurs"
                    module == ZeeModule.MARKET && index == ROLE_SECOND -> "Afficher les acheteurs"
                    module == ZeeModule.JOB && index == ROLE_ALL -> "Afficher tous les profils Job"
                    module == ZeeModule.JOB && index == ROLE_FIRST -> "Afficher les chercheurs d'emploi"
                    module == ZeeModule.JOB && index == ROLE_SECOND -> "Afficher les recruteurs"
                    else -> button.text.toString()
                }
            }
        }

        if (module != ZeeModule.CHAT) {
            filterAll.setOnClickListener { selectedRoleFilter = ROLE_ALL; updateFilterVisuals(); refreshDisplayedPeers() }
            filterFirst.setOnClickListener { selectedRoleFilter = ROLE_FIRST; updateFilterVisuals(); refreshDisplayedPeers() }
            filterSecond.setOnClickListener { selectedRoleFilter = ROLE_SECOND; updateFilterVisuals(); refreshDisplayedPeers() }
            updateFilterVisuals()
        }

        val swipeRefresh = view.findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.swipeRefresh)
        swipeRefresh.setColorSchemeResources(R.color.zee_blue)
        swipeRefresh.setOnRefreshListener {
            (activity as? MainActivity)?.refreshPeers()
            view.postDelayed({ swipeRefresh.isRefreshing = false }, 4000)
        }

        (activity as? MainActivity)?.observePeers(module) { peers ->
            // Une découverte et connexion sont deux états distincts : un pair réellement découvert
            // peut être affiché avant la connexion. Le clic établit la session si nécessaire.
            currentPeers = peers.filter { it.status == PeerStatus.CONNECTED || it.status == PeerStatus.AVAILABLE }
            refreshDisplayedPeers()
            if (module == ZeeModule.MARKET) renderBusinessActivities(businessActivitiesContainer)
            swipeRefresh.isRefreshing = false
        }
    }

    /**
     * Page RENCONTRES : reproduit la liste de conversations de la maquette,
     * mais sans aucune donnée fictive. Une conversation n'est affichée que
     * si son contact est actuellement réellement connecté et qu'un vrai
     * message a été enregistré. Heure, aperçu et pastille proviennent du
     * trafic réel ZEE.
     */
    private fun setupChatPage(view: View) {
        val chatWelcomeIcon = view.findViewById<android.widget.ImageView>(R.id.imgChatWelcome)
        setWelcomePhoto(requireContext(), chatWelcomeIcon, ZeeModule.CHAT, R.drawable.ic_live_chat_people_white)
        val recycler = view.findViewById<RecyclerView>(R.id.chatRecycler)
        recycler.layoutManager = LinearLayoutManager(requireContext())
        val filterAll = view.findViewById<TextView>(R.id.chatFilterAll)
        val filterMen = view.findViewById<TextView>(R.id.chatFilterMen)
        val filterWomen = view.findViewById<TextView>(R.id.chatFilterWomen)
        val nearbyRow = view.findViewById<View>(R.id.chatNearbyRow)
        val nearbyCount = view.findViewById<TextView>(R.id.txtChatNearbyCount)

        selectedChatSexFilter = when (com.zee.app.model.ProfileStore.getChatMeetPreference(requireContext())) {
            "Hommes" -> ROLE_FIRST
            "Femmes" -> ROLE_SECOND
            else -> ROLE_ALL
        }

        // RENCONTRES affiche désormais les profils réellement découverts, exactement
        // comme JOB/BUSINESS. Un profil AVAILABLE peut être ouvert : openChat()
        // déclenche alors la connexion avant d'ouvrir la conversation.
        val adapter = PeerAdapter(emptyList(), { peer ->
            openChat(peer)
        }, ZeeModule.CHAT)
        recycler.adapter = adapter

        fun updateFilterVisuals() {
            listOf(filterAll, filterMen, filterWomen).forEachIndexed { index, button ->
                val selected = selectedChatSexFilter == index
                button.setBackgroundResource(
                    if (selected) R.drawable.bg_filter_selected else R.drawable.bg_filter_unselected
                )
                button.setTextColor(
                    requireContext().getColor(
                        if (selected) R.color.zee_white else R.color.zee_text_dark
                    )
                )
                button.setTypeface(null, if (selected) Typeface.BOLD else Typeface.NORMAL)
                button.isSelected = selected
                button.contentDescription = when (index) {
                    ROLE_ALL -> "Afficher tous les utilisateurs de RENCONTRES"
                    ROLE_FIRST -> "Afficher uniquement les hommes"
                    else -> "Afficher uniquement les femmes"
                }
            }
        }

        fun chatSexMatches(peer: Peer): Boolean {
            if (selectedChatSexFilter == ROLE_ALL) return true
            val criteria = peer.criteriaByModule[ZeeModule.CHAT] ?: return false
            val sex = criteria.substringBefore("|", "").trim()
            return when (selectedChatSexFilter) {
                ROLE_FIRST -> sex.equals("Homme", true) || sex.equals("Hommes", true)
                ROLE_SECOND -> sex.equals("Femme", true) || sex.equals("Femmes", true)
                else -> true
            }
        }

        fun eligiblePeers(): List<Peer> = currentPeers.filter {
            (it.status == PeerStatus.CONNECTED || it.status == PeerStatus.AVAILABLE) &&
            it.visibleModules.contains(ZeeModule.CHAT) &&
            chatSexMatches(it)
        }

        fun update() {
            val discovered = eligiblePeers()
            nearbyCount.text = getString(com.zee.app.R.string.users_detected, discovered.size)
            adapter.submitList(discovered)
            adapter.setRestrictedPeers(
                discovered.associate { (it.nodeId ?: it.deviceAddress) to !isChatCompatible(it) }
            )
        }

        fun chooseChatPreference(index: Int, value: String) {
            selectedChatSexFilter = index
            com.zee.app.model.ProfileStore.setChatMeetPreference(requireContext(), value)
            updateFilterVisuals()
            (activity as? MainActivity)?.refreshPeers()
            update()
        }

        filterAll.setOnClickListener { chooseChatPreference(ROLE_ALL, "Tous") }
        filterMen.setOnClickListener { chooseChatPreference(ROLE_FIRST, "Hommes") }
        filterWomen.setOnClickListener { chooseChatPreference(ROLE_SECOND, "Femmes") }
        updateFilterVisuals()

        nearbyRow.setOnClickListener {
            showNearbyProfilesDialog(eligiblePeers(), ZeeModule.CHAT)
        }

        val swipe = view.findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.chatSwipeRefresh)
        swipe.setColorSchemeResources(R.color.zee_blue)
        swipe.setOnRefreshListener {
            (activity as? MainActivity)?.refreshPeers()
            view.postDelayed({ swipe.isRefreshing = false; update() }, 1000)
        }

        (activity as? MainActivity)?.observePeers(ZeeModule.CHAT) { peers ->
            currentPeers = peers.filter { it.status == PeerStatus.CONNECTED || it.status == PeerStatus.AVAILABLE }
            update()
            swipe.isRefreshing = false
        }
        update()
    }

    /** Page JOB : reproduction dédiée de la maquette avec filtres fonctionnels. */
    private fun setupJobPage(view: View) {
        val jobWelcomeIcon = view.findViewById<android.widget.ImageView>(R.id.imgJobWelcome)
        setWelcomePhoto(requireContext(), jobWelcomeIcon, ZeeModule.JOB, R.drawable.ic_job_briefcase_white)
        val recycler = view.findViewById<RecyclerView>(R.id.jobRecycler)
        recycler.layoutManager = LinearLayoutManager(requireContext())

        val all = view.findViewById<TextView>(R.id.jobFilterAll)
        val seekers = view.findViewById<TextView>(R.id.jobFilterSeekers)
        val recruiters = view.findViewById<TextView>(R.id.jobFilterRecruiters)
        val swipe = view.findViewById<androidx.swiperefreshlayout.widget.SwipeRefreshLayout>(R.id.jobSwipeRefresh)
        swipe.setColorSchemeResources(R.color.zee_blue)
        val nearbyRow = view.findViewById<View>(R.id.jobNearbyRow)
        val nearbyCount = view.findViewById<TextView>(R.id.txtJobNearbyCount)

        var selected = ROLE_ALL
        val adapter = JobAdapter(emptyList()) { row ->
            if (row.peer != null) {
                openChat(row.peer)
            } else {
                Toast.makeText(requireContext(), "Profil Job de ${row.name} — ${row.role}", Toast.LENGTH_SHORT).show()
            }
        }
        recycler.adapter = adapter

        fun actualRows(peers: List<Peer>): List<JobAdapter.JobRow> = peers
            .filter { it.visibleModules.contains(ZeeModule.JOB) }
            // Ne jamais inventer le rôle : un profil JOB doit avoir annoncé
            // explicitement son critère par le handshake ZEE.
            .mapNotNull { peer ->
                val role = when (peer.criteriaByModule[ZeeModule.JOB]) {
                    "A" -> "Chercheur d'emploi"
                    "B" -> "Recruteur"
                    // En mode « Tous », conserver aussi les profils visibles dont
                    // le critère JOB n'est pas encore arrivé via le TXT/handshake.
                    else -> "Rôle non renseigné"
                }
                JobAdapter.JobRow(
                    name = peer.displayNamesByModule[ZeeModule.JOB]?.takeIf { it.isNotBlank() }
                        ?: peer.displayName?.takeIf { it.isNotBlank() } ?: peer.deviceName,
                    role = role,
                    online = peer.status == PeerStatus.CONNECTED,
                    minutesAgo = null,
                    distance = peer.distanceMeters,
                    avatar = R.drawable.ic_default_avatar,
                    peer = peer
                )
            }

        fun update() {
            // Aucun profil fictif : seuls les pairs réellement annoncés par ZEE sont affichés.
            // Une session TCP n'est pas nécessaire pour afficher un profil découvert ;
            // elle sera établie au clic si nécessaire.
            val connectedEligible = currentPeers.filter {
                (it.status == PeerStatus.CONNECTED || it.status == PeerStatus.AVAILABLE) &&
                    it.visibleModules.contains(ZeeModule.JOB)
            }
            nearbyCount.text = getString(com.zee.app.R.string.users_detected, connectedEligible.size)
            val source = actualRows(connectedEligible)
            val filtered = when (selected) {
                ROLE_FIRST -> source.filter { it.role == "Chercheur d'emploi" }
                ROLE_SECOND -> source.filter { it.role == "Recruteur" }
                else -> source
            }
            adapter.submitList(filtered)
            listOf(all, seekers, recruiters).forEachIndexed { index, button ->
                val isSelected = selected == index
                button.setBackgroundResource(if (isSelected) R.drawable.bg_filter_selected else R.drawable.bg_filter_unselected)
                button.setTextColor(requireContext().getColor(if (isSelected) R.color.zee_white else R.color.zee_text_dark))
                button.setTypeface(null, if (isSelected) Typeface.BOLD else Typeface.NORMAL)
                button.isSelected = isSelected
            }
        }

        all.setOnClickListener { selected = ROLE_ALL; update() }
        seekers.setOnClickListener { selected = ROLE_FIRST; update() }
        recruiters.setOnClickListener { selected = ROLE_SECOND; update() }
        nearbyRow.setOnClickListener {
            val nearby = currentPeers.filter {
                (it.status == PeerStatus.CONNECTED || it.status == PeerStatus.AVAILABLE) &&
                    it.visibleModules.contains(ZeeModule.JOB)
            }
            if (nearby.isEmpty()) {
                recycler.visibility = View.GONE
            } else {
                recycler.visibility = if (recycler.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                if (recycler.visibility == View.VISIBLE) update()
            }
        }
        swipe.setOnRefreshListener {
            (activity as? MainActivity)?.refreshPeers()
            view.postDelayed({ swipe.isRefreshing = false }, 1000)
        }

        (activity as? MainActivity)?.observePeers(ZeeModule.JOB) { peers ->
            currentPeers = peers.filter { it.status == PeerStatus.CONNECTED || it.status == PeerStatus.AVAILABLE }
            update()
            swipe.isRefreshing = false
        }
        update()
    }

    private fun showNearbyProfilesDialog(peers: List<Peer>, module: ZeeModule) {
        if (!isAdded) return
        val ctx = requireContext()
        val connected = peers.filter { (it.status == PeerStatus.CONNECTED || it.status == PeerStatus.AVAILABLE) && it.visibleModules.contains(module) }
        if (connected.isEmpty()) {
            androidx.appcompat.app.AlertDialog.Builder(ctx)
                .setTitle(getString(com.zee.app.R.string.kt_proximit))
                .setMessage("0 utilisateurs détectés\n\nAucun autre utilisateur ZEE découvert et visible pour le moment.")
                .setPositiveButton(getString(com.zee.app.R.string.kt_fermer), null)
                .show()
            return
        }
        val labels = connected.map { peer ->
            val name = peer.displayNamesByModule[module]?.takeIf { it.isNotBlank() }
                ?: peer.displayName?.takeIf { it.isNotBlank() } ?: peer.deviceName
            val distance = peer.distanceMeters?.let { " — ${it} m" } ?: ""
            "$name$distance"
        }.toTypedArray()
        androidx.appcompat.app.AlertDialog.Builder(ctx)
            .setTitle(getString(com.zee.app.R.string.nearby_users_count, connected.size))
            .setItems(labels) { _, which -> openChat(connected[which]) }
            .setNegativeButton(getString(com.zee.app.R.string.kt_fermer), null)
            .show()
    }

    private fun renderBusinessActivities(container: android.widget.LinearLayout) {
        if (!isAdded) return
        val ctx = requireContext()
        container.removeAllViews()
        BusinessActivityStore.list(ctx).take(8).forEachIndexed { index, item ->
            val row = layoutInflater.inflate(R.layout.item_business_activity, container, false)
            row.findViewById<de.hdodenhof.circleimageview.CircleImageView>(R.id.activityAvatar).setImageResource(item.avatar)
            row.findViewById<TextView>(R.id.activityName).text = item.name
            row.findViewById<TextView>(R.id.activityTitle).text = item.title
            row.findViewById<TextView>(R.id.activityComment).text = item.comment
            row.findViewById<TextView>(R.id.activityTime).text = BusinessActivityStore.time(item.timestamp)
            val badge = row.findViewById<ImageView>(R.id.activityBadge)
            badge.setBackgroundResource(item.badge)
            badge.setImageResource(when (item.title) {
                "Nouveau message" -> R.drawable.ic_chat_white
                "Nouvelle publicité" -> R.drawable.ic_info_white
                "Profil visité" -> R.drawable.ic_visibility_white
                else -> R.drawable.ic_business_handshake_white
            })
            row.setOnClickListener {
                val peer = currentPeers.firstOrNull { p ->
                    (p.displayNamesByModule[ZeeModule.MARKET]?.equals(item.name, true) == true) ||
                        (p.displayName?.equals(item.name, true) == true) || p.deviceName.equals(item.name, true)
                }
                if (peer != null) openChat(peer) else Toast.makeText(ctx, "Activité de ${item.name} — ${item.comment}", Toast.LENGTH_SHORT).show()
            }
            container.addView(row)
            if (index < BusinessActivityStore.list(ctx).take(8).lastIndex) {
                val line = View(ctx).apply { setBackgroundColor(ctx.getColor(R.color.zee_border)) }
                container.addView(line, android.widget.LinearLayout.LayoutParams(-1, 1))
            }
        }
    }

    /**
     * BUSINESS/JOB : les trois boutons en haut de page sont un FILTRE d'affichage.
     *  - Le statut choisi dans les paramètres du profil ("A" = Vendeur / Cherche emploi,
     *    "B" = Acheteur / Recrute) désigne ce que l'utilisateur EST ; il est annoncé aux voisins.
     *  - Le bouton sélectionné signifie : « je ne veux voir que les utilisateurs qui ont
     *    choisi ce statut ». « Tous » affiche tout le monde.
     *  - Mon propre statut n'intervient jamais dans ce tri.
     */
    private fun roleMatches(peer: Peer): Boolean {
        if (module == ZeeModule.CHAT || selectedRoleFilter == ROLE_ALL) return true
        val criterion = peer.criteriaByModule[module] ?: return false
        return when (selectedRoleFilter) {
            ROLE_FIRST -> criterion == "A"
            ROLE_SECOND -> criterion == "B"
            else -> true
        }
    }

    private fun refreshDisplayedPeers() {
        if (!::adapter.isInitialized || !isAdded) return
        val visible = currentPeers
            .filter { it.visibleModules.contains(module) }
            .filter { roleMatches(it) }
        adapter.submitList(visible)
        if (module == ZeeModule.MARKET && !businessUserToggled && visible.isNotEmpty()) {
            view?.findViewById<View>(R.id.recyclerPeers)?.visibility = View.VISIBLE
            view?.findViewById<View>(R.id.businessPeersSection)?.visibility = View.VISIBLE
        }
        adapter.setRestrictedPeers(
            if (module == ZeeModule.CHAT)
                visible.associate { (it.nodeId ?: it.deviceAddress) to !isChatCompatible(it) }
            else emptyMap()
        )
        view?.findViewById<TextView>(R.id.txtNearbyCount)?.text = visible.size.toString()
        view?.findViewById<TextView>(R.id.txtBusinessNearbyCount)?.text = getString(com.zee.app.R.string.users_detected, visible.size)
    }

    private fun isChatCompatible(peer: Peer): Boolean {
        if (module != ZeeModule.CHAT) return true
        val mine = com.zee.app.model.ProfileStore.getLiveChatCriteria(requireContext())
        val theirs = peer.criteriaByModule[ZeeModule.CHAT] ?: return false
        return com.zee.app.model.ProfileStore.areLiveChatCriteriaCompatible(mine, theirs)
    }

    private fun isRestrictedPeer(peer: Peer): Boolean = module == ZeeModule.CHAT && !isChatCompatible(peer)

    private fun openChat(peer: Peer) {
        if (module == ZeeModule.MARKET) {
            BusinessActivityStore.add(
                requireContext(),
                peer.displayNamesByModule[ZeeModule.MARKET]?.takeIf { it.isNotBlank() }
                    ?: peer.displayName?.takeIf { it.isNotBlank() } ?: peer.deviceName,
                "Profil visité",
                "Vous avez consulté ce profil",
                R.drawable.ic_default_avatar,
                R.drawable.bg_activity_badge_cyan
            )
            view?.findViewById<android.widget.LinearLayout>(R.id.businessActivitiesContainer)?.let { renderBusinessActivities(it) }
        }
        if (isRestrictedPeer(peer)) {
            android.widget.Toast.makeText(
                requireContext(),
                "Profil visible, mais échange restreint : les critères de RENCONTRES ne sont pas compatibles.",
                android.widget.Toast.LENGTH_LONG
            ).show()
            return
        }
        peer.unreadCount = 0
        if (module == ZeeModule.CHAT) {
            val key = peer.nodeId?.takeIf { it.isNotBlank() } ?: peer.deviceAddress
            ChatConversationStore.markRead(requireContext(), "${com.zee.app.model.MessageChannels.fromModuleName(module.name)}:$key")
        }
        if (::adapter.isInitialized) adapter.notifyDataSetChanged()
        (activity as? MainActivity)?.connectToPeer(peer)
        startActivity(Intent(requireContext(), ChatActivity::class.java).apply {
            putExtra(ChatActivity.EXTRA_PEER_ADDRESS, peer.deviceAddress)
            putExtra(ChatActivity.EXTRA_PEER_NAME, peer.displayNamesByModule[module]?.takeIf { it.isNotBlank() }
                ?: peer.displayName?.takeIf { it.isNotBlank() } ?: peer.deviceName)
            putExtra(ChatActivity.EXTRA_PEER_TAG, peer.actusByModule[module] ?: peer.actu ?: "")
            putExtra(ChatActivity.EXTRA_PEER_PHOTO_BASE64, peer.photosByModule[module] ?: peer.photoBase64)
            putExtra(ChatActivity.EXTRA_PEER_NODE_ID, peer.nodeId)
            putExtra(ChatActivity.EXTRA_CHAT_CHANNEL, com.zee.app.model.MessageChannels.fromModuleName(module.name))
            putExtra(ChatActivity.EXTRA_CHAT_RESTRICTED, isRestrictedPeer(peer))
        })
    }
}
