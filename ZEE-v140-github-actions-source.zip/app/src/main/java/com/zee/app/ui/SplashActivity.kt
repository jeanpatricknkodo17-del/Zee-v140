package com.zee.app.ui

import android.animation.Animator
import android.animation.Keyframe
import android.animation.ObjectAnimator
import android.animation.PropertyValuesHolder
import android.animation.ValueAnimator
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.zee.app.MainActivity
import com.zee.app.R
import com.zee.app.update.UpdateGate

class SplashActivity : AppCompatActivity() {

    private var heartbeatAnimator: Animator? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)
        applyZeeEdgeToEdge(topInsetView = null)

        // Logo qui "bat" comme un cœur pendant le chargement du splash :
        // grossit puis rétrécit en boucle (double pulsation type battement
        // cardiaque : un grand puis un petit, comme "lub-dub").
        heartbeatAnimator = startHeartbeatAnimation(findViewById(R.id.logoZ))

        // Le vrai splash attend ici la confirmation que le module Wi-Fi P2P
        // est initialisé (voir WifiDirectManager) avant de passer à l'accueil.
        Handler(Looper.getMainLooper()).postDelayed({
            // Verrouillage : 30 jours après l'installation, l'app ne va pas
            // plus loin que le splash tant que l'utilisateur n'a pas été
            // renvoyé vers le Play Store pour mettre à jour.
            if (UpdateGate.isUpdateRequired(this)) {
                showUpdateRequiredDialog()
            } else {
                proceedToApp()
            }
        }, 1200)
    }

    /**
     * Anime le logo pour qu'il "batte" comme un cœur : il grossit puis
     * revient à sa taille normale, avec un grand battement suivi d'un plus
     * petit (rythme "lub-dub"), en boucle continue tant que le splash est
     * affiché.
     */
    private fun startHeartbeatAnimation(view: View): Animator {
        val scaleXKeyframes = arrayOf(
            Keyframe.ofFloat(0f, 1f),
            Keyframe.ofFloat(0.14f, 1.18f),   // grand battement (lub)
            Keyframe.ofFloat(0.28f, 1f),
            Keyframe.ofFloat(0.42f, 1.12f),   // petit battement (dub)
            Keyframe.ofFloat(0.58f, 1f),
            Keyframe.ofFloat(1f, 1f)           // pause avant le prochain cycle
        )
        val scaleYKeyframes = arrayOf(
            Keyframe.ofFloat(0f, 1f),
            Keyframe.ofFloat(0.14f, 1.18f),
            Keyframe.ofFloat(0.28f, 1f),
            Keyframe.ofFloat(0.42f, 1.12f),
            Keyframe.ofFloat(0.58f, 1f),
            Keyframe.ofFloat(1f, 1f)
        )
        val pvhScaleX = PropertyValuesHolder.ofKeyframe("scaleX", *scaleXKeyframes)
        val pvhScaleY = PropertyValuesHolder.ofKeyframe("scaleY", *scaleYKeyframes)

        return ObjectAnimator.ofPropertyValuesHolder(view, pvhScaleX, pvhScaleY).apply {
            duration = 1000L
            repeatCount = ValueAnimator.INFINITE
            start()
        }
    }

    /**
     * Message affiché sur l'écran de démarrage 30 jours après l'installation :
     * bloque l'accès à l'app tant que l'utilisateur n'a pas été redirigé
     * vers le Play Store (non-annulable, pas de bouton "plus tard").
     */
    private fun showUpdateRequiredDialog() {
        AlertDialog.Builder(this)
            .setTitle(getString(com.zee.app.R.string.kt_mise_jour_requise))
            .setMessage(getString(com.zee.app.R.string.kt_une_nouvelle_version_de_zee_est_disponible_me))
            .setCancelable(false)
            .setPositiveButton(getString(com.zee.app.R.string.kt_mettre_jour)) { _, _ ->
                UpdateGate.openPlayStore(this)
                // On ne relance pas automatiquement l'accès à l'app ici :
                // l'utilisateur revient sur ZEE seulement après avoir
                // effectivement mis à jour depuis le Play Store.
                finish()
            }
            .show()
    }

    private fun proceedToApp() {
        // L'écran d'accueil est désormais le point d'entrée principal de ZEE.
        // La configuration du profil reste accessible depuis l'application
        // via l'écran Profil.
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }

    override fun onDestroy() {
        heartbeatAnimator?.cancel()
        heartbeatAnimator = null
        super.onDestroy()
    }
}
