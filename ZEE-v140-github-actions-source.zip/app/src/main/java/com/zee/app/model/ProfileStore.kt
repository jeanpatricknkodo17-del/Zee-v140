package com.zee.app.model

import android.content.Context

/**
 * Stockage local du profil ZEE.
 *
 * Gère aussi les informations de profil PROPRES À CHAQUE MODULE (voir plus
 * bas) — l'utilisateur peut avoir une ACTU, un âge affiché, un critère de
 * rencontre et une photo différents et complètement indépendants selon son
 * besoin sur chaque onglet (RENCONTRES / BUSINESS / JOB), plutôt qu'un seul
 * profil unique partagé partout.
 *
 * Persisté en SharedPreferences, donc conservé entre les lancements de
 * l'app sur le même téléphone.
 */
object ProfileStore {
    private const val PREFS = "zee_profile"
    private const val KEY_SETUP_DONE = "setup_done"
    private const val KEY_AGE_CONFIRMED = "age_confirmed"
    private const val KEY_NAME = "name"
    private const val KEY_AGE = "age"
    private const val KEY_ACTIVITY = "activity"
    private const val KEY_SEXE = "sexe"
    private const val KEY_MEET = "meet"
    private const val KEY_CHAT_MEET = "chat_meet_preference"
    private const val KEY_AGE_FILTER = "age_filter"
    private const val KEY_PHOTO_URI = "photo_uri"
    private const val KEY_NODE_ID = "node_id"

    fun isSetupComplete(context: Context): Boolean =
        prefs(context).getBoolean(KEY_SETUP_DONE, false)

    fun isAgeConfirmed(context: Context): Boolean =
        prefs(context).getBoolean(KEY_AGE_CONFIRMED, false)

    fun setAgeConfirmed(context: Context, confirmed: Boolean) {
        prefs(context).edit().putBoolean(KEY_AGE_CONFIRMED, confirmed).apply()
    }

    fun save(
        context: Context,
        name: String,
        age: String,
        activity: String = "",
        sexe: String,
        meet: String,
        ageFilter: String,
        photoUri: String?
    ) {
        prefs(context).edit()
            .putBoolean(KEY_SETUP_DONE, true)
            .putBoolean(KEY_AGE_CONFIRMED, true)
            .putString(KEY_NAME, name)
            .putString(KEY_AGE, age)
            .putString(KEY_ACTIVITY, activity)
            .putString(KEY_SEXE, sexe)
            .putString(KEY_MEET, meet)
            .putString(KEY_AGE_FILTER, ageFilter)
            .putString(KEY_PHOTO_URI, photoUri)
            .apply()
    }

    fun getName(context: Context): String = prefs(context).getString(KEY_NAME, "") ?: ""

    /** Nom affichable de secours pour le handshake réseau si le profil est vide. */
    fun getDisplayName(context: Context): String {
        val saved = getName(context).trim()
        if (saved.isNotEmpty()) return saved
        val manufacturer = android.os.Build.MANUFACTURER.orEmpty().trim()
        val model = android.os.Build.MODEL.orEmpty().trim()
        return when {
            model.isNotEmpty() && manufacturer.isNotEmpty() &&
                !model.startsWith(manufacturer, ignoreCase = true) -> "$manufacturer $model"
            model.isNotEmpty() -> model
            manufacturer.isNotEmpty() -> manufacturer
            else -> "ZEE"
        }
    }
    fun setName(context: Context, name: String) {
        prefs(context).edit().putString(KEY_NAME, name).apply()
    }
    fun getAge(context: Context): String = prefs(context).getString(KEY_AGE, "") ?: ""
    fun getActivity(context: Context): String = prefs(context).getString(KEY_ACTIVITY, "") ?: ""
    fun setActivity(context: Context, value: String) { prefs(context).edit().putString(KEY_ACTIVITY, value).apply() }
    fun getSexe(context: Context): String = prefs(context).getString(KEY_SEXE, "Homme") ?: "Homme"
    fun setSexe(context: Context, value: String) { prefs(context).edit().putString(KEY_SEXE, value).apply() }
    fun getMeet(context: Context): String = prefs(context).getString(KEY_MEET, "Femmes") ?: "Femmes"
    fun getAgeFilter(context: Context): String = prefs(context).getString(KEY_AGE_FILTER, "supérieur") ?: "supérieur"

    /** Préférence RENCONTRES unique : Tous, Hommes ou Femmes. */
    fun getChatMeetPreference(context: Context): String {
        val stored = prefs(context).getString(KEY_CHAT_MEET, null)?.trim()
        if (stored.equals("Tous", true) || stored.equals("Hommes", true) || stored.equals("Femmes", true)) {
            return stored!!.replaceFirstChar { it.uppercase() }
        }
        // Migration des anciennes versions : true = Femmes, false = Hommes.
        return if (getModuleMeetChoice(context, com.zee.app.model.ZeeModule.CHAT)) "Femmes" else "Hommes"
    }

    fun setChatMeetPreference(context: Context, value: String) {
        val normalized = when {
            value.equals("Tous", true) -> "Tous"
            value.equals("Hommes", true) || value.equals("Homme", true) -> "Hommes"
            value.equals("Femmes", true) || value.equals("Femme", true) -> "Femmes"
            else -> return
        }
        prefs(context).edit().putString(KEY_CHAT_MEET, normalized).apply()
    }

    /** Critères RENCONTRES annoncés aux voisins : SEXE|Tous/Hommes/Femmes. */
    fun getLiveChatCriteria(context: Context): String {
        val sexe = when {
            getSexe(context).equals("Femme", true) || getSexe(context).equals("Femmes", true) -> "Femme"
            else -> "Homme"
        }
        return "$sexe|${getChatMeetPreference(context)}"
    }

    /**
     * Compatibilité RENCONTRES strictement réciproque.
     *
     * - Homme -> Hommes <-> Homme -> Hommes : autorisé.
     * - Femme -> Femmes <-> Femme -> Femmes : autorisé.
     * - Homme -> Femmes <-> Femme -> Hommes : autorisé.
     * - Femme -> Hommes <-> Homme -> Femmes : autorisé.
     * - Tous <-> Tous : autorisé, quel que soit le sexe.
     * - Tous avec Hommes/Femmes, ou toute combinaison non réciproque : refusé.
     *
     * Cette règle complète la logique précédente : les couples H-H et F-F
     * sont ajoutés comme combinaisons valides lorsqu elles sont réciproques,
     * sans supprimer la combinaison H-F/F-H déjà prévue.
     *
     * La visibilité du profil est indépendante de cette autorisation.
     */
    fun areLiveChatCriteriaCompatible(myCriteria: String, peerCriteria: String): Boolean {
        val mine = myCriteria.split("|", limit = 2).map { it.trim() }
        val peer = peerCriteria.split("|", limit = 2).map { it.trim() }
        if (mine.size != 2 || peer.size != 2) return false

        val mySex = normalizeSex(mine[0])
        val myMeet = normalizeMeet(mine[1])
        val peerSex = normalizeSex(peer[0])
        val peerMeet = normalizeMeet(peer[1])
        if (mySex == null || myMeet == null || peerSex == null || peerMeet == null) return false

        // Tous est un groupe fermé : seuls deux utilisateurs ayant choisi
        // Tous peuvent échanger.
        if (myMeet == "Tous" || peerMeet == "Tous") {
            return myMeet == "Tous" && peerMeet == "Tous"
        }

        // Pour Hommes/Femmes, chacun doit rechercher exactement le sexe de
        // l'autre : cela autorise aussi bien les combinaisons H-H/F-F que
        // les combinaisons H-F/F-H, mais jamais un croisement unilatéral.
        return myMeet == peerSex && peerMeet == mySex
    }

    private fun normalizeSex(value: String): String? = when {
        value.equals("Homme", true) || value.equals("Hommes", true) -> "Homme"
        value.equals("Femme", true) || value.equals("Femmes", true) -> "Femme"
        else -> null
    }

    private fun normalizeMeet(value: String): String? = when {
        value.equals("Tous", true) -> "Tous"
        value.equals("Homme", true) || value.equals("Hommes", true) -> "Hommes"
        value.equals("Femme", true) || value.equals("Femmes", true) -> "Femmes"
        else -> null
    }
    fun getPhotoUri(context: Context): String? = prefs(context).getString(KEY_PHOTO_URI, null)

    /** Identifiant ZEE stable de cet appareil, utilisé pour le routage maillé. */
    fun getNodeId(context: Context): String {
        val p = prefs(context)
        val existing = p.getString(KEY_NODE_ID, null)
        if (!existing.isNullOrBlank()) return existing
        val generated = java.util.UUID.randomUUID().toString()
        p.edit().putString(KEY_NODE_ID, generated).apply()
        return generated
    }

    // ---- Informations INDÉPENDANTES PAR MODULE ----
    //
    // Le nom (ci-dessus) reste partagé : c'est la même personne. Mais
    // l'ACTU, l'âge affiché, le filtre d'âge, le critère de rencontre et la
    // photo peuvent varier selon le besoin réel de l'utilisateur sur cet
    // onglet précis — ex. une ACTU "Vêtements à partir de 50 000 FCFA" en
    // BUSINESS, différente de "Aime femme brune" en RENCONTRES, différente
    // encore de "Développeur, 3 ans d'expérience" en JOB — chacune éditée
    // et conservée séparément, sans jamais écraser les deux autres.
    private fun moduleKey(module: com.zee.app.model.ZeeModule, field: String) = "${module.name}_$field"

    fun getModuleActu(context: Context, module: com.zee.app.model.ZeeModule): String =
        prefs(context).getString(moduleKey(module, "actu"), "") ?: ""

    fun setModuleActu(context: Context, module: com.zee.app.model.ZeeModule, value: String) {
        prefs(context).edit().putString(moduleKey(module, "actu"), value).apply()
    }

    /** Repli sur l'âge global (issu de l'ancien profil global) tant que ce module n'a pas encore sa propre valeur. */
    fun getModuleAge(context: Context, module: com.zee.app.model.ZeeModule): String =
        prefs(context).getString(moduleKey(module, "age"), null) ?: getAge(context)

    fun setModuleAge(context: Context, module: com.zee.app.model.ZeeModule, value: String) {
        prefs(context).edit().putString(moduleKey(module, "age"), value).apply()
    }

    fun getModuleAgeFilter(context: Context, module: com.zee.app.model.ZeeModule): String =
        prefs(context).getString(moduleKey(module, "age_filter"), null) ?: getAgeFilter(context)

    fun setModuleAgeFilter(context: Context, module: com.zee.app.model.ZeeModule, value: String) {
        prefs(context).edit().putString(moduleKey(module, "age_filter"), value).apply()
    }

    /** true = 2e option du module (Femmes / Acheteur / Recrute), false = 1re option (Hommes / Vendeur / Cherche emploi). */
    fun getModuleMeetChoice(context: Context, module: com.zee.app.model.ZeeModule): Boolean =
        prefs(context).getBoolean(moduleKey(module, "meet_choice"), module == com.zee.app.model.ZeeModule.JOB)

    fun setModuleMeetChoice(context: Context, module: com.zee.app.model.ZeeModule, value: Boolean) {
        prefs(context).edit().putBoolean(moduleKey(module, "meet_choice"), value).apply()
    }

    fun setPhotoUri(context: Context, value: String) {
        prefs(context).edit().putString(KEY_PHOTO_URI, value).apply()
    }

    /**
     * Photo de profil STRICTEMENT indépendante pour chaque onglet.
     *
     * Les anciennes versions utilisaient le slot global pour RENCONTRES.
     * Cela créait un effet de bord : choisir une photo dans RENCONTRES
     * modifiait indirectement la photo visible dans les autres onglets.
     *
     * Migration douce : si un module n'a encore jamais eu sa propre photo,
     * on initialise une seule fois son slot avec l'ancienne photo globale.
     * Après cette initialisation, le slot est totalement indépendant.
     */
    fun getModulePhotoUri(context: Context, module: com.zee.app.model.ZeeModule): String? {
        val prefs = prefs(context)
        val key = moduleKey(module, "photo_uri")
        val stored = prefs.getString(key, null)
        if (!stored.isNullOrBlank()) return stored

        // Migration d'une ancienne installation : copie UNE FOIS la photo
        // globale vers le module demandé, sans maintenir de lien entre eux.
        val legacy = prefs.getString(KEY_PHOTO_URI, null)
        if (!legacy.isNullOrBlank()) {
            prefs.edit().putString(key, legacy).apply()
            return legacy
        }
        return null
    }

    fun setModulePhotoUri(context: Context, module: com.zee.app.model.ZeeModule, value: String?) {
        val editor = prefs(context).edit()
        val key = moduleKey(module, "photo_uri")
        if (value.isNullOrBlank()) {
            editor.remove(key)
        } else {
            editor.putString(key, value)
        }
        // IMPORTANT : ne jamais écrire KEY_PHOTO_URI ici.
        // Le profil global historique reste indépendant des onglets.
        // apply() met à jour immédiatement le cache mémoire de
        // SharedPreferences et déclenche les listeners enregistrés ; les
        // écrans visibles peuvent donc rafraîchir leur photo sans attendre
        // un changement d'onglet ou un redémarrage de l'application.
        editor.apply()
    }

    /**
     * Permet aux écrans visibles de réagir immédiatement aux changements du
     * profil sans dépendre de onResume()/d'un changement d'onglet.
     */
    fun registerPhotoChangeListener(
        context: Context,
        listener: android.content.SharedPreferences.OnSharedPreferenceChangeListener
    ) {
        prefs(context).registerOnSharedPreferenceChangeListener(listener)
    }

    fun unregisterPhotoChangeListener(
        context: Context,
        listener: android.content.SharedPreferences.OnSharedPreferenceChangeListener
    ) {
        prefs(context).unregisterOnSharedPreferenceChangeListener(listener)
    }

    private fun prefs(context: Context) =
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
}
