package com.zee.app.network

import android.content.Context
import android.os.Handler
import android.os.Looper
import com.zee.app.model.AdPayload
import com.zee.app.model.AdRelayStore

/**
 * Moteur de propagation opportuniste.
 *
 * A chaque cycle, chaque publicité active est comparée à CHAQUE voisin ZEE
 * actuellement connecté. Une paire (pub, voisin) n'est marquée comme envoyée
 * qu'après un send réussi. Un nouveau voisin est donc automatiquement servi,
 * même si la publicité existe depuis plusieurs heures.
 */
class AdBroadcastScheduler(
    private val context: Context,
    private val intervalMs: Long = 20_000L
) {
    private val handler = Handler(Looper.getMainLooper())
    private var broadcaster: ((AdPayload, String) -> Boolean)? = null

    private val tick = object : Runnable {
        override fun run() {
            val active = AdRelayStore.getActiveAds(context)
            val neighbors = SessionRegistry.activeNodeIds()

            active.forEach { ad ->
                neighbors.forEach { nodeId ->
                    if (nodeId == SessionRegistry.localNodeId) return@forEach
                    if (AdRelayStore.wasSentToNeighbor(context, ad.id, nodeId)) return@forEach

                    val sent = broadcaster?.invoke(ad, nodeId) == true
                    if (sent) {
                        AdRelayStore.markSentToNeighbor(context, ad.id, nodeId)
                    }
                }
            }
            handler.postDelayed(this, intervalMs)
        }
    }

    fun start(
        peersProvider: () -> List<com.zee.app.model.Peer>,
        broadcaster: (AdPayload, String) -> Boolean
    ) {
        // peersProvider est conservé dans la signature pour compatibilité avec
        // les appels existants. La source d'autorité est SessionRegistry :
        // seuls les voisins ayant une session réellement ouverte sont servis.
        this.broadcaster = broadcaster
        handler.removeCallbacks(tick)
        handler.post(tick)
    }

    fun stop() {
        handler.removeCallbacks(tick)
        broadcaster = null
    }
}
