package com.zee.app.network

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap

/**
 * File d'attente persistante du réseau ZEE Mesh.
 *
 * Les messages sortants sont conservés jusqu'à réception d'un ACK de livraison
 * par le destinataire final. Les IDs déjà vus sont également persistés afin
 * qu'un message relayé ne soit pas dupliqué après une reconnexion ou un
 * redémarrage de l'application.
 */
class MeshMessageStore(context: Context) {
    data class Pending(
        val messageId: String,
        val targetNodeId: String,
        val line: String,
        val createdAt: Long,
        var attempts: Int = 0,
        var nextRetryAt: Long = 0L
    )

    private val prefs = context.getSharedPreferences("zee_mesh_store", Context.MODE_PRIVATE)
    private val lock = Any()
    private val pending = LinkedHashMap<String, Pending>()
    private val seen = LinkedHashSet<String>()
    /** IDs déjà livrés au destinataire final. Contrairement à `seen`, cette
     * collection est persistante : un relais qui redémarre doit pouvoir
     * retransmettre un message non livré, tandis que le destinataire doit
     * pouvoir ignorer un doublon tout en renvoyant son ACK. */
    private val delivered = LinkedHashSet<String>()

    init {
        load()
    }

    fun enqueue(targetNodeId: String, line: String, messageId: String = extractMessageId(line) ?: UUID.randomUUID().toString()) {
        synchronized(lock) {
            if (!pending.containsKey(messageId)) {
                pending[messageId] = Pending(messageId, targetNodeId, line, System.currentTimeMillis())
                trimPending()
                persist()
            }
        }
    }

    fun ack(messageId: String) {
        synchronized(lock) {
            if (pending.remove(messageId) != null) persist()
        }
    }

    fun pendingFor(targetNodeId: String? = null): List<Pending> = synchronized(lock) {
        val now = System.currentTimeMillis()
        pending.values.filter { (targetNodeId == null || it.targetNodeId == targetNodeId) && it.nextRetryAt <= now }
    }

    fun markAttempt(messageId: String, backoffMs: Long = 5_000L) {
        synchronized(lock) {
            val p = pending[messageId] ?: return
            p.attempts += 1
            val capped = minOf(p.attempts, 6)
            p.nextRetryAt = System.currentTimeMillis() + backoffMs * (1L shl (capped - 1))
            persist()
        }
    }

    /** Déduplication de relais pendant la durée du processus. */
    fun markSeen(messageId: String): Boolean = synchronized(lock) {
        if (messageId.isBlank() || !seen.add(messageId)) return false
        while (seen.size > 2_000) seen.remove(seen.first())
        true
    }

    /** Marque une livraison finale de façon persistante. */
    fun markDelivered(messageId: String): Boolean = synchronized(lock) {
        if (messageId.isBlank() || !delivered.add(messageId)) return false
        while (delivered.size > 2_000) delivered.remove(delivered.first())
        persist()
        true
    }

    fun wasDelivered(messageId: String): Boolean = synchronized(lock) {
        delivered.contains(messageId)
    }

    fun pendingTarget(messageId: String): String? = synchronized(lock) { pending[messageId]?.targetNodeId }

    fun pendingCount(): Int = synchronized(lock) { pending.size }

    private fun load() {
        synchronized(lock) {
            runCatching {
                val p = JSONArray(prefs.getString("pending", "[]"))
                for (i in 0 until p.length()) {
                    val o = p.getJSONObject(i)
                    val item = Pending(
                        messageId = o.getString("id"),
                        targetNodeId = o.optString("target"),
                        line = o.getString("line"),
                        createdAt = o.optLong("createdAt", System.currentTimeMillis()),
                        attempts = o.optInt("attempts", 0),
                        // Une nouvelle instance du processus doit pouvoir
                        // reprendre immédiatement dès qu'une route ZEE est
                        // disponible : ne pas attendre l'ancien backoff mémoire.
                        nextRetryAt = 0L
                    )
                    pending[item.messageId] = item
                }
                // `seen` est volontairement process-local. Le rendre persistant
                // empêcherait un relais redémarré de traiter une retransmission
                // légitime provenant du saut précédent.
                val d = JSONArray(prefs.getString("delivered", "[]"))
                for (i in 0 until d.length()) delivered.add(d.optString(i))
            }
        }
    }

    private fun persist() {
        val p = JSONArray()
        pending.values.forEach {
            p.put(JSONObject().apply {
                put("id", it.messageId)
                put("target", it.targetNodeId)
                put("line", it.line)
                put("createdAt", it.createdAt)
                put("attempts", it.attempts)
                put("nextRetryAt", it.nextRetryAt)
            })
        }
        val d = JSONArray()
        delivered.forEach { d.put(it) }
        prefs.edit().putString("pending", p.toString()).putString("delivered", d.toString()).apply()
    }

    private fun trimPending() {
        while (pending.size > 500) {
            val oldest = pending.values.minByOrNull { it.createdAt } ?: break
            pending.remove(oldest.messageId)
        }
    }

    private fun extractMessageId(line: String): String? = runCatching {
        val o = JSONObject(line)
        o.optString("messageId").ifBlank { null }
    }.getOrNull()
}
