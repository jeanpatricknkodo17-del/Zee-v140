package com.zee.app.network

import android.content.Context
import android.net.Uri
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import java.io.*
import java.net.InetSocketAddress
import java.net.ServerSocket
import java.net.Socket

/**
 * Canal binaire des pièces jointes ZEE.
 *
 * Le flux est routable : chaque saut lit le fichier dans un stockage temporaire
 * puis le transmet au prochain voisin connu. Les métadonnées sont embarquées
 * dans le même en-tête que les octets, ce qui évite toute course entre le canal
 * texte et le canal fichier.
 */
object FileTransferManager {
    const val ZEE_FILE_PORT = WifiDirectManager.ZEE_PORT + 1
    private const val CHUNK_SIZE = 64 * 1024
    private const val MAX_FILE_SIZE = 1024L * 1024L * 1024L * 2L

    private data class WebRtcReceiveState(
        val file: File, val output: RandomAccessFile, val meta: TransferMeta,
        var expectedSequence: Int = 0, var received: Long = 0L, var lastAckOffset: Long = 0L
    )
    private val webRtcReceives = java.util.concurrent.ConcurrentHashMap<String, WebRtcReceiveState>()
    @Volatile var webRtcCompletionListener: ((File, TransferMeta) -> Unit)? = null

    interface ProgressListener {
        fun onProgress(sentBytes: Long, totalBytes: Long)
        fun onComplete(file: File, meta: TransferMeta)
        fun onError(error: Exception)
    }

    data class TransferMeta(
        val messageId: String,
        val fromNodeId: String,
        val toNodeId: String,
        val ttl: Int,
        val fileName: String,
        val mimeType: String,
        val fileSize: Long,
        val kind: String = "CHAT"
    )

    fun sendFile(
        context: Context,
        scope: CoroutineScope,
        hostAddress: String,
        fileUri: Uri,
        fileName: String,
        messageId: String,
        fromNodeId: String,
        toNodeId: String,
        mimeType: String,
        ttl: Int,
        listener: ProgressListener,
        kind: String = "CHAT",
        preferredWebRtcSender: ((TransferMeta, File) -> Boolean)? = null,
        preferredFastWifiSender: ((TransferMeta, File) -> Boolean)? = null
    ) {
        scope.launch(Dispatchers.IO) {
            try {
                val size = context.contentResolver.openFileDescriptor(fileUri, "r")?.use { it.statSize }
                    ?: throw IOException("Taille du fichier introuvable")
                val meta = TransferMeta(messageId, fromNodeId, toNodeId, ttl, safeName(fileName), mimeType, size, kind)
                context.contentResolver.openInputStream(fileUri)?.use { input ->
                    val callbackFile = if (fileUri.scheme == "file" && !fileUri.path.isNullOrBlank()) {
                        File(fileUri.path!!)
                    } else {
                        // Les content:// et FileProvider:// Uris n'exposent pas
                        // forcément un chemin réel. On conserve une copie locale
                        // de la source envoyée afin que onComplete() puisse
                        // toujours fournir un fichier réellement existant.
                        val dir = File(context.cacheDir, "zee_sent_files").apply { mkdirs() }
                        File(dir, "${messageId}_${safeName(fileName)}").also { dest ->
                            java.io.FileOutputStream(dest).use { out -> input.copyTo(out, CHUNK_SIZE) }
                        }
                    }
                    if (callbackFile.length() == size) {
                        // WebRTC est le chemin préféré une fois WEBRTC_READY.
                        // Le callback doit retourner false avant toute émission
                        // TCP si le DataChannel n'est pas disponible. En cas de
                        // panne pendant l'émission, on retombe sur TCP.
                        val rtcSent = preferredWebRtcSender?.invoke(meta, callbackFile) == true
                        val fastWifiSent = if (!rtcSent) preferredFastWifiSender?.invoke(meta, callbackFile) == true else false
                        if (!rtcSent && !fastWifiSent) {
                            java.io.FileInputStream(callbackFile).use { source ->
                                sendStream(scope, hostAddress, meta, source, size, listener, callbackFile)
                            }
                        } else {
                            listener.onProgress(size, size)
                            listener.onComplete(callbackFile, meta)
                        }
                    } else {
                        throw IOException("Copie locale de la pièce jointe incomplète")
                    }
                } ?: throw IOException("Impossible de lire la pièce jointe")
            } catch (e: Exception) {
                listener.onError(e)
            }
        }
    }

    fun startListening(
        scope: CoroutineScope,
        destinationDir: File,
        localNodeId: String,
        nextHopAddress: (String) -> String?,
        listener: ProgressListener
    ): ServerSocket {
        val serverSocket = ServerSocket(ZEE_FILE_PORT)
        scope.launch(Dispatchers.IO) {
            while (!serverSocket.isClosed) {
                try {
                    val client = serverSocket.accept()
                    scope.launch(Dispatchers.IO) {
                        receiveOne(client, destinationDir, localNodeId, nextHopAddress, scope, listener)
                    }
                } catch (e: Exception) {
                    if (!serverSocket.isClosed) listener.onError(e)
                }
            }
        }
        return serverSocket
    }

    fun sendLocalFile(
        scope: CoroutineScope,
        hostAddress: String,
        meta: TransferMeta,
        file: File,
        listener: ProgressListener
    ) {
        sendLocalFileInternal(scope, hostAddress, meta, file, listener)
    }

    private fun receiveOne(
        client: Socket,
        destinationDir: File,
        localNodeId: String,
        nextHopAddress: (String) -> String?,
        scope: CoroutineScope,
        listener: ProgressListener
    ) {
        try {
            val input = DataInputStream(BufferedInputStream(client.getInputStream(), CHUNK_SIZE))
            val meta = TransferMeta(
                messageId = input.readUTF(),
                fromNodeId = input.readUTF(),
                toNodeId = input.readUTF(),
                ttl = input.readInt(),
                fileName = safeName(input.readUTF()),
                mimeType = input.readUTF(),
                fileSize = input.readLong(),
                kind = runCatching { input.readUTF() }.getOrDefault("CHAT")
            )
            require(meta.fileSize in 0..MAX_FILE_SIZE) { "Taille de fichier invalide" }

            if (!destinationDir.exists()) destinationDir.mkdirs()
            val destFile = File(destinationDir, "${meta.messageId}_${meta.fileName}")
            FileOutputStream(destFile).use { fos ->
                val out = BufferedOutputStream(fos, CHUNK_SIZE)
                val buffer = ByteArray(CHUNK_SIZE)
                var received = 0L
                while (received < meta.fileSize) {
                    val n = input.read(buffer, 0, minOf(CHUNK_SIZE.toLong(), meta.fileSize - received).toInt())
                    if (n < 0) throw EOFException("Transfert interrompu")
                    out.write(buffer, 0, n)
                    received += n
                    listener.onProgress(received, meta.fileSize)
                }
                out.flush()
            }

            if (meta.toNodeId.isNotBlank() && meta.toNodeId != localNodeId) {
                if (meta.ttl <= 0) throw IOException("TTL de relais épuisé")
                val hop = nextHopAddress(meta.toNodeId) ?: throw IOException("Aucune route de relais")
                val forwarded = meta.copy(ttl = meta.ttl - 1)
                sendLocalFile(scope, hop, forwarded, destFile, object : ProgressListener {
                    override fun onProgress(sentBytes: Long, totalBytes: Long) {}
                    override fun onComplete(file: File, meta: TransferMeta) { destFile.delete() }
                    override fun onError(error: Exception) { destFile.delete(); listener.onError(error) }
                })
            } else {
                listener.onComplete(destFile, meta)
            }
        } catch (e: Exception) {
            listener.onError(e)
        } finally {
            client.close()
        }
    }

    private fun sendLocalFileInternal(
        scope: CoroutineScope,
        hostAddress: String,
        meta: TransferMeta,
        file: File,
        listener: ProgressListener
    ) {
        scope.launch(Dispatchers.IO) {
            try {
                FileInputStream(file).use { input ->
                    sendStream(scope, hostAddress, meta, input, meta.fileSize, listener, file)
                }
            } catch (e: Exception) {
                listener.onError(e)
            }
        }
    }

    private fun sendStream(
        scope: CoroutineScope,
        hostAddress: String,
        meta: TransferMeta,
        input: InputStream,
        total: Long,
        listener: ProgressListener,
        completionFile: File? = null
    ) {
        var socket: Socket? = null
        try {
            var last: Exception? = null
            for (attempt in 0 until 10) {
                try {
                    socket = Socket()
                    socket!!.connect(InetSocketAddress(hostAddress, ZEE_FILE_PORT), 3000)
                    break
                } catch (e: Exception) {
                    last = e
                    socket?.close()
                    socket = null
                    if (attempt < 9) Thread.sleep(400)
                }
            }
            socket ?: throw (last ?: IOException("Connexion fichier impossible"))

            val out = DataOutputStream(BufferedOutputStream(socket!!.getOutputStream(), CHUNK_SIZE))
            out.writeUTF(meta.messageId)
            out.writeUTF(meta.fromNodeId)
            out.writeUTF(meta.toNodeId)
            out.writeInt(meta.ttl)
            out.writeUTF(meta.fileName)
            out.writeUTF(meta.mimeType)
            out.writeLong(total)
            out.writeUTF(meta.kind)
            out.flush()

            val buffer = ByteArray(CHUNK_SIZE)
            var sent = 0L
            while (sent < total) {
                val n = input.read(buffer, 0, minOf(CHUNK_SIZE.toLong(), total - sent).toInt())
                if (n < 0) throw EOFException("Lecture du fichier interrompue")
                out.write(buffer, 0, n)
                sent += n
                listener.onProgress(sent, total)
            }
            out.flush()
            listener.onComplete(completionFile ?: File(meta.fileName), meta)
        } finally {
            socket?.close()
        }
    }

    /**
     * Prépare/réouvre une réception WebRTC. Le fichier partiel est conservé
     * après une coupure afin que le prochain FileStart puisse reprendre au
     * dernier offset réellement écrit.
     */
    fun onWebRtcFileStart(
        context: Context, remoteNodeId: String, messageId: String, fromNodeId: String,
        toNodeId: String, ttl: Int, fileName: String, mimeType: String, fileSize: Long, kind: String,
        requestedOffset: Long = 0L
    ): Long {
        if (fileSize !in 0..MAX_FILE_SIZE || messageId.isBlank()) return 0L
        // WebRTC est un lien direct : l'identité annoncée par le protocole
        // doit correspondre au pair qui possède réellement le DataChannel.
        if (fromNodeId.isBlank() || fromNodeId != remoteNodeId) return 0L
        if (toNodeId.isBlank() || toNodeId != SessionRegistry.localNodeId) return 0L
        webRtcReceives.remove(messageId)?.let { runCatching { it.output.close() } }
        val dir = File(context.cacheDir, "zee_rtc_received").apply { mkdirs() }
        val file = File(dir, "${messageId}_${safeName(fileName)}")
        val existing = if (file.exists()) file.length() else 0L
        // Un fichier partiel plus grand que la taille annoncée est corrompu
        // ou provient d'un ancien transfert portant le même ID : il faut
        // repartir de zéro, et surtout ne pas créer un fichier creux à
        // fileSize octets puis le considérer comme déjà reçu.
        val resume = if (existing > fileSize) {
            file.delete()
            0L
        } else {
            existing
        }
        val meta = TransferMeta(messageId, fromNodeId, toNodeId, ttl, safeName(fileName), mimeType, fileSize, kind)
        return runCatching {
            val raf = RandomAccessFile(file, "rw")
            raf.seek(resume)
            webRtcReceives[messageId] = WebRtcReceiveState(
                file = file, output = raf, meta = meta,
                expectedSequence = 0, received = resume, lastAckOffset = resume
            )
            resume
        }.getOrElse {
            file.delete()
            0L
        }
    }

    /** Retourne le nouvel offset à ACKer, ou -1 lorsqu'il n'est pas encore
     * nécessaire d'émettre un ACK de fenêtre. */
    fun onWebRtcFileChunk(
        context: Context, remoteNodeId: String, messageId: String, sequence: Int,
        offset: Long, end: Boolean, data: ByteArray
    ): Long {
        val state = webRtcReceives[messageId] ?: return -1L
        if (sequence != state.expectedSequence || offset != state.received) return -1L
        if (data.isEmpty() || data.size > 16 * 1024 ||
            state.received + data.size > state.meta.fileSize) {
            webRtcReceives.remove(messageId)
            runCatching { state.output.close() }
            state.file.delete()
            return -1L
        }
        return runCatching {
            state.output.seek(state.received)
            state.output.write(data)
            state.received += data.size
            state.expectedSequence++
            val shouldAck = end || state.received - state.lastAckOffset >= 2L * 1024L * 1024L
            if (shouldAck) {
                state.output.fd.sync()
                state.lastAckOffset = state.received
                if (end && state.received == state.meta.fileSize) {
                    webRtcReceives.remove(messageId)
                    runCatching { state.output.close() }
                    webRtcCompletionListener?.invoke(state.file, state.meta)
                }
                state.received
            } else -1L
        }.getOrElse {
            webRtcReceives.remove(messageId)
            runCatching { state.output.close() }
            -1L
        }
    }

    fun onWebRtcFileEnd(context: Context, remoteNodeId: String, messageId: String) {
        val state = webRtcReceives.remove(messageId) ?: return
        runCatching { state.output.fd.sync(); state.output.close() }.onFailure {
            state.file.delete(); return
        }
        if (state.received != state.meta.fileSize) {
            // Conservation du fichier partiel : le prochain FileStart le
            // rouvrira et annoncera son offset exact au nouvel émetteur.
            return
        }
        webRtcCompletionListener?.invoke(state.file, state.meta)
    }

    private fun safeName(name: String): String {
        val clean = name.replace('\\', '_').replace('/', '_').trim()
        return clean.ifBlank { "fichier" }.take(180)
    }
}
