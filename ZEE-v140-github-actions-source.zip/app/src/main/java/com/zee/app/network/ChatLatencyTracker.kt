package com.zee.app.network

import android.os.SystemClock
import android.util.Log
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.atomic.AtomicLong

/**
 * Mesure la latence du canal chat sans horloge réseau :
 * - RTT A<->B pour chaque message (send -> ACK reçu)
 * - nombre de relais
 *
 * SystemClock.elapsedRealtimeNanos() est monotone et ne dépend pas d'un
 * changement d'heure. La mesure est donc exploitable même si les téléphones
 * n'ont pas leurs horloges synchronisées.
 */
object ChatLatencyTracker {
    data class Sample(
        val messageId: String,
        val targetNodeId: String,
        val rttMs: Double,
        val estimatedOneWayMs: Double,
        val atMs: Long
    )

    private val pending = ConcurrentHashMap<String, Long>()
    private val relayQueued = ConcurrentHashMap<String, Long>()
    private val lastRttBits = AtomicLong(Double.NaN.toRawBits())
    @Volatile private var lastSample: Sample? = null

    fun markSent(messageId: String) {
        if (messageId.isNotBlank()) pending[messageId] = SystemClock.elapsedRealtimeNanos()
    }

    /** Début du traitement local d'un paquet CHAT par un nœud relais. */
    fun markRelayQueued(messageId: String) {
        if (messageId.isNotBlank()) relayQueued[messageId] = SystemClock.elapsedRealtimeNanos()
    }

    /** Temps local entre réception du CHAT par le relais et flush vers le prochain saut. */
    fun markRelayFlushed(messageId: String) {
        val started = relayQueued.remove(messageId) ?: return
        val ms = (SystemClock.elapsedRealtimeNanos() - started) / 1_000_000.0
        Log.i("ZeeChatLatency", "messageId=$messageId RELAY_PROCESSING=${"%.2f".format(ms)}ms")
    }

    fun markAck(messageId: String, targetNodeId: String) {
        val started = pending.remove(messageId) ?: return
        val rttMs = (SystemClock.elapsedRealtimeNanos() - started) / 1_000_000.0
        val sample = Sample(
            messageId = messageId,
            targetNodeId = targetNodeId,
            rttMs = rttMs,
            estimatedOneWayMs = rttMs / 2.0,
            atMs = System.currentTimeMillis()
        )
        lastSample = sample
        lastRttBits.set(rttMs.toRawBits())
        Log.i("ZeeChatLatency", "messageId=${sample.messageId} target=${sample.targetNodeId} RTT=${"%.2f".format(rttMs)}ms estimatedOneWay=${"%.2f".format(sample.estimatedOneWayMs)}ms")
    }

    fun lastSample(): Sample? = lastSample
    fun lastRttMs(): Double = Double.fromBits(lastRttBits.get())

    fun clear(messageId: String) {
        pending.remove(messageId)
        relayQueued.remove(messageId)
    }
}
