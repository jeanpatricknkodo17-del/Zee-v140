package com.zee.app.network

import android.annotation.SuppressLint
import android.content.Context
import android.content.IntentFilter
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.net.NetworkRequest
import android.net.wifi.p2p.WifiP2pConfig
import android.net.wifi.p2p.WifiP2pDevice
import android.net.wifi.p2p.WifiP2pManager
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceInfo
import android.net.wifi.p2p.nsd.WifiP2pDnsSdServiceRequest
import android.util.Base64
import android.util.Log
import java.io.ByteArrayOutputStream
import androidx.core.content.ContextCompat
import com.zee.app.model.Peer
import com.zee.app.model.PeerStatus
import com.zee.app.model.ProfileStore
import com.zee.app.model.VisibilityStore
import com.zee.app.model.ZeeModule

/**
 * Encapsule toute la communication locale de ZEE.
 *
 * ZEE n'utilise jamais internet : la découverte et l'échange de données
 * passent uniquement par l'API Wi-Fi Direct d'Android (WifiP2pManager),
 * exactement comme le fait Xender pour le transfert de fichiers.
 *
 * RESTRICTION IMPORTANTE — c'est le cœur de ce fichier :
 * ZEE n'affiche QUE les appareils qui font tourner l'application ZEE.
 * Jamais un simple point d'accès Wi-Fi ouvert, ni un appareil Wi-Fi Direct
 * quelconque (imprimante, TV, autre app P2P) qui se trouverait à portée.
 *
 * Pour ça, on n'utilise PAS la découverte Wi-Fi Direct générique
 * (manager.discoverPeers, qui remonte TOUT appareil P2P visible sans
 * distinction). On utilise à la place la "découverte de service" Wi-Fi
 * Direct — l'équivalent P2P de Bonjour/DNS-SD :
 *   1. Chaque appareil ZEE annonce un service local nommé SERVICE_INSTANCE
 *      sur le type SERVICE_TYPE (addLocalService), avec un TXT record qui
 *      liste sur QUELS MODULES (RENCONTRES / BUSINESS / JOB) il est visible
 *      (voir VisibilityStore), ET son propre critère pour chacun de ces
 *      modules (voir TXT_KEY_CRITERIA) — sexe pour RENCONTRES, statut pour
 *      BUSINESS/JOB — pour permettre le filtrage croisé des listes sans
 *      avoir à se connecter d'abord (voir PeerListFragment).
 *   2. La recherche (discoverServices) ne déclenche onZeePeerFound() QUE
 *      lorsqu'un appareil répond avec CE service précis — un point d'accès
 *      Wi-Fi classique ou un appareil P2P générique ne répond jamais à
 *      cette requête, donc n'apparaît jamais dans la liste.
 *
 * Flux général :
 *   1. startDiscovery()   -> annonce notre propre service ZEE (modules
 *                             visibles + critère par module) + lance la
 *                             recherche des autres services ZEE alentour
 *   2. onPeersChanged     -> callback avec les Peer confirmés ZEE
 *   3. connectTo(peer)    -> négocie qui devient "group owner" (mini point d'accès)
 *   4. Une fois connectés, ZeeSocketSession ouvre un canal TCP sur le
 *      réseau P2P local pour échanger messages texte + fichiers.
 *
 * NOTE POUR LE DÉVELOPPEUR :
 * Ce fichier suppose que les permissions ACCESS_FINE_LOCATION et
 * NEARBY_WIFI_DEVICES ont déjà été accordées par l'utilisateur avant
 * d'appeler startDiscovery() (voir MainActivity.requestZeePermissions()).
 */
class WifiDirectManager(
    private val context: Context,
    private val onPeersChanged: (List<Peer>) -> Unit,
    private val onConnected: (groupOwnerAddress: String, isGroupOwner: Boolean, peerDeviceAddress: String?) -> Unit,
    private val onStateChanged: (enabled: Boolean) -> Unit,
    private val onConnectedStateLost: () -> Unit = {},
    /** Pairs Wi-Fi Direct bruts vus par discoverPeers(); diagnostic uniquement. */
    private val onRawPeersAvailable: (List<WifiP2pDevice>) -> Unit = {}
) {
    companion object {
        private const val TAG = "WifiDirectManager"
        const val ZEE_PORT = 8988

        // Identifiants du service Wi-Fi Direct propre à ZEE : seuls les
        // appareils qui annoncent EXACTEMENT ce couple (nom + type) sont
        // reconnus comme des pairs ZEE.
        private const val SERVICE_INSTANCE = "_zee_app_service"
        /** Préfixe du nom d'instance V2 : "zeev2-<nodeId 32 hex>-<modules>-<chat>-<market>-<job>" (49 car. max, limite DNS : 63). */
        private const val SERVICE_INSTANCE_V2 = "zeev2"
        /**
         * Services « aperçu de profil » : le nom d'instance (réponse PTR, seule partie qui arrive
         * toujours dans les journaux) porte aussi le nom et l'ACTU, en base32 minuscule :
         * "zeev2p-<n|c|m|j>-<base32>", 57 caractères au plus (limite DNS 63).
         * Mettre à false pour revenir à une annonce à un seul service si une annonce plus
         * grosse dégradait la découverte sur un modèle.
         */
        private const val PTR_PREVIEW_ENABLED = false
        private const val SERVICE_INSTANCE_PREVIEW = "zeev2p"
        private const val PREVIEW_MAX_BYTES = 30
        /**
         * Photo d'aperçu par nom d'instance : miniature 6x6 en RGB444 = 54 octets, envoyée en
         * 2 labels de 27 octets ("zeev2p-0-..." et "zeev2p-1-...", 53 caractères chacun).
         * Reconstruite à la réception en PNG 96x96 lissé.
         */
        private const val PHOTO_PTR_SIDE = 6
        private const val PHOTO_PTR_CHUNK_BYTES = 27
        private const val PHOTO_PREVIEW_UPSCALE = 96
        private const val B32_ALPHABET = "abcdefghijklmnopqrstuvwxyz234567"
        private const val SERVICE_TYPE = "_presence._tcp"

        // Clé du TXT record qui transporte la liste des modules visibles
        // (valeurs séparées par des virgules, ex. "CHAT,JOB").
        private const val TXT_KEY_MODULES = "m"
        private const val TXT_KEY_MODULES_OLD = "modules"

        // Clé du TXT record transportant le critère propre à chaque module
        // visible, au format "MODULE:valeur,MODULE:valeur", ex.
        // "CHAT:Femmes,MARKET:A" — voir Peer.criteriaByModule pour le sens
        // exact de chaque valeur selon le module.
        private const val TXT_KEY_CRITERIA = "c"
        private const val TXT_KEY_CRITERIA_OLD = "criteria"
        private const val TXT_KEY_NODE_ID = "n"
        private const val TXT_KEY_NODE_ID_OLD = "nodeId"
        private const val TXT_KEY_PROFILE_NAME = "p"
        private const val TXT_KEY_PROFILE_NAME_OLD = "profileName"
        private const val TXT_KEY_CHAT_ACTU = "a"
        private const val TXT_KEY_CHAT_ACTU_OLD = "chatActu"
        private const val TXT_KEY_MARKET_ACTU = "b"
        private const val TXT_KEY_MARKET_ACTU_OLD = "marketActu"
        private const val TXT_KEY_JOB_ACTU = "j"
        private const val TXT_KEY_JOB_ACTU_OLD = "jobActu"
        // Miniature de photo de profil diffusée AVANT connexion. Chaque
        // fragment reste sous la limite pratique d'un champ TXT DNS-SD.
        private const val TXT_KEY_PHOTO_CHUNKS = "pc"
        private const val TXT_KEY_PHOTO_CHUNKS_OLD = "photoChunks"
        private const val TXT_KEY_PHOTO_PREFIX = "p"
        private const val TXT_KEY_PHOTO_PREFIX_OLD = "photo"
        // "R565:" (5 car.) + 6x6x2 octets en Base64 (96 car.) = 101 car. Un budget de 96
        // rejetait systématiquement la miniature (v123). 120 laisse une marge.
        private const val PHOTO_CHUNK_SIZE = 120
        /** Attente du TXT (nodeId) avant un arbitrage de connexion de repli. */
        private const val NODE_ID_WAIT_MS = 3000L
        /** Relance périodique de discoverServices() tant qu'aucun TXT n'a été reçu / une fois les pairs connus. */
        private const val SERVICE_REFRESH_FAST_MS = 8000L
        private const val SERVICE_REFRESH_SLOW_MS = 25000L
        /** Service vu sans TXT : nouvelle requête de service après ce délai (au plus 1 fois / cooldown par pair). */
        private const val TXT_WATCHDOG_MS = 4000L
        private const val TXT_WATCHDOG_COOLDOWN_MS = 20000L
        /** Le côté qui « attend l'initiative du pair » se connecte lui-même si rien ne s'est formé. */
        private const val LATE_INITIATE_MS = 15000L
        private const val PHOTO_MAX_CHUNKS = 1
        private const val PHOTO_THUMB_SIZE = 6
        private const val PHOTO_RAW_PREFIX = "R565:"

        /** Nombre d'essais internes de connect() avant de remonter un échec
         * code 0 (ERROR) à l'appelant — voir doConnect(). */
        private const val MAX_CONNECT_ATTEMPTS = 4
        /** Attente maximale de la (ré)apparition du pair dans la liste avant connect(). */
        private const val PEER_WAIT_MS = 8000L
        private const val PEER_POLL_MS = 600L
        /**
         * Connexion rapide Android 10+ (API 29) « par informations prédéterminées » : un téléphone
         * crée le groupe avec un nom de réseau + mot de passe connus des deux (createGroup(config)),
         * l'autre le rejoint avec la même config (connect(config)). Aucune négociation WPS/PBC,
         * donc aucune boîte de dialogue « Invitation à se connecter » à accepter sur l'autre
         * téléphone. Repli automatique sur la connexion classique en cas d'échec.
         */
        private const val FAST_CONNECT_ENABLED = true
        /**
         * Réseau ZEE « libre » : même nom et même mot de passe pour tous les téléphones ZEE, intégrés
         * à l'application. Tout utilisateur ZEE peut donc rejoindre n'importe quel groupe ZEE sans
         * négociation, sans invitation et sans aucune saisie. (Android n'offre pas de groupe
         * Wi-Fi Direct sans chiffrement : la clé existe, mais personne n'a à la connaître ni à la saisir.)
         */
        private const val FAST_SSID = "DIRECT-ZE-ZEEFree"
        private const val FAST_PASSPHRASE = "ZEE-free-wifi-direct-2026"
        private const val FAST_PROBE_WAIT_MS = 10000L
        /** Délai avant le fallback radio quand un pair P2P est visible mais DNS-SD n'a pas encore répondu. */
        private const val RAW_PEER_CONNECT_FALLBACK_MS = 4500L
        /** Un même pair radio ne doit pas être sondé en boucle pendant un cycle. */
        private const val RAW_PEER_CONNECT_COOLDOWN_MS = 30000L
        private const val PROBE_COOLDOWN_MS = 120000L
        private const val FAST_JOIN_WAIT_MS = 18000L
        private const val FAST_JOIN_ATTEMPT_MS = 7000L
        private const val FAST_JOIN_RETRY_MS = 1500L
        private const val FAST_GROUP_WAIT_MS = 40000L
        /** Pendant ce délai après connectTo(), un « pas de groupe » du système n'est pas une perte de connexion. */
        private const val CONNECT_GRACE_MS = 20000L
    }

    private val manager: WifiP2pManager =
        context.getSystemService(Context.WIFI_P2P_SERVICE) as WifiP2pManager
    private val channel: WifiP2pManager.Channel = manager.initialize(context, context.mainLooper, null)
    private val connectivityManager: ConnectivityManager =
        context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
    private var p2pNetworkCallback: ConnectivityManager.NetworkCallback? = null
    @Volatile private var boundP2pNetwork: Network? = null
    @Volatile private var networkReadyForSockets = false
    @Volatile private var connectionGeneration = 0L

    /** Vrai pendant la négociation P2P ; la découverte ne doit pas être relancée. */
    @Volatile var isConnecting: Boolean = false
        private set

    // Pairs confirmés ZEE (ayant répondu à notre requête de service), tenus
    // à jour au fil des réponses DNS-SD reçues.
    private val discoveredPeers = mutableMapOf<String, Peer>()

    // Connexion automatique ZEE : la découverte seule ne suffit pas à
    // échanger les données de l'application. Dès qu'un autre appareil ZEE
    // est confirmé par DNS-SD, un seul des deux appareils prend l'initiative
    // de la connexion P2P, déterminé de façon stable par le nodeId. Cela
    // évite que les deux téléphones appellent connect() simultanément et
    // obtiennent ERROR/BUSY.
    @Volatile private var autoConnectScheduled = false
    @Volatile private var autoConnectAttemptedNodeId: String? = null
    private val autoConnectHandler = android.os.Handler(context.mainLooper)
    private val nodeIdFallbackScheduled = mutableSetOf<String>()
    private val lateInitiateScheduled = mutableSetOf<String>()
    private val fastConnectFailures = mutableMapOf<String, Int>()
    private val fastConnectDisabled = mutableSetOf<String>()
    @Volatile private var fastGroupToken = 0
    /** Adresses des appareils vus dans la liste brute comme Group Owner (capacité Wi-Fi Direct « GO »). */
    private val rawGroupOwners = mutableSetOf<String>()
    private val probedGoAt = mutableMapOf<String, Long>()
    private val rawPeerConnectAt = mutableMapOf<String, Long>()
    @Volatile private var localP2pDeviceAddress: String? = null
    /** Tant que now < fastGroupUntil, un groupe créé par la connexion rapide attend son client : pas de connexion classique sortante. */
    @Volatile private var fastGroupUntil = 0L
    @Volatile private var connectStartedAt = 0L
    private val txtWatchdogAt = mutableMapOf<String, Long>()
    /** Aperçus (nom/ACTU) reçus par nom d'instance, par adresse, appliqués dès que le pair est connu. */
    private val previewCache = mutableMapOf<String, MutableMap<Char, String>>()
    /** Morceaux de photo d'aperçu reçus (2 par pair) ; le PNG reconstruit est rangé sous la clé 'p' de previewCache. */
    private val photoChunkCache = mutableMapOf<String, Array<ByteArray?>>()
    /** Pixels ARGB de la miniature 6x6 calculée par encodeDiscoveryPhoto (vide si pas de photo). */
    @Volatile private var discoveryThumbPixels: IntArray = IntArray(0)
    private var serviceRefreshTask: Runnable? = null

    private var receiver: WifiDirectBroadcastReceiver? = null
    @Volatile private var receiverRegistered = false

    // État unique du cycle de découverte : plusieurs événements Android
    // (permission, reprise d'activité, état P2P) peuvent arriver presque ensemble.
    @Volatile private var discoveryActive = false
    @Volatile private var discoveryStarting = false
    @Volatile private var discoveryGeneration = 0L
    @Volatile private var localServiceSignature: String? = null
    @Volatile private var serviceRequestRegistered = false
    @Volatile private var lastForceRestartAt = 0L
    private val discoveryHandler = android.os.Handler(context.mainLooper)
    private val rawPeerPolls = mutableListOf<Runnable>()

    /** Vrai si un cycle de découverte est en cours ou en démarrage (lu par le heartbeat de MainActivity). */
    val isDiscoveryRunning: Boolean get() = discoveryActive || discoveryStarting

    val intentFilter = IntentFilter().apply {
        addAction(WifiP2pManager.WIFI_P2P_STATE_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_CONNECTION_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_THIS_DEVICE_CHANGED_ACTION)
        addAction(WifiP2pManager.WIFI_P2P_PEERS_CHANGED_ACTION)
        // Ce callback est utilisé uniquement pour le diagnostic. La liste
        // affichée par ZEE continue de provenir des réponses DNS-SD ZEE.
    }

    /**
     * Force les sockets de l'app (ZeeSocketSession, FileTransferManager) à
     * passer par l'interface réseau du groupe Wi-Fi Direct, et pas par le
     * Wi-Fi domestique ou les données mobiles si le téléphone y est encore
     * connecté. Sans ce branchement explicite, Android choisit parfois
     * silencieusement le mauvais réseau par défaut pour Socket()/
     * ServerSocket() : le groupe P2P se forme correctement, mais toute
     * tentative de connexion au pair échoue en timeout — même avec des
     * réessais — puisqu'elle part sur une interface qui ne mène jamais à
     * son adresse IP locale. C'est la cause la plus fréquente d'un chat qui
     * reste bloqué (et donc du profil jamais reçu, nom du téléphone affiché
     * indéfiniment) alors que le groupe Wi-Fi Direct est bien établi.
     */
    /**
     * Prépare le transport P2P sans détourner globalement le Wi-Fi Internet.
     *
     * Ancienne implémentation : requestNetwork() demandait n'importe quel
     * réseau WIFI sans Internet puis bindProcessToNetwork(). Sur certains OEM,
     * Android retournait un réseau Wi-Fi local qui n'était PAS le groupe P2P.
     * Le groupe Wi-Fi Direct était alors bien formé, mais les sockets ZEE
     * partaient sur la mauvaise interface : découverte OK, échange KO.
     *
     * Nouveau modèle : ne jamais changer le réseau par défaut du processus.
     * Android possède déjà une route spécifique vers l'adresse du Group Owner
     * après la formation du groupe. Les sockets TCP ZEE utilisent donc cette
     * route directement, comme le modèle socket recommandé par Android pour
     * WifiP2pInfo. Cela évite les conflits avec le Wi-Fi Internet et les VPN.
     */
    private fun bindToP2pNetwork(onReady: () -> Unit) {
        releaseP2pNetworkBinding()
        networkReadyForSockets = true
        Log.d(TAG, "Groupe Wi-Fi Direct formé : conservation du routage P2P natif, sans bind global du processus")
        onReady()
    }

    private fun releaseP2pNetworkBinding() {
        p2pNetworkCallback?.let {
            try { connectivityManager.unregisterNetworkCallback(it) } catch (_: Exception) {}
        }
        p2pNetworkCallback = null
        boundP2pNetwork = null
        networkReadyForSockets = false
        // Ne pas appeler bindProcessToNetwork(null) ici : cette classe ne lie
        // plus le processus à un réseau. Modifier le binding global au moment
        // du nettoyage pourrait perturber un éventuel binding géré ailleurs.
    }

    @SuppressLint("MissingPermission")
    private fun notifyConnected(groupOwnerAddress: String, isGroupOwner: Boolean) {
        ZeeDiagnostic.log(context, "P2P_CONNECTED owner=$groupOwnerAddress isGO=$isGroupOwner")
        isConnecting = false
        autoConnectAttemptedNodeId = null
        if (isGroupOwner) {
            manager.requestGroupInfo(channel) { group ->
                val peerAddress = group?.clientList?.firstOrNull()?.deviceAddress
                onConnected(groupOwnerAddress, true, peerAddress)
            }
        } else {
            onConnected(groupOwnerAddress, false, null)
        }
    }

    /**
     * Android peut publier le groupe avant que l'adresse du Group Owner soit
     * disponible. Plusieurs petites vérifications sont plus robustes qu'un
     * délai unique : cela absorbe les différences de timing entre appareils
     * sans bloquer le thread principal.
     */
    @SuppressLint("MissingPermission")
    private fun retryConnectionInfo(attempt: Int, maxAttempts: Int, generation: Long = connectionGeneration) {
        android.os.Handler(context.mainLooper).postDelayed({
            if (generation != connectionGeneration) return@postDelayed
            manager.requestConnectionInfo(channel) { retryInfo ->
                val retryAddr = retryInfo.groupOwnerAddress?.hostAddress
                if (retryInfo.groupFormed && !retryAddr.isNullOrEmpty() && retryAddr != "0.0.0.0") {
                    notifyConnected(retryAddr, retryInfo.isGroupOwner)
                } else if (attempt < maxAttempts) {
                    Log.d(TAG, "Adresse du group owner indisponible (essai $attempt/$maxAttempts)")
                    retryConnectionInfo(attempt + 1, maxAttempts, generation)
                } else {
                    Log.e(TAG, "Adresse du group owner toujours indisponible après $maxAttempts vérifications")
                }
            }
        }, 1000L)
    }

    /** À appeler dans onResume() de l'activité hôte. */
    fun register() {
        if (receiverRegistered && receiver != null) {
            ZeeDiagnostic.log(context, "REGISTER skipped: receiver déjà enregistré")
            return
        }
        ZeeDiagnostic.log(context, "REGISTER Wi-Fi Direct receiver")
        receiver = WifiDirectBroadcastReceiver(
            manager, channel,
            onPeersAvailable = { peers ->
                val summary = peers.joinToString(" | ") {
                    "${it.deviceName.ifBlank { "(sans nom)" }} [${it.deviceAddress}] status=${it.status}"
                }
                ZeeDiagnostic.log(context, "P2P_RAW_PEERS count=${peers.size}${if (summary.isNotBlank()) " :: $summary" else ""}")
                handleRawPeers(peers)
            },
            onConnectionChanged = { info ->
                // Pendant une tentative, le système diffuse aussi des changements « pas de groupe »
                // (négociation en cours, essai précédent annulé). Les traiter comme une perte de
                // connexion relançait la découverte au milieu de la négociation et invalidait les
                // essais en cours : on les ignore pendant CONNECT_GRACE_MS.
                val attemptInProgress = !info.groupFormed && isConnecting &&
                    android.os.SystemClock.elapsedRealtime() - connectStartedAt < CONNECT_GRACE_MS
                if (attemptInProgress) {
                    ZeeDiagnostic.log(context, "CONNECTION_CHANGED ignoré : tentative de connexion en cours")
                } else {
                connectionGeneration++
                if (!info.groupFormed) {
                    // Le groupe précédent a disparu : libérer l'état local
                    // afin que la découverte automatique puisse repartir.
                    // Le routage persistant garde les messages en attente.
                    isConnecting = false
                    fastGroupUntil = 0L
                    autoConnectAttemptedNodeId = null
                    releaseP2pNetworkBinding()
                    onConnectedStateLost()
                } else {
                    // Étape indispensable AVANT toute tentative de socket :
                    // voir bindToP2pNetwork() ci-dessus.
                    bindToP2pNetwork {
                        val ownerAddr = info.groupOwnerAddress?.hostAddress
                        // Android peut transmettre "0.0.0.0" ou une adresse vide
                        // à l'instant précis où le groupe se forme, avant que
                        // l'attribution réseau (DHCP) soit terminée — se
                        // connecter à cette adresse échouerait toujours, même
                        // avec des réessais. On revérifie une seconde fois après
                        // un court délai plutôt que d'abandonner.
                        if (ownerAddr.isNullOrEmpty() || ownerAddr == "0.0.0.0") {
                            Log.d(TAG, "Adresse du group owner pas encore prête, démarrage des nouvelles vérifications...")
                            retryConnectionInfo(attempt = 1, maxAttempts = 5)
                        } else {
                            notifyConnected(ownerAddr, info.isGroupOwner)
                        }
                    }
                }
                }
            },
            onStateChanged = onStateChanged
        )
        try {
            // L'application cible Android 14 (API 34). À partir d'Android 14,
            // un BroadcastReceiver enregistré dynamiquement doit déclarer
            // explicitement son comportement d'exportation. Les événements
            // Wi-Fi Direct viennent du système / composants système : le
            // receiver doit donc être exporté. Sans ce flag, Android peut
            // lever une SecurityException dès l'entrée dans MainActivity,
            // ce qui donne l'impression que ZEE se ferme juste après
            // l'activation du profil.
            ContextCompat.registerReceiver(
                context,
                receiver,
                intentFilter,
                ContextCompat.RECEIVER_EXPORTED
            )
            receiverRegistered = true
            setupServiceDiscoveryListeners()
        } catch (e: SecurityException) {
            receiverRegistered = false
            receiver = null
            Log.e(TAG, "Impossible d'enregistrer le receiver Wi-Fi Direct", e)
            onStateChanged(false)
        }
    }

    /** À appeler dans onPause() de l'activité hôte. */
    fun unregister() {
        if (!receiverRegistered && receiver == null) return
        ZeeDiagnostic.log(context, "UNREGISTER Wi-Fi Direct receiver")
        autoConnectHandler.removeCallbacksAndMessages(null)
        autoConnectScheduled = false
        nodeIdFallbackScheduled.clear()
        lateInitiateScheduled.clear()
        txtWatchdogAt.clear()
        previewCache.clear()
        photoChunkCache.clear()
        fastGroupToken++
        fastGroupUntil = 0L
        rawGroupOwners.clear()
        probedGoAt.clear()
        rawPeerConnectAt.clear()
        cancelServiceRefresh()
        cancelRawPeerPolls()
        discoveryGeneration++ // invalide les callbacks d'un ancien cycle
        discoveryActive = false
        discoveryStarting = false
        localServiceSignature = null
        serviceRequestRegistered = false
        receiver?.let {
            runCatching { context.unregisterReceiver(it) }
                .onFailure { error -> Log.w(TAG, "Receiver déjà désenregistré", error) }
        }
        receiver = null
        receiverRegistered = false
        runCatching { manager.stopPeerDiscovery(channel, null) }
        manager.clearServiceRequests(channel, null)
        serviceRequestRegistered = false
        manager.clearLocalServices(channel, null)
        releaseP2pNetworkBinding()
    }

    /**
     * Écoute les réponses DNS-SD des autres appareils ZEE : la réponse de
     * service (identité) et la réponse TXT record (modules visibles +
     * critère par module chez ce pair) arrivent séparément et dans un
     * ordre non garanti par Android — on fusionne les deux dans la même
     * entrée `discoveredPeers`, en créant l'entrée si besoin depuis
     * n'importe lequel des deux callbacks.
     */
    /** Tronque à maxBytes octets UTF-8 sans couper un caractère en deux (accents, émojis). */
    private fun truncateUtf8(value: String, maxBytes: Int): String {
        var out = value.trim()
        while (out.isNotEmpty() && out.toByteArray(Charsets.UTF_8).size > maxBytes) out = out.dropLast(1)
        return out.trim()
    }

    private fun base32Encode(bytes: ByteArray): String {
        val sb = StringBuilder()
        var buffer = 0
        var bits = 0
        for (b in bytes) {
            buffer = (buffer shl 8) or (b.toInt() and 0xFF)
            bits += 8
            while (bits >= 5) {
                sb.append(B32_ALPHABET[(buffer shr (bits - 5)) and 31])
                bits -= 5
            }
            buffer = buffer and ((1 shl bits) - 1)
        }
        if (bits > 0) sb.append(B32_ALPHABET[(buffer shl (5 - bits)) and 31])
        return sb.toString()
    }

    private fun base32Decode(text: String): ByteArray? {
        val out = java.io.ByteArrayOutputStream()
        var buffer = 0
        var bits = 0
        for (ch in text.lowercase()) {
            val v = B32_ALPHABET.indexOf(ch)
            if (v < 0) return null
            buffer = (buffer shl 5) or v
            bits += 5
            if (bits >= 8) {
                out.write((buffer shr (bits - 8)) and 0xFF)
                bits -= 8
            }
            buffer = buffer and ((1 shl bits) - 1)
        }
        return out.toByteArray()
    }

    /** Noms d'instance « aperçu » : un pour le nom, un par ACTU renseignée (modules visibles). */
    private fun buildPreviewInstanceNames(name: String, actus: Map<ZeeModule, String>, photo: ByteArray?): List<String> {
        val list = mutableListOf<String>()
        fun add(kind: Char, text: String) {
            val t = truncateUtf8(text, PREVIEW_MAX_BYTES)
            if (t.isNotEmpty()) list += "$SERVICE_INSTANCE_PREVIEW-$kind-${base32Encode(t.toByteArray(Charsets.UTF_8))}"
        }
        add('n', name)
        add('c', actus[ZeeModule.CHAT].orEmpty())
        add('m', actus[ZeeModule.MARKET].orEmpty())
        add('j', actus[ZeeModule.JOB].orEmpty())
        if (photo != null && photo.size == PHOTO_PTR_CHUNK_BYTES * 2) {
            list += "$SERVICE_INSTANCE_PREVIEW-0-${base32Encode(photo.copyOfRange(0, PHOTO_PTR_CHUNK_BYTES))}"
            list += "$SERVICE_INSTANCE_PREVIEW-1-${base32Encode(photo.copyOfRange(PHOTO_PTR_CHUNK_BYTES, PHOTO_PTR_CHUNK_BYTES * 2))}"
        }
        return list
    }

    private fun parsePreviewInstance(name: String): Pair<Char, ByteArray>? {
        val parts = name.trim().lowercase().split("-")
        if (parts.size != 3 || parts[0] != SERVICE_INSTANCE_PREVIEW || parts[1].length != 1) return null
        val kind = parts[1][0]
        if (kind !in "ncmj01") return null
        val bytes = base32Decode(parts[2])?.takeIf { it.isNotEmpty() } ?: return null
        return kind to bytes
    }

    /** Complète (sans jamais écraser) nom et ACTU d'un pair avec les aperçus reçus par nom d'instance. */
    private fun applyPreview(peer: Peer): Peer {
        val cache = previewCache[peer.deviceAddress] ?: return peer
        var p = peer
        cache['n']?.let { n -> if (p.displayName.isNullOrBlank()) p = p.copy(displayName = n) }
        val actus = p.actusByModule.toMutableMap()
        var changed = false
        for ((kind, module) in listOf('c' to ZeeModule.CHAT, 'm' to ZeeModule.MARKET, 'j' to ZeeModule.JOB)) {
            val text = cache[kind] ?: continue
            if (actus[module].isNullOrBlank()) { actus[module] = text; changed = true }
        }
        if (changed) p = p.copy(actusByModule = actus)
        cache['c']?.let { c -> if (p.actu.isNullOrBlank()) p = p.copy(actu = c) }
        cache['p']?.let { photo -> if (p.photoBase64.isNullOrBlank()) p = p.copy(photoBase64 = photo) }
        return p
    }

    private fun onZeePeerPreview(device: WifiP2pDevice, kind: Char, bytes: ByteArray) {
        val cache = previewCache.getOrPut(device.deviceAddress) { mutableMapOf() }
        if (kind == '0' || kind == '1') {
            val chunks = photoChunkCache.getOrPut(device.deviceAddress) { arrayOfNulls(2) }
            chunks[kind - '0'] = bytes
            val first = chunks[0]
            val second = chunks[1]
            if (first == null || second == null) return
            val png = decodePhotoPtr(first + second)
            if (png == null) {
                ZeeDiagnostic.log(context, "ZEE_PREVIEW photo decode failed addr=${device.deviceAddress}")
                return
            }
            cache['p'] = png
            ZeeDiagnostic.log(context, "ZEE_PREVIEW photo ready addr=${device.deviceAddress} pngChars=${png.length}")
        } else {
            cache[kind] = String(bytes, Charsets.UTF_8).trim()
        }
        // Pas de création de pair ici : la visibilité du pair n'est pas encore connue.
        val existing = discoveredPeers[device.deviceAddress] ?: return
        val updated = applyPreview(existing)
        if (updated != existing) {
            discoveredPeers[device.deviceAddress] = updated
            onPeersChanged(discoveredPeers.values.toList())
        }
    }

    private class InstanceInfo(val nodeId: String, val modulesRaw: String, val criteriaRaw: String)

    /**
     * Nom d'instance DNS-SD porteur des données de filtrage :
     * zeev2-<nodeId 32 hex>-<modules c/m/j ou x>-<chat sexe+préférence ou x>-<market a/b ou x>-<job a/b ou x>
     * Minuscules, sans point (un point serait découpé en labels DNS), 49 caractères au plus.
     * Retourne null si le nodeId n'est pas un UUID : on garde alors l'ancien nom fixe + TXT.
     */
    private fun buildInstanceName(nodeId: String, visible: Set<ZeeModule>, criteria: Map<ZeeModule, String>): String? {
        val id = nodeId.replace("-", "").lowercase()
        if (!Regex("[0-9a-f]{32}").matches(id)) return null
        val mods = buildString {
            if (ZeeModule.CHAT in visible) append('c')
            if (ZeeModule.MARKET in visible) append('m')
            if (ZeeModule.JOB in visible) append('j')
        }.ifEmpty { "x" }
        val chat = if (ZeeModule.CHAT in visible) {
            val parts = (criteria[ZeeModule.CHAT] ?: "").split("|")
            val sex = if (parts.getOrNull(0)?.startsWith("F", ignoreCase = true) == true) 'f' else 'h'
            val pref = when (parts.getOrNull(1)?.lowercase()) {
                "femmes", "femme" -> 'f'
                "tous" -> 't'
                else -> 'h'
            }
            "$sex$pref"
        } else "x"
        fun ab(module: ZeeModule): String =
            if (module !in visible) "x" else if (criteria[module] == "B") "b" else "a"
        return "$SERVICE_INSTANCE_V2-$id-$mods-$chat-${ab(ZeeModule.MARKET)}-${ab(ZeeModule.JOB)}"
    }

    private fun parseInstanceName(name: String): InstanceInfo? {
        val parts = name.trim().lowercase().split("-")
        if (parts.size != 6 || parts[0] != SERVICE_INSTANCE_V2) return null
        val id = parts[1]
        if (!Regex("[0-9a-f]{32}").matches(id)) return null
        val nodeId = "${id.substring(0, 8)}-${id.substring(8, 12)}-${id.substring(12, 16)}-${id.substring(16, 20)}-${id.substring(20)}"
        val mods = parts[2]
        val modules = mutableListOf<String>()
        val criteria = mutableListOf<String>()
        if ('c' in mods) {
            modules += "CHAT"
            val c = parts[3]
            if (c.length == 2) {
                val sex = if (c[0] == 'f') "Femme" else "Homme"
                val pref = when (c[1]) { 'f' -> "Femmes"; 't' -> "Tous"; else -> "Hommes" }
                criteria += "CHAT:$sex|$pref"
            }
        }
        if ('m' in mods) {
            modules += "MARKET"
            criteria += "MARKET:" + if (parts[4] == "b") "B" else "A"
        }
        if ('j' in mods) {
            modules += "JOB"
            criteria += "JOB:" + if (parts[5] == "b") "B" else "A"
        }
        return InstanceInfo(nodeId, modules.joinToString(","), criteria.joinToString(","))
    }

    private fun setupServiceDiscoveryListeners() {
        manager.setDnsSdResponseListeners(
            channel,
            { instanceName, registrationType, device ->
                // Filtre de sécurité supplémentaire : on ignore toute
                // réponse qui ne correspond pas exactement au service ZEE,
                // au cas où un autre service DNS-SD traînerait sur le réseau.
                val normalizedType = registrationType.trim().trimEnd('.')
                val isZeeType = normalizedType.startsWith(SERVICE_TYPE)
                val instanceInfo = if (isZeeType) parseInstanceName(instanceName) else null
                val preview = if (isZeeType) parsePreviewInstance(instanceName) else null
                if (preview != null) {
                    ZeeDiagnostic.log(context, "ZEE_PREVIEW addr=${device.deviceAddress} kind=${preview.first} bytes=${preview.second.size}")
                    onZeePeerPreview(device, preview.first, preview.second)
                } else if (isZeeType && (instanceName == SERVICE_INSTANCE || instanceInfo != null)) {
                    ZeeDiagnostic.log(context, "ZEE_SERVICE_FOUND name=${device.deviceName} addr=${device.deviceAddress} type=$registrationType instance=$instanceName")
                    if (instanceInfo != null) {
                        ZeeDiagnostic.log(context, "ZEE_INSTANCE nodeId=${instanceInfo.nodeId} modules=${instanceInfo.modulesRaw} criteria=${instanceInfo.criteriaRaw}")
                        onZeePeerModulesReceived(device, instanceInfo.modulesRaw, instanceInfo.criteriaRaw, instanceInfo.nodeId)
                    }
                    onZeePeerFound(device)
                } else {
                    ZeeDiagnostic.log(context, "DNS_SD_OTHER instance=$instanceName type=$registrationType device=${device.deviceName}")
                }
            },
            { _, txtRecordMap, device ->
                val modulesRaw = txtRecordMap[TXT_KEY_MODULES] ?: txtRecordMap[TXT_KEY_MODULES_OLD]
                val criteriaRaw = txtRecordMap[TXT_KEY_CRITERIA] ?: txtRecordMap[TXT_KEY_CRITERIA_OLD]
                val nodeId = txtRecordMap[TXT_KEY_NODE_ID] ?: txtRecordMap[TXT_KEY_NODE_ID_OLD]
                val profileName = decodeTxtProfileValue(txtRecordMap[TXT_KEY_PROFILE_NAME] ?: txtRecordMap[TXT_KEY_PROFILE_NAME_OLD])
                val chatActu = decodeTxtProfileValue(txtRecordMap[TXT_KEY_CHAT_ACTU] ?: txtRecordMap[TXT_KEY_CHAT_ACTU_OLD])
                val marketActu = decodeTxtProfileValue(txtRecordMap[TXT_KEY_MARKET_ACTU] ?: txtRecordMap[TXT_KEY_MARKET_ACTU_OLD])
                val jobActu = decodeTxtProfileValue(txtRecordMap[TXT_KEY_JOB_ACTU] ?: txtRecordMap[TXT_KEY_JOB_ACTU_OLD])
                val photoChunks = (txtRecordMap[TXT_KEY_PHOTO_CHUNKS] ?: txtRecordMap[TXT_KEY_PHOTO_CHUNKS_OLD])?.toIntOrNull()?.coerceIn(0, PHOTO_MAX_CHUNKS) ?: 0
                val photoPayload = if (photoChunks > 0) {
                    val chunks = (0 until photoChunks).map { index ->
                        txtRecordMap["$TXT_KEY_PHOTO_PREFIX$index"] ?: txtRecordMap["$TXT_KEY_PHOTO_PREFIX_OLD$index"]
                    }
                    if (chunks.all { !it.isNullOrBlank() }) chunks.joinToString("") else null
                } else null
                val photoBase64 = photoPayload?.let { decodeDiscoveryPhotoPayload(it) }
                if (!modulesRaw.isNullOrEmpty() || !profileName.isNullOrBlank() || photoBase64 != null) {
                    ZeeDiagnostic.log(context, "ZEE_TXT device=${device.deviceName} modules=$modulesRaw criteria=$criteriaRaw nodeId=$nodeId profile=${!profileName.isNullOrBlank()} photo=${!photoBase64.isNullOrBlank()}")
                    onZeePeerModulesReceived(device, modulesRaw.orEmpty(), criteriaRaw, nodeId,
                        profileName, chatActu, marketActu, jobActu, photoBase64)
                } else {
                    ZeeDiagnostic.log(context, "ZEE_TXT_EMPTY device=${device.deviceName} keys=${txtRecordMap.keys.joinToString(",")}")
                }
            }
        )
    }

    /**
     * Arbitrage de connexion SYMÉTRIQUE : un seul des deux téléphones initie.
     *
     * Avant : si le TXT du pair n'était pas encore arrivé, on comparait NOTRE
     * nodeId à SON adresse MAC, alors que l'autre téléphone comparait SON
     * nodeId à NOTRE MAC : deux règles différentes, donc deux initiateurs
     * simultanés ou aucun. Et si les deux nodeId étaient identiques
     * (restauration/clonage), les deux côtés attendaient indéfiniment.
     *
     * Maintenant : l'ordre par nodeId n'est utilisé que lorsque les deux
     * nodeId sont connus ET distincts. Sinon on attend le TXT pendant
     * NODE_ID_WAIT_MS, puis on tente avec un délai aléatoire (les deux côtés
     * ne partent pas ensemble) ; les réessais de doConnect() absorbent le reste.
     */
    @SuppressLint("MissingPermission")
    private fun maybeAutoConnect(peer: Peer, allowWithoutNodeId: Boolean = false, ignoreOrder: Boolean = false) {
        if (isConnecting || autoConnectScheduled) return
        if (peer.deviceAddress.isBlank()) return
        // Déjà connecté à ce pair : ne pas relancer connect() à chaque réponse DNS-SD.
        if (peer.status == PeerStatus.CONNECTED) return
        val remoteNodeId = peer.nodeId?.takeIf { it.isNotBlank() }?.lowercase()
        val localNodeId = ProfileStore.getNodeId(context).lowercase()
        val orderedByNodeId = !ignoreOrder && remoteNodeId != null && localNodeId.isNotBlank() && remoteNodeId != localNodeId

        if (!orderedByNodeId && !allowWithoutNodeId && !ignoreOrder) {
            scheduleNodeIdFallback(peer.deviceAddress, if (remoteNodeId == null) "remote-nodeId-unknown" else "same-nodeId")
            return
        }

        manager.requestConnectionInfo(channel) { info ->
            val groupFormed = info.groupFormed
            if (groupFormed && info.isGroupOwner && android.os.SystemClock.elapsedRealtime() < fastGroupUntil) {
                ZeeDiagnostic.log(context, "AUTOCONNECT wait addr=${peer.deviceAddress} reason=fast-group-waiting-client")
                return@requestConnectionInfo
            }
            val fast = fastConnectEligible(peer)
            val fastRole = if (fast) fastRoleFor(peer) else null
            if (fastRole == FastRole.WAIT) {
                ZeeDiagnostic.log(context, "AUTOCONNECT wait addr=${peer.deviceAddress} reason=je-suis-GO-le-pair-me-rejoint")
                return@requestConnectionInfo
            }
            if (!fast && !groupFormed && orderedByNodeId && remoteNodeId != null && localNodeId <= remoteNodeId) {
                ZeeDiagnostic.log(context, "AUTOCONNECT wait addr=${peer.deviceAddress} reason=peer-initiates")
                scheduleLateInitiate(peer.deviceAddress)
                return@requestConnectionInfo
            }
            // Avec un groupe déjà formé, seul le Group Owner ajoute un client.
            if (groupFormed && !info.isGroupOwner) {
                ZeeDiagnostic.log(context, "AUTOCONNECT wait addr=${peer.deviceAddress} reason=client-in-group")
                return@requestConnectionInfo
            }

            val attemptKey = remoteNodeId ?: peer.deviceAddress
            if (autoConnectAttemptedNodeId == attemptKey) return@requestConnectionInfo
            autoConnectAttemptedNodeId = attemptKey
            autoConnectScheduled = true
            // Mode rapide : le GO crée le groupe tout de suite, le client attend un peu qu'il existe.
            val delayMs = when {
                fastRole == FastRole.GO -> 450L
                fastRole == FastRole.JOIN -> if (peer.deviceAddress in rawGroupOwners) 300L else 1200L + (0L..600L).random()
                orderedByNodeId -> 450L
                else -> 450L + (300L..1700L).random()
            }
            ZeeDiagnostic.log(context, "AUTOCONNECT initiate addr=${peer.deviceAddress} delay=${delayMs}ms ordered=$orderedByNodeId")
            autoConnectHandler.postDelayed({
                autoConnectScheduled = false
                if (!isConnecting) {
                    Log.d(TAG, "Connexion automatique ZEE vers $attemptKey (${peer.deviceAddress})")
                    connectTo(peer) { reason ->
                        Log.w(TAG, "Connexion automatique vers $attemptKey échouée, code=$reason")
                        autoConnectAttemptedNodeId = null
                    }
                }
            }, delayMs)
        }
    }

    private fun scheduleNodeIdFallback(address: String, reason: String) {
        if (!nodeIdFallbackScheduled.add(address)) return
        ZeeDiagnostic.log(context, "AUTOCONNECT wait addr=$address reason=$reason (repli dans ${NODE_ID_WAIT_MS}ms)")
        autoConnectHandler.postDelayed({
            nodeIdFallbackScheduled.remove(address)
            val current = discoveredPeers[address] ?: return@postDelayed
            if (!receiverRegistered || isConnecting) return@postDelayed
            maybeAutoConnect(current, allowWithoutNodeId = true)
        }, NODE_ID_WAIT_MS)
    }

    /**
     * Anti-blocage : si ce téléphone attend l'initiative du pair (ordre nodeId)
     * mais que le pair n'initie jamais (ancienne version, TXT perdu, connect()
     * en échec), on prend l'initiative après LATE_INITIATE_MS.
     */
    private fun scheduleLateInitiate(address: String) {
        if (!lateInitiateScheduled.add(address)) return
        autoConnectHandler.postDelayed({
            lateInitiateScheduled.remove(address)
            val current = discoveredPeers[address] ?: return@postDelayed
            if (!receiverRegistered || isConnecting || SessionRegistry.active != null) return@postDelayed
            ZeeDiagnostic.log(context, "AUTOCONNECT late-fallback addr=$address (le pair n'a pas initié)")
            maybeAutoConnect(current, allowWithoutNodeId = true, ignoreOrder = true)
        }, LATE_INITIATE_MS + (0L..3000L).random())
    }

    /**
     * Service ZEE vu mais TXT absent (cas de l'itel dans le journal : ZEE_SERVICE_FOUND
     * sans ZEE_TXT) : on relance une requête de service au lieu d'attendre indéfiniment.
     */
    private fun scheduleTxtWatchdog(address: String) {
        val now = android.os.SystemClock.elapsedRealtime()
        if (now - (txtWatchdogAt[address] ?: 0L) < TXT_WATCHDOG_COOLDOWN_MS) return
        txtWatchdogAt[address] = now
        val generation = discoveryGeneration
        autoConnectHandler.postDelayed({
            val current = discoveredPeers[address] ?: return@postDelayed
            if (!current.nodeId.isNullOrBlank()) return@postDelayed
            if (generation != discoveryGeneration || !receiverRegistered || isConnecting) return@postDelayed
            ZeeDiagnostic.log(context, "TXT_MISSING addr=$address -> nouvelle requête de service")
            refreshServiceDiscovery(generation, "txt-missing")
        }, TXT_WATCHDOG_MS)
    }

    private fun cancelServiceRefresh() {
        serviceRefreshTask?.let { discoveryHandler.removeCallbacks(it) }
        serviceRefreshTask = null
    }

    /**
     * Relance périodique de discoverServices().
     *
     * Journal TECNO : discoverServices() appelé à 16:49:57 alors qu'aucun pair
     * n'était encore là ; l'itel apparaît à 16:50:04 mais aucune requête de service
     * n'est renvoyée pendant 57 s. Après un rafraîchissement manuel (génération 3),
     * le TXT arrive en 4 s. Une seule requête par cycle ne suffit donc pas : la
     * requête de service est maintenant renvoyée périodiquement (sans effacer
     * l'annonce ni la requête enregistrée).
     */
    private fun scheduleServiceRefresh(generation: Long) {
        cancelServiceRefresh()
        val interval = if (discoveredPeers.values.any { !it.nodeId.isNullOrBlank() }) SERVICE_REFRESH_SLOW_MS else SERVICE_REFRESH_FAST_MS
        val task = Runnable {
            serviceRefreshTask = null
            if (generation != discoveryGeneration || !receiverRegistered) return@Runnable
            if (isConnecting || SessionRegistry.active != null) {
                scheduleServiceRefresh(generation)
            } else {
                refreshServiceDiscovery(generation, "periodic")
            }
        }
        serviceRefreshTask = task
        discoveryHandler.postDelayed(task, interval)
    }

    @SuppressLint("MissingPermission")
    private fun refreshServiceDiscovery(generation: Long, reason: String) {
        if (generation != discoveryGeneration || !receiverRegistered || isConnecting) return
        if (!serviceRequestRegistered) return
        ZeeDiagnostic.log(context, "SERVICE_REFRESH reason=$reason generation=$generation")
        manager.discoverServices(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                if (generation == discoveryGeneration && receiverRegistered) scheduleServiceRefresh(generation)
            }
            override fun onFailure(reasonCode: Int) {
                ZeeDiagnostic.log(context, "SERVICE_REFRESH failure code=$reasonCode generation=$generation")
                if (generation == discoveryGeneration && receiverRegistered) scheduleServiceRefresh(generation)
            }
        })
    }

    @SuppressLint("MissingPermission")
    private fun onZeePeerFound(device: WifiP2pDevice) {
        val existing = discoveredPeers[device.deviceAddress]
        discoveredPeers[device.deviceAddress] = applyPreview(Peer(
            deviceAddress = device.deviceAddress,
            deviceName = device.deviceName,
            nodeId = existing?.nodeId,
            status = when (device.status) {
                WifiP2pDevice.CONNECTED -> PeerStatus.CONNECTED
                WifiP2pDevice.INVITED, WifiP2pDevice.AVAILABLE -> PeerStatus.AVAILABLE
                WifiP2pDevice.FAILED -> PeerStatus.FAILED
                else -> PeerStatus.AVAILABLE
            },
            // La découverte de service se redéclenche périodiquement tant
            // que l'app est ouverte : sans cette conservation, chaque
            // rafraîchissement écrasait le profil réel (nom/ACTU/photo) et
            // même les messages non lus déjà reçus via le socket, faisant
            // réapparaître le nom brut de l'appareil à la place.
            displayName = existing?.displayName,
            actu = existing?.actu,
            photoBase64 = existing?.photoBase64,
            displayNamesByModule = existing?.displayNamesByModule ?: emptyMap(),
            actusByModule = existing?.actusByModule ?: emptyMap(),
            photosByModule = existing?.photosByModule ?: emptyMap(),
            adActive = existing?.adActive ?: false,
            adExpiresAt = existing?.adExpiresAt,
            unreadCount = existing?.unreadCount ?: 0,
            // Le service ZEE est une preuve suffisante que l'app distante est
            // présente. En attendant son TXT complet, on expose provisoirement
            // CHAT afin que la liste ne reste pas vide sur certains OEM où le
            // callback TXT arrive après le callback service. Le TXT remplace
            // immédiatement ce provisoire dès qu'il est reçu.
            visibleModules = existing?.visibleModules ?: setOf(ZeeModule.CHAT),
            criteriaByModule = existing?.criteriaByModule ?: emptyMap()
        ))
        onPeersChanged(discoveredPeers.values.toList())
        if (discoveredPeers[device.deviceAddress]?.nodeId.isNullOrBlank()) scheduleTxtWatchdog(device.deviceAddress)
        maybeAutoConnect(discoveredPeers[device.deviceAddress] ?: return)
    }

    private fun onZeePeerModulesReceived(
        device: WifiP2pDevice,
        modulesRaw: String,
        criteriaRaw: String?,
        nodeId: String?,
        profileName: String? = null,
        chatActu: String? = null,
        marketActu: String? = null,
        jobActu: String? = null,
        photoBase64: String? = null
    ) {
        val modules = modulesRaw.split(",")
            .mapNotNull { name -> runCatching { ZeeModule.valueOf(name.trim()) }.getOrNull() }
            .toSet()

        val criteria = criteriaRaw?.split(",")
            ?.mapNotNull { pair ->
                val parts = pair.split(":", limit = 2)
                if (parts.size != 2) return@mapNotNull null
                val module = runCatching { ZeeModule.valueOf(parts[0].trim()) }.getOrNull() ?: return@mapNotNull null
                module to parts[1].trim()
            }?.toMap() ?: emptyMap()

        val existing = discoveredPeers[device.deviceAddress]
        val namesByModule = if (!profileName.isNullOrBlank()) ZeeModule.values().associateWith { profileName } else existing?.displayNamesByModule.orEmpty()
        val actusByModule = existing?.actusByModule.orEmpty().toMutableMap().apply {
            if (chatActu != null) put(ZeeModule.CHAT, chatActu)
            if (marketActu != null) put(ZeeModule.MARKET, marketActu)
            if (jobActu != null) put(ZeeModule.JOB, jobActu)
        }.toMap()
        if (existing != null) {
            discoveredPeers[device.deviceAddress] = existing.copy(
                visibleModules = modules.ifEmpty { existing.visibleModules },
                criteriaByModule = criteria.ifEmpty { existing.criteriaByModule },
                nodeId = nodeId ?: existing.nodeId,
                displayName = profileName ?: existing.displayName,
                displayNamesByModule = namesByModule,
                actu = chatActu ?: existing.actu,
                actusByModule = actusByModule,
                photoBase64 = photoBase64 ?: existing.photoBase64
            )
        } else {
            // Le TXT record est arrivé avant la réponse de service : on crée
            // une entrée minimale, que onZeePeerFound complétera ensuite.
            discoveredPeers[device.deviceAddress] = Peer(
                deviceAddress = device.deviceAddress,
                deviceName = device.deviceName,
                nodeId = nodeId,
                displayName = profileName,
                displayNamesByModule = namesByModule,
                actu = chatActu,
                actusByModule = actusByModule,
                photoBase64 = photoBase64,
                visibleModules = modules,
                criteriaByModule = criteria
            )
        }
        discoveredPeers[device.deviceAddress]?.let { discoveredPeers[device.deviceAddress] = applyPreview(it) }
        onPeersChanged(discoveredPeers.values.toList())
        maybeAutoConnect(discoveredPeers[device.deviceAddress] ?: return)
    }

    /**
     * Annonce notre propre service ZEE (pour être visible des autres
     * appareils, uniquement sur les modules pour lesquels l'utilisateur
     * n'est pas masqué — voir VisibilityStore), avec notre propre critère
     * pour chacun de ces modules (sexe pour RENCONTRES, statut pour
     * BUSINESS/JOB — voir Peer.criteriaByModule), puis lance la recherche
     * des autres services ZEE alentour, qui reste TOUJOURS active : se
     * masquer ne nous empêche jamais de voir les autres, seulement d'être
     * vu par eux. Remplace l'ancien discoverPeers() générique.
     */
    /** Réinitialise la présence de proximité sans toucher aux sessions Mesh. */
    fun clearNearbyPresence() {
        previewCache.clear()
        photoChunkCache.clear()
        if (discoveredPeers.isEmpty()) return
        discoveredPeers.clear()
        onPeersChanged(emptyList())
        Log.d(TAG, "Présence Wi-Fi Direct réinitialisée avant une nouvelle recherche")
    }

    @SuppressLint("MissingPermission")
    private fun requestRawPeers(tag: String) {
        try {
            manager.requestPeers(channel) { list ->
                val peers = list.deviceList.toList()
                ZeeDiagnostic.log(context, "RAW_REQUEST_PEERS[$tag] count=${peers.size}")
                handleRawPeers(peers)
            }
        } catch (e: SecurityException) {
            ZeeDiagnostic.log(context, "RAW_REQUEST_PEERS[$tag] SecurityException=${e.message}")
        }
    }

    private fun cancelRawPeerPolls() {
        rawPeerPolls.forEach(discoveryHandler::removeCallbacks)
        rawPeerPolls.clear()
    }

    private fun scheduleRawPeerRefreshes(generation: Long) {
        cancelRawPeerPolls()
        listOf(350L, 1200L, 2500L, 5000L, 8000L).forEachIndexed { index, delay ->
            val task = Runnable {
                if (generation == discoveryGeneration && receiverRegistered && !isConnecting) {
                    requestRawPeers("poll${index + 1}")
                }
            }
            rawPeerPolls += task
            discoveryHandler.postDelayed(task, delay)
        }
    }

    @SuppressLint("MissingPermission")
    fun startDiscovery(forceRestart: Boolean = false) {
        if (!receiverRegistered || receiver == null) {
            ZeeDiagnostic.log(context, "DISCOVERY_SKIP receiver-not-registered")
            return
        }
        if (isConnecting) {
            ZeeDiagnostic.log(context, "DISCOVERY_SKIP connecting")
            return
        }

        // Les appels provenant de plusieurs écrans/callbacks peuvent arriver
        // en rafale (onResume, changement de visibilité, retour de réglages,
        // P2P_STATE). Ne redémarre pas la pile à chaque notification : un
        // cycle DNS-SD reste vivant et les demandes déjà enregistrées sont
        // réutilisées. Un rafraîchissement explicite peut toujours forcer un
        // nouveau scan, mais pas plusieurs fois dans la même fenêtre.
        val now = android.os.SystemClock.elapsedRealtime()
        if (forceRestart && now - lastForceRestartAt < 3500L) {
            ZeeDiagnostic.log(context, "DISCOVERY_SKIP force-restart-debounced")
            return
        }
        if (!forceRestart && (discoveryActive || discoveryStarting)) {
            ZeeDiagnostic.log(context, "DISCOVERY_SKIP already-active")
            return
        }
        if (forceRestart) {
            lastForceRestartAt = now
            cancelRawPeerPolls()
            discoveryGeneration++
            discoveryActive = false
            discoveryStarting = false
            runCatching { manager.stopPeerDiscovery(channel, null) }
        }

        val generation = ++discoveryGeneration
        discoveryStarting = true
        ZeeDiagnostic.log(context, "DISCOVERY start; generation=$generation; wifi=${(context.getSystemService(Context.WIFI_SERVICE) as android.net.wifi.WifiManager).isWifiEnabled}; nearby=${if (android.os.Build.VERSION.SDK_INT >= 33) (ContextCompat.checkSelfPermission(context, "android.permission.NEARBY_WIFI_DEVICES") == android.content.pm.PackageManager.PERMISSION_GRANTED).toString() else "n/a"}")

        // Le pré-scan radio reste utile sur certains firmwares pour réveiller
        // la couche P2P, mais il ne doit plus entraîner la reconstruction de
        // l'annonce et de la requête DNS-SD à chaque passage.
        manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                if (generation != discoveryGeneration) return
                ZeeDiagnostic.log(context, "DISCOVER_PEERS success generation=$generation")
                requestRawPeers("discoverPeers-success")
                scheduleRawPeerRefreshes(generation)
            }
            override fun onFailure(reason: Int) {
                if (generation != discoveryGeneration) return
                ZeeDiagnostic.log(context, "DISCOVER_PEERS failure code=$reason generation=$generation")
                requestRawPeers("discoverPeers-failure-$reason")
            }
        })

        // Ne'efface pas la présence actuellement affichée au début d'un nouveau
        // scan : certains firmwares vident temporairement requestPeers() pendant
        // la relance de discoverPeers(). La présence ZEE est validée par DNS-SD,
        // puis fusionnée avec lastPeers côté MainActivity. Conserver la liste
        // pendant ce court intervalle évite le clignotement et la disparition
        // transitoire des profils déjà détectés.
        ensureDnsSdConfigured(generation)
    }

    /**
     * Configure DNS-SD une seule fois par configuration locale.
     *
     * Avant cette correction, chaque startDiscovery() effaçait puis recréait
     * l'annonce et la requête. Sur certains firmwares, cela supprimait une
     * annonce juste au moment où l'autre téléphone commençait à la découvrir.
     * On conserve maintenant les objets DNS-SD tant que leur contenu n'a pas
     * changé. Une modification de visibilité/profil produit une nouvelle
     * signature et reconstruit proprement l'annonce une seule fois.
     */
    private fun encodeTxtProfileValue(value: String?, maxUtf8Bytes: Int): String {
        val bytes = truncateUtf8(value.orEmpty(), maxUtf8Bytes).toByteArray(Charsets.UTF_8)
        return android.util.Base64.encodeToString(bytes, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING)
    }

    private fun decodeTxtProfileValue(value: String?): String? {
        if (value.isNullOrBlank()) return null
        return runCatching {
            String(android.util.Base64.decode(value, android.util.Base64.URL_SAFE or android.util.Base64.NO_WRAP or android.util.Base64.NO_PADDING), Charsets.UTF_8)
                .trim().takeIf { it.isNotEmpty() }
        }.getOrNull()
    }

    /**
     * Prépare une miniature très compacte de la photo du profil pour la
     * découverte DNS-SD. La photo complète reste envoyée après connexion.
     * L'objectif ici est que la vraie photo soit visible immédiatement dans
     * la liste, sans attendre le handshake TCP.
     */
    private fun encodeDiscoveryPhoto(visibleModules: Set<ZeeModule>): List<String> {
        discoveryThumbPixels = IntArray(0)
        val preferredModules = listOf(ZeeModule.CHAT, ZeeModule.MARKET, ZeeModule.JOB)
            .filter { it in visibleModules }
        val uriString = (preferredModules.asSequence()
            .mapNotNull { ProfileStore.getModulePhotoUri(context, it)?.takeIf(String::isNotBlank) }
            .toList() + listOfNotNull(ProfileStore.getPhotoUri(context)?.takeIf(String::isNotBlank)))
            .distinct()
            .firstOrNull()
        if (uriString == null) {
            ZeeDiagnostic.log(context, "DISCOVERY_PHOTO skipped: no profile photo URI for visible modules=$preferredModules")
            return emptyList()
        }

        val photoStart = android.os.SystemClock.elapsedRealtime()
        return runCatching {
            val source = decodeSampledForThumbnail(Uri.parse(uriString)) ?: run {
                ZeeDiagnostic.log(context, "DISCOVERY_PHOTO failed: URI unreadable or image decode failed uri=$uriString")
                return emptyList()
            }

            // DNS-SD TXT n'est pas un canal d'image. Une miniature JPEG, même
            // minuscule, garde des en-têtes trop volumineux et dépassait encore
            // le budget sur certains téléphones. On utilise donc une miniature
            // RGB565 brute 8x8 : 128 octets, soit 172 caractères Base64,
            // parfaitement déterministes et sans dépendance au codec JPEG.
            val thumb = Bitmap.createScaledBitmap(source, PHOTO_THUMB_SIZE, PHOTO_THUMB_SIZE, true)
            val raw = ByteArray(PHOTO_THUMB_SIZE * PHOTO_THUMB_SIZE * 2)
            var offset = 0
            for (y in 0 until PHOTO_THUMB_SIZE) {
                for (x in 0 until PHOTO_THUMB_SIZE) {
                    val c = thumb.getPixel(x, y)
                    val r = (c shr 16) and 0xff
                    val g = (c shr 8) and 0xff
                    val b = c and 0xff
                    val rgb565 = ((r and 0xf8) shl 8) or ((g and 0xfc) shl 3) or (b shr 3)
                    raw[offset++] = (rgb565 ushr 8).toByte()
                    raw[offset++] = rgb565.toByte()
                }
            }
            discoveryThumbPixels = IntArray(PHOTO_THUMB_SIZE * PHOTO_THUMB_SIZE).also {
                thumb.getPixels(it, 0, PHOTO_THUMB_SIZE, 0, 0, PHOTO_THUMB_SIZE, PHOTO_THUMB_SIZE)
            }
            thumb.recycle()
            source.recycle()

            val payload = PHOTO_RAW_PREFIX + Base64.encodeToString(raw, Base64.NO_WRAP)
            if (payload.length > PHOTO_CHUNK_SIZE) {
                ZeeDiagnostic.log(context, "DISCOVERY_PHOTO failed: raw thumbnail chars=${payload.length} budget=$PHOTO_CHUNK_SIZE uri=$uriString")
                return emptyList()
            }
            ZeeDiagnostic.log(context, "DISCOVERY_PHOTO raw565 chars=${payload.length} chunks=1 ms=${android.os.SystemClock.elapsedRealtime() - photoStart}")
            listOf(payload)
        }.getOrElse { error ->
            ZeeDiagnostic.log(context, "DISCOVERY_PHOTO exception=${error.javaClass.simpleName}:${error.message}")
            emptyList()
        }
    }

    /**
     * Décode la photo en basse résolution (inSampleSize) : le journal montrait
     * 300 à 700 ms entre « DISCOVERY start » et le résultat de la photo, sur le
     * thread principal, car l'image était décodée en pleine taille à chaque
     * démarrage de découverte (risque de saccade et de mémoire insuffisante).
     */
    private fun decodeSampledForThumbnail(uri: Uri): Bitmap? {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        var opened = false
        context.contentResolver.openInputStream(uri)?.use {
            opened = true
            BitmapFactory.decodeStream(it, null, bounds)
        }
        if (!opened) return null
        val minSide = minOf(bounds.outWidth, bounds.outHeight)
        if (minSide <= 0) return null
        var sample = 1
        while (minSide / (sample * 2) >= 24) sample *= 2
        val options = BitmapFactory.Options().apply { inSampleSize = sample }
        return context.contentResolver.openInputStream(uri)?.use {
            BitmapFactory.decodeStream(it, null, options)
        }
    }

    /** Transforme la miniature RGB565 transportée par DNS-SD en PNG Base64,
     * format déjà compris par toute l'UI existante. Les anciennes photos
     * JPEG/PNG diffusées par une version précédente restent acceptées. */
    private fun decodeDiscoveryPhotoPayload(payload: String): String? {
        if (!payload.startsWith(PHOTO_RAW_PREFIX)) return payload.takeIf { it.isNotBlank() }
        return runCatching {
            val raw = Base64.decode(payload.removePrefix(PHOTO_RAW_PREFIX), Base64.NO_WRAP)
            // Taille déduite des octets reçus : accepte 6x6 (v123+) comme 8x8 (v122).
            val side = kotlin.math.sqrt((raw.size / 2).toDouble()).toInt()
            if (side < 1 || side > 16 || side * side * 2 != raw.size) return null
            val bitmap = Bitmap.createBitmap(side, side, Bitmap.Config.RGB_565)
            var offset = 0
            for (y in 0 until side) {
                for (x in 0 until side) {
                    val hi = raw[offset++].toInt() and 0xff
                    val lo = raw[offset++].toInt() and 0xff
                    val v = (hi shl 8) or lo
                    val r = ((v shr 11) and 0x1f) * 255 / 31
                    val g = ((v shr 5) and 0x3f) * 255 / 63
                    val b = (v and 0x1f) * 255 / 31
                    bitmap.setPixel(x, y, android.graphics.Color.rgb(r, g, b))
                }
            }
            bitmapToSmoothPngBase64(bitmap)
        }.getOrNull()
    }

    /** Agrandit une miniature de quelques pixels en 96x96 lissé (bilinéaire), pour un rendu flou plutôt qu'en mosaïque. */
    private fun bitmapToSmoothPngBase64(small: Bitmap): String {
        val scaled = Bitmap.createScaledBitmap(small, PHOTO_PREVIEW_UPSCALE, PHOTO_PREVIEW_UPSCALE, true)
        val out = ByteArrayOutputStream()
        scaled.compress(Bitmap.CompressFormat.PNG, 100, out)
        if (scaled !== small) scaled.recycle()
        small.recycle()
        return Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP)
    }

    /** Miniature 6x6 -> 54 octets (12 bits par pixel, 2 pixels dans 3 octets). */
    private fun encodePhotoPtr(pixels: IntArray): ByteArray? {
        if (pixels.size != PHOTO_PTR_SIDE * PHOTO_PTR_SIDE) return null
        val out = ByteArray(pixels.size / 2 * 3)
        var o = 0
        fun p12(c: Int): Int = (((c shr 16) and 0xff) shr 4 shl 8) or (((c shr 8) and 0xff) shr 4 shl 4) or ((c and 0xff) shr 4)
        var i = 0
        while (i < pixels.size) {
            val a = p12(pixels[i])
            val b = p12(pixels[i + 1])
            out[o++] = (a shr 4).toByte()
            out[o++] = (((a and 0xf) shl 4) or (b shr 8)).toByte()
            out[o++] = (b and 0xff).toByte()
            i += 2
        }
        return out
    }

    private fun decodePhotoPtr(bytes: ByteArray): String? {
        val count = PHOTO_PTR_SIDE * PHOTO_PTR_SIDE
        if (bytes.size != count / 2 * 3) return null
        return runCatching {
            val bitmap = Bitmap.createBitmap(PHOTO_PTR_SIDE, PHOTO_PTR_SIDE, Bitmap.Config.ARGB_8888)
            var i = 0
            var o = 0
            while (i < count) {
                val b0 = bytes[o++].toInt() and 0xff
                val b1 = bytes[o++].toInt() and 0xff
                val b2 = bytes[o++].toInt() and 0xff
                val a = (b0 shl 4) or (b1 shr 4)
                val b = ((b1 and 0xf) shl 8) or b2
                for ((k, v) in listOf(i to a, i + 1 to b)) {
                    bitmap.setPixel(k % PHOTO_PTR_SIDE, k / PHOTO_PTR_SIDE,
                        android.graphics.Color.rgb(((v shr 8) and 0xf) * 17, ((v shr 4) and 0xf) * 17, (v and 0xf) * 17))
                }
                i += 2
            }
            bitmapToSmoothPngBase64(bitmap)
        }.getOrNull()
    }

    @SuppressLint("MissingPermission")
    private fun ensureDnsSdConfigured(generation: Long) {
        if (generation != discoveryGeneration || !receiverRegistered) return

        val visibleModules = VisibilityStore.getVisibleModules(context)
        val localCriteria: Map<ZeeModule, String> = visibleModules.associateWith { module ->
            when (module) {
                ZeeModule.CHAT -> ProfileStore.getLiveChatCriteria(context)
                ZeeModule.MARKET, ZeeModule.JOB ->
                    if (ProfileStore.getModuleMeetChoice(context, module)) "B" else "A"
            }
        }
        val criteriaStr = visibleModules.joinToString(",") { module -> "${module.name}:${localCriteria[module]}" }
        val nodeId = ProfileStore.getNodeId(context)
        // Journaux itel / Infinix / TECNO : la réponse PTR (nom d'instance) arrive toujours
        // (ZEE_SERVICE_FOUND), alors que le TXT n'arrive pas toujours (ZEE_TXT absent). Les
        // données qui commandent les filtres et l'arbitrage de connexion (nodeId, modules,
        // critères) voyagent donc AUSSI dans le nom d'instance. Le TXT garde le profil.
        val instanceName = buildInstanceName(nodeId, visibleModules, localCriteria) ?: SERVICE_INSTANCE
        // Les métadonnées textuelles du profil sont diffusées dans le TXT DNS-SD
        // pour afficher le profil avant connexion. Les valeurs sont encodées et
        // bornées pour respecter les limites pratiques des enregistrements TXT.
        val profileName = encodeTxtProfileValue(ProfileStore.getDisplayName(context), 48)
        val chatActu = encodeTxtProfileValue(ProfileStore.getModuleActu(context, ZeeModule.CHAT), 45)
        val marketActu = encodeTxtProfileValue(ProfileStore.getModuleActu(context, ZeeModule.MARKET), 45)
        val jobActu = encodeTxtProfileValue(ProfileStore.getModuleActu(context, ZeeModule.JOB), 45)
        val discoveryPhotoChunks = encodeDiscoveryPhoto(visibleModules)
        val photoSignature = discoveryPhotoChunks.joinToString(".")
        val photoPtr = if (PTR_PREVIEW_ENABLED) encodePhotoPtr(discoveryThumbPixels) else null
        // Quand la photo voyage par nom d'instance, on la retire du TXT : les seuls TXT jamais reçus
        // dans les journaux étaient ceux d'avant l'ajout de la photo (clé "p0"), et un TXT plus
        // petit a plus de chances d'arriver.
        val txtPhotoChunks = if (photoPtr != null) emptyList() else discoveryPhotoChunks
        val previewNames = if (PTR_PREVIEW_ENABLED) {
            buildPreviewInstanceNames(
                ProfileStore.getDisplayName(context),
                visibleModules.associateWith { ProfileStore.getModuleActu(context, it) },
                photoPtr
            )
        } else emptyList()
        val signature = "$instanceName|${previewNames.joinToString(".")}|${visibleModules.joinToString(",")}|$criteriaStr|$nodeId|$profileName|$chatActu|$marketActu|$jobActu|$photoSignature"

        fun startServiceDiscovery() {
            if (generation != discoveryGeneration || !receiverRegistered) return
            manager.discoverServices(channel, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    if (generation != discoveryGeneration || !receiverRegistered) return
                    discoveryStarting = false
                    discoveryActive = true
                    ZeeDiagnostic.log(context, "DISCOVER_SERVICES success generation=$generation")
                    scheduleServiceRefresh(generation)
                }
                override fun onFailure(reasonCode: Int) {
                    if (generation != discoveryGeneration) return
                    discoveryStarting = false
                    discoveryActive = false
                    ZeeDiagnostic.log(context, "DISCOVER_SERVICES failure code=$reasonCode generation=$generation")
                }
            })
        }

        fun ensureSearchRequest() {
            if (generation != discoveryGeneration || !receiverRegistered) return
            if (serviceRequestRegistered) {
                startServiceDiscovery()
                return
            }
            val request = WifiP2pDnsSdServiceRequest.newInstance()
            manager.addServiceRequest(channel, request, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    if (generation != discoveryGeneration || !receiverRegistered) return
                    serviceRequestRegistered = true
                    ZeeDiagnostic.log(context, "SERVICE_REQUEST registered generation=$generation")
                    startServiceDiscovery()
                }
                override fun onFailure(reasonCode: Int) {
                    if (generation != discoveryGeneration) return
                    discoveryStarting = false
                    discoveryActive = false
                    ZeeDiagnostic.log(context, "SERVICE_REQUEST failure code=$reasonCode generation=$generation")
                }
            })
        }

        fun addPreviewServices(index: Int) {
            if (generation != discoveryGeneration || !receiverRegistered) return
            if (index >= previewNames.size) {
                localServiceSignature = signature
                ZeeDiagnostic.log(context, "LOCAL_SERVICE announced modules=$visibleModules nodeId=$nodeId previews=${previewNames.size}")
                ensureSearchRequest()
                return
            }
            val previewService = WifiP2pDnsSdServiceInfo.newInstance(previewNames[index], SERVICE_TYPE, emptyMap<String, String>())
            manager.addLocalService(channel, previewService, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    ZeeDiagnostic.log(context, "LOCAL_PREVIEW added name=${previewNames[index]}")
                    addPreviewServices(index + 1)
                }
                override fun onFailure(reasonCode: Int) {
                    ZeeDiagnostic.log(context, "LOCAL_PREVIEW failure code=$reasonCode name=${previewNames[index]}")
                    addPreviewServices(index + 1)
                }
            })
        }

        fun addLocalService() {
            if (generation != discoveryGeneration || !receiverRegistered) return
            val txtRecord = mapOf(
                TXT_KEY_MODULES to visibleModules.joinToString(",") { it.name },
                TXT_KEY_CRITERIA to criteriaStr,
                TXT_KEY_NODE_ID to nodeId,
                TXT_KEY_PROFILE_NAME to profileName,
                TXT_KEY_CHAT_ACTU to chatActu,
                TXT_KEY_MARKET_ACTU to marketActu,
                TXT_KEY_JOB_ACTU to jobActu
            ).toMutableMap().apply {
                if (txtPhotoChunks.isNotEmpty()) {
                    put(TXT_KEY_PHOTO_CHUNKS, txtPhotoChunks.size.toString())
                    txtPhotoChunks.forEachIndexed { index, chunk ->
                        put("$TXT_KEY_PHOTO_PREFIX$index", chunk)
                    }
                }
            }
            // Une clé à valeur vide ("a=") est une entrée TXT sans valeur : certains
            // analyseurs DNS-SD (anciens Android) rejettent alors TOUT l'enregistrement,
            // ce qui expliquerait ZEE_SERVICE_FOUND sans jamais de ZEE_TXT. On n'annonce
            // donc que les clés renseignées ; le récepteur gère déjà les clés absentes.
            txtRecord.entries.removeAll { it.value.isEmpty() }
            val estimatedTxtChars = txtRecord.entries.sumOf { (k, v) -> k.length + v.length + 2 }
            ZeeDiagnostic.log(context, "TXT_ESTIMATE chars=$estimatedTxtChars keys=${txtRecord.keys.joinToString(",")}")
            ZeeDiagnostic.log(context, "LOCAL_INSTANCE name=$instanceName")
            val localService = WifiP2pDnsSdServiceInfo.newInstance(
                instanceName, SERVICE_TYPE, txtRecord
            )
            manager.addLocalService(channel, localService, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    if (generation != discoveryGeneration || !receiverRegistered) return
                    addPreviewServices(0)
                }
                override fun onFailure(reasonCode: Int) {
                    if (generation != discoveryGeneration) return
                    localServiceSignature = null
                    ZeeDiagnostic.log(context, "LOCAL_SERVICE failure code=$reasonCode")
                    ensureSearchRequest()
                }
            })
        }

        if (localServiceSignature == signature) {
            ensureSearchRequest()
            return
        }

        // Rebuild uniquement lorsque le contenu de l'annonce a réellement
        // changé (visibilité, critères ou nodeId), jamais à chaque scan.
        manager.clearLocalServices(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                if (generation == discoveryGeneration && receiverRegistered) addLocalService()
            }
            override fun onFailure(reason: Int) {
                if (generation == discoveryGeneration && receiverRegistered) addLocalService()
            }
        })
    }

    private enum class FastRole { GO, JOIN, WAIT }

    /** Vrai si ce téléphone héberge déjà un groupe (ou vient d'en créer un) : les autres le rejoignent. */
    private fun iAmGroupOwnerNow(): Boolean =
        SessionRegistry.active?.isGroupOwner == true || android.os.SystemClock.elapsedRealtime() < fastGroupUntil

    /**
     * Rôle sans aucune négociation :
     *  - je suis déjà Group Owner  -> WAIT : le pair rejoint MON groupe ;
     *  - le pair héberge déjà un groupe -> JOIN : je rejoins le sien, quel que soit l'ordre des nodeId ;
     *  - aucun groupe -> le nodeId le plus grand crée le groupe (GO), l'autre le rejoint (JOIN).
     */
    private fun fastRoleFor(peer: Peer): FastRole {
        if (iAmGroupOwnerNow()) return FastRole.WAIT
        if (peer.deviceAddress in rawGroupOwners) return FastRole.JOIN
        val local = ProfileStore.getNodeId(context).lowercase()
        val remote = peer.nodeId?.lowercase().orEmpty()
        return if (local > remote) FastRole.GO else FastRole.JOIN
    }

    private fun fastConnectEligible(peer: Peer): Boolean {
        if (!FAST_CONNECT_ENABLED || android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) return false
        if (peer.deviceAddress in fastConnectDisabled) return false
        // Client d'un groupe existant : pas de nouvelle connexion (le maillage passe par le GO).
        if (SessionRegistry.active != null && !iAmGroupOwnerNow()) return false
        if (peer.deviceAddress in rawGroupOwners) return true
        val remote = peer.nodeId?.lowercase()?.takeIf { it.isNotBlank() } ?: return false
        val local = ProfileStore.getNodeId(context).lowercase()
        return local.isNotBlank() && local != remote
    }

    @SuppressLint("MissingPermission")
    fun connectTo(peer: Peer, onFailure: (Int) -> Unit = {}) {
        if (fastConnectEligible(peer)) startFastConnect(peer, onFailure) else connectLegacy(peer, onFailure)
    }

    private class FastCreds(val ssid: String, val passphrase: String)

    private fun universalFastCreds() = FastCreds(ssid = FAST_SSID, passphrase = FAST_PASSPHRASE)

    /** goAddress : adresse P2P du Group Owner visé quand on la connaît (sinon, rejoint le groupe ZEE visible). */
    private fun buildFastConfig(creds: FastCreds, goAddress: String?): WifiP2pConfig? {
        fun build(address: String?): WifiP2pConfig? = runCatching {
            val builder = WifiP2pConfig.Builder()
                .setNetworkName(creds.ssid)
                .setPassphrase(creds.passphrase)
                .enablePersistentMode(false)
            if (address != null) builder.setDeviceAddress(android.net.MacAddress.fromString(address))
            builder.build()
        }.getOrNull()
        return build(goAddress) ?: build(null)
    }

    /**
     * Liste brute des pairs : repère les appareils qui hébergent déjà un groupe Wi-Fi Direct et, si
     * c'est un groupe inconnu de nous, tente de le rejoindre avec le réseau ZEE libre (comme un
     * téléphone qui se connecte tout seul à un réseau Wi-Fi connu dès qu'il le voit).
     */
    private fun handleRawPeers(peers: List<WifiP2pDevice>) {
        val owners = peers.filter { it.isGroupOwner }.map { it.deviceAddress }.toSet()
        if (owners != rawGroupOwners) {
            ZeeDiagnostic.log(context, "GO_DEVICES count=${owners.size} :: ${owners.joinToString()}")
            rawGroupOwners.clear()
            rawGroupOwners.addAll(owners)
        }
        onRawPeersAvailable(peers)
        maybeProbeGroupOwners()
        refreshLocalP2pDeviceAddress()
        // Fallback pour les OEM qui publient le pair radio avant DNS-SD.
        scheduleRawPeerConnectFallback(peers)
    }

    /**
     * Certains OEM (notamment TECNO/itel) exposent le pair dans requestPeers()
     * plusieurs secondes avant de livrer la réponse DNS-SD. Dans ce cas, attendre
     * indéfiniment ZEE_SERVICE_FOUND empêche toute connexion automatique.
     *
     * Le fallback utilise uniquement le réseau ZEE prédéterminé (API 29+) :
     * - l'adresse MAC sert uniquement à choisir de façon déterministe GO/JOIN ;
     * - le SSID + mot de passe ZEE restent obligatoires pour que la jonction aboutisse ;
     * - après connexion, le handshake applicatif PROFILE reste l'autorité sur l'identité ZEE.
     * Un appareil P2P quelconque ne possède donc pas de session ZEE simplement parce qu'il
     * est visible dans la couche radio.
     */
    @SuppressLint("MissingPermission")
    private fun refreshLocalP2pDeviceAddress() {
        if (android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) return
        runCatching {
            manager.requestDeviceInfo(channel) { device ->
                localP2pDeviceAddress = device?.deviceAddress?.takeIf { it.isNotBlank() }
            }
        }
    }

    @SuppressLint("MissingPermission")
    private fun scheduleRawPeerConnectFallback(peers: List<WifiP2pDevice>) {
        if (!FAST_CONNECT_ENABLED || android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) return
        if (!receiverRegistered || isConnecting || SessionRegistry.active != null) return
        val now = android.os.SystemClock.elapsedRealtime()
        peers.asSequence()
            .filter { it.status == WifiP2pDevice.AVAILABLE || it.status == WifiP2pDevice.INVITED }
            .filter { it.deviceAddress.isNotBlank() }
            .filter { it.deviceAddress !in discoveredPeers }
            .filter { now - (rawPeerConnectAt[it.deviceAddress] ?: 0L) >= RAW_PEER_CONNECT_COOLDOWN_MS }
            .forEach { device ->
                val address = device.deviceAddress
                rawPeerConnectAt[address] = now
                autoConnectHandler.postDelayed({
                    if (!receiverRegistered || isConnecting || SessionRegistry.active != null) return@postDelayed
                    if (discoveredPeers[address] != null) return@postDelayed
                    val local = localP2pDeviceAddress?.lowercase().orEmpty()
                    val remote = address.lowercase()
                    // Les deux téléphones connaissent la même paire d'adresses P2P :
                    // le plus grand devient GO. Ne jamais comparer nodeId local à MAC distante :
                    // cette ancienne règle n'était pas symétrique et pouvait faire créer deux groupes.
                    if (local.isBlank() || remote.isBlank() || local == remote) return@postDelayed
                    val localWins = local > remote
                    val fakePeer = Peer(
                        deviceAddress = address,
                        deviceName = device.deviceName,
                        nodeId = null,
                        status = PeerStatus.AVAILABLE,
                        displayName = device.deviceName
                    )
                    connectRawFastFallback(fakePeer, localWins)
                }, RAW_PEER_CONNECT_FALLBACK_MS)
            }
    }

    @SuppressLint("MissingPermission")
    private fun connectRawFastFallback(peer: Peer, localWins: Boolean) {
        if (isConnecting || SessionRegistry.active != null) return
        val generation = ++connectionGeneration
        val now = android.os.SystemClock.elapsedRealtime()
        connectStartedAt = now
        isConnecting = true
        ZeeDiagnostic.log(context, "FASTCONNECT raw-fallback role=${if (localWins) "GO" else "JOIN"} peer=${peer.deviceAddress} name=${peer.deviceName}")
        discoveryGeneration++
        discoveryActive = false
        discoveryStarting = false
        cancelServiceRefresh()
        cancelRawPeerPolls()
        val fail: (Int) -> Unit = { code ->
            if (generation == connectionGeneration) {
                isConnecting = false
                ZeeDiagnostic.log(context, "FASTCONNECT raw-fallback failed code=$code peer=${peer.deviceAddress} -> discovery")
                startDiscovery()
            }
        }
        if (localWins) {
            createFastGroup(universalFastCreds(), generation, 1, fail)
        } else {
            joinFastGroup(universalFastCreds(), peer.deviceAddress, generation, 1, now + FAST_JOIN_WAIT_MS, fail)
        }
    }

    @SuppressLint("MissingPermission")
    private fun maybeProbeGroupOwners() {
        if (!FAST_CONNECT_ENABLED || android.os.Build.VERSION.SDK_INT < android.os.Build.VERSION_CODES.Q) return
        if (!receiverRegistered || isConnecting || SessionRegistry.active != null) return
        val now = android.os.SystemClock.elapsedRealtime()
        val target = rawGroupOwners.firstOrNull { addr ->
            discoveredPeers[addr]?.nodeId.isNullOrBlank() && now - (probedGoAt[addr] ?: -PROBE_COOLDOWN_MS) >= PROBE_COOLDOWN_MS
        } ?: return
        probedGoAt[target] = now
        ZeeDiagnostic.log(context, "FASTCONNECT probe groupe inconnu addr=$target ssid=$FAST_SSID")
        connectStartedAt = now
        connectionGeneration++
        val generation = connectionGeneration
        isConnecting = true
        discoveryGeneration++
        discoveryActive = false
        discoveryStarting = false
        cancelServiceRefresh()
        cancelRawPeerPolls()
        joinFastGroup(universalFastCreds(), target, generation, 1, now + FAST_PROBE_WAIT_MS) { code ->
            if (generation == connectionGeneration) {
                ZeeDiagnostic.log(context, "FASTCONNECT probe sans résultat addr=$target code=$code (pas un groupe ZEE)")
                isConnecting = false
                startDiscovery()
            }
        }
    }

    /**
     * Connexion sans négociation, sans invitation et sans saisie : voir fastRoleFor() pour les rôles.
     */
    @SuppressLint("MissingPermission")
    private fun startFastConnect(peer: Peer, onFailure: (Int) -> Unit) {
        val role = fastRoleFor(peer)
        if (role == FastRole.WAIT) {
            ZeeDiagnostic.log(context, "FASTCONNECT wait : je suis déjà Group Owner, ${peer.deviceAddress} me rejoint")
            return
        }
        val creds = universalFastCreds()
        ZeeDiagnostic.log(context, "FASTCONNECT start role=$role ssid=${creds.ssid} peer=${peer.deviceAddress} peerIsGO=${peer.deviceAddress in rawGroupOwners}")
        connectStartedAt = android.os.SystemClock.elapsedRealtime()
        connectionGeneration++
        val generation = connectionGeneration
        isConnecting = true
        discoveryGeneration++
        discoveryActive = false
        discoveryStarting = false
        cancelServiceRefresh()
        cancelRawPeerPolls()
        val fail: (Int) -> Unit = { code ->
            if (generation == connectionGeneration) {
                val failures = (fastConnectFailures[peer.deviceAddress] ?: 0) + 1
                fastConnectFailures[peer.deviceAddress] = failures
                if (failures >= 2) fastConnectDisabled += peer.deviceAddress
                ZeeDiagnostic.log(context, "FASTCONNECT failed code=$code failures=$failures -> connexion classique")
                awaitPeerThenConnect(
                    peer, attempt = 1, generation = generation, onFailure = onFailure,
                    deadlineAt = android.os.SystemClock.elapsedRealtime() + PEER_WAIT_MS, rediscovered = false
                )
            }
        }
        if (role == FastRole.GO) {
            createFastGroup(creds, generation, 1, fail)
        } else {
            joinFastGroup(creds, peer.deviceAddress, generation, 1, android.os.SystemClock.elapsedRealtime() + FAST_JOIN_WAIT_MS, fail)
        }
    }

    @SuppressLint("MissingPermission")
    private fun createFastGroup(creds: FastCreds, generation: Long, attempt: Int, fail: (Int) -> Unit) {
        if (generation != connectionGeneration) return
        val config = buildFastConfig(creds, null)
        if (config == null) {
            ZeeDiagnostic.log(context, "FASTCONNECT config invalide")
            fail(WifiP2pManager.ERROR)
            return
        }
        fun doCreate() {
            if (generation != connectionGeneration) return
            manager.createGroup(channel, config, object : WifiP2pManager.ActionListener {
                override fun onSuccess() {
                    ZeeDiagnostic.log(context, "FASTCONNECT group-created ssid=${creds.ssid} attempt=$attempt")
                    fastGroupUntil = android.os.SystemClock.elapsedRealtime() + FAST_GROUP_WAIT_MS
                    scheduleFastGroupTimeout()
                }
                override fun onFailure(reasonCode: Int) {
                    ZeeDiagnostic.log(context, "FASTCONNECT createGroup failure code=$reasonCode attempt=$attempt")
                    if (attempt < 3 && (reasonCode == WifiP2pManager.BUSY || reasonCode == WifiP2pManager.ERROR)) {
                        autoConnectHandler.postDelayed({ createFastGroup(creds, generation, attempt + 1, fail) }, 900L * attempt)
                    } else {
                        fail(reasonCode)
                    }
                }
            })
        }
        // Un groupe d'une ancienne session ferait échouer createGroup (BUSY) : on le retire d'abord.
        manager.requestGroupInfo(channel) { existing ->
            if (generation != connectionGeneration) return@requestGroupInfo
            if (existing != null) {
                ZeeDiagnostic.log(context, "FASTCONNECT ancien groupe retiré avant création")
                manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() { autoConnectHandler.postDelayed({ doCreate() }, 600L) }
                    override fun onFailure(reason: Int) { autoConnectHandler.postDelayed({ doCreate() }, 600L) }
                })
            } else {
                doCreate()
            }
        }
    }

    /** Si aucun client n'a rejoint le groupe créé après FAST_GROUP_WAIT_MS, on le supprime (la découverte repart). */
    @SuppressLint("MissingPermission")
    private fun scheduleFastGroupTimeout() {
        val token = ++fastGroupToken
        autoConnectHandler.postDelayed({
            if (token != fastGroupToken || !receiverRegistered) return@postDelayed
            manager.requestGroupInfo(channel) { group ->
                if (token != fastGroupToken) return@requestGroupInfo
                if (group != null && group.clientList.isEmpty()) {
                    ZeeDiagnostic.log(context, "FASTCONNECT group-timeout : aucun client -> removeGroup")
                    fastGroupUntil = 0L
                    isConnecting = false
                    manager.removeGroup(channel, null)
                }
            }
        }, FAST_GROUP_WAIT_MS)
    }

    @SuppressLint("MissingPermission")
    private fun joinFastGroup(creds: FastCreds, goAddress: String?, generation: Long, attempt: Int, deadlineAt: Long, fail: (Int) -> Unit) {
        if (generation != connectionGeneration) return
        // Essais impairs : on vise le GO par son adresse ; essais pairs : nom de réseau + mot de passe seuls.
        val config = buildFastConfig(creds, if (attempt % 2 == 1) goAddress else null)
        if (config == null) {
            ZeeDiagnostic.log(context, "FASTCONNECT config invalide")
            fail(WifiP2pManager.ERROR)
            return
        }
        fun retry() {
            if (generation != connectionGeneration || SessionRegistry.active != null) return
            if (android.os.SystemClock.elapsedRealtime() >= deadlineAt) {
                fail(WifiP2pManager.ERROR)
                return
            }
            manager.cancelConnect(channel, null)
            autoConnectHandler.postDelayed({ joinFastGroup(creds, goAddress, generation, attempt + 1, deadlineAt, fail) }, FAST_JOIN_RETRY_MS)
        }
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                ZeeDiagnostic.log(context, "FASTCONNECT join requested attempt=$attempt")
                // La jonction aboutit par WIFI_P2P_CONNECTION_CHANGED (qui incrémente connectionGeneration).
                autoConnectHandler.postDelayed({ retry() }, FAST_JOIN_ATTEMPT_MS)
            }
            override fun onFailure(reasonCode: Int) {
                ZeeDiagnostic.log(context, "FASTCONNECT join failure code=$reasonCode attempt=$attempt (le groupe n'existe peut-être pas encore)")
                retry()
            }
        })
    }

    @SuppressLint("MissingPermission")
    private fun connectLegacy(peer: Peer, onFailure: (Int) -> Unit = {}) {
        ZeeDiagnostic.log(context, "CONNECT requested peer=${peer.deviceName} addr=${peer.deviceAddress} nodeId=${peer.nodeId}")
        connectStartedAt = android.os.SystemClock.elapsedRealtime()
        connectionGeneration++
        val generation = connectionGeneration
        isConnecting = true
        discoveryGeneration++
        discoveryActive = false
        discoveryStarting = false
        cancelServiceRefresh()
        cancelRawPeerPolls()
        // Journal itel W6502 (Android 10) : l'ancien enchaînement clearServiceRequests ->
        // stopPeerDiscovery -> connect() vidait la liste des pairs (P2P_PEERS count=0 juste
        // après STOP_PEER_DISCOVERY) ; connect() visait donc un pair devenu inconnu et échouait
        // 4 fois avec code=0, à chaque cycle. Le framework arrête lui-même la découverte au
        // moment de connect() : on ne l'arrête plus à la main, et on vérifie que le pair est
        // bien connu (sinon on relance discoverPeers et on attend qu'il réapparaisse).
        awaitPeerThenConnect(
            peer, attempt = 1, generation = generation, onFailure = onFailure,
            deadlineAt = android.os.SystemClock.elapsedRealtime() + PEER_WAIT_MS, rediscovered = false
        )
    }

    @SuppressLint("MissingPermission")
    private fun awaitPeerThenConnect(
        peer: Peer, attempt: Int, generation: Long, onFailure: (Int) -> Unit,
        deadlineAt: Long, rediscovered: Boolean
    ) {
        if (generation != connectionGeneration) return
        manager.requestPeers(channel) { list ->
            if (generation != connectionGeneration) return@requestPeers
            val known = list?.deviceList?.any { it.deviceAddress.equals(peer.deviceAddress, ignoreCase = true) } == true
            if (known) {
                ZeeDiagnostic.log(context, "CONNECT peer-known addr=${peer.deviceAddress} attempt=$attempt")
                doConnect(peer, attempt, generation, onFailure)
                return@requestPeers
            }
            if (android.os.SystemClock.elapsedRealtime() >= deadlineAt) {
                ZeeDiagnostic.log(context, "CONNECT peer-wait timeout addr=${peer.deviceAddress} attempt=$attempt")
                isConnecting = false
                onFailure(WifiP2pManager.ERROR)
                return@requestPeers
            }
            if (!rediscovered) {
                ZeeDiagnostic.log(context, "CONNECT peer-absent addr=${peer.deviceAddress} -> discoverPeers")
                manager.discoverPeers(channel, object : WifiP2pManager.ActionListener {
                    override fun onSuccess() {}
                    override fun onFailure(reason: Int) {
                        ZeeDiagnostic.log(context, "CONNECT discoverPeers failure code=$reason")
                    }
                })
            }
            autoConnectHandler.postDelayed({
                awaitPeerThenConnect(peer, attempt, generation, onFailure, deadlineAt, rediscovered = true)
            }, PEER_POLL_MS)
        }
    }

    @SuppressLint("MissingPermission")
    private fun doConnect(peer: Peer, attempt: Int, generation: Long, onFailure: (Int) -> Unit) {
        val config = WifiP2pConfig().apply {
            deviceAddress = peer.deviceAddress
            wps.setup = android.net.wifi.WpsInfo.PBC
        }
        manager.connect(channel, config, object : WifiP2pManager.ActionListener {
            override fun onSuccess() {
                ZeeDiagnostic.log(context, "CONNECT accepted peer=${peer.deviceName} attempt=$attempt")
                Log.d(TAG, "Connexion à ${peer.deviceName} initiée (essai $attempt)")
            }
            override fun onFailure(reasonCode: Int) {
                ZeeDiagnostic.log(context, "CONNECT failure peer=${peer.deviceName} code=$reasonCode attempt=$attempt")
                // reasonCode == WifiP2pManager.ERROR (0) est un échec générique
                // très souvent transitoire (pile encore occupée par la
                // négociation précédente, ou négociation simultanée initiée
                // par les deux pairs en même temps). Le retenter quelques
                // fois avec un backoff croissant, après avoir explicitement
                // annulé toute négociation résiduelle (cancelConnect), résout
                // la grande majorité des échecs « code 0 » sans intervention
                // de l'utilisateur. On ne boucle pas indéfiniment : au-delà
                // de MAX_CONNECT_ATTEMPTS on remonte l'échec normalement.
                if ((reasonCode == WifiP2pManager.ERROR || reasonCode == WifiP2pManager.BUSY) && attempt < MAX_CONNECT_ATTEMPTS) {
                    val delayMs = 500L * attempt
                    Log.w(TAG, "Échec connexion à ${peer.deviceName} (code=$reasonCode, essai $attempt/$MAX_CONNECT_ATTEMPTS) — nouvel essai dans ${delayMs}ms")
                    manager.cancelConnect(channel, object : WifiP2pManager.ActionListener {
                        override fun onSuccess() {}
                        override fun onFailure(reasonCode: Int) {}
                    })
                    autoConnectHandler.postDelayed({
                        if (generation == connectionGeneration) {
                            awaitPeerThenConnect(
                                peer, attempt = attempt + 1, generation = generation, onFailure = onFailure,
                                deadlineAt = android.os.SystemClock.elapsedRealtime() + PEER_WAIT_MS, rediscovered = false
                            )
                        }
                    }, delayMs)
                } else {
                    Log.e(TAG, "Échec de connexion à ${peer.deviceName}, code=$reasonCode (abandon après $attempt essai(s))")
                    isConnecting = false
                    onFailure(reasonCode)
                }
            }
        })
    }

    /** Annule l'état local d'une tentative qui a dépassé son délai. */
    fun cancelPendingConnection() {
        ZeeDiagnostic.log(context, "CONNECT cancelled by timeout/UI")
        connectionGeneration++
        fastGroupToken++
        isConnecting = false
        runCatching { manager.cancelConnect(channel, null) }
    }

    fun disconnect() {
        fastGroupToken++
        fastGroupUntil = 0L
        connectionGeneration++
        isConnecting = false
        runCatching { manager.cancelConnect(channel, null) }
        manager.removeGroup(channel, object : WifiP2pManager.ActionListener {
            override fun onSuccess() = releaseP2pNetworkBinding()
            override fun onFailure(reason: Int) = releaseP2pNetworkBinding()
        })
    }
}
