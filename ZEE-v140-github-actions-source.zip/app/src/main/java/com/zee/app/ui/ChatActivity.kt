package com.zee.app.ui
import java.io.File

import android.Manifest
import android.app.Dialog
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.provider.ContactsContract
import android.location.LocationManager
import android.os.Handler
import android.os.Looper
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.zee.app.R
import com.zee.app.adapter.MessageAdapter
import com.zee.app.model.ChatMessage
import com.zee.app.model.ChatConversationStore
import com.zee.app.model.MessageType
import com.zee.app.network.SessionRegistry
import com.zee.app.network.ZeeMessageCodec
import com.zee.app.network.ZeeSocketSession
import kotlinx.coroutines.MainScope

/**
 * Écran de discussion avec un pair ZEE. La session réseau (ZeeSocketSession)
 * doit être injectée/récupérée depuis MainActivity une fois la connexion
 * Wi-Fi Direct établie avec ce pair précis — ici on illustre uniquement le
 * flux UI local (ajout de messages, ouverture du sélecteur de pièces jointes).
 */
class ChatActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_PEER_ADDRESS = "extra_peer_address"
        const val EXTRA_PEER_NAME = "extra_peer_name"
        const val EXTRA_PEER_TAG = "extra_peer_tag"
        const val EXTRA_PEER_PHOTO_BASE64 = "extra_peer_photo_base64"
        const val EXTRA_PEER_NODE_ID = "extra_peer_node_id"
        const val EXTRA_CHAT_RESTRICTED = "extra_chat_restricted"
        const val EXTRA_CHAT_CHANNEL = "extra_chat_channel"
    }

    private lateinit var adapter: MessageAdapter
    private var peerAddress: String? = null
    private var peerNodeId: String? = null
    private var peerDisplayName: String = "Profil ZEE"
    private var chatRestricted = false
    private var channel: String = com.zee.app.model.MessageChannels.CHAT
    private val scope = MainScope()

    // Galerie : on utilise le Photo Picker Android au lieu de demander
    // READ_MEDIA_IMAGES. Le Photo Picker ne nécessite pas d'autorisation
    // de lecture permanente et fonctionne avec Android 13+ ainsi qu'avec
    // les versions plus anciennes via le fallback de la librairie Activity.
    // C'était la cause principale du défaut : l'ancien code demandait une
    // permission média avant d'ouvrir GetContent, ce qui pouvait bloquer
    // l'accès à la galerie sur certains appareils/versions Android.
    private val pickGalleryMedia = registerForActivityResult(
        ActivityResultContracts.GetContent()
    ) { uri ->
        if (uri != null) {
            val prepared = copyUriToAppStorage(uri)
            if (prepared != null) sendFileMessage(prepared)
        }
    }

    // Documents et audio utilisent le sélecteur système sans permission
    // READ_* : ACTION_OPEN_DOCUMENT donne à ZEE un accès explicite à l'Uri
    // choisie par l'utilisateur.
    private val pickDocument = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            val prepared = copyUriToAppStorage(uri)
            if (prepared != null) sendFileMessage(prepared)
        }
    }

    private fun openGalleryPicker() {
        // Ouvre directement le sélecteur système pour les photos et vidéos.
        // Aucun dialogue intermédiaire ni permission READ_MEDIA_* n'est requis.
        pickGalleryMedia.launch("image/* video/*")
    }

    /**
     * Copie immédiatement l'Uri fournie par la galerie dans le stockage
     * privé de ZEE. Ainsi, si le message doit attendre dans le Mesh Store
     * parce que le destinataire est hors ligne, l'accès au fichier reste
     * valide après fermeture du sélecteur ou même après redémarrage de ZEE.
     */
    private fun copyUriToAppStorage(uri: Uri): Uri? {
        return try {
            val originalName = queryFileDisplayName(uri)
            val safeName = originalName.replace(Regex("[^A-Za-z0-9._-]"), "_")
            val file = java.io.File(filesDir, "chat_attachments").apply { mkdirs() }
            val destination = java.io.File(file, "${System.currentTimeMillis()}_$safeName")
            contentResolver.openInputStream(uri)?.use { input ->
                java.io.FileOutputStream(destination).use { output ->
                    input.copyTo(output, 64 * 1024)
                }
            } ?: return null
            androidx.core.content.FileProvider.getUriForFile(
                this, "$packageName.fileprovider", destination
            )
        } catch (e: Exception) {
            android.widget.Toast.makeText(
                this, "Impossible de lire la pièce jointe sélectionnée.",
                android.widget.Toast.LENGTH_SHORT
            ).show()
            null
        }
    }

    // Sélecteur dédié à la prise de photo directe (bouton caméra à côté de
    // la barre de saisie), qui ouvre l'appli caméra du téléphone.
    private var pendingCameraUri: Uri? = null
    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success && pendingCameraUri != null) sendFileMessage(pendingCameraUri!!)
    }

    // --- Enregistrement vocal ---
    private var currentPeerPhotoBase64: String? = null
    private var mediaRecorder: MediaRecorder? = null
    private var recordingFile: java.io.File? = null
    private var isRecording = false
    private var recordSeconds = 0
    private val recordHandler = Handler(Looper.getMainLooper())
    private val recordTicker = object : Runnable {
        override fun run() {
            recordSeconds++
            updateRecordingTimer()
            recordHandler.postDelayed(this, 1000)
        }
    }

    private val requestLocationPermission = registerForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result[Manifest.permission.ACCESS_FINE_LOCATION] == true ||
            result[Manifest.permission.ACCESS_COARSE_LOCATION] == true) {
            sendCurrentLocationAttachment()
        } else {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_autorisation_de_localisation_refus_e), android.widget.Toast.LENGTH_LONG).show()
        }
    }

    private val pickContact = registerForActivityResult(
        ActivityResultContracts.PickContact()
    ) { uri ->
        if (uri != null) sendSelectedContact(uri)
    }

    private val requestContactsPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) pickContact.launch(null)
        else android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_autorisation_des_contacts_refus_e), android.widget.Toast.LENGTH_LONG).show()
    }

    private val requestMicPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) startRecording() else {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_autorisation_micro_refus_e_impossible_d_enreg), android.widget.Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_chat)

        chatRestricted = intent.getBooleanExtra(EXTRA_CHAT_RESTRICTED, false)
        channel = com.zee.app.model.MessageChannels.normalize(
            intent.getStringExtra(EXTRA_CHAT_CHANNEL)
        )
        window.addFlags(android.view.WindowManager.LayoutParams.FLAG_SECURE)
        val peerName = intent.getStringExtra(EXTRA_PEER_NAME)?.takeIf { it.isNotBlank() } ?: "Connexion…"
        peerDisplayName = peerName
        peerAddress = intent.getStringExtra(EXTRA_PEER_ADDRESS)
        peerNodeId = intent.getStringExtra(EXTRA_PEER_NODE_ID)
        val peerTag = intent.getStringExtra(EXTRA_PEER_TAG) ?: ""
        val peerPhotoBase64 = intent.getStringExtra(EXTRA_PEER_PHOTO_BASE64)
        currentPeerPhotoBase64 = peerPhotoBase64
        findViewById<android.widget.TextView>(R.id.txtPeerName).text = peerName
        findViewById<android.widget.TextView>(R.id.txtPeerTag).text = peerTag
        setPeerPhoto(peerPhotoBase64)

        // La photo de l'en-tête s'agrandit en plein écran au tap.
        findViewById<de.hdodenhof.circleimageview.CircleImageView>(R.id.imgPeerPhoto).setOnClickListener {
            val currentPhoto = currentPeerPhotoBase64
            if (currentPhoto.isNullOrEmpty()) {
                android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_aucune_photo_disponible_pour_ce_profil), android.widget.Toast.LENGTH_SHORT).show()
            } else {
                openPeerPhoto(currentPhoto) 
            }
        }

        val recycler = findViewById<RecyclerView>(R.id.recyclerMessages)
        recycler.layoutManager = LinearLayoutManager(this)
        adapter = MessageAdapter(mutableListOf())
        recycler.adapter = adapter

        val conversationId = peerNodeId?.takeIf { it.isNotBlank() } ?: peerAddress.orEmpty()
        com.zee.app.model.MessageStore.list(this, channel, conversationId).forEach { stored ->
            adapter.addMessage(ChatMessage(
                id = stored.id.hashCode().toLong(),
                fromMe = stored.fromMe,
                type = stored.type,
                text = stored.text ?: stored.fileName,
                filePath = stored.localFilePath?.let { android.net.Uri.fromFile(java.io.File(it)).toString() },
                timestamp = stored.timestamp,
                channel = stored.channel,
                conversationId = stored.conversationId
            ))
        }

        findViewById<android.widget.ImageButton>(R.id.btnBack).setOnClickListener { finish() }
        findViewById<android.widget.ImageButton>(R.id.btnAttach).setOnClickListener {
            if (!chatRestricted) openGalleryPicker()
        }
        findViewById<android.widget.ImageButton>(R.id.btnEmoji).setOnClickListener { showEmojiPicker() }
        findViewById<android.widget.ImageButton>(R.id.btnCamera).setOnClickListener { if (!chatRestricted) launchCamera() }
        findViewById<android.widget.ImageButton>(R.id.btnMic).setOnClickListener { if (!chatRestricted) onMicPressed() }

        val editMessage = findViewById<android.widget.EditText>(R.id.editMessage)
        findViewById<android.widget.ImageButton>(R.id.btnSend).setOnClickListener {
            val text = editMessage.text.toString().trim()
            if (text.isNotEmpty()) {
                if (chatRestricted) {
                    android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_change_restreint_pour_ce_profil), android.widget.Toast.LENGTH_SHORT).show()
                } else {
                    sendTextMessage(text)
                    editMessage.text.clear()
                }
            }
        }

        connectSessionForPeer(intent.getStringExtra(EXTRA_PEER_ADDRESS), intent.getStringExtra(EXTRA_PEER_NODE_ID))
        applyZeeEdgeToEdge(topInsetView = findViewById(R.id.chatHeader), bottomInsetView = findViewById(R.id.chatInputBar))
    }

    /** Affiche immédiatement la photo reçue dans le profil du pair. */
    private fun setPeerPhoto(base64: String?) {
        if (base64.isNullOrBlank()) return
        currentPeerPhotoBase64 = base64
        try {
            val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            val bitmap = android.graphics.BitmapFactory.decodeByteArray(bytes, 0, bytes.size) ?: return
            findViewById<de.hdodenhof.circleimageview.CircleImageView>(R.id.imgPeerPhoto).setImageBitmap(bitmap)
        } catch (_: Exception) {
            // Une photo invalide ne doit jamais empêcher le chat de fonctionner.
        }
    }

    /** Décode la photo du pair (base64) et l'ouvre dans le visualiseur plein écran. */
    private fun openPeerPhoto(base64: String) {
        try {
            val bytes = android.util.Base64.decode(base64, android.util.Base64.DEFAULT)
            val file = java.io.File(com.zee.app.model.MessageStore.mediaDir(this, channel), "profile_${System.currentTimeMillis()}.jpg")
            java.io.FileOutputStream(file).use { it.write(bytes) }
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
            PhotoViewerActivity.start(this, uri.toString())
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_impossible_d_afficher_cette_photo), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun connectSessionForPeer(peerAddress: String?, nodeId: String?) {
        this.peerAddress = peerAddress ?: return
        // Tant que ChatActivity est au premier plan pour CE pair, les
        // messages entrants sont transmis directement ici (au lieu de
        // passer par la pastille non lue + notification, voir
        // MainActivity.handleIncomingMessage) ; et le nom/l'ACTU réels du
        // pair remplacent le nom brut de l'appareil dès qu'ils arrivent.
        SessionRegistry.registerActiveChat(
            this.peerAddress!!,
            nodeId,
            channel = channel,
            onChat = { text ->
                runOnUiThread {
                    val parsed = parseStructuredChat(text)
                    val shown = parsed?.second ?: text
                    val type = parsed?.first ?: MessageType.TEXT
                    adapter.addMessage(ChatMessage(fromMe = false, type = type, text = shown))
                    val key = peerNodeId?.takeIf { it.isNotBlank() } ?: peerAddress.orEmpty()
                    ChatConversationStore.recordIncoming(this@ChatActivity, "$channel:$key", peerDisplayName, shown, currentPeerPhotoBase64)
                    findViewById<RecyclerView>(R.id.recyclerMessages).scrollToPosition(adapter.itemCount - 1)
                }
            },
            onProfile = { name, actu, photoBase64 ->
                // Le PROFILE est la source d'identité applicative.
                // MainActivity a déjà associé le nodeId réel à cette session ;
                // il ne faut surtout pas rappeler bindActiveChatNode() depuis
                // ce callback, sinon on ré-entre récursivement dans onProfile.
                runOnUiThread {
                    if (name.isNotBlank()) findViewById<android.widget.TextView>(R.id.txtPeerName).text = name
                    if (actu.isNotBlank()) findViewById<android.widget.TextView>(R.id.txtPeerTag).text = actu
                    if (!photoBase64.isNullOrBlank()) setPeerPhoto(photoBase64)
                }
            },
            onAttachment = { file, mime, fileName, fromNodeId ->
                runOnUiThread {
                    val type = when {
                        mime.startsWith("image/") -> MessageType.IMAGE
                        mime.startsWith("audio/") -> MessageType.AUDIO
                        mime.startsWith("video/") -> MessageType.VIDEO
                        else -> MessageType.DOCUMENT
                    }
                    val key = peerNodeId?.takeIf { it.isNotBlank() } ?: peerAddress.orEmpty()
                    val path = file.absolutePath
                    adapter.addMessage(ChatMessage(fromMe = false, type = type, filePath = android.net.Uri.fromFile(java.io.File(path)).toString(), text = fileName, channel = channel, conversationId = key))
                    ChatConversationStore.recordIncoming(this@ChatActivity, "$channel:$key", peerDisplayName, fileName, currentPeerPhotoBase64)
                    findViewById<RecyclerView>(R.id.recyclerMessages).scrollToPosition(adapter.itemCount - 1)
                }
            }
        )
    }

    private fun sendTextMessage(text: String) {
        if (chatRestricted) return
        val message = ChatMessage(fromMe = true, type = MessageType.TEXT, text = text)
        adapter.addMessage(message)
        val key = peerNodeId?.takeIf { it.isNotBlank() } ?: peerAddress.orEmpty()
        com.zee.app.model.MessageStore.save(this, message.id.toString(), key, channel, com.zee.app.network.SessionRegistry.localNodeId,
            true, MessageType.TEXT, text, null, null, "text/plain")
        ChatConversationStore.recordOutgoing(this, "$channel:$key", peerDisplayName, text, currentPeerPhotoBase64)
        findViewById<RecyclerView>(R.id.recyclerMessages).scrollToPosition(adapter.itemCount - 1)

        SessionRegistry.sendChat(text, channel)
    }

    /** Ajoute un message image/fichier à la conversation à partir d'une Uri choisie. */
    private fun sendFileMessage(uri: Uri) {
        if (chatRestricted) return
        val mime = contentResolver.getType(uri) ?: ""
        val type = when {
            mime.startsWith("image/") -> MessageType.IMAGE
            mime.startsWith("audio/") -> MessageType.AUDIO
            mime.startsWith("video/") -> MessageType.VIDEO
            else -> MessageType.DOCUMENT
        }
        // Autorisation persistante de lecture, nécessaire si l'Uri doit être
        // relue plus tard (ex. après redémarrage de l'app).
        // Les pièces jointes sélectionnées sont normalement déjà copiées
        // dans le stockage privé de ZEE par copyUriToAppStorage(). Pour les
        // autres Uris (ex. photo prise avec la caméra), on conserve le
        // comportement FileProvider actuel.
        try {
            contentResolver.takePersistableUriPermission(
                uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
        } catch (_: SecurityException) {
            // Certains fournisseurs ne permettent pas la persistance.
        }

        val persistentSource = com.zee.app.model.MessageStore.copyUriToPersistent(this, uri, channel, queryFileDisplayName(uri))
        val persistentUri = persistentSource?.let { android.net.Uri.fromFile(it) } ?: uri
        val message = ChatMessage(fromMe = true, type = type, filePath = persistentUri.toString(), channel = channel,
            conversationId = peerNodeId?.takeIf { it.isNotBlank() } ?: peerAddress.orEmpty())
        adapter.addMessage(message)
        val key = peerNodeId?.takeIf { it.isNotBlank() } ?: peerAddress.orEmpty()
        val preview = when (type) {
            MessageType.IMAGE -> "Photo"
            MessageType.VIDEO -> "Vidéo"
            MessageType.AUDIO -> "Message vocal"
            else -> queryFileDisplayName(uri)
        }
        com.zee.app.model.MessageStore.save(this, message.id.toString(), key, channel,
            com.zee.app.network.SessionRegistry.localNodeId, true, type, preview,
            persistentSource?.absolutePath, queryFileDisplayName(uri), mime)
        ChatConversationStore.recordOutgoing(this, "$channel:$key", peerDisplayName, preview, currentPeerPhotoBase64)
        findViewById<RecyclerView>(R.id.recyclerMessages).scrollToPosition(adapter.itemCount - 1)

        transferFileToPeer(persistentUri, queryFileDisplayName(uri))
    }

    /**
     * Envoie réellement les octets du fichier au pair connecté, via le
     * canal binaire dédié et optimisé (voir FileTransferManager — blocs de
     * 64 Ko, séparé du canal texte, même principe que Xender).
     */
    private fun transferFileToPeer(uri: Uri, fileName: String) {
        val targetNode = SessionRegistry.activeChatNodeId ?: return
        val targetAddress = SessionRegistry.nextHopAddress(targetNode)
        if (targetAddress == null) {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_aucune_route_vers_le_destinataire), android.widget.Toast.LENGTH_SHORT).show()
            return
        }
        val mime = contentResolver.getType(uri) ?: "application/octet-stream"
        val size = contentResolver.openFileDescriptor(uri, "r")?.use { it.statSize } ?: 0L
        val messageId = java.util.UUID.randomUUID().toString()
        val fromNode = SessionRegistry.localNodeId

        // Les métadonnées suivent exactement le même routage que le fichier.
        val attachmentLine = com.zee.app.network.ZeeMessageCodec.encodeAttachment(
            messageId, fromNode, targetNode, fileName, mime, size, ttl = 8, channel = channel
        )
        if (!SessionRegistry.routeTo(targetNode, attachmentLine)) {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_m_tadonn_es_non_transmises_au_destinataire), android.widget.Toast.LENGTH_SHORT).show()
        }

        com.zee.app.network.FileTransferManager.sendFile(
            context = this,
            scope = scope,
            hostAddress = targetAddress,
            fileUri = uri,
            fileName = fileName,
            messageId = messageId,
            fromNodeId = fromNode,
            toNodeId = targetNode,
            mimeType = mime,
            ttl = 8,
            kind = channel,
            listener = object : com.zee.app.network.FileTransferManager.ProgressListener {
                override fun onProgress(sentBytes: Long, totalBytes: Long) {}
                override fun onComplete(file: java.io.File, meta: com.zee.app.network.FileTransferManager.TransferMeta) {
                    runOnUiThread {
                        android.widget.Toast.makeText(this@ChatActivity, getString(com.zee.app.R.string.kt_fichier_envoy), android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
                override fun onError(error: Exception) {
                    runOnUiThread {
                        android.widget.Toast.makeText(this@ChatActivity, getString(com.zee.app.R.string.kt_chec_de_l_envoi_du_fichier), android.widget.Toast.LENGTH_SHORT).show()
                    }
                }
            },
            preferredWebRtcSender = { meta, localFile ->
                // Le DataChannel n'est utilisé que pour le prochain saut direct
                // réellement READY. S'il tombe avant ou pendant l'envoi,
                // FileTransferManager reprend automatiquement le flux TCP.
                SessionRegistry.sendFilePreferred(
                    nodeId = targetNode, file = localFile, messageId = meta.messageId,
                    fromNodeId = meta.fromNodeId, toNodeId = meta.toNodeId, ttl = meta.ttl,
                    fileName = meta.fileName, mimeType = meta.mimeType, fileSize = meta.fileSize,
                    kind = meta.kind
                )
            },
            preferredFastWifiSender = { meta, localFile ->
                // Deuxième voie : transfert Wi-Fi local direct inspiré de la
                // logistique AnExplorer. Elle n'est activée que pour un voisin
                // ZEE physique, jamais pour un nodeId relayé.
                SessionRegistry.sendFileFastWifi(
                    nodeId = targetNode, file = localFile, messageId = meta.messageId,
                    fromNodeId = meta.fromNodeId, toNodeId = meta.toNodeId, ttl = meta.ttl,
                    fileName = meta.fileName, mimeType = meta.mimeType, fileSize = meta.fileSize,
                    kind = meta.kind
                ) { host, fastMeta, file ->
                    com.zee.app.network.ZeeFastWifiTransfer.send(
                        hostAddress = host, meta = fastMeta, file = file
                    )
                }
            }
        )
    }

    private fun queryFileDisplayName(uri: Uri): String {
        var name = "fichier_${System.currentTimeMillis()}"
        contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(android.provider.OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) name = cursor.getString(idx)
        }
        return name
    }

    // L'app déclare android.permission.CAMERA dans le manifeste, donc
    // Android exige qu'elle soit accordée à l'exécution AVANT de lancer
    // l'appareil photo — sans cette demande, l'app plante à l'ouverture
    // de la caméra sur de nombreux téléphones.
    private val requestCameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            launchCameraInternal()
        } else {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_autorisation_cam_ra_refus_e), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    /** Ouvre l'appli caméra du téléphone pour prendre une photo à envoyer directement. */
    private fun launchCamera() {
        val alreadyGranted = androidx.core.content.ContextCompat.checkSelfPermission(
            this, android.Manifest.permission.CAMERA
        ) == android.content.pm.PackageManager.PERMISSION_GRANTED
        if (alreadyGranted) {
            launchCameraInternal()
        } else {
            requestCameraPermission.launch(android.Manifest.permission.CAMERA)
        }
    }

    private fun launchCameraInternal() {
        val photoFile = java.io.File(cacheDir, "zee_capture_${System.currentTimeMillis()}.jpg")
        val uri = androidx.core.content.FileProvider.getUriForFile(
            this, "$packageName.fileprovider", photoFile
        )
        pendingCameraUri = uri
        takePicture.launch(uri)
    }

    // --- Messages vocaux ---

    private fun onMicPressed() {
        if (isRecording) {
            stopRecordingAndSend()
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                startRecording()
            } else {
                requestMicPermission.launch(Manifest.permission.RECORD_AUDIO)
            }
        }
    }

    private fun startRecording() {
        val file = java.io.File(cacheDir, "zee_voice_${System.currentTimeMillis()}.m4a")
        recordingFile = file

        val recorder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            MediaRecorder(this)
        } else {
            @Suppress("DEPRECATION")
            MediaRecorder()
        }

        try {
            recorder.setAudioSource(MediaRecorder.AudioSource.MIC)
            recorder.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            recorder.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            recorder.setOutputFile(file.absolutePath)
            recorder.prepare()
            recorder.start()
            mediaRecorder = recorder
            isRecording = true
            recordSeconds = 0
            updateRecordingTimer()
            recordHandler.postDelayed(recordTicker, 1000)
            setRecordingUiVisible(true)
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_impossible_de_d_marrer_l_enregistrement), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun stopRecordingAndSend() {
        recordHandler.removeCallbacks(recordTicker)
        setRecordingUiVisible(false)
        isRecording = false

        try {
            mediaRecorder?.stop()
        } catch (e: Exception) { /* enregistrement trop court ou déjà arrêté, on ignore */ }
        mediaRecorder?.release()
        mediaRecorder = null

        val file = recordingFile ?: return
        if (file.exists() && file.length() > 0) {
            val persistent = com.zee.app.model.MessageStore.copyFileToPersistent(this, file, channel, file.name)
            val sendFile = persistent ?: file
            val uri = androidx.core.content.FileProvider.getUriForFile(this, "$packageName.fileprovider", sendFile)
            val message = ChatMessage(fromMe = true, type = MessageType.AUDIO, filePath = uri.toString(), channel = channel)
            adapter.addMessage(message)
            val key = peerNodeId?.takeIf { it.isNotBlank() } ?: peerAddress.orEmpty()
            com.zee.app.model.MessageStore.save(this, message.id.toString(), key, channel,
                com.zee.app.network.SessionRegistry.localNodeId, true, MessageType.AUDIO,
                "Message vocal", sendFile.absolutePath, file.name, "audio/mp4")
            ChatConversationStore.recordOutgoing(this, "$channel:$key", peerDisplayName, "Message vocal", currentPeerPhotoBase64)
            findViewById<RecyclerView>(R.id.recyclerMessages).scrollToPosition(adapter.itemCount - 1)

            transferFileToPeer(uri, file.name)
        }
    }

    private fun setRecordingUiVisible(recording: Boolean) {
        val timer = findViewById<android.widget.TextView>(R.id.txtRecordingTimer)
        val micBtn = findViewById<android.widget.ImageButton>(R.id.btnMic)
        timer.visibility = if (recording) android.view.View.VISIBLE else android.view.View.GONE
        micBtn.setImageResource(
            if (recording) android.R.drawable.ic_media_pause else android.R.drawable.ic_btn_speak_now
        )
    }

    private fun updateRecordingTimer() {
        val m = recordSeconds / 60
        val s = recordSeconds % 60
        findViewById<android.widget.TextView>(R.id.txtRecordingTimer).text =
            String.format("%02d:%02d", m, s)
    }

    // --- Émojis ---
    private val emojis = listOf(
        "😀","😂","😍","😉","😎","🥳","😢","😡","👍","🙏","❤️","🔥",
        "🎉","🙌","😴","🤔","😅","👏","🤝","💯","😘","🥺","😊","🚀"
    )

    private fun showEmojiPicker() {
        AlertDialog.Builder(this)
            .setTitle(getString(com.zee.app.R.string.kt_moji))
            .setItems(emojis.toTypedArray()) { _, which ->
                // L'emoji part comme son propre message, séparé du texte —
                // il ne se mélange jamais avec ce que l'utilisateur tape.
                sendTextMessage(emojis[which])
            }
            .show()
    }

    private fun showAttachmentPicker() {
        val dialog = Dialog(this)
        dialog.setContentView(R.layout.dialog_attachments)
        dialog.window?.setBackgroundDrawableResource(android.R.color.transparent)

        dialog.findViewById<android.view.View>(R.id.optDocument).setOnClickListener {
            dialog.dismiss(); pickDocument.launch(arrayOf("*/*"))
        }
        dialog.findViewById<android.view.View>(R.id.optCamera).setOnClickListener {
            dialog.dismiss(); launchCamera()
        }
        dialog.findViewById<android.view.View>(R.id.optGallery).setOnClickListener {
            dialog.dismiss(); openGalleryPicker()
        }
        dialog.findViewById<android.view.View>(R.id.optAudio).setOnClickListener {
            dialog.dismiss(); pickDocument.launch(arrayOf("audio/*"))
        }
        dialog.findViewById<android.view.View>(R.id.optLocation).setOnClickListener {
            dialog.dismiss()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED) {
                sendCurrentLocationAttachment()
            } else {
                requestLocationPermission.launch(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION))
            }
        }
        dialog.findViewById<android.view.View>(R.id.optContact).setOnClickListener {
            dialog.dismiss()
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                pickContact.launch(null)
            } else {
                requestContactsPermission.launch(Manifest.permission.READ_CONTACTS)
            }
        }

        dialog.show()
    }

    private fun sendCurrentLocationAttachment() {
        try {
            val lm = getSystemService(LOCATION_SERVICE) as LocationManager
            val location = sequenceOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)
                .mapNotNull { provider -> runCatching { lm.getLastKnownLocation(provider) }.getOrNull() }
                .maxByOrNull { it.time }
            if (location == null) {
                android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_position_actuelle_indisponible_activez_la_loc), android.widget.Toast.LENGTH_LONG).show()
                return
            }
            val url = "https://maps.google.com/?q=${location.latitude},${location.longitude}"
            val payload = "__ZEE_LOCATION__|${location.latitude}|${location.longitude}|$url"
            sendStructuredChatMessage(MessageType.LOCATION, "📍 Ma position\n$url", payload)
        } catch (e: Exception) {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_impossible_de_r_cup_rer_la_position), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendSelectedContact(uri: Uri) {
        try {
            var name = "Contact"
            var phone = ""
            contentResolver.query(uri, arrayOf(ContactsContract.Contacts.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) name = c.getString(0) ?: name
            }
            contentResolver.query(
                ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
                arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
                "${ContactsContract.CommonDataKinds.Phone.CONTACT_ID}=?",
                arrayOf(uri.lastPathSegment ?: ""),
                null
            )?.use { c -> if (c.moveToFirst()) phone = c.getString(0) ?: "" }
            val shown = "👤 $name" + if (phone.isNotBlank()) "\n$phone" else ""
            val payload = "__ZEE_CONTACT__|${name.replace("|", "/").replace("\n", " ")}|${phone.replace("|", "/")}"
            sendStructuredChatMessage(MessageType.CONTACT, shown, payload)
        } catch (_: Exception) {
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_impossible_de_lire_ce_contact), android.widget.Toast.LENGTH_SHORT).show()
        }
    }

    private fun sendStructuredChatMessage(type: MessageType, shownText: String, wireText: String) {
        if (chatRestricted) return
        adapter.addMessage(ChatMessage(fromMe = true, type = type, text = shownText))
        val key = peerNodeId?.takeIf { it.isNotBlank() } ?: peerAddress.orEmpty()
        ChatConversationStore.recordOutgoing(this, key, peerDisplayName, shownText, currentPeerPhotoBase64)
        findViewById<RecyclerView>(R.id.recyclerMessages).scrollToPosition(adapter.itemCount - 1)
        SessionRegistry.sendChat(wireText)
    }

    private fun parseStructuredChat(text: String): Pair<MessageType, String>? {
        return when {
            text.startsWith("__ZEE_LOCATION__|") -> {
                val p = text.split("|")
                if (p.size >= 4) MessageType.LOCATION to "📍 Position\n${p[3]}" else null
            }
            text.startsWith("__ZEE_CONTACT__|") -> {
                val p = text.split("|")
                if (p.size >= 2) MessageType.CONTACT to ("👤 " + p[1] + if (p.size >= 3 && p[2].isNotBlank()) "\n${p[2]}" else "") else null
            }
            else -> null
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        peerAddress?.let { SessionRegistry.unregisterActiveChat(it) }
        mediaRecorder?.release()
        adapter.releasePlayer()
    }
}
