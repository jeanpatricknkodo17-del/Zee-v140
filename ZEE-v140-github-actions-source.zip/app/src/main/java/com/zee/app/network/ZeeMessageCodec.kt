package com.zee.app.network

import com.zee.app.model.AdPayload
import com.zee.app.model.ZeeModule
import com.zee.app.model.MessageChannels
import org.json.JSONObject

/**
 * Protocole applicatif échangé sur le canal texte (ZeeSocketSession), une
 * fois la connexion Wi-Fi Direct établie entre deux appareils ZEE.
 *
 * Chaque message est une seule ligne JSON (voir ZeeSocketSession, qui gère
 * le \n de fin de ligne). Trois types de message :
 *   - PROFILE : envoyé automatiquement dès la connexion (les deux côtés),
 *     pour que chaque appareil affiche le nom/l'actu réels de l'autre au
 *     lieu de son identifiant Wi-Fi Direct brut.
 *   - AD      : une publicité relayée (voir AdRelayStore / AdRelay —
 *     propagation virale). Envoyée à la connexion pour toutes les pubs
 *     actives, puis à chaque nouvelle activation.
 *   - CHAT    : un message texte (ou un emoji, envoyé comme son propre
 *     message) tapé dans la conversation.
 *
 * Volontairement minimal : les pièces jointes volumineuses (photo, audio,
 * vidéo, document) ne transitent jamais par ce canal — elles utilisent le
 * canal binaire dédié et optimisé (voir FileTransferManager), pour ne
 * jamais ralentir ni bloquer l'échange de messages/pubs/profil.
 */
object ZeeMessageCodec {

    sealed class Decoded {
        data class Hello(val nodeId: String) : Decoded()
        data class Ready(val nodeId: String) : Decoded()
        data class Profile(val nodeId: String, val module: ZeeModule, val name: String, val actu: String, val photoBase64: String?, val direct: Boolean) : Decoded()
        data class Ad(val payload: AdPayload) : Decoded()
        data class Chat(val messageId: String, val fromNodeId: String, val toNodeId: String, val ttl: Int, val text: String, val channel: String) : Decoded()
        data class Attachment(val messageId: String, val fromNodeId: String, val toNodeId: String, val ttl: Int, val fileName: String, val mimeType: String, val fileSize: Long, val channel: String) : Decoded()
        data class Ack(val messageId: String, val toNodeId: String, val ttl: Int) : Decoded()
        data class WebRtcSignal(
            val signalType: String,
            val nodeId: String,
            val sdpType: String? = null,
            val sdp: String? = null,
            val sdpMid: String? = null,
            val sdpMLineIndex: Int? = null,
            val candidate: String? = null
        ) : Decoded()
    }

    fun encodeHello(nodeId: String): String =
        JSONObject().apply {
            put("type", "HELLO")
            put("nodeId", nodeId)
        }.toString()

    fun encodeReady(nodeId: String): String =
        JSONObject().apply {
            put("type", "READY")
            put("nodeId", nodeId)
        }.toString()

    fun encodeProfile(nodeId: String, name: String, actu: String, photoBase64: String? = null, direct: Boolean = true, module: ZeeModule = ZeeModule.CHAT): String =
        JSONObject().apply {
            put("type", "PROFILE")
            put("nodeId", nodeId)
            put("module", module.name)
            put("name", name)
            put("actu", actu)
            put("direct", direct)
            if (photoBase64.isNullOrBlank()) put("photoBase64", JSONObject.NULL)
            else put("photoBase64", photoBase64)
        }.toString()

    fun encodeAd(payload: AdPayload): String =
        JSONObject().apply {
            put("type", "AD")
            put("id", payload.id)
            put("module", payload.module.name)
            put("sellerName", payload.sellerName)
            put("headline", payload.headline)
            put("subtext", payload.subtext)
            put("imageBase64", payload.imageBase64)
            put("adCode", payload.adCode)
            put("expiresAt", payload.expiresAt)
            put("mediaMimeType", payload.mediaMimeType)
            put("mediaFileName", payload.mediaFileName)
        }.toString()

    fun encodeChat(text: String, fromNodeId: String, toNodeId: String, ttl: Int = 8, messageId: String = java.util.UUID.randomUUID().toString(), channel: String = MessageChannels.CHAT): String =
        JSONObject().apply {
            put("type", "CHAT")
            put("messageId", messageId)
            put("fromNodeId", fromNodeId)
            put("toNodeId", toNodeId)
            put("ttl", ttl)
            put("channel", MessageChannels.normalize(channel))
            put("text", text)
        }.toString()

    fun encodeAttachment(messageId: String, fromNodeId: String, toNodeId: String, fileName: String, mimeType: String, fileSize: Long, ttl: Int = 8, channel: String = MessageChannels.CHAT): String =
        JSONObject().apply {
            put("type", "ATTACHMENT")
            put("messageId", messageId)
            put("fromNodeId", fromNodeId)
            put("toNodeId", toNodeId)
            put("ttl", ttl)
            put("channel", MessageChannels.normalize(channel))
            put("fileName", fileName)
            put("mimeType", mimeType)
            put("fileSize", fileSize)
        }.toString()

    /** ACK minimal : ID du message + destination (origine) + TTL. */


    /** Signalisation locale du transport WebRTC. Les SDP/ICE transitent
     * uniquement par le canal ZEE déjà établi; aucun serveur Snapdrop n'est
     * nécessaire. */
    fun encodeWebRtcOffer(nodeId: String, sdp: String): String =
        JSONObject().apply {
            put("type", "WEBRTC")
            put("signal", "OFFER")
            put("nodeId", nodeId)
            put("sdpType", "offer")
            put("sdp", sdp)
        }.toString()

    fun encodeWebRtcAnswer(nodeId: String, sdp: String): String =
        JSONObject().apply {
            put("type", "WEBRTC")
            put("signal", "ANSWER")
            put("nodeId", nodeId)
            put("sdpType", "answer")
            put("sdp", sdp)
        }.toString()

    fun encodeWebRtcIce(nodeId: String, candidate: String, sdpMid: String?, sdpMLineIndex: Int): String =
        JSONObject().apply {
            put("type", "WEBRTC")
            put("signal", "ICE")
            put("nodeId", nodeId)
            put("candidate", candidate)
            if (sdpMid != null) put("sdpMid", sdpMid) else put("sdpMid", JSONObject.NULL)
            put("sdpMLineIndex", sdpMLineIndex)
        }.toString()

    fun encodeAck(messageId: String, toNodeId: String, ttl: Int = 8): String =
        JSONObject().apply {
            put("type", "ACK")
            put("messageId", messageId)
            put("toNodeId", toNodeId)
            put("ttl", ttl)
        }.toString()

    /** Retourne null si la ligne n'est pas un JSON valide ou d'un type inconnu (ignorée sans planter). */
    fun decode(line: String): Decoded? {
        return try {
            val o = JSONObject(line)
            when (o.optString("type")) {
                "HELLO" -> Decoded.Hello(o.optString("nodeId"))
                "READY" -> Decoded.Ready(o.optString("nodeId"))
                "PROFILE" -> Decoded.Profile(
                    nodeId = o.optString("nodeId"),
                    module = runCatching { ZeeModule.valueOf(o.optString("module", ZeeModule.CHAT.name)) }.getOrDefault(ZeeModule.CHAT),
                    name = o.optString("name"),
                    actu = o.optString("actu"),
                    photoBase64 = if (o.isNull("photoBase64")) null else o.optString("photoBase64").ifBlank { null },
                    direct = o.optBoolean("direct", true)
                )
                "AD" -> Decoded.Ad(
                    AdPayload(
                        id = o.getString("id"),
                        module = runCatching { ZeeModule.valueOf(o.optString("module", ZeeModule.CHAT.name)) }.getOrDefault(ZeeModule.CHAT),
                        sellerName = o.optString("sellerName"),
                        headline = o.optString("headline"),
                        subtext = if (o.isNull("subtext")) null else o.optString("subtext"),
                        imageBase64 = if (o.isNull("imageBase64")) null else o.optString("imageBase64"),
                        adCode = o.optString("adCode"),
                        expiresAt = o.optLong("expiresAt"),
                        mediaMimeType = o.optString("mediaMimeType").ifBlank { null },
                        mediaFileName = o.optString("mediaFileName").ifBlank { null }
                    )
                )
                "CHAT" -> Decoded.Chat(
                    messageId = o.optString("messageId", java.util.UUID.randomUUID().toString()),
                    fromNodeId = o.optString("fromNodeId"),
                    toNodeId = o.optString("toNodeId"),
                    ttl = o.optInt("ttl", 8),
                    text = o.optString("text"),
                    channel = MessageChannels.normalize(o.optString("channel", MessageChannels.CHAT))
                )
                "ATTACHMENT" -> Decoded.Attachment(
                    messageId = o.optString("messageId", java.util.UUID.randomUUID().toString()),
                    fromNodeId = o.optString("fromNodeId"),
                    toNodeId = o.optString("toNodeId"),
                    ttl = o.optInt("ttl", 8),
                    fileName = o.optString("fileName", "fichier"),
                    mimeType = o.optString("mimeType", "application/octet-stream"),
                    fileSize = o.optLong("fileSize", -1L),
                    channel = MessageChannels.normalize(o.optString("channel", MessageChannels.CHAT))
                )
                "WEBRTC" -> Decoded.WebRtcSignal(
                    signalType = o.optString("signal"),
                    nodeId = o.optString("nodeId"),
                    sdpType = o.optString("sdpType").ifBlank { null },
                    sdp = o.optString("sdp").ifBlank { null },
                    sdpMid = if (o.isNull("sdpMid")) null else o.optString("sdpMid").ifBlank { null },
                    sdpMLineIndex = if (o.has("sdpMLineIndex")) o.optInt("sdpMLineIndex") else null,
                    candidate = o.optString("candidate").ifBlank { null }
                )
                "ACK" -> Decoded.Ack(
                    messageId = o.optString("messageId"),
                    toNodeId = o.optString("toNodeId"),
                    ttl = o.optInt("ttl", 8)
                )
                else -> null
            }
        } catch (e: Exception) {
            null
        }
    }
}
