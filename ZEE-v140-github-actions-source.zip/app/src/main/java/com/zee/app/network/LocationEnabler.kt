package com.zee.app.network

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.location.LocationManager
import android.os.Build
import android.provider.Settings

/**
 * Sur Android 10 à 12, la découverte Wi-Fi Direct (WifiP2pManager) ne
 * remonte AUCUN appareil si le service de LOCALISATION du téléphone est
 * désactivé dans les réglages rapides — même si la permission
 * ACCESS_FINE_LOCATION est bien accordée à l'application. C'est une
 * restriction du système Android, pas une limite de ZEE, et elle explique
 * la quasi-totalité des cas où "aucun utilisateur ZEE à proximité ne
 * s'affiche" alors que tout le reste est correctement configuré.
 *
 * À partir d'Android 13, ZEE utilise NEARBY_WIFI_DEVICES avec le drapeau
 * "neverForLocation" (voir AndroidManifest.xml), qui n'a PAS besoin que la
 * localisation soit activée — cette vérification ne concerne donc que les
 * versions antérieures.
 */
object LocationEnabler {

    fun isRequired(): Boolean = Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU

    fun isLocationEnabled(context: Context): Boolean {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            lm.isLocationEnabled
        } else {
            @Suppress("DEPRECATION")
            (lm.isProviderEnabled(LocationManager.GPS_PROVIDER) || lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
        }
    }

    /** Ouvre directement l'écran système de réglage de la localisation si elle est nécessaire et désactivée. */
    fun ensureEnabledIfRequired(activity: Activity, requestCode: Int) {
        if (!isRequired()) return
        if (isLocationEnabled(activity)) return
        try {
            activity.startActivityForResult(Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS), requestCode)
        } catch (e: Exception) {
            // Écran de réglages introuvable sur cet appareil (rare) : rien
            // de plus à faire côté app, l'utilisateur devra l'activer
            // manuellement depuis ses réglages rapides.
        }
    }
}
