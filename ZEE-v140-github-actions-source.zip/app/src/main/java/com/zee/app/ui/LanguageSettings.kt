package com.zee.app.ui

import android.content.Context
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatDelegate
import androidx.core.os.LocaleListCompat
import com.zee.app.R
import java.util.Locale

/** Sélecteur de langue de l’application, indépendant de la langue système. */
object LanguageSettings {
    fun showPicker(context: Context) {
        val currentTags = AppCompatDelegate.getApplicationLocales().toLanguageTags()
        val current = currentTags.substringBefore(',').ifBlank { Locale.getDefault().language }
        val languages = arrayOf(
            context.getString(R.string.language_french),
            context.getString(R.string.language_english)
        )
        val tags = arrayOf("fr", "en")
        val checked = tags.indexOf(current).takeIf { it >= 0 } ?: 0

        AlertDialog.Builder(context)
            .setTitle(R.string.language_dialog_title)
            .setSingleChoiceItems(languages, checked) { dialog, which ->
                val selected = tags[which]
                dialog.dismiss()
                if (selected != current) {
                    AppCompatDelegate.setApplicationLocales(
                        LocaleListCompat.forLanguageTags(selected)
                    )
                }
            }
            .setNegativeButton(R.string.settings_close, null)
            .show()
    }
}
