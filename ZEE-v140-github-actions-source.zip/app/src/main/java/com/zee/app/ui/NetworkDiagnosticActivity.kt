package com.zee.app.ui

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.zee.app.R
import com.zee.app.network.ZeeDiagnostic

class NetworkDiagnosticActivity : AppCompatActivity() {
    private lateinit var logView: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_network_diagnostic)
        logView = findViewById(R.id.diagnosticLog)
        findViewById<Button>(R.id.btnDiagnosticRefresh).setOnClickListener { refresh() }
        findViewById<Button>(R.id.btnDiagnosticCopy).setOnClickListener {
            val cm = getSystemService(CLIPBOARD_SERVICE) as android.content.ClipboardManager
            cm.setPrimaryClip(android.content.ClipData.newPlainText("Diagnostic ZEE", ZeeDiagnostic.snapshot(this)))
            android.widget.Toast.makeText(this, getString(com.zee.app.R.string.kt_diagnostic_copi), android.widget.Toast.LENGTH_SHORT).show()
        }
        findViewById<Button>(R.id.btnDiagnosticShare).setOnClickListener {
            startActivity(Intent.createChooser(Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, ZeeDiagnostic.snapshot(this@NetworkDiagnosticActivity))
            }, "Partager le diagnostic ZEE"))
        }
        findViewById<Button>(R.id.btnDiagnosticClear).setOnClickListener {
            ZeeDiagnostic.clear(this)
            refresh()
        }
        findViewById<Button>(R.id.btnDiagnosticClose).setOnClickListener { finish() }
        refresh()
    }

    override fun onResume() {
        super.onResume()
        refresh()
    }

    private fun refresh() {
        logView.text = ZeeDiagnostic.snapshot(this)
    }
}
