plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.zee.app"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.zee.app"
        minSdk = 24          // Wi-Fi Direct APIs are stable from API 21+; 24 keeps things simple
        targetSdk = 34
        versionCode = 70
        versionName = "0.70.0-v140"
    }

    signingConfigs {
        create("release") {
            val ks = System.getenv("ZEE_KEYSTORE_PATH")
            if (!ks.isNullOrBlank()) {
                storeFile = file(ks)
                storePassword = System.getenv("ZEE_KEYSTORE_PASSWORD")
                keyAlias = System.getenv("ZEE_KEY_ALIAS")
                keyPassword = System.getenv("ZEE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            val ks = System.getenv("ZEE_KEYSTORE_PATH")
            if (!ks.isNullOrBlank()) {
                signingConfig = signingConfigs.getByName("release")
            }
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
    buildFeatures {
        viewBinding = true
    }
}

// Demande explicitement à Gradle d'utiliser (et si besoin de télécharger
// automatiquement) un JDK 17 pour la compilation Kotlin — indépendamment
// du JDK par défaut installé sur la machine. Corrige les plantages du
// "daemon" de compilation (ex. "Daemon compilation failed",
// "IllegalArgumentException: 25.0.3") qui surviennent quand un JDK trop
// récent (21+) est utilisé avec d'anciennes versions de Kotlin/Gradle.
kotlin {
    jvmToolchain(17)
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.activity:activity-ktx:1.9.2")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    implementation("androidx.constraintlayout:constraintlayout:2.1.4")
    implementation("androidx.recyclerview:recyclerview:1.3.2")
    implementation("androidx.viewpager2:viewpager2:1.1.0")
    implementation("androidx.swiperefreshlayout:swiperefreshlayout:1.1.0")
    implementation("androidx.lifecycle:lifecycle-runtime-ktx:2.8.4")
    implementation("androidx.fragment:fragment-ktx:1.8.2")
    implementation("de.hdodenhof:circleimageview:3.1.0")
    // WebRTC DataChannel : transport P2P chiffré inspiré de l’architecture Snapdrop.
    // Le transport TCP/Wi-Fi Direct reste le fallback et le canal de signalisation.
    implementation("io.github.webrtc-sdk:android:150.7871.01")
}
