# ZEE v40 — menus indépendants des modules et publicité

Cette version part de ZEE v39 et ajoute l'accès direct, depuis les trois points verticaux des en-têtes LIVE CHAT, BUSINESS et JOB, aux réglages propres au module courant.

## Menus `⋮`

Chaque onglet possède son propre menu :
- **LIVE CHAT** : Paramètres du profil, Publicité, Paramètres réseau.
- **BUSINESS** : Paramètres du profil Business, Publicité Business, Paramètres réseau.
- **JOB** : Paramètres du profil Job, Publicité Job, Paramètres réseau.

Le menu ouvre `ProfileActivity` avec le module explicitement transmis. Les données de module (actu, photo, critère/statut et visibilité) restent indépendantes selon le module, conformément à `ProfileStore`/`VisibilityStore`.

## Publicité

L'entrée **Publicité** ouvre directement la section de configuration publicitaire et fait défiler l'écran jusqu'à celle-ci. Elle expose les éléments déjà présents dans le projet :
- contenu texte de la publicité ;
- choix d'un média : image, audio, vidéo, document ou autre fichier ;
- champ de saisie du code pub à 6 chiffres ;
- affichage/masquage du code ;
- achat du code via WhatsApp ;
- activation pour 24 h ;
- validation locale du code selon `assets/ad_codes.csv` ;
- minuterie d'expiration ;
- refus d'activation lorsque le statut du module ne permet pas la diffusion (Business = Vendeur, Job = Recruteur ; Live Chat = utilisateur Live Chat).

Même lorsque l'utilisateur ouvre explicitement **Publicité** depuis un module non éligible, tous les champs restent consultables et préparables ; l'activation est bloquée tant que le statut réel requis n'est pas sélectionné.

Aucune donnée de profil ou publicité fictive n'est ajoutée par cette modification.
