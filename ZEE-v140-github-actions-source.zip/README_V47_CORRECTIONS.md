# ZEE v47 — Corrections localisation et accueil des modules

- Retour depuis les réglages système de localisation : ne réouvre plus en boucle l'écran système si l'utilisateur appuie sur Précédent sans activer la localisation.
- Une action explicite « Actualiser » permet de redemander la localisation.
- JOB : ajout du bloc de bienvenue avec logo, puis « Proximité / X utilisateurs détectés » comme BUSINESS.
- LIVE CHAT : ajout du bloc de bienvenue avec logo, puis « Proximité / X utilisateurs détectés ».
- Les compteurs ne comptent que les utilisateurs ZEE réellement connectés et visibles dans le module.
- Aucun profil fictif n'est ajouté.
- Dans JOB, le clic sur Proximité affiche/masque les profils réellement connectés et compatibles.
- Dans LIVE CHAT, le clic sur Proximité ouvre une liste des utilisateurs réellement connectés et visibles, ou indique 0 si la liste est vide.
