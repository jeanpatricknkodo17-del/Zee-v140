# Corrections réseau fusionnées — ZEE

Cette version fusionne les optimisations temps réel du chat avec les corrections de connexion Wi‑Fi Direct et renforce le routage mesh.

## Corrections appliquées

- Routage séparé entre **destination logique (`nodeId`)** et **voisin TCP direct**.
  - Plusieurs `nodeId` peuvent maintenant passer par une même session relais sans écraser l'identité du voisin direct.
  - Les profils relayés ne sont plus traités comme une nouvelle connexion directe.
- `ZeeSocketSession.send()` retourne maintenant `Boolean` afin que le routeur sache si le paquet a réellement été accepté dans la file d'envoi non bloquante.
- `ZeeMeshServer.sendTo()` propage ce résultat au routeur.
- Suppression du fallback ACK qui pouvait renvoyer un ACK vers la session source lorsqu'aucune route vers l'origine n'était connue.
- Binding Wi‑Fi Direct renforcé : un ancien `onLost()` ne peut plus détacher un réseau P2P plus récent.
- Résolution de l'adresse du Group Owner renforcée : jusqu'à 5 vérifications espacées d'une seconde lorsque Android publie temporairement `0.0.0.0`.

## Test recommandé

```bash
./gradlew clean assembleDebug
```

Puis tester au minimum :

1. A → B en connexion directe.
2. A → B → C avec B comme relais.
3. Plusieurs clients C/D connectés au même relais B.
4. Déconnexion/reconnexion de B ou C avec message en attente.
5. ACK retour jusqu'à l'expéditeur.
