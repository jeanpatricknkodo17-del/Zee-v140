# ZEE v57 — poignée de main Business entièrement blanche

Correction ciblée basée sur v56.

- Correction de `ic_business_handshake_white.png` : tous les pixels visibles de la poignée de main sont désormais en blanc opaque (`#FFFFFFFF`).
- Le même fichier est utilisé dans l'en-tête Business, la carte d'accueil Business et les activités Business : la correction s'applique donc partout où le logo est affiché.
- Aucun changement apporté aux filtres, à la logique Live Chat, ni au Wi‑Fi Direct/Xender de v56.
