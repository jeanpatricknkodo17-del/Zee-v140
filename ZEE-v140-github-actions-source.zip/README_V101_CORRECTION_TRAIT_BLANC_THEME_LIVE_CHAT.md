# ZEE v101 — Correction du trait blanc dans LIVE CHAT avec les thèmes

Correction du rendu de la page LIVE CHAT lorsque l’utilisateur sélectionne un thème de fond.

Cause : le `RecyclerView` des conversations conservait un fond blanc opaque, ce qui créait une bande blanche visible sous la section « Conversations » lorsque le contenu était vide.

Correction : le `RecyclerView` utilise désormais un fond transparent. Le fond blanc reste fourni par le conteneur de page avec le thème par défaut, tandis que les thèmes personnalisés peuvent apparaître jusqu’au bas de la zone LIVE CHAT.

Version Android : `0.43.0-v101-chat-theme-stripe-fix` (versionCode 43).
