# V52 — logique LIVE CHAT corrigée

La préférence LIVE CHAT choisie au-dessus de l'onglet est `Tous`, `Hommes` ou `Femmes`.

## Autorisation d'échange

La visibilité du profil reste indépendante de la préférence. L'échange messages/médias est autorisé uniquement si les préférences sont réciproques :

- Homme → Hommes + Homme → Hommes : autorisé.
- Femme → Femmes + Femme → Femmes : autorisé.
- Homme → Femmes + Femme → Hommes : autorisé.
- Femme → Hommes + Homme → Femmes : autorisé.
- Tous + Tous : autorisé, quel que soit le sexe.
- Tous avec Hommes/Femmes : refusé.
- Toute combinaison non réciproque : refusée.

Ainsi, un homme ayant choisi `Hommes` ne peut pas échanger avec un homme ayant choisi `Femmes`; de même, une femme ayant choisi `Femmes` ne peut pas échanger avec une femme ayant choisi `Hommes`. Les combinaisons H-H et F-F restent donc possibles lorsqu'elles sont choisies des deux côtés.
