# Correctifs Wi-Fi Direct ZEE

- Android 13+ : `NEARBY_WIFI_DEVICES` est la permission Wi-Fi Direct requise; `ACCESS_FINE_LOCATION` est limité à Android 12 et antérieur.
- Le refus des notifications ne bloque plus Wi-Fi Direct.
- La découverte DNS-SD est maintenant séquencée: nettoyage -> annonce locale -> requête de service -> `discoverServices()`.
- Le réseau Wi-Fi local sans Internet n'est plus remplacé par plusieurs callbacks `onAvailable()`.
- Les retries d'informations de connexion sont invalidés lorsqu'une nouvelle connexion P2P démarre.
- `connect()` utilise WPS PBC et réessaie 3 fois les erreurs transitoires `ERROR(0)`/`BUSY(2)`.
- Les demandes DNS-SD sont retirées avant une négociation de connexion pour réduire les conflits avec le framework.
- Le code utilisateur affiche désormais la signification de `ERROR(0)`.
