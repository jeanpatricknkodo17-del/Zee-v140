# ZEE V126 — relance DNS-SD, anti-blocage de connexion (2e journal : TECNO KN3, Android 35)

Base : `zee-v125-relecture-journal.zip`.

## Constat (croisement des deux journaux, même fenêtre 16:49–16:52)
- Les deux journaux viennent encore d'une version antérieure à V122 (« exceeds TXT budget »).
- TECNO : `discoverServices()` appelé à 16:49:57 avec 0 pair ; l'itel apparaît à 16:50:04 ; aucun `ZEE_SERVICE_FOUND` / `ZEE_TXT` pendant 57 s. Après un rafraîchissement manuel (génération 3), le TXT de l'itel arrive en 4 s.
- Itel : `ZEE_SERVICE_FOUND` du TECNO, jamais de `ZEE_TXT`, aucune connexion.
- Aucun `DISCOVERY_IF_READY` périodique dans les deux journaux : `discoveryHeartbeat` est défini dans MainActivity mais n'était posté nulle part.
- nodeId distincts des deux côtés (c551… et 9e7c…) : pas de cas « même nodeId ».

## Corrections
1. **Relance périodique de `discoverServices()`** (8 s tant qu'aucun TXT n'est connu, 25 s ensuite), sans effacer l'annonce ni la requête. Journal : `SERVICE_REFRESH`.
2. **Chien de garde TXT** : service vu sans TXT → nouvelle requête après 4 s (1 fois / 20 s par pair). Journal : `TXT_MISSING`.
3. **Heartbeat réellement lancé** dans `onResume()` ; il ne relance un cycle que s'il est arrêté (`isDiscoveryRunning`), donc plus de bruit `already-active`.
4. **Anti-blocage** : le téléphone qui « attend l'initiative du pair » se connecte lui-même après 15 s si rien ne s'est formé. Journal : `AUTOCONNECT late-fallback`.
5. **Pas de `connect()` vers un pair déjà connecté** (garde `PeerStatus.CONNECTED`).

## À vérifier au prochain test (installer la v126 sur les DEUX téléphones)
- Des lignes `SERVICE_REFRESH` toutes les ~8 s, puis `ZEE_TXT` des deux côtés.
- Un seul `AUTOCONNECT initiate` (celui dont le nodeId est le plus grand), puis `CONNECT accepted` / `P2P_CONNECTED`.
- Si `ZEE_SERVICE_FOUND` revient toujours sans `ZEE_TXT` après `TXT_MISSING` : le firmware ne livre pas le TXT ; la connexion se fera quand même (repli 3 s) et le profil arrivera par le handshake.

Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).
