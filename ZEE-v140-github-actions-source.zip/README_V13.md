# ZEE v13 — fiabilisation du retry et reconnexion

Cette version poursuit v12 avec une correction de course dans la file de messages persistants.

## Correction principale
Pour les messages récupérés depuis `MeshMessageStore`, l'état `in-flight` est désormais armé **avant** l'appel à `routeTo()`.

Le writer TCP peut en effet effectuer le `flush` immédiatement sur un autre thread. L'ancien ordre était :

1. `routeTo()`
2. le writer flush
3. callback `onLineFlushed`
4. ajout de l'ID dans `inFlight`

Cette séquence pouvait réintroduire l'ID après son retrait par le callback et permettre au retry de remettre le même CHAT sur le socket.

Le nouvel ordre est :

1. vérifier la route READY
2. marquer `inFlight`
3. associer l'ID à la session
4. placer la ligne dans le writer
5. retirer l'état si l'offre échoue

Cela complète la protection déjà présente dans `sendChat()` et réduit fortement le risque de doublons lors d'une reconnexion ou d'un flush de la file persistante.

## Contrôle
Archive créée depuis v12 et structure Kotlin inspectée. Un build Android complet n'est pas exécuté dans cet environnement car le SDK/Gradle Android n'y sont pas configurés.
