# ZEE v10 — fiabilisation du canal privé

Cette version poursuit la stabilisation de v9.

## Changements
- Un même `nodeId` ne peut plus rester attaché à deux sockets TCP concurrents.
- Lorsqu'un même téléphone se reconnecte, l'ancien transport est fermé avant de poursuivre avec le nouveau.
- Le routage logique reste séparé de l'identité du voisin TCP direct.
- Le handshake HELLO/READY est conservé : un CHAT privé n'est envoyé qu'après confirmation du canal applicatif.
- Ajout de traces Logcat `HANDSHAKE_START`, `HANDSHAKE_TIMEOUT`, `CHAT_RECEIVED` et `ACK_RECEIVED`.
- Les messages en attente restent persistants et sont repris lorsque la route et le canal READY redeviennent disponibles.

## Vérification
Le ZIP de livraison a été contrôlé avec `unzip -t`.

## Limite d'environnement
Aucun build Android complet n'est déclaré ici : l'environnement d'exécution ne fournit pas le Gradle Wrapper/SDK Android nécessaires. La validation effectuée porte sur l'intégrité de l'archive et les modifications source.
