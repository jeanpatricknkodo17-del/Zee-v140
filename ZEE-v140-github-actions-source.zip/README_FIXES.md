# ZEE — corrections profil et messagerie maillée

Cette version corrige les points suivants :

- identité utilisateur basée sur le `nodeId` ZEE et le profil, jamais sur le nom système Android ;
- cache des profils par `nodeId` pour conserver nom, actu et photo après une reconnexion ou un rafraîchissement de la découverte Wi‑Fi Direct ;
- chat routé exclusivement vers le `nodeId` du destinataire ; aucun fallback vers un téléphone arbitraire ;
- files d'attente persistantes pour les messages lorsque la route est momentanément indisponible ;
- ACK de livraison acheminé par le même réseau maillé ;
- suppression de la copie en attente chez chaque relais lorsque l'ACK traverse ce relais ;
- relais Wi‑Fi Direct côté Group Owner via `ZeeMeshServer`, avec routage par `nodeId` ;
- les paquets privés inconnus ne sont plus diffusés à tous les voisins ;
- le sélecteur de galerie de la version précédente est conservé.

## Compilation

Le projet est livré avec ses sources Android/Gradle. Le dépôt d'origine ne contient pas de Gradle Wrapper et l'environnement de correction ne disposait pas de Gradle installé ; une compilation Android complète n'a donc pas pu être exécutée ici. Importer le dossier dans Android Studio et lancer une synchronisation Gradle avant le build.
