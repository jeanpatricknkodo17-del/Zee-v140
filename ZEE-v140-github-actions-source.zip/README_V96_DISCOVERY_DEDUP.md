# ZEE v96 — correction de la découverte Wi-Fi Direct répétée

## Modifications
- `WifiDirectManager.register()` est idempotent : le récepteur n'est pas enregistré plusieurs fois.
- `startDiscovery()` ignore les déclenchements concurrents lorsque la découverte est déjà en cours ou active.
- Les callbacks asynchrones sont associés à une génération de découverte ; les réponses d'un ancien cycle sont ignorées.
- Les sondages `requestPeers()` sont conservés une seule fois par cycle et annulés à l'arrêt, à la reconnexion ou lors d'un rafraîchissement explicite.
- `unregister()` arrête le scan, invalide les callbacks en attente et remet l'état à zéro.
- Le geste explicite de rafraîchissement des pairs force toujours un nouveau scan.

Cela évite que les événements `PERMISSION_RESULT`, `P2P_STATE` et `onResume()` lancent plusieurs découvertes simultanées.

## Vérification
- Archive ZIP vérifiée avec `unzip -t`.
- Compilation Android non exécutée dans cet environnement : le projet ne contient pas de Gradle Wrapper et aucun exécutable Gradle système n'est disponible.
