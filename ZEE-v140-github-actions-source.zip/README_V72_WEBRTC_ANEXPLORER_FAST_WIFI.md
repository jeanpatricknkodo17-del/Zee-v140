# ZEE v72 — WebRTC + Fast Wi‑Fi direct lane

## Objectif

ZEE utilise maintenant trois voies de données, dans cet ordre :

1. **WebRTC DataChannel** lorsque `WEBRTC_READY` est confirmé ;
2. **Fast Wi‑Fi direct** pour un voisin ZEE physique connecté sur le réseau Wi‑Fi Direct ;
3. **TCP/mesh historique** en dernier recours.

Cette architecture reprend les principes documentés par AnExplorer pour son transfert local : découverte préalable d'un appareil, connexion directe sur le réseau local, puis flux de fichiers directement entre les deux appareils, sans cloud ni Internet. AnExplorer indique que son mode Transfer fonctionne entre appareils sur le même Wi‑Fi et peut utiliser un téléphone comme hotspot, avec des débits annoncés de l'ordre de dizaines de Mo/s selon le matériel et le réseau. Voir la documentation officielle AnExplorer et son dépôt open source. 

- https://anexplorer.io/docs/wifishare
- https://anexplorer.io/features/wifi-transfer
- https://github.com/1hakr/AnExplorer

## Ce qui a été intégré

`ZeeFastWifiTransfer.kt` est un nouveau moteur ZEE de transfert direct :

- serveur local sur le port `8990` ;
- en-tête binaire court avec magic/version/métadonnées JSON ;
- streaming avec blocs de **256 KiB** ;
- buffers socket jusqu'à **1 MiB** ;
- pas de `TCP_NODELAY` afin de favoriser le débit des gros flux ;
- validation du destinataire `toNodeId` ;
- validation de la taille annoncée et de la taille finale ;
- stockage temporaire dans `cacheDir/zee_fast_received` ;
- aucun relais mesh sur cette voie : les destinations indirectes restent sur le transport TCP existant.

## Fallback

Pour une pièce jointe directe :

`WebRTC → Fast Wi‑Fi → TCP`

Si le DataChannel n'est pas `OPEN` ou si son envoi échoue, ZEE tente le Fast Wi‑Fi. Si celui-ci échoue également (serveur absent, IP inaccessible, timeout, etc.), le flux TCP existant est conservé.

## Pourquoi ne pas copier directement le code AnExplorer ?

Le dépôt public `1hakr/AnExplorer` est publié sous Apache-2.0. Cette version de ZEE ne copie pas de fichiers AnExplorer : elle reprend seulement le modèle architectural de transfert local et implémente un transport ZEE propre, afin de préserver le protocole mesh et le fallback déjà présents dans l'application.

## Limites à tester sur appareils réels

La disponibilité et les performances dépendent du téléphone, de la version Android et du chipset Wi‑Fi. Le Fast Wi‑Fi doit donc être validé sur au moins deux téléphones physiques avec Wi‑Fi Direct réellement connecté. L'environnement de développement fourni ici ne contient pas le wrapper Gradle et ne permet pas de produire une APK vérifiée dans cette session.

## Fichiers modifiés

- `app/src/main/java/com/zee/app/network/ZeeFastWifiTransfer.kt` — nouveau transport direct.
- `FileTransferManager.kt` — ajout du niveau de préférence Fast Wi‑Fi entre WebRTC et TCP.
- `SessionRegistry.kt` — distinction voisin direct / destination relayée et routage Fast Wi‑Fi.
- `ChatActivity.kt` — les pièces jointes directes utilisent la chaîne WebRTC → Fast Wi‑Fi → TCP.
- `MainActivity.kt` — démarrage/arrêt du serveur Fast Wi‑Fi et réception des fichiers.
- `app/build.gradle.kts` — version ZEE `0.38.0-v72-webrtc-anexplorer-fast-wifi`.
