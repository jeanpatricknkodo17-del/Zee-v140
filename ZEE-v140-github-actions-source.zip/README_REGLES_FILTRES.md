# ZEE — règles des filtres (référence unique, consignes de l'utilisateur)

Principe commun
- Ce qu'un utilisateur choisit dans les PARAMÈTRES de son profil désigne CE QU'IL EST (annoncé aux voisins).
- Les TROIS BOUTONS en haut de chaque page signifient : « je veux uniquement voir les utilisateurs qui ont choisi ce profil ». « Tous » = tout le monde. Mon propre profil n'intervient pas dans ce tri.

BUSINESS : Tous / Vendeurs / Acheteurs  (statut annoncé : A = Vendeur, B = Acheteur)
JOB : Tous / Chercheurs d'emploi / Recruteurs  (A = Cherche emploi, B = Recrute)
- Un profil dont le statut n'est pas encore connu n'apparaît que sous « Tous ».

RENCONTRES : Tous / Hommes / Femmes
- Le SEXE du profil désigne ce que l'utilisateur est ; les boutons filtrent la liste par sexe annoncé et enregistrent aussi la préférence utilisée pour la réciprocité.
- Échange autorisé uniquement si les préférences sont réciproques : Homme→Hommes ↔ Homme→Hommes, Femme→Femmes ↔ Femme→Femmes, Homme→Femmes ↔ Femme→Hommes, Femme→Hommes ↔ Homme→Femmes, Tous ↔ Tous.
- Sinon le profil reste visible, l'échange est restreint et un petit cadenas apparaît sur la photo.

Code concerné : `PeerListFragment.roleMatches` (Business/Job), `chatSexMatches` + `isChatCompatible` (Rencontres), `ProfileStore.areLiveChatCriteriaCompatible`.
