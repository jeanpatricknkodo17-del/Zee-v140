# ZEE — Projet Android (squelette de code source)

Ce projet implémente la structure de l'application décrite dans le cahier
des charges : trois modules (LIVE CHAT, MARKET, JOB) avec liste de pairs
à proximité, chat avec pièces jointes, et communication **sans internet**
via **Wi-Fi Direct** (comme Xender).

## Comment le compiler

1. Installer **Android Studio** (gratuit) : https://developer.android.com/studio
2. `Fichier > Ouvrir` → sélectionner ce dossier `zee-android/`
3. Laisser Gradle synchroniser (télécharge les dépendances — nécessite internet
   *pendant le développement*, pas dans l'app finale)
4. Brancher un téléphone Android (mode développeur + débogage USB activé),
   ou lancer un émulateur avec Wi-Fi Direct supporté (⚠️ les émulateurs ne
   supportent pas toujours le Wi-Fi Direct — préférer un vrai téléphone)
5. Cliquer sur ▶ Run

Pour un fichier `.apk` installable manuellement :
`Build > Build Bundle(s) / APK(s) > Build APK(s)` → le `.apk` apparaît
dans `app/build/outputs/apk/`. Il faudra ensuite transférer ce fichier
sur le téléphone et autoriser "Sources inconnues" pour l'installer.

## Compiler en ligne, sans installer Android Studio

Un fichier `.github/workflows/build.yml` est déjà inclus dans ce projet.
Il permet de compiler l'app gratuitement via **GitHub Actions**, sans rien
installer sur votre ordinateur.

### Depuis un ordinateur

1. Créer un compte gratuit sur https://github.com (si besoin)
2. Créer un nouveau dépôt (bouton vert "New")
3. Téléverser tout le contenu de ce dossier `zee-android/` dans ce dépôt
   (glisser-déposer les fichiers via l'interface web GitHub, ou `git push`)
4. Aller dans l'onglet **"Actions"** du dépôt : la compilation démarre
   automatiquement (quelques minutes)
5. Une fois terminé (coche verte ✅), cliquer sur le run terminé, puis sur
   **"zee-app-debug"** en bas de page pour télécharger l'APK compilé
6. Transférer ce `.apk` sur un téléphone Android et l'installer (autoriser
   "Sources inconnues" si demandé)

### Depuis un téléphone (un seul fichier à envoyer)

Envoyer toute l'arborescence de dossiers depuis un téléphone est peu
pratique — ce n'est pas nécessaire ici : le workflow sait extraire le zip
tout seul, il suffit d'envoyer le fichier **zee-android-source.zip** tel quel.

1. Créer un compte gratuit sur https://github.com (si besoin), depuis le
   navigateur du téléphone
2. Créer un nouveau dépôt (bouton vert "New")
3. Sur la page du dépôt vide, taper **"uploading an existing file"**
   (lien proposé automatiquement), ou aller dans "Add file" > "Upload files"
4. Appuyer sur "choose your files", sélectionner **zee-android-source.zip**
   depuis le téléphone (fichier unique, aucune extraction nécessaire au
   préalable), puis valider l'envoi ("Commit changes")
5. Aller dans l'onglet **"Actions"** du dépôt : la compilation démarre
   automatiquement (le workflow extrait le zip puis compile, quelques
   minutes)
6. Une fois terminé (coche verte ✅), ouvrir ce run, puis télécharger
   **"zee-app-debug"** en bas de page pour récupérer l'APK compilé
7. Installer ce `.apk` directement sur le téléphone (autoriser
   "Sources inconnues" si demandé)

## Ce qui est implémenté

- Structure du projet (Gradle, manifeste, permissions Wi-Fi Direct)
- Écran splash → accueil à 3 onglets (LIVE CHAT / MARKET / JOB)
- Découverte de pairs via `WifiP2pManager` (`WifiDirectManager.kt`)
- Connexion à un pair et formation du groupe P2P
- Écran de chat avec bulles de message + sélecteur de pièces jointes
  (Document, Caméra, Galerie, Audio, Localisation, Contact)
- Écran de profil (nom, ACTU, photo, critères de rencontre)
- Squelette de canal TCP pour l'échange de messages une fois connectés
  (`ZeeSocketSession.kt`)
- Notification de message reçu (`NotificationHelper.kt`) : son/vibration
  gérés par le système Android via un `NotificationChannel`, donc respectés
  automatiquement selon le mode du téléphone (sonnerie, vibreur, silencieux,
  Ne pas déranger) — l'app ne force jamais elle-même une vibration
- Affichage plein écran sans bordure, compatible tous téléphones
  (`EdgeToEdge.kt`) : chaque écran s'étend derrière la barre de statut et la
  barre de navigation (pas de bande de couleur système visible), s'adapte
  aux encoches/bords incurvés, et les tailles d'écran sont déclarées comme
  toutes supportées dans le manifeste (`<supports-screens>`)
- Restriction ZEE (`WifiDirectManager.kt`) : la découverte utilise le
  Wi-Fi Direct Service Discovery (DNS-SD), pas le scan générique
  `discoverPeers()`. Seuls les appareils annonçant explicitement le
  service ZEE apparaissent dans les listes — jamais un simple point
  d'accès Wi-Fi ouvert ni un appareil P2P non-ZEE à proximité.
- Transfert de fichiers optimisé (`FileTransferManager.kt`) : canal TCP
  dédié et séparé des messages texte, blocs de 64 Ko avec flux bufferisés
  — même principe que Xender pour maximiser le débit réel du Wi-Fi Direct
  sous-jacent (jusqu'à ~250 Mbps théoriques). Envoi câblé depuis
  `ChatActivity` (photos, audio, documents) ; réception écoutée en continu
  côté "group owner" (voir `MainActivity.onConnected`).
- Propagation virale des pubs (`AdRelayStore.kt` + `AdRelay.kt`) : une pub
  reçue par un appareil est automatiquement rediffusée par CET appareil à
  son tour aux autres utilisateurs ZEE à proximité — comme un virus qui se
  propage de proche en proche, au-delà de la portée radio du diffuseur
  d'origine. La date d'expiration reste toujours celle fixée par l'appareil
  d'origine (jamais recalculée en cours de relais), donc toute la chaîne
  s'éteint ensemble à minuit chez le diffuseur d'origine. Déduplication par
  identifiant unique : un utilisateur ne voit et ne relaie jamais deux fois
  la même publicité.
- Codes pub calendaires (`AdCodeValidator.kt` + `assets/ad_codes.csv`) :
  5 codes à 6 chiffres par jour, du 01/09/2026 au 01/01/2028, embarqués
  directement dans l'app (aucun serveur nécessaire, cohérent avec le
  fonctionnement 100% hors-ligne). Un code n'est accepté que le jour exact
  où il est prévu, comparé à la date système du téléphone. Une fois validé,
  la pub (texte + image jointe, voir `MyAdState.kt`) est active 24h.

## Ce qui reste à faire (marqué `// TODO` dans le code)

- **Échange réel des fichiers** (photo/vidéo/audio) : `ZeeSocketSession`
  ne transmet aujourd'hui que des lignes JSON (texte). Il faut ajouter un
  second canal binaire pour les pièces jointes volumineuses.
- **Pickers Android natifs** pour Caméra / Galerie / Document / Contact
  (actuellement des boutons qui affichent un message temporaire)
- **Persistance du profil** (SharedPreferences ou Room) et diffusion aux
  pairs connectés
- **Filtrage par module** : actuellement `WifiDirectManager` détecte tous
  les pairs ZEE sans distinguer s'ils sont en mode CHAT/MARKET/JOB — il faut
  échanger cette info dans un petit "handshake" applicatif après connexion
- **Vérification réelle du code pub** (module MARKET) — actuellement un
  simple dialogue sans logique de validation
- **Icônes et image assets** définitifs (le logo Z et les captures du
  cahier des charges n'ont pas été copiés dans `res/drawable`)

## Pourquoi pas d'APK livré directement ?

Générer un `.apk` nécessite le SDK Android et un compilateur Gradle complet,
qui ne sont pas disponibles dans cet environnement de génération de code.
Le projet est en revanche un vrai projet Android Studio, prêt à être ouvert
et compilé.


## Réseau maillé Wi‑Fi ZEE

Cette version ajoute un **relais multi-utilisateurs** au-dessus de Wi‑Fi Direct : le Group Owner ouvre un serveur TCP qui accepte plusieurs appareils ZEE au lieu d'un seul. Chaque appareil possède un `nodeId` ZEE stable annoncé dans le service DNS-SD. Les profils (nom + photo) sont distribués aux membres du groupe et les messages CHAT sont adressés par `nodeId`. Le Group Owner achemine le message vers le bon appareil et utilise un TTL comme mécanisme de relais de secours.

### Limite Android importante

Ce n'est pas un Wi‑Fi Mesh radio natif au sens 802.11s : Android ne garantit pas qu'un même téléphone puisse être simultanément client d'un groupe Wi‑Fi Direct et Group Owner d'un second groupe. La version livrée réalise donc le **maillage applicatif local** dans un groupe Wi‑Fi Direct multi-clients (A↔relais↔B/C/D). Pour un véritable A→B→C hors portée radio du relais, il faudra une technologie radio permettant plusieurs liaisons simultanées (par exemple Wi‑Fi Aware selon le matériel/Android) ou une couche réseau dédiée.

### Flux

1. Découverte DNS-SD du service ZEE + `nodeId`.
2. Création du groupe Wi‑Fi Direct.
3. Le Group Owner démarre le serveur TCP multi-clients sur le port 8988.
4. Chaque client envoie son profil ZEE (nom, actu, photo).
5. Le relais distribue les profils aux autres membres.
6. Un message CHAT contient `messageId`, `fromNodeId`, `toNodeId` et `ttl`.
7. Le relais transmet le message au destinataire; si aucune liaison ciblée n'est connue, il utilise le relais contrôlé par TTL.

## ZEE Mesh v2 — découverte, routage et mode hors ligne

La version Mesh v2 ajoute une vraie couche **store-and-forward** au protocole
ZEE :

- **Découverte automatique** : le service ZEE est relancé périodiquement tant
  que l'application est au premier plan.
- **Identité stable** : chaque installation possède un `nodeId` persistant.
- **Table de voisins** : les sessions TCP actives sont enregistrées par
  `nodeId` et servent de prochains sauts pour le routage.
- **Routage par TTL** : un paquet est adressé au `nodeId` final et chaque
  relais diminue le TTL afin d'éviter les boucles.
- **Déduplication persistante** : les `messageId` déjà vus sont conservés
  même après redémarrage.
- **File d'attente persistante** : un message envoyé à un utilisateur hors
  ligne reste dans `MeshMessageStore` jusqu'à sa livraison.
- **ACK de livraison finale** : l'expéditeur ne supprime son message de la
  file qu'après confirmation par le destinataire final.
- **Store-and-forward sur les relais** : chaque relais conserve temporairement
  le paquet si le prochain saut est indisponible, puis le réessaie dès qu'une
  route revient.
- **Reconnexion automatique** : après une perte de canal, ZEE recherche le
  pair connu et tente de reconstruire la liaison automatiquement.

### Important — portée radio réelle

Android Wi-Fi Direct permet un groupe avec un **Group Owner et plusieurs
clients**, ce qui convient très bien à un chat local multi-utilisateurs.
Android ne fournit toutefois pas un mode 802.11s mesh natif permettant de
faire simultanément de chaque téléphone un client et un relais radio
indépendant. Pour des sauts radio A → B → C lorsque A ne voit pas C, la couche
Mesh v2 est prête à accepter plusieurs liaisons, mais il faut un transport
radio multi-liens (par exemple Wi-Fi Aware lorsque le matériel le supporte).
La documentation Android indique que Wi-Fi Aware permet la découverte et les
connexions P2P directes, et que les appareils peuvent être simultanément
publishers et subscribers. citeturn0search9turn0search2

## ZEE Mesh v3 — Wi‑Fi Aware

Cette version ajoute un transport **Wi‑Fi Aware (NAN)** en complément de Wi‑Fi Direct.

### Fonctionnement

1. Chaque appareil ZEE publie `zee-mesh-v2` avec son `nodeId`, ses modules visibles et leurs critères.
2. Chaque appareil s'abonne au même service et découvre automatiquement les voisins compatibles.
3. Un seul des deux nœuds initie le data-path afin d'éviter les doublons.
4. Le publisher crée un `ServerSocket` éphémère et réserve un data-path Aware sécurisé avec une clé dérivée des deux `nodeId`.
5. Le port et l'adresse IPv6 du data-path sont utilisés pour créer le socket TCP.
6. Le socket est injecté dans `ZeeSocketSession`, donc le protocole ZEE existant (PROFILE/CHAT/ACK), le TTL et `MeshMessageStore` continuent à fonctionner.
7. Si la liaison disparaît, la session est fermée et le message reste dans le store jusqu'à ce qu'une route soit retrouvée.

### Compatibilité

- Le transport Aware est activé pour les appareils **Android 10 / API 29+** disposant du matériel Wi‑Fi Aware.
- Les appareils sans Wi‑Fi Aware continuent d'utiliser Wi‑Fi Direct.
- Android 13+ requiert `NEARBY_WIFI_DEVICES`; les versions plus anciennes utilisent l'autorisation de localisation pour les API Wi‑Fi concernées.

Wi‑Fi Aware permet la découverte directe et les connexions bidirectionnelles entre appareils sans point d'accès. La documentation Android indique également que les appareils peuvent publier et s'abonner simultanément et que les data-paths Aware utilisent des sockets via `Network.getSocketFactory()`. 


## Correctif pièces jointes / galerie

La pièce jointe « Galerie » du chat utilise maintenant `ActivityResultContracts.PickVisualMedia` (Photo Picker Android) au lieu de demander `READ_MEDIA_IMAGES` avant d'ouvrir la galerie. Cela évite les blocages liés aux permissions média et ouvre directement le sélecteur de photos/vidéos du téléphone.

Les photos/vidéos/documents/audio sélectionnés sont copiés immédiatement dans `files/chat_attachments/`. Cette copie locale permet au moteur Mesh de conserver la pièce jointe disponible lorsque le destinataire est hors ligne et que le transfert doit être repris plus tard.

## Mise à jour JOB — maquette 18/09/2026
L'onglet JOB a été remplacé par une vue dédiée reproduisant la maquette de référence : en-tête ZEE/Job, partage, favoris, menu, filtres Tous/Chercheurs d’emploi/Recruteurs, cinq cartes de profils avec rôles colorés, états en ligne/récents et distances. Les filtres et les cartes restent interactifs ; les vrais pairs ZEE prennent automatiquement la place des données de démonstration lorsqu'ils sont détectés.


## v39 — Live Chat maquette réelle
- La page Live Chat reprend l'en-tête, la liste de conversations, les heures et la pastille bleue de messages non lus de la maquette.
- Aucune conversation, aucun nom, aucune heure et aucun compteur fictif n'est créé.
- Une conversation apparaît uniquement pour un pair ZEE actuellement connecté et après un vrai message envoyé ou reçu.
- L'aperçu sous le nom, l'heure et le compteur proviennent des événements de messagerie réels et sont persistés localement.
- L'ouverture d'une conversation remet le compteur non lu à zéro.

## Mise à jour v41 — diffusion publicitaire ouverte à tous les onglets

La diffusion publicitaire est désormais éligible dans les trois modules, sans condition sur le statut choisi :
- BUSINESS : Vendeur et Acheteur
- JOB : Chercheur d'emploi et Recruteur
- LIVE CHAT : tous les utilisateurs

La validation du formulaire et du code publicitaire reste obligatoire avant activation.
