# Générer l'APK localement (v20)

Cet environnement de revue n'a ni SDK Android ni Gradle installés, donc l'APK doit être généré sur ton ordinateur, dans Android Studio (comme d'habitude).

## Option A — Android Studio (le plus simple)

1. Dézippe `zee-android-fusion-chat-temps-reel-connexion-corrigee-v20.zip` dans un nouveau dossier (pas par-dessus l'ancienne v19, pour éviter un mélange de `build/`/`.gradle/` périmés).
2. `File > Open...` → sélectionne ce dossier.
3. Laisse Gradle synchroniser (barre de progression en bas). Android Studio génère automatiquement `gradlew`/`gradlew.bat` s'ils manquent.
4. `Build > Clean Project`, puis `Build > Rebuild Project`.
5. Pour l'APK :
   - `Build > Build Bundle(s) / APK(s) > Build APK(s)`
   - Une fois terminé, clique sur le lien "locate" dans la notification en bas à droite, ou va directement dans :
     `app/build/outputs/apk/debug/app-debug.apk`

C'est un APK **debug**, installable directement (active "Sources inconnues" sur le téléphone) — suffisant pour tester le contrôle d'accès 21+ et les écrans modifiés.

## Option B — Ligne de commande

Depuis le dossier du projet (celui contenant `build.gradle.kts` et `settings.gradle.kts`) :

```bash
# Si gradlew n'est pas présent (le zip ne l'inclut pas) :
gradle wrapper

# Build debug (rapide, non signé mais installable) :
./gradlew assembleDebug
# Windows : gradlew.bat assembleDebug

# L'APK se trouve ensuite dans :
# app/build/outputs/apk/debug/app-debug.apk
```

Prérequis : JDK 17 installé et accessible (`java -version`), et le SDK Android (variable `ANDROID_HOME` ou fichier `local.properties` avec `sdk.dir=...`, généré automatiquement si tu passes par Android Studio au moins une fois).

## Pour une version release (signée, à distribuer / publier)

```bash
./gradlew assembleRelease
```

Nécessite un keystore de signature. Si tu n'en as pas encore, Android Studio peut en générer un via `Build > Generate Signed Bundle / APK...` — plus simple que de configurer la signature en ligne de commande la première fois.

## Si le build échoue

Voir `README_BUILD.md` (correctifs déjà appliqués pour un `Internal compiler error` déjà rencontré) : en résumé, fermer Android Studio, supprimer les dossiers `app/build` et `.gradle` du projet, puis relancer `Clean Project` → `Rebuild Project` avant de reconstruire l'APK.
