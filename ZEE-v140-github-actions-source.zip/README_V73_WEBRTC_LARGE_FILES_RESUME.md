# ZEE v73 — gros fichiers WebRTC : bufferedAmount + fenêtre de congestion + reprise par offset

Cette version fait évoluer le transfert de pièces jointes WebRTC pour les gros fichiers.

## 1. Contrôle de `bufferedAmount`

Le DataChannel est alimenté en blocs de 16 KiB. Avant chaque bloc, ZEE attend que le
buffer sortant reste sous 512 KiB. Cela évite de remplir la file native WebRTC avec
plusieurs dizaines de mégaoctets.

WebRTC expose `bufferedAmount`, qui représente les octets applicatifs encore en file,
et l'événement de changement de buffer peut être utilisé pour piloter une file
d'émission. Voir la documentation WebRTC/MDN :
- https://developer.mozilla.org/en-US/docs/Web/API/RTCDataChannel/bufferedAmount
- https://developer.mozilla.org/en-US/docs/Web/API/RTCDataChannel/bufferedamountlow_event

## 2. Fenêtre de congestion adaptative

La fenêtre applicative démarre à 512 KiB, augmente par pas de 256 KiB après des ACK
cumulatifs réussis, jusqu'à 4 MiB. En cas de timeout, saturation ou fermeture du
DataChannel, elle est divisée par deux avec un plancher de 256 KiB.

Le but est de maintenir le débit sans provoquer une accumulation excessive dans le
DataChannel.

## 3. ACK cumulatif

Le récepteur confirme l'offset réellement écrit sur disque toutes les ~2 MiB ou à la
fin d'un fichier. L'ACK contient :

- `messageId`
- `offset`

L'émetteur ne considère une fenêtre comme confirmée qu'après cet ACK.

## 4. Reprise par offset

Le fichier reçu est conservé dans `cacheDir/zee_rtc_received` lorsqu'une connexion
se coupe avant la fin. Au prochain `FILE_START`, le récepteur calcule la taille réelle
du fichier partiel et renvoie l'offset disponible.

L'émetteur repositionne son `FileInputStream` sur cet offset et continue l'envoi.

Ainsi, un fichier de 1 Go interrompu à 620 Mo ne doit pas nécessairement être
retransmis depuis zéro lorsque la liaison WebRTC revient.

## 5. Fallback

Après plusieurs tentatives WebRTC infructueuses, le pipeline existant de ZEE conserve
son comportement :

`WebRTC -> Fast Wi-Fi -> TCP`

La reprise par offset est donc une optimisation du chemin WebRTC, pas un remplacement
du mécanisme de secours.

## 6. Limite de validation

Le code a été contrôlé structurellement dans l'archive, mais une compilation Android
Gradle complète n'est pas disponible dans cet environnement : le projet fourni ne
contient pas `gradlew` et Gradle n'est pas installé ici. La validation finale doit
être faite avec une build Android et, surtout, avec deux téléphones ZEE réels.
