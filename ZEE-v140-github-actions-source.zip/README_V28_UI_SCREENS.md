# ZEE UI V28 — 4 écrans de navigation

La navigation principale a été remplacée par quatre écrans :

1. ACCUEIL
2. LIVE CHAT
3. BUSINESS
4. JOB

Les icônes demandées sont blanches :
- LIVE CHAT : deux personnes côte à côte ;
- BUSINESS : poignée de mains ;
- JOB : mallette ;
- ACCUEIL : maison.

La logique réseau, la présence Wi-Fi Direct, la visibilité par module et le moteur Mesh sont conservés. BUSINESS/JOB ne filtrent pas les rôles : seule la visibilité du module du pair décide de son affichage.
