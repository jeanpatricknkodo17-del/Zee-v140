# ZEE v50 — RENCONTRER déplacé dans LIVE CHAT

- Suppression de la sélection RENCONTRER de l'écran Accueil.
- Suppression de la sélection RENCONTRER du profil Live Chat.
- BUSINESS/JOB conservent uniquement leur sélection de STATUT.
- LIVE CHAT utilise uniquement les trois filtres Tous / Hommes / Femmes comme interface de rencontre.
- Hommes/Femmes mettent à jour la préférence persistée `CHAT_meet_choice`.
- Tous est un filtre d'affichage neutre : la compatibilité réciproque existante reste obligatoire.
- SEXE reste une donnée du profil Live Chat et continue d'alimenter le croisement réciproque.
- Aucun profil fictif n'est ajouté.


## V51 — précision de logique
La sélection Tous/Hommes/Femmes est une préférence persistante, pas un filtre de visibilité. Les profils restent visibles ; seuls les échanges sont soumis à la compatibilité réciproque : Homme→Femme avec Femme→Homme, ou Tous↔Tous. Les croisements avec Tous sont refusés.
