# ZEE v98 — Sélecteur de langue

- Ajout d’un choix de langue dans les paramètres de l’écran d’accueil.
- Langues proposées : français et anglais.
- Utilise AppCompat application locales pour appliquer la langue dans l’application, sans changer la langue globale du téléphone.
- Le choix est conservé automatiquement par AppCompat (metadata autoStoreLocales).
- Ajout des ressources anglaises pour les libellés principaux et les menus de paramètres.
- Les thèmes, les illustrations, le réseau et les autres fonctions de la base v97 sont conservés.

Note : les textes codés en dur dans certains écrans plus anciens ne sont pas encore tous externalisés en ressources traduisibles ; les ressources localisées et les libellés des paramètres/onglets sont pris en charge, mais une traduction intégrale de chaque écran nécessitera de migrer ces textes vers strings.xml.
