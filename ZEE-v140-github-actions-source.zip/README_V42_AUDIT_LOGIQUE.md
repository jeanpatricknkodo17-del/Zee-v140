# ZEE v42 — Audit et corrections de logique

Audit statique effectué sur la base de ZEE v41. Les corrections portent sur les incohérences qui pouvaient produire des profils/états non réels ou mélanger les modules.

## Corrections

1. **Présence réelle uniquement**
   - Les listes BUSINESS/JOB/LIVE CHAT n'affichent que les pairs ayant une session ZEE réellement établie (`CONNECTED`).
   - Un profil relayé (`direct=false`) ne transforme plus un utilisateur distant en faux voisin directement connecté.
   - La fermeture d'une session retire le pair correspondant de la présence locale.
   - Un service Wi-Fi Aware sans modules explicitement annoncés ne reçoit plus automatiquement les trois modules par défaut.

2. **Profils indépendants par onglet**
   - Le protocole PROFILE transporte maintenant le module concerné.
   - Nom, ACTU et photo reçus sont mémorisés par module.
   - BUSINESS, JOB et LIVE CHAT utilisent leur propre profil distant au lieu de réutiliser systématiquement le profil CHAT.

3. **Filtres BUSINESS/JOB**
   - Le statut distant doit être explicitement annoncé (`A`/`B`).
   - Le profil affiché doit être compatible avec le statut choisi localement.
   - Les filtres « Tous / premier / second » ne contournent plus cette compatibilité.

4. **Publicité indépendante par onglet**
   - L'état local de publicité est maintenant stocké séparément pour BUSINESS, JOB et LIVE CHAT.
   - Le protocole AD transporte le module d'origine.
   - Les anciennes publicités sans module sont supprimées lors de la migration afin de ne pas être classées arbitrairement dans CHAT.
   - L'activation d'un code ne peut plus consommer le code avant que l'activation locale ait réellement réussi.

5. **Validation du contenu publicitaire**
   - Les codes texte/image/document n'acceptent plus « Autre fichier ».
   - Les codes AUDIO et VIDEO exigent désormais exclusivement leur média correspondant et aucun texte.

6. **Expiration**
   - La durée est réellement de 24 heures à partir de l'activation, conformément au libellé de l'interface, au lieu d'une expiration au prochain minuit.

7. **Données de démonstration héritées**
   - Les anciennes conversations pouvant provenir des maquettes sont purgées une fois à la migration du store LIVE CHAT.
   - Les anciennes publicités dont le module n'était pas connu sont purgées à la migration.
   - Les activités BUSINESS avaient déjà une migration dédiée et restent alimentées uniquement par des événements réels.

## Limitation structurelle conservée

La validation des codes publicitaires est locale au téléphone. Sans serveur ou registre partagé, l'application hors-ligne ne peut pas garantir qu'un même code imprimé n'a pas été consommé sur **un autre téléphone**. Le contrôle « déjà utilisé » est donc garanti localement, pas mondialement.

## Vérifications effectuées

- Aucun nom de profil de la maquette JOB/BUSINESS/LIVE CHAT n'est injecté dans le code Kotlin comme donnée runtime.
- Aucun kilométrage de maquette n'est injecté comme donnée runtime.
- Aucun statut « Il y a X min » fictif n'est généré pour JOB.
- Les fichiers XML ont été analysés : aucune erreur XML détectée.
- L'archive source v41 a été décompressée et auditée avant modification.
- L'environnement de vérification ne contient pas Gradle/gradlew : une compilation Android complète n'a donc pas pu être exécutée ici.
