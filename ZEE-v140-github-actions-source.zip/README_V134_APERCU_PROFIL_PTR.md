# ZEE V134 — nom et ACTU visibles dès la découverte

Base : `zee-v133-business-job-visibles.zip`.

## Constat
À la découverte, la liste affiche le nom de la marque/modèle du téléphone (ex. « Infinix SMART 10 HD ») au lieu du nom et de l'ACTU de l'utilisateur. Le nom et l'ACTU voyagent dans le TXT DNS-SD, et dans tous les journaux fournis (itel, Infinix, TECNO) le TXT n'arrive pas alors que la réponse de service (PTR) arrive toujours.

## Correction
Le nom et l'ACTU sont maintenant aussi annoncés dans des noms d'instance supplémentaires (réponse PTR) :
`zeev2p-<n|c|m|j>-<base32>` : n = nom, c = ACTU Rencontres, m = ACTU Business, j = ACTU Job.
- 30 octets UTF-8 au plus par texte, coupés sans casser un accent ou un émoji ; label de 57 caractères au plus (limite DNS 63).
- N'est annoncé que ce qui est renseigné et visible : l'ACTU d'un module masqué n'est jamais envoyée.
- Réception : un aperçu complète le nom et l'ACTU du pair sans jamais écraser une valeur déjà connue. Il ne crée pas de pair (la visibilité d'un pair n'est connue que par son service principal).
- Quand le TXT ou le handshake PROFILE fournit le texte complet, il remplace l'aperçu tronqué, et un texte complet n'est plus remplacé par son début tronqué lors des rafraîchissements.
- Aussi corrigé : le TXT coupait parfois un caractère accentué en deux (troncature à l'octet).
- Interrupteur de sécurité : `PTR_PREVIEW_ENABLED` (WifiDirectManager, constante) à `false` revient à une annonce à un seul service.

Vérifié hors appareil : aller-retour base32 sur 1 à 30 octets aléatoires et sur des textes accentués/émojis ; longueur maximale 57.

## Limites
- Les textes de plus de 30 octets apparaissent tronqués jusqu'à l'arrivée du TXT ou de la connexion.
- La photo n'a pas de canal de repli : elle dépend du TXT (ou de la connexion).
- Annonce plus lourde : jusqu'à 5 services au lieu de 1. Non testé sur appareil.

## À vérifier au prochain test (v134 sur les DEUX téléphones)
- Journal émetteur : `LOCAL_PREVIEW added ...` puis `LOCAL_SERVICE announced ... previews=N`.
- Journal récepteur : `ZEE_PREVIEW addr=... kind=n` (puis c/m/j) ; le nom et l'ACTU s'affichent dans les listes.
- Surveiller que `ZEE_SERVICE_FOUND` / `ZEE_INSTANCE` continuent d'arriver. S'ils disparaissent, l'annonce plus lourde gêne : passer `PTR_PREVIEW_ENABLED` à false et envoyer les journaux.

Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).
