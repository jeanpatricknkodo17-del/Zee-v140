# ZEE v35 — accueil inspiré de la maquette fournie

L'écran **ACCUEIL** reprend la structure visuelle de la maquette :
- profil en haut (photo, nom, rôle, statut « En ligne ») ;
- raccourcis **Mon profil**, **Visibilité**, **Mes services**, **Paramètres**, **Aide & Support** et **À propos de ZEE** ;
- bouton de visibilité rapide avec activation/désactivation des trois services ;
- en-tête bleu avec engrenage sur l'accueil ;
- navigation inférieure blanche avec icône/texte bleus pour l'onglet sélectionné.

Les raccourcis sont fonctionnels :
- **Mon profil** ouvre le profil LIVE CHAT ;
- **Visibilité** permet de régler BUSINESS/JOB/LIVE CHAT et relance la découverte réseau ;
- **Mes services** ouvre directement l'onglet choisi ;
- **Paramètres** ouvre les réglages Wi-Fi/notifications et affiche l'état du mesh ;
- **Aide & Support** affiche une FAQ et ouvre WhatsApp pour contacter le support ;
- **À propos de ZEE** affiche la version et les informations de l'application.
