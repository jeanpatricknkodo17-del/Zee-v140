# ZEE v5 — fusion Wi‑Fi Direct + moteur mesh

Cette version est une fusion ciblée de la v24 et des correctifs Wi‑Fi Direct de la v4.

## Conservé de v24
- moteur mesh/session/ACK/retransmission;
- gestion multi-pairs;
- identité du voisin TCP et routes logiques;
- architecture UI et profils.

## Intégré depuis v4
- permissions Android 13+ avec NEARBY_WIFI_DEVICES;
- séquencement asynchrone DNS-SD;
- WPS PBC pour connect();
- garde contre callbacks/réessais obsolètes;
- protection contre plusieurs NetworkCallback onAvailable();
- retries de connexion pour ERROR(0) et BUSY(2);
- nettoyage plus robuste du groupe et du binding réseau.

## Correction supplémentaire
- suppression de la double déclaration de networkReadyForSockets/connectionGeneration présente dans v4.

## Limitation connue
Android ne fournit pas à WifiP2pManager une API universelle permettant de transformer directement WifiP2pInfo en Network pour tous les OEM. Le projet conserve donc un binding ConnectivityManager sur le réseau Wi‑Fi local sans Internet comme mécanisme de compatibilité. Le Logcat OEM reste nécessaire si ERROR(0) persiste.

## Compilation
Le ZIP source ne contient pas nécessairement le Gradle wrapper. Compiler avec Android Studio/Gradle installé et vérifier Logcat sur les appareils cibles.
