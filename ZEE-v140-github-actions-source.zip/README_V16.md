# ZEE v16 — reprise réseau et identité de secours

Corrections principales par rapport à v15 :

- Le handshake PROFILE utilise désormais `ProfileStore.getDisplayName()` : le nom enregistré reste prioritaire, mais un nom d'appareil lisible (fabricant/modèle) est utilisé si le profil est vide. Cela évite qu'une identité vide retombe sur un placeholder.
- Les messages persistants au démarrage redeviennent immédiatement éligibles dès qu'une route ZEE READY est disponible ; l'ancien backoff n'est pas conservé entre deux processus Android.
- Le routage reste strictement conditionné à l'état READY et au `nodeId` cible ; aucun fallback arbitraire n'est ajouté.
- La logique direct/relayée et le chemin inverse des ACK de v15 sont conservés.

## Diagnostic attendu dans Logcat

`HANDSHAKE_START` → `HELLO_SENT` → `READY_RECEIVED` → `PROFILE_RECEIVED` → `CHAT_RECEIVED` → `ACK_RECEIVED`.

Si `READY_RECEIVED` n'apparaît jamais, le problème est dans le canal TCP/handshake.
Si `PROFILE_RECEIVED` apparaît mais pas le bon nom/photo, le problème est dans la lecture du profil local ou l'encodage photo.
Si `CHAT_RECEIVED` apparaît mais pas `ACK_RECEIVED`, le problème est dans le chemin retour.
