# ZEE V119 — Statut et texte de profil

- Le statut « Connexion en cours... » / « En ligne » reste dans la ligne d’informations sous le nom, à l’emplacement prévu pour le statut (et non dans la colonne de distance).
- La colonne centrale est limitée à la hauteur du cercle photo (72 dp) et centrée verticalement.
- Le texte descriptif du profil reste sur une seule ligne avec ellipse en cas de dépassement, afin de ne pas déborder verticalement du diamètre de la photo.
- La distance et les autres éléments de la colonne de droite ne sont pas déplacés.
