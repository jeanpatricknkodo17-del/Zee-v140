# ZEE v103 — Nom du profil sur l’accueil

Le libellé de l’accueil affiche maintenant le nom enregistré dans « Mon profil ». Tant qu’aucun nom n’est renseigné, le texte de remplacement « Profil zee » reste affiché. Le contenu est actualisé au retour sur l’accueil.
