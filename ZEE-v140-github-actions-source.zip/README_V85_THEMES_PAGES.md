# ZEE v85 — thèmes de fond des pages

- Le fond clair/blanc actuel reste le thème par défaut après installation ou mise à jour.
- Un choix « Thème de l'application » est accessible depuis les paramètres de l'accueil.
- L'utilisateur peut choisir : Ville au coucher du soleil, Dégradé épuré, Messages — Lumière douce, Vagues élégantes, ou Rubans lumineux.
- Le choix est enregistré dans les préférences Android et reste actif au prochain lancement.
- Le thème s'applique aux pages Accueil, Business, Job et Live Chat, sans remplacer les fonds des cartes ni modifier les données ou comportements des pages.
- L'option « Blanc (par défaut) » permet de revenir à l'affichage actuel.
- Les fonds sont des images locales légères, sans téléchargement réseau.
- Compilation Android complète non exécutée dans cet environnement (aucun Gradle wrapper ni Gradle système disponible).
