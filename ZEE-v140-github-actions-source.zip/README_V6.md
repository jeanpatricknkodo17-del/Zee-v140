# ZEE v6 — stabilisation chat / profils / multi-clients

Cette version poursuit la correction du chat Wi-Fi Direct / Wi-Fi Aware.

## Corrections principales

- La photo du correspondant est maintenant conservée dans un état mutable dans `ChatActivity` : si la photo arrive après l'ouverture du chat via PROFILE, le bouton de plein écran utilise aussi la nouvelle photo.
- Suppression du double callback PROFILE côté `MainActivity` : `bindActiveChatNode()` déclenche déjà le callback du chat, évitant les mises à jour UI en double.
- Ajout d'une table adresse TCP par session dans `SessionRegistry`.
- Côté Group Owner multi-clients, l'adresse IP du socket qui a réellement envoyé le PROFILE est utilisée pour associer le profil au bon téléphone ; on ne dépend plus d'une adresse globale pouvant appartenir à un autre client.
- Les routes restent indexées par `nodeId` et un même socket peut transporter plusieurs nodeId relayés.
- `ZeeMeshServer` trace le remplacement d'une route lorsqu'un même nodeId se reconnecte.

## Vérification

Le ZIP a été vérifié comme archive ZIP valide. Un build Android complet n'est pas exécuté dans cet environnement car le projet ne contient pas de Gradle Wrapper et l'environnement ne fournit pas le SDK Android/Gradle nécessaires.
