# ZEE — fusion des améliorations

Cette version fusionne les deux branches fournies :

- branche `chat-temps-reel-optimise-build-fix2` :
  - connexion TCP persistante et `TCP_NODELAY`
  - file d'envoi non bloquante
  - ACK léger
  - routage strict par `nodeId`
  - mesure de latence
  - pièces jointes et relais de fichiers
  - propagation publicitaire opportuniste
  - corrections de compilation (`java.io.File`)
  - réglages de build contre les caches Kotlin/R.jar obsolètes

- branche `connexion-corrigee` :
  - liaison explicite du processus Android au réseau Wi-Fi Direct via
    `ConnectivityManager.bindProcessToNetwork`
  - nouvelle vérification de l'adresse du Group Owner lorsque Android renvoie
    temporairement `0.0.0.0`
  - libération du binding lors de la perte/arrêt de la connexion

La version fusionnée conserve le routage et le canal temps réel de la première
branche tout en réintégrant le correctif réseau Wi-Fi Direct de la seconde.
