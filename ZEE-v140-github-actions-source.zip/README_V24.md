# ZEE v24 — état de la liste des pairs vs la référence WhatsApp

Ce que l'image de référence montre (écran "Sélectionner un contact") est **déjà en place** dans `item_peer.xml` / `PeerAdapter.kt`, ligne par ligne :

| Élément de la référence | Où c'est dans le code | État |
|---|---|---|
| Photo ronde | `imgPeerPhoto` (CircleImageView) | ✅ décodée depuis `peer.photoBase64` |
| Nom | `txtPeerName` | ✅ `peer.displayName`, secours = nom système tant que le profil n'est pas reçu |
| Sous-texte (ACTU) | `txtPeerTag` | ✅ `peer.actu` |
| Pastille (messages non lus) | `txtUnreadBadge` | ✅ verte, en haut à droite de la photo |
| Cadenas | `imgProfileLockBadge` | ✅ en bas de la photo, pour les profils visibles mais non contactables (même sexe en LIVE TCHAT) |
| Distance | `txtPeerDistance` | ✅ pastille grise à droite du nom |
| Badge pub | `imgLock` (réutilisé) | ✅ visible si `peer.adActive` |

**Ce qui a réellement empêché ce rendu de fonctionner sur vos deux téléphones n'a jamais été cet écran, mais ce qui l'alimente en amont** — la connexion Wi-Fi Direct elle-même :

- v21 : `manager.connect()` échouait systématiquement (code 0) avant toute négociation → corrigé.
- v22 : la photo/nom/ACTU reçus étaient écrasés dès qu'un onglet se rafraîchissait → corrigé.
- v23 : votre propre photo de profil (par onglet) disparaissait car sa permission de lecture expirait → corrigée.

Ce zip cumule les trois. Sans ces trois correctifs réseau, l'écran ci-dessus ne pouvait de toute façon jamais afficher grand-chose : la photo/nom/ACTU n'arrivaient tout simplement jamais jusqu'à `PeerAdapter`, quelle que soit la qualité du layout.

## Pour le prochain test

Sur les deux téléphones, avec ce build : que voyez-vous exactement dans la liste — toujours l'icône par défaut à la place de la photo, le nom du téléphone au lieu du nom ZEE, ou autre chose de précis ? C'est ce détail qui indique si le problème reste réseau (rien n'arrive) ou purement visuel (ça arrive mais s'affiche mal).
