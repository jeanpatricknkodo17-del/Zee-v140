# ZEE v111 — Photo de profil pleine dans le cercle

La photo de profil découverte avant connexion est affichée en `CENTER_CROP` dans les `CircleImageView` afin de remplir entièrement le cercle, sans bandes ni marges internes.

Appliqué aux vues de profils des listes LIVE CHAT, JOB, BUSINESS, aux conversations, à l'en-tête du chat, au profil et à l'accueil.

La photo conserve ses proportions et est recadrée automatiquement pour occuper tout le cercle.
