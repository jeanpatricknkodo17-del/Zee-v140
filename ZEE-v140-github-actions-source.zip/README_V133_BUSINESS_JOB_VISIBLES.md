# ZEE V133 — onglets BUSINESS et JOB vides

Base : `zee-v132-instance-nodeid.zip`.

## Cause trouvée
Les listes BUSINESS et JOB n'affichent qu'un profil dont `visibleModules` contient leur module. Or un pair découvert sans TXT n'était exposé qu'avec `CHAT` (valeur provisoire) : il apparaissait dans RENCONTRES et jamais dans BUSINESS ni JOB. Dans tous les journaux fournis, le TXT n'arrive pas : les deux onglets restaient donc vides, quel que soit le statut annoncé.
Deuxième effet : la liste BUSINESS reste repliée tant qu'on ne touche pas la ligne « N utilisateurs détectés ».

## Corrections
1. V132 (déjà livrée) : modules et critères voyagent dans le nom d'instance, donc BUSINESS et JOB reçoivent leurs profils dès `ZEE_SERVICE_FOUND`.
2. Pair sans aucune annonce de modules (ancienne version) : la réception d'un PROFILE pour un module prouve que ce module est visible chez lui (un PROFILE n'est envoyé que pour les modules rendus visibles) ; le module est ajouté.
3. `mergeDiscoveredPeers` conserve ces modules appris tant que la découverte ne fournit pas de critères ; sinon ils disparaissaient à chaque rafraîchissement.
4. BUSINESS : la liste s'ouvre automatiquement dès qu'un profil est visible, tant que l'utilisateur n'a pas touché la ligne « utilisateurs détectés ».

## Règles inchangées
Un profil masqué dans un module n'apparaît pas dans ce module ; les filtres Tous / Vendeurs / Acheteurs et Tous / Chercheurs / Recruteurs restent des filtres d'affichage (voir README_REGLES_FILTRES.md).

## À vérifier au prochain test (v133 sur les DEUX téléphones)
- Journal : `ZEE_INSTANCE ... modules=CHAT,MARKET,JOB ...` côté voisin.
- Dans BUSINESS et JOB : le voisin apparaît sous « Tous », et sous le bouton correspondant à son statut.
- Si un téléphone est encore en v131 ou avant, il n'apparaîtra dans BUSINESS/JOB qu'après connexion (cas 2).

Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).
