# ZEE V135 — photo de profil dès la découverte

Base : `zee-v134-apercu-profil-ptr.zip`.

## Constat
La photo de profil n'apparaît pas à la découverte alors que le cercle est affiché : la miniature (clés TXT `pc` / `p0`) n'arrive jamais, comme le TXT lui-même. Observation : les seuls TXT reçus dans les journaux étaient ceux d'avant l'ajout de la photo ; tous ceux qui en contiennent n'ont jamais été reçus.

## Correction
- La photo voyage maintenant aussi par nom d'instance (réponse PTR, qui arrive toujours) : miniature 6x6 en RGB444 = 54 octets, en 2 services `zeev2p-0-<base32>` et `zeev2p-1-<base32>` (53 caractères chacun, limite DNS 63), à côté de l'aperçu du nom et de l'ACTU de la V134.
- À la réception, les deux morceaux sont assemblés puis agrandis en PNG 96x96 lissé (bilinéaire) : rendu flou et continu au lieu d'une mosaïque de 36 carrés. Le même lissage s'applique aux miniatures reçues par TXT.
- Le TXT n'emporte plus la photo quand elle part par nom d'instance : TXT plus petit (nom, ACTU et critères seulement).
- La photo d'aperçu ne remplace jamais une photo complète déjà reçue par handshake ; elle sert de repli pour tous les modules sans photo dédiée.
- Même interrupteur de sécurité que la V134 : `PTR_PREVIEW_ENABLED = false` revient à une annonce à un seul service, avec la photo dans le TXT.

Vérifié hors appareil : aller-retour du codage 12 bits (erreur <= 16/255 par canal) ; longueur des labels 53 caractères.

## Limites
- 6x6 pixels : c'est un aperçu flou (couleurs dominantes et forme générale), pas la photo nette. La photo complète arrive après la connexion (handshake PROFILE), comme avant.
- Annonce plus lourde : jusqu'à 7 services (principal, nom, 3 ACTU, 2 photo). Non testé sur appareil.

## À vérifier au prochain test (v135 sur les DEUX téléphones)
- Émetteur : `LOCAL_PREVIEW added name=zeev2p-0-...` et `...-1-...`, puis `LOCAL_SERVICE announced ... previews=N`.
- Récepteur : `ZEE_PREVIEW ... kind=0`, `kind=1`, puis `ZEE_PREVIEW photo ready ... pngChars=...` ; le cercle affiche une photo floutée.
- `ZEE_SERVICE_FOUND` et `ZEE_INSTANCE` doivent continuer d'arriver (sinon `PTR_PREVIEW_ENABLED = false` et envoyer les journaux).
- Un `ZEE_TXT` sans photo arrivant enfin confirmerait que la photo gênait le TXT.

Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).
