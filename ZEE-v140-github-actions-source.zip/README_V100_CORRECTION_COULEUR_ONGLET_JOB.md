# ZEE v100 — Correction de couleur de l’onglet Job

Correction de l’icône Job dans la barre d’onglets inférieure : elle utilise désormais la même logique de teinte que Live Chat et Business.
- Onglet sélectionné : bleu ZEE.
- Onglet non sélectionné : gris atténué.

Version Android : `0.42.0-v100-job-tab-tint-fix` (versionCode 42).
