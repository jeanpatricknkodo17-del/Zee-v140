# V116 — Photos de profil uniformisées

- Les photos des utilisateurs détectés dans la liste des profils passent de 54 dp à 72 dp.
- Le conteneur et l’image conservent une forme carrée affichée en cercle, avec `centerCrop`, comme les avatars de la liste de conversations WhatsApp-like (`item_chat_conversation.xml`).
- Le badge de verrouillage reste ancré en bas au centre de la photo.
