# V117 — Distance affichée avant le profil

Dans la liste des utilisateurs détectés, la distance estimée est désormais affichée avant le nom de chaque profil, sur la même ligne. La valeur provient de `peer.distanceMeters` ; si elle n'est pas disponible, l'interface affiche `--` plutôt qu'une distance inventée.

Fichier modifié : `app/src/main/res/layout/item_peer.xml`.
