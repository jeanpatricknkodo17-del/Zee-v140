# ZEE v110 — Photo de profil avant connexion

Cette version conserve la vision du projet : un utilisateur ZEE découvert à proximité doit pouvoir être identifié immédiatement par son **vrai profil**, y compris sa photo, avant l'établissement d'une session TCP.

## Modification

- Une miniature JPEG compacte de la photo de profil est ajoutée à l'annonce DNS-SD ZEE.
- La miniature est découpée en fragments TXT pour rester dans les limites pratiques de DNS-SD.
- Le pair reconstruit immédiatement la photo et la place dans `Peer.photoBase64`.
- `PeerAdapter` utilise cette photo dès que le profil apparaît dans LIVE CHAT, BUSINESS ou JOB.
- Après connexion, le profil complet par module continue d'être transmis par le handshake `PROFILE` et remplace la miniature lorsque disponible.
- Si aucune photo n'est définie, l'avatar par défaut reste utilisé.

## Pourquoi une miniature

DNS-SD/TXT n'est pas un canal adapté à une photo pleine résolution. La photo de découverte est donc une **vraie miniature de la photo choisie par l'utilisateur**, et non un avatar artificiel. La photo complète est ensuite transmise après connexion.

## Onglets

Le fallback `photoBase64` permet à la vraie miniature d'être visible avant connexion dans LIVE CHAT, BUSINESS et JOB. Les photos spécifiques à chaque module reçues après connexion restent prioritaires.
