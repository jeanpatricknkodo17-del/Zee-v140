# ZEE v51 — logique LIVE CHAT : visibilité et échange réciproque

Les trois choix au-dessus de LIVE CHAT sont désormais la préférence unique de
rencontre : **Tous / Hommes / Femmes**.

## Visibilité
- Un profil réellement connecté et annoncé sur LIVE CHAT reste visible aux
  autres utilisateurs, quelle que soit sa préférence.
- La préférence ne sert pas de filtre de visibilité.
- Aucune donnée fictive n'est créée.

## Autorisation d'échange
- Homme + Femme ↔ Femme + Homme : messages et médias autorisés.
- Tous ↔ Tous : messages et médias autorisés, quel que soit le sexe.
- Tous ↔ Hommes/Femmes : échange refusé.
- Toute autre combinaison non réciproque : échange refusé.

Le contrôle est symétrique et repose sur le critère annoncé par les deux
appareils.

## Persistance
Le choix Tous/Hommes/Femmes est stocké séparément de SEXE et restauré à la
réouverture de LIVE CHAT. Le SEXE reste une donnée de profil indépendante.

## Business / Job
Les choix de statut Business/Job restent inchangés.
