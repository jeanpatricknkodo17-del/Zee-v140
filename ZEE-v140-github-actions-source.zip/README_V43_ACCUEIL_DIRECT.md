# ZEE v43 — Accueil direct après splash

- Suppression du parcours d'onboarding : `SplashActivity` ouvre directement `MainActivity`.
- Les anciennes données saisies pendant l'onboarding sont désormais intégrées à l'accueil : confirmation 21+, nom, photo, sexe et RENCONTRER.
- Ces champs sont éditables depuis l'accueil et enregistrés dans `ProfileStore`.
- L'accès à l'accueil n'est jamais bloqué par l'absence de configuration.
- Tant que le profil local n'est pas enregistré avec un nom et la confirmation 21+, le service local ZEE n'est pas annoncé aux autres appareils ; cela évite de diffuser un profil vide.
- Après enregistrement, `refreshPeers()` relance la présence réelle.
- Les listes de proximité restent régies par la règle précédente : aucune donnée fictive n'est injectée.
