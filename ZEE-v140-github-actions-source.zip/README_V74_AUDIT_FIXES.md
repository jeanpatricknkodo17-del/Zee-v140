# ZEE v74 — audit réseau / WebRTC

Corrections appliquées après relecture de v73 :

1. Empêcher qu'un `FILE_END` perdu transforme un fichier déjà intégralement reçu en échec logique : le dernier chunk `end=true` et son ACK complet sont désormais suffisants pour finaliser la réception.
2. Valider la taille maximale du header et du paquet WebRTC avant allocation/décodage.
3. Refuser un transfert WebRTC dont `fromNodeId` ne correspond pas au pair direct, ou dont `toNodeId` n'est pas le nœud local.
4. Refuser les chunks vides ou supérieurs à la taille de chunk ZEE.
5. Corriger un bug de reprise : si un fichier partiel existant est plus grand que la taille annoncée, il est supprimé et la reprise repart de 0. L'ancien code pouvait créer un fichier creux de `fileSize` octets et le considérer à tort comme terminé.
6. ZIP vérifié avec `unzip -t`.

La compilation Gradle complète n'est pas exécutée dans cet environnement car l'archive ne contient pas `gradlew` et aucun exécutable Gradle n'est installé ici.
