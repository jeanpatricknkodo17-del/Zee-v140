# ZEE v89 — Illustrations des cartes de bienvenue

- Ajout d’illustrations d’arrière-plan distinctes aux cartes de bienvenue BUSINESS, JOB et LIVE CHAT.
- BUSINESS : illustration de collaboration professionnelle et environnement de bureau.
- JOB : illustration professionnelle avec tablette et skyline, dans le style de l’aperçu Job.
- LIVE CHAT : téléphone et bulles de conversation.
- Les illustrations sont placées à droite sur un fond clair pour préserver la lisibilité des textes à gauche.
- Les icônes, les photos de profil, les fonctionnalités et le choix de thème des pages sont conservés.

La compilation Android complète n’a pas été exécutée dans cet environnement (pas de Gradle wrapper ni de Gradle système).
