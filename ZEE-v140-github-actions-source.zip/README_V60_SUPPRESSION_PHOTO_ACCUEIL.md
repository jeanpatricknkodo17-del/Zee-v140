# ZEE v60 — suppression de la photo en doublon sur l’Accueil

- Suppression uniquement de la photo/zone « Choisir une photo » située juste sous « Je confirme avoir 21 ans ou plus ».
- La photo principale de l’Accueil (`homeAvatar`) reste conservée.
- La confirmation « 21 ans ou plus » reste sur l’Accueil.
- Le bouton « Enregistrer mon profil » reste à son emplacement prévu sous « À propos de ZEE ».
- La gestion de la photo de profil reste dans « Mon profil ».
- Les autres éléments et fonctionnalités de la version précédente sont conservés.
