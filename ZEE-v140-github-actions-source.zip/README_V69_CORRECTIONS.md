# ZEE v69 — corrections publicités, transferts et chat

Base : ZEE v68.

## Publicités
- Les pièces jointes d’une publicité sont copiées dans le stockage privé de ZEE à l’activation.
- Les médias image/audio/vidéo sont transférés sur le canal binaire dédié, séparément du JSON AD.
- Les médias peuvent être relayés de proche en proche avec le même `adId`.
- La publicité attend son média binaire avant affichage lorsqu’un média est annoncé.
- L’écran Publicité sait afficher image, lire audio et lire vidéo.
- Remplacement d’une publicité encore active : confirmation explicite avant de consommer le nouveau code.

## Codes publicitaires
- La consommation reste garantie localement sur l’appareil.
- L’architecture 100 % hors-ligne ne peut pas garantir une unicité globale absolue d’un même code sur deux téléphones déconnectés ou en usage simultané. La documentation et les messages ont été corrigés pour ne plus promettre cette garantie impossible sans autorité centrale/synchronisation forte.

## Transferts
- `FileTransferManager.sendStream()` renvoie désormais au callback un fichier réellement existant lorsque le contexte le permet ; pour les `content://`, une copie locale de la source est conservée dans le cache des transferts sortants.

## Chat
- Localisation : récupération d’une dernière position connue et envoi d’un message de localisation ouvrable dans Maps.
- Contact : sélecteur de contact + lecture du nom/numéro + envoi structuré.
- Les permissions nécessaires sont demandées au moment de l’action.
- Icône PUB dédiée dans `PeerAdapter` à la place de l’icône système e-mail.

## Validation
- Les fichiers Kotlin modifiés ont été contrôlés par analyse syntaxique des délimiteurs.
- Une compilation Gradle Android complète n’a pas pu être exécutée dans cet environnement car le ZIP ne contient pas de Gradle Wrapper et Gradle n’est pas installé ici.
