# ZEE v105 — Logo de l’onglet Job légèrement réduit

Le logo porte-documents de l’onglet Job est affiché à 88 % de sa taille précédente pour mieux correspondre aux autres icônes de la barre inférieure. La taille de la zone de l’onglet et son comportement de teinte sélectionné/non sélectionné restent inchangés.
