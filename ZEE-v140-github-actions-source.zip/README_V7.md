# ZEE v7 — identité directe vs profils relayés

Cette version poursuit la stabilisation du chat maillé.

## Corrections
- Le protocole PROFILE porte `direct=true/false`.
- `direct=true` : le profil provient du voisin TCP directement connecté et peut définir l'identité physique de la session.
- `direct=false` : le profil a été relayé par le Group Owner et ne peut jamais remplacer l'identité du socket.
- `SessionRegistry.registerDirectPeer()` est la seule opération qui définit l'identité physique d'une session.
- Un PROFILE relayé ne peut plus initialiser automatiquement un chat dont le nodeId était encore inconnu. Cela évite qu'un autre membre du groupe prenne la place du téléphone réellement sélectionné.
- Logs `PROFILE_SENT` / `PROFILE_RECEIVED` pour diagnostiquer nom, nodeId, transport et photo.

## Fiabilité
Les messages CHAT restent persistants jusqu'à ACK final et sont repris lorsqu'une route devient disponible.

## Vérification
L'archive ZIP a été testée avec `unzip -t`. Le build Android complet n'est pas exécuté ici car Gradle/SDK Android ne sont pas configurés dans cet environnement.
