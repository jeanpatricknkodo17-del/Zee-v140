# ZEE v76 — corrections UI Business / Job / Live Chat

Cette version corrige les trois points signalés sur la capture d'écran :

1. **Icône BUSINESS / poignée de main**
   - remplacement de l'ancien pictogramme blanc trop compact par une icône de poignée de main beaucoup plus lisible ;
   - le même asset est utilisé par l'en-tête BUSINESS, l'onglet inférieur et les activités Business.

2. **Carte de bienvenue LIVE CHAT alignée**
   - suppression du `layout_marginTop` supplémentaire de 14dp qui faisait descendre la carte LIVE CHAT par rapport à BUSINESS et JOB ;
   - mêmes espacements verticaux de base que les deux autres onglets ;
   - ajout d'identifiants aux deux textes de bienvenue pour conserver une structure cohérente.

3. **Photos de profil dans les cercles de bienvenue**
   - le cercle de chaque module charge maintenant la photo enregistrée dans son propre slot (`CHAT`, `MARKET`, `JOB`) ;
   - le chargement se fait par décodage Bitmap depuis le `FileProvider`, avec réduction automatique de la taille pour éviter de charger une photo pleine résolution dans un cercle de 64dp ;
   - le photo est rechargée dans `PeerListFragment.onResume()`, ce qui corrige le cas où `ViewPager2` conserve le fragment après un retour depuis l'écran de profil ;
   - en l'absence de photo valide, l'icône du module reste le fallback.

Le moteur Wi-Fi Direct / Wi-Fi Aware / WebRTC n'a pas été modifié dans cette version.

## Vérification

- XML des ressources modifiées vérifié avec le parseur XML.
- Le projet ne contient pas de wrapper Gradle embarqué utilisable dans cet environnement, donc une compilation Android complète n'a pas pu être exécutée ici.
