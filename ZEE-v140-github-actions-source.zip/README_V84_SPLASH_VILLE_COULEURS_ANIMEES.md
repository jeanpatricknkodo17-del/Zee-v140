# ZEE v84 — Splash ville, logo centré et couleurs animées

- Intégration de l'illustration splash fournie par l'utilisateur : ville au coucher du soleil, logo ZEE centré et barre de progression visuelle.
- Aucun personnage et aucun slogan sur l'écran splash.
- Conservation de la palette violette/lavande avec des nuances pêche chaleureuses.
- Ajout d'un calque transparent animé : les halos et une légère nuance des vagues se déplacent lentement, sans déplacer ni masquer le logo.
- L'illustration contient une représentation de la barre d'état ; les barres système Android sont masquées pendant le splash pour éviter un affichage en double.
- Le flux de démarrage existant et le contrôle de mise à jour sont conservés.

La compilation Android complète n'a pas été exécutée dans cet environnement.
