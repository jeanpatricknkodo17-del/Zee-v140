# ZEE V140 — séparation des canaux, persistance et médias

Base : `zee-v138-reseau-corrige.zip` (branche réseau Wi-Fi Direct conservée).
Le correctif réseau existant n'est pas réécrit.

## Corrections V140

- MessageEnvelope logique : `messageId`, `conversationId`, `channel`, type, timestamp, fichier local.
- Canaux persistants : CHAT, JOBS, BUSINESS, RENCONTRES.
- `channel` ajouté au protocole `CHAT` et `ATTACHMENT`, avec compatibilité descendante : absence du champ => CHAT.
- Les relais conservent le channel lors du forwarding.
- Une réception est persistée avant la notification/UI.
- Historique rechargé depuis `MessageStore` au retour dans ChatActivity.
- Les pièces jointes finales sont copiées dans `files/zee_media/<channel>/`, jamais considérées comme définitives dans `cache/`.
- Images, vidéos, audio et documents sont conservés avec leur MIME et chemin local.
- Visionneuse plein écran pour images/vidéos/audio et ouverture des documents via Android.
- Partage et copie de l'URI via `ClipData` lorsque le type le permet.
- Photo de profil ouvrable en plein écran.
- `FLAG_SECURE` sur MainActivity, ChatActivity, ProfileActivity, PhotoViewerActivity et MediaViewerActivity.
- `allowBackup=false`.
- Fond des bulles reçues légèrement gris.
- Le lecteur vidéo utilise `VideoView` sur l'URI finale ; aucune modification artificielle d'extension/MIME.
- Le lecteur audio utilise le fichier final conservé.
- Le canal actif est vérifié avant de pousser un événement vers ChatActivity.

## Réseau

Le transport Wi-Fi Direct / Nearby / FAST_WIFI existant de la base est conservé. V140 ne remplace pas la logique de connexion V139.

## Signature

Utiliser la clé fournie séparément :

- keystore : `ZEE-v140-release.jks`
- alias : `zee-release`
- versionCode : 70
- versionName : `0.70.0-v140`

Ne jamais générer une nouvelle clé pour V141+ si l'on veut conserver la possibilité de mettre à jour V140.

## Compilation

Le ZIP source ne contient pas le Gradle wrapper. Ouvrir le dossier `zee/` avec Android Studio/Gradle compatible avec le projet et exécuter `assembleRelease`, puis signer l'APK avec le JKS V140.

