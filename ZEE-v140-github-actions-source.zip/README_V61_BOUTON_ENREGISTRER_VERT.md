# ZEE v61 — bouton « Enregistrer mon profil » vert

- Le bouton « Enregistrer mon profil » situé sous « À propos de ZEE » est maintenant vert.
- La couleur du texte reste blanche.
- Aucun autre élément de l’écran d’accueil n’a été modifié.
- Les corrections précédentes de ZEE v60 sont conservées.
