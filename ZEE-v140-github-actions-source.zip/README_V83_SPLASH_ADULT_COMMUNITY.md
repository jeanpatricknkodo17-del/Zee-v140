# ZEE v83 — Splash cohérent avec le public 21+

- Ajout d'une illustration originale de quatre adultes en tenues casual-chic.
- Suppression des codes visuels évoquant des élèves/étudiants : aucun sac à dos, uniforme ou équipement scolaire.
- Conservation du logo ZEE, du slogan et du fond aux couleurs violettes/lavande animées.
- Illustration dessinée en Kotlin Canvas, sans image externe ni dépendance supplémentaire.

La compilation Android complète n'a pas été exécutée dans cet environnement (le projet ne contient pas de Gradle Wrapper et aucun Gradle système n'est disponible).
