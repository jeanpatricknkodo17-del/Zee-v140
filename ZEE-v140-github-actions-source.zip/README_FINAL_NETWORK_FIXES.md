# ZEE — correctif final profil + canal chat

Corrections ajoutées après la fusion :

- chaque socket TCP accepté par le Group Owner est enregistré comme transport dès son ouverture ;
- le nodeId du correspondant reste déterminé par le message PROFILE, même si la découverte Wi‑Fi Direct n'avait pas encore fourni de nodeId ;
- PROFILE est renvoyé 3 fois (immédiatement, +700 ms, +2 s) pour absorber les différences de timing entre appareils ;
- un message tapé avant la fin du handshake reste en file et est envoyé dès que le nodeId est connu ;
- les routes relayées ne remplacent pas l'identité du voisin TCP ;
- l'ACK reste strictement routé vers le nodeId d'origine ;
- les profils restent en cache par nodeId et la photo CHAT est envoyée depuis le slot de profil CHAT ;
- le serveur multi-client du Group Owner reste utilisé pour les connexions simultanées.

Test recommandé :
1. Téléphone A → téléphone B en Wi‑Fi Direct.
2. Ouvrir le chat immédiatement après la connexion.
3. Vérifier que le vrai nom et la photo remplacent « Profil ZEE » après réception du PROFILE.
4. Envoyer un message avant même que le profil soit affiché : il doit partir automatiquement après le handshake.
5. Répondre depuis B.
6. Tester A → B → C pour valider le relais.
