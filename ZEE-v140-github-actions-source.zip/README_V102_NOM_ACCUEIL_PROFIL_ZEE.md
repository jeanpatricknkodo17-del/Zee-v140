# ZEE v102 — Libellé du profil sur l’accueil

Le texte affiché à côté de l’avatar sur l’écran d’accueil est maintenant « Profil zee », au lieu du nom du téléphone ou du nom enregistré. Ce changement est limité à l’écran d’accueil : le nom du profil utilisé ailleurs dans l’application et dans les échanges réseau n’est pas modifié.
