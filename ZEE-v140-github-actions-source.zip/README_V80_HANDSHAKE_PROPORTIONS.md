# ZEE v80 — proportions de l’icône Business

Correction ciblée de l’icône poignée de main de l’onglet Business.

- La même poignée de main de référence est conservée.
- Le dessin utile a été recadré et agrandi dans le canvas 128×128.
- La poignée occupe désormais presque toute la largeur de l’icône, afin d’avoir un poids visuel comparable aux icônes Job et Live Chat.
- Aucun changement de couleur : l’en-tête reste blanc et l’onglet Business sélectionné reste bleu via le tint existant.
- Les autres icônes et la logique de photo instantanée restent inchangées.
