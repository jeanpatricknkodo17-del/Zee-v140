# ZEE v97 — Titres des cadres de bienvenue

- Retrait de « Bienvenue dans » dans les titres des trois modules.
- Les titres affichent désormais uniquement « BUSINESS », « JOB » et « LIVE CHAT ».
- Aucun autre texte, visuel ou comportement n'a été modifié intentionnellement.
