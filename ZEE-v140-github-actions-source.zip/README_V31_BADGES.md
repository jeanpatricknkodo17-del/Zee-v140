# ZEE v31 — Pastilles messages multi-modules

- Pastille bleue positionnée à droite de chaque carte, conformément à la maquette.
- Affichée dans LIVE CHAT, BUSINESS et JOB.
- Utilise le même `Peer.unreadCount` existant : aucun nouveau compteur parallèle.
- Le clic sur un contact ouvre le même `ChatActivity` et remet `unreadCount` à 0 comme auparavant.
- Les filtres Business/Job ne suppriment pas la pastille lorsque le contact est visible.
- Réseau Wi-Fi Direct/Mesh inchangé.
