# ZEE v78 — Business handshake bottom tab

- The Business header handshake remains white.
- Only the selected bottom Business tab handshake is blue, matching the selected Job/Live Chat tab icons.
- Bottom tab tint is applied explicitly during tab selection to avoid the white vector drawable overriding the selected color.
- Profile photo instant-refresh changes from v77 are preserved.
