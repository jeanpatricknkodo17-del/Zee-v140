# ZEE v56 — filtres de visibilité uniformisés

## UI
Les trois boutons de sélection de BUSINESS, JOB et LIVE CHAT utilisent désormais exactement le même gabarit :
- hauteur 42dp (gabarit BUSINESS de référence) ;
- trois boutons de largeur égale ;
- mêmes espacements horizontaux ;
- même padding du conteneur ;
- texte centré sur une seule ligne.

## BUSINESS
Les trois choix sont des filtres de visibilité :
- Tous
- Vendeurs
- Acheteurs

Le filtre ne supprime pas un profil réel en fonction du rôle de l'utilisateur local. Il sélectionne uniquement le type de profil annoncé par l'autre utilisateur.

## JOB
Les trois choix sont des filtres de visibilité :
- Tous
- Chercheurs d'emploi
- Recruteurs

Même principe : seuls le rôle annoncé du profil distant et le filtre choisi déterminent ce qui est affiché.

## LIVE CHAT
Les trois choix restent :
- Tous
- Hommes
- Femmes

Ils conservent leur logique LIVE CHAT précédente : la sélection reste la préférence enregistrée pour les règles réciproques d'échange et ne masque pas globalement les profils réellement connectés.

Aucune donnée fictive n'a été ajoutée.
