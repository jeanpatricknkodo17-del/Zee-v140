# ZEE v75 — correction des erreurs de compilation

Corrections basées sur le journal `./gradlew clean assembleDebug` fourni :

1. `MainActivity.kt` : ajout de la branche `FileResumeAck` dans le `when` exhaustif.
   `FileResumeAck` est normalement consommé en interne par `ZeeWebRtcTransport`, mais
   la sealed class Kotlin impose une branche dans le `when` du callback.
2. `MainActivity.kt` : suppression du `onDestroy()` dupliqué placé après la fermeture
   de `MainActivity`.
3. Fusion du nettoyage `zeeWebRtcTransport.closeAll()` dans le vrai `onDestroy()` de
   `MainActivity`, ce qui corrige les erreurs `override` top-level, `zeeWebRtcTransport`
   non résolu et `No supertypes are accessible in this context`.

Le message `Unable to strip libjingle_peerconnection_so.so` n'était pas la cause de
l'échec Kotlin et n'a pas été modifié.

Limitation : le ZIP source ne contient pas `gradlew`, et aucun Gradle wrapper n'est
présent dans cette copie, donc la compilation complète n'a pas pu être exécutée ici.
