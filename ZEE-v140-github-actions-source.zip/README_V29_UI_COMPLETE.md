# ZEE v29 — UI complète BUSINESS / JOB / LIVE CHAT

Cette version part de la v28 et modernise l'interface sans modifier les classes du moteur Wi-Fi Direct/Mesh.

## UI
- Navigation : ACCUEIL → BUSINESS → JOB → LIVE CHAT.
- Icônes blanches : poignée de mains BUSINESS, mallette JOB, deux personnes LIVE CHAT.
- Palette bleue/blanc/gris inspirée de la maquette.
- Cartes de profils avec photo, nom, rôle, statut et distance.
- BUSINESS : boutons Tous / Vendeurs / Acheteurs.
- JOB : boutons Tous / Chercheurs d'emploi / Recruteurs.
- Les filtres sont des filtres d'affichage locaux et ne modifient pas la visibilité réseau.
- La visibilité annoncée par le pair reste toujours obligatoire : un pair masqué reste absent.
- LIVE CHAT conserve son affichage des profils et ses restrictions de compatibilité existantes.
- Les sessions Wi-Fi Direct/Mesh ne sont pas supprimées par les changements de filtre UI.

## Mapping des rôles
- BUSINESS : critère A = Vendeur, B = Acheteur.
- JOB : critère A = Chercheur d'emploi, B = Recruteur.
