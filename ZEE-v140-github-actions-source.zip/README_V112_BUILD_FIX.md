# ZEE v112 — Build fix

Correction de compilation dans `WifiDirectManager.kt` : ajout de l'import `java.io.ByteArrayOutputStream` utilisé par l'encodage de la photo de profil DNS-SD.

Aucune logique réseau, Wi-Fi Direct, DNS-SD, TCP ou affichage photo n'a été modifiée.

Version : 0.54.0-v112-build-fix (versionCode 54)
