# ZEE v107 — affichage des profils découverts

- Les onglets BUSINESS et JOB n'exigent plus que le peer soit déjà CONNECTED pour l'affichage.
- Un profil ZEE annoncé et découvert est maintenant visible dès l'état AVAILABLE.
- `online` reste basé sur `PeerStatus.CONNECTED`, afin de distinguer découverte et connexion réelle.
- Le clic sur un profil continue de passer par `connectToPeer()` pour établir la session si nécessaire.
- LIVE CHAT conserve son fonctionnement conversationnel : les conversations réelles restent liées aux sessions établies.
