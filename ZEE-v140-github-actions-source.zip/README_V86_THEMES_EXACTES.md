# ZEE v86 — Variantes de thème exactes

Les cinq arrière-plans des thèmes personnalisables ont été remplacés par les cinq variantes visuelles de la planche de conception proposée :
1. Ville au coucher du soleil
2. Dégradé épuré
3. Messages — Lumière douce
4. Vagues élégantes
5. Rubans lumineux

Le fond blanc reste le thème par défaut. Les libellés, l'ordre des choix et la mémorisation du thème sélectionné sont conservés.
