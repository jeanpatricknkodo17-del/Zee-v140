# ZEE V127 — « Live Chat » remplacé par « Rencontres »

Base : `zee-v126-relance-dnssd.zip`.

- Libellés visibles : réglages de visibilité et services (HomeFragment), titre du module, description d'accessibilité du filtre et message « échange restreint » (PeerListFragment) affichent désormais « RENCONTRES ».
- Commentaires du code mis à jour de la même façon.
- Les ressources `strings.xml` affichaient déjà « Rencontres » : inchangées.
- Identifiants techniques conservés pour ne pas casser la compilation : `ic_live_chat_people_white`, `ui_live_chat`, `getLiveChatCriteria`, `ZeeModule.CHAT`.
- Les anciens README de version gardent leur texte d'origine (historique).

Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).
