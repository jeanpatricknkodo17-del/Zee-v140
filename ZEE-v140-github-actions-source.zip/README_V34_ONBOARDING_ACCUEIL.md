# ZEE v34 — onboarding réintégré dans l'écran d'accueil

Ce zip partait "sans onboarding" (`SplashActivity.proceedToApp()` allait directement à `MainActivity`) : `ProfileStore.isSetupComplete()`, `save()` et la confirmation d'âge existaient encore dans le code mais plus aucun écran ne les appelait. Conséquence concrète et pas seulement cosmétique : `ProfileStore.getSexe()` restait bloqué sur sa valeur par défaut ("Hommes") pour tout le monde, faute d'un endroit pour la renseigner — ce qui cassait silencieusement le filtrage croisé LIVE CHAT (`areLiveChatCriteriaCompatible`), qui en dépend directement.

## Ce qui a été ajouté

**`fragment_home.xml`** : une carte d'onboarding (`onboardingCard`) tout en haut de l'écran d'accueil, visible uniquement tant que `ProfileStore.isSetupComplete()` est faux — le reste de l'accueil (`homeMainContent` : Wi-Fi Direct, proximité, modules) reste masqué jusqu'à validation. Elle reprend les informations de l'ancien onboarding :
- confirmation "J'ai 21 ans ou plus" (obligatoire pour continuer)
- photo (partagée avec LIVE CHAT, comme avant)
- nom
- sexe ("Vous êtes") — la pièce manquante depuis la suppression de l'ancien écran
- critère de rencontre LIVE CHAT ("Vous souhaitez rencontrer")

**`HomeFragment.kt`** : gère l'affichage de cette carte, la sélection de photo (copiée immédiatement dans le stockage propre de l'app, comme dans `ProfileActivity`, pour ne jamais dépendre d'une permission externe qui expire), et la validation — qui appelle `ProfileStore.save()` **et** `setModuleMeetChoice(CHAT, ...)` (le critère réellement utilisé pour la diffusion Wi-Fi Direct, que `save()` seul n'alimente pas).

**`WifiDirectManager.kt`** : tant que l'onboarding n'est pas validé, l'appareil ne s'annonce plus aux autres (pas de profil par défaut visible malgré lui) mais continue de chercher les autres autour de lui — même logique que le cas "masqué sur tous les modules".

## Choix assumé

Contrairement à l'ancien écran séparé, il n'y a plus de blocage strict "app injoignable tant que non confirmé" — l'utilisateur reste sur l'accueil avec la carte affichée tant qu'il n'a pas coché la confirmation d'âge et indiqué son nom, sans y accéder autrement. Le sélecteur de photo ici est volontairement simplifié (galerie uniquement) ; l'appareil photo reste disponible ensuite via l'écran Profil de chaque onglet, qui garde ses deux options.
