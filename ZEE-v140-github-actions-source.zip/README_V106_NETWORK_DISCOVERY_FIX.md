# ZEE v106 — correction découverte Wi-Fi Direct / DNS-SD

Corrections appliquées à partir du diagnostic croisé TECNO Android 36 ↔ itel Android 29.

## 1. Annonce locale ZEE

L'annonce DNS-SD n'est plus conditionnée par `ProfileStore.isSetupComplete()`. Un appareil peut donc être découvert avant la finalisation complète de son profil. Les informations détaillées du profil restent échangées uniquement après connexion.

## 2. Stabilisation DNS-SD

`startDiscovery()` ne reconstruit plus l'annonce locale et la requête DNS-SD à chaque cycle. Elles sont conservées et réutilisées tant que leur signature n'a pas changé. Elles ne sont reconstruites que si la visibilité, les critères ou le `nodeId` changent.

Les redémarrages forcés rapprochés sont également temporisés afin d'éviter une succession de générations de découverte qui pouvait interrompre l'annonce au moment où l'autre téléphone la recherchait.

La requête DNS-SD est marquée comme non enregistrée lorsqu'elle est explicitement supprimée avant une connexion P2P ou lors du désenregistrement du manager.

## Version

`versionCode=48` — `0.48.0-v106-network-discovery-fix`
