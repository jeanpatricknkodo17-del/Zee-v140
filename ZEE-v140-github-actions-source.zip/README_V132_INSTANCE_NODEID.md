# ZEE V132 — filtres et ordre de connexion portés par le nom d'instance DNS-SD

Base : `zee-v131-connexion-pair-connu.zip`.

## Constat (journal Infinix X6525D, Android 34, croisé avec le journal itel W6502 du même test, 18:27)
- Les deux journaux viennent de la même version (avant V131) : `ZEE_SERVICE_FOUND` arrive des deux côtés, `ZEE_TXT` n'arrive d'AUCUN côté, malgré `SERVICE_REFRESH` toutes les 8 s pendant plus de 2 minutes.
- Infinix : la réponse de service arrive à 18:27:44 alors que la liste des pairs est vide (`peers=0`), puis `CONNECT failure code=0` x4. Même schéma que sur l'itel : le pair n'est pas dans la liste au moment de `connect()` (corrigé en V131).
- Sans TXT, le nodeId du pair est inconnu : les deux téléphones passent par le repli « sans nodeId » et initient chacun leur connexion (itel à 18:27:54, Infinix à 18:27:50), et les filtres Rencontres/Business/Job ne peuvent pas s'appliquer (sexe et statut inconnus).

## Correction
Le nom d'instance du service (réponse PTR, qui arrive toujours) porte maintenant les données de filtrage :
`zeev2-<nodeId 32 hex>-<modules c/m/j>-<chat sexe+préférence>-<market a/b>-<job a/b>`
exemple : `zeev2-ca6ec8fbadbf4c2fb24d2aea4527432a-cmj-hh-a-b` (49 caractères, limite DNS 63, minuscules, sans point).
- Le récepteur lit nodeId, modules et critères dès `ZEE_SERVICE_FOUND` (journal `ZEE_INSTANCE`) : filtres Tous/Hommes/Femmes, Vendeurs/Acheteurs, Chercheurs/Recruteurs et cadenas fonctionnent sans TXT.
- L'ordre de connexion par nodeId devient déterministe : un seul téléphone initie (le plus grand nodeId).
- Le TXT garde le nom, l'ACTU et la photo ; s'il arrive il complète le profil, sinon il est récupéré après connexion (handshake).
- Compatibilité : l'ancien nom fixe `_zee_app_service` reste reconnu (anciennes versions), et le nouveau est utilisé seulement si le nodeId est un UUID.
- Comparaison des nodeId insensible à la casse.

Vérifié hors appareil : aller-retour encodage/décodage sur les 192 combinaisons de visibilité/critères, longueur maximale 49.
Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).

## À vérifier au prochain test (v132 sur les DEUX téléphones)
- `LOCAL_INSTANCE name=zeev2-...` puis, côté voisin, `ZEE_INSTANCE nodeId=... modules=... criteria=...`.
- Un seul `AUTOCONNECT initiate ... ordered=true`, puis `CONNECT peer-known`, `CONNECT accepted`.
- Si `CONNECT failure` persiste alors que `peer-known` apparaît : envoyer les deux journaux, le problème sera alors dans la négociation Wi-Fi Direct elle-même.
