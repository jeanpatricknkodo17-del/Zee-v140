# ZEE v14 — reconnexion TCP sans renégociation P2P

Cette version corrige le cycle de reconnexion côté client.

## Correction
Après une perte du socket TCP, l’ancienne logique pouvait relancer `WifiP2pManager.connect()` alors que le groupe Wi-Fi Direct était encore établi. Android pouvait alors rester en état CONNECTED sans canal ZEE réellement prêt.

La v14 :
- conserve le groupe Wi-Fi Direct existant ;
- recrée uniquement la session TCP vers le Group Owner ;
- refait `HELLO → PROFILE` sur chaque nouvelle session ;
- réenregistre la route et déclenche le flush de la file persistante ;
- évite plusieurs reconnexions TCP simultanées ;
- abandonne la reconnexion TCP dès que le groupe P2P est réellement perdu.

## Résultat attendu
`Wi-Fi Direct connecté → TCP ZEE → READY → PROFILE → CHAT` peut maintenant être rétabli sans renégociation P2P inutile après une simple coupure TCP.

## Limitation
Pas de build Android complet dans cet environnement : SDK/Gradle Wrapper indisponibles. Archive contrôlée par `unzip -t`.
