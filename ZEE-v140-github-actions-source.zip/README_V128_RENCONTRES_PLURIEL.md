# ZEE V128 — « Rencontres » au pluriel partout

Vérification : tous les libellés visibles affichaient déjà « RENCONTRES » / « Rencontres » (onglet, titre du module, réglages, filtres, messages).
Seule correction : l'accord des messages favoris — « Rencontres ajoutées aux favoris » / « Rencontres retirées des favoris ».
Le libellé « RENCONTRER » (verbe, écran de profil) reste inchangé.
