# ZEE v99 — Migration de traduction

- Centralisation des textes statiques visibles dans les layouts Android via les ressources `strings.xml`.
- Traductions françaises et anglaises pour les libellés des écrans principaux, profils, publicité, diagnostic, pièces jointes et restriction d'âge.
- Migration de plusieurs messages dynamiques et dialogues Kotlin vers les ressources localisées, avec paramètres de format pour les compteurs et messages contextualisés.
- Le sélecteur de langue utilise les locales AppCompat et mémorise le choix de l'utilisateur.
- La langue de l'application est indépendante de la langue système.

Limite connue : certains textes très spécifiques ou contenus générés par l'utilisateur peuvent encore être construits dans le code ou provenir des données. La compilation Gradle complète doit être effectuée dans un environnement disposant de Gradle/JDK.
