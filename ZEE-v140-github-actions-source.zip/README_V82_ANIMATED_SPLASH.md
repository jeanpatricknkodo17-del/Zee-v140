# ZEE v82 — écran splash aux couleurs animées

- Remplacement du fond blanc statique par un fond animé personnalisé, sans dépendance externe.
- Dégradés violet, lavande et pêche qui dérivent lentement, avec deux vagues colorées en bas de l'écran.
- Logo ZEE conservé, avec slogan « Une communauté. Des opportunités. » et indicateur de chargement assorti.
- Animation active uniquement lorsque la vue est attachée à l'écran et arrêtée lorsqu'elle est détachée.
- Le flux de démarrage, le contrôle de mise à jour et la navigation existante restent inchangés.

La compilation Gradle complète n'a pas été exécutée dans cet environnement (le projet ne contient pas de wrapper Gradle et aucun exécutable Gradle système n'est disponible).
