# ZEE v62 — filtres de visibilité sexe dans LIVE CHAT

- Tous : affiche tous les utilisateurs LIVE CHAT réellement connectés et visibles.
- Hommes : affiche uniquement les utilisateurs dont le sexe annoncé est Homme.
- Femmes : affiche uniquement les utilisateurs dont le sexe annoncé est Femme.
- Le filtre s'applique à la liste des conversations et au compteur/dialogue des utilisateurs à proximité.
- La préférence sélectionnée reste persistante via ProfileStore.
- La logique de croisement réciproque existante (`areLiveChatCriteriaCompatible`) est conservée : le filtre de visibilité ne remplace pas et ne désactive pas cette vérification.
- Aucun profil fictif n'est ajouté.
