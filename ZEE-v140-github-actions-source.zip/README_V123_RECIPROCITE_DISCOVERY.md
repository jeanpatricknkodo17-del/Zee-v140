# ZEE V123 — découverte réciproque et TXT DNS-SD compact

Corrections ciblées après diagnostic Android 29 / itel W6502 :

- Réduction importante du TXT DNS-SD : clés compactes et métadonnées profil bornées.
- Miniature pré-connexion RGB565 6x6, au lieu de 8x8.
- Compatibilité de lecture avec les anciennes clés TXT.
- Journal `TXT_ESTIMATE` pour contrôler la taille de l'annonce réelle.
- Lorsqu'un service ZEE est découvert avant son TXT, le pair est créé immédiatement en présence provisoire CHAT ; le TXT complet remplace cette entrée dès réception.
- L'arbitrage de connexion ne bloque plus la découverte lorsque deux appareils ont accidentellement le même `nodeId` (cas possible après restauration/clonage). Le mécanisme conserve l'identité ZEE lorsqu'elle est distincte et utilise l'adresse P2P comme repli.
- Les listes déjà découvertes restent conservées pendant les relances de recherche.

Le correctif vise particulièrement le symptôme observé sur l'itel : `ZEE_SERVICE_FOUND` sans `ZEE_TXT`, suivi d'une liste vide.
