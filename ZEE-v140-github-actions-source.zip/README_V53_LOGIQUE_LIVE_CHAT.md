# V53 — Logique LIVE CHAT conservée et étendue

La logique précédente est conservée. Les combinaisons suivantes sont toutes réciproquement compatibles pour l’échange de messages et de médias :

- Homme → Hommes ↔ Homme → Hommes
- Femme → Femmes ↔ Femme → Femmes
- Homme → Femmes ↔ Femme → Hommes
- Femme → Hommes ↔ Homme → Femmes
- Tous ↔ Tous, quel que soit le sexe

Les autres combinaisons sont refusées pour l’échange. La visibilité des profils reste indépendante : un profil réellement connecté et visible peut rester affiché même si l’échange est restreint.

Les trois choix Tous / Hommes / Femmes restent l’unique interface de préférence LIVE CHAT. SEXE reste une donnée de profil séparée.
