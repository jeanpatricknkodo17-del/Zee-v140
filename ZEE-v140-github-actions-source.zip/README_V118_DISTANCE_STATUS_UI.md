# ZEE V118 — Distance et état de connexion

- La distance est déplacée à l'extrémité droite de chaque ligne de profil.
- Le nom, le rôle et l'actualité restent dans leur emplacement existant.
- Avant que l'état réseau soit CONNECTED, la ligne de statut affiche « Connexion en cours » avec une animation cyclique de zéro à trois points.
- Une fois CONNECTED, le statut affiche « ● En ligne » en vert.
- L'animation est arrêtée lorsque la vue est recyclée.
