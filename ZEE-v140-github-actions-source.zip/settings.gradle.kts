pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
    }
}

// Permet à Gradle de télécharger automatiquement le JDK 17 requis par le
// projet (voir jvmToolchain(17) dans app/build.gradle.kts) si aucun n'est
// déjà installé sur la machine — corrige l'erreur "Cannot find a Java
// installation on your machine" sans avoir besoin d'installer quoi que ce
// soit manuellement.
plugins {
    id("org.gradle.toolchains.foojay-resolver-convention") version "0.8.0"
}

rootProject.name = "ZEE"
include(":app")
