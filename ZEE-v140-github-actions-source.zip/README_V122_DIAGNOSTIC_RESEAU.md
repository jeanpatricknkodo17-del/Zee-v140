# ZEE V122 — Correction diagnostic réseau Android 29/35

## Problème observé
Les journaux montraient systématiquement `DISCOVERY_PHOTO failed: compressed image exceeds TXT budget`. Le JPEG miniature restait trop volumineux pour le budget DNS-SD TXT sur certains appareils.

## Correction
- La miniature pré-connexion n'est plus encodée en JPEG.
- Elle est réduite à 8×8 pixels et encodée en RGB565 brut : 128 octets, 172 caractères Base64, plus le préfixe de format.
- Un seul champ `photo0` est utilisé (budget 180 caractères).
- À la réception, le RGB565 est reconstruit en PNG Base64 pour rester compatible avec toute l'UI existante.
- Les anciennes miniatures JPEG/PNG restent acceptées comme format de compatibilité.
- La photo complète continue d'être transférée après connexion.

## Découverte
Le redémarrage de `discoverPeers()` peut temporairement retourner zéro pair sur certains firmwares. Le projet ne vide pas la présence ZEE à ce moment-là ; la liste reste fusionnée côté application jusqu'à confirmation DNS-SD.

## Limitation
Une miniature 8×8 est volontairement très légère : elle sert à afficher rapidement une indication visuelle avant connexion. La photo complète reste la source de qualité après établissement de la connexion.
