# ZEE v115 — échange réciproque + photos de profil

Corrections ciblées :

- Les deux rôles Wi-Fi Direct continuent d’envoyer HELLO + PROFILE pour chaque module visible.
- Les profils reçus par module sont conservés lors des rafraîchissements de découverte : noms, ACTU et photos ne sont plus écrasés par une nouvelle liste P2P brute.
- Les photos restent indexées par module (CHAT, BUSINESS/MARKET, JOB).
- JOB affiche la photo JOB avec repli sur la photo générale du profil.
- Le cercle JOB est aligné sur les proportions du cercle LIVE CHAT/BUSINESS.
- BUSINESS utilise le même PeerAdapter et bénéficie de la même conservation des photos par module.
- Aucun changement du protocole de filtrage des critères ni du routage des messages.

Journal attendu :
`MODULE_PROFILES_SENT` des deux côtés, puis `PROFILE_RECEIVED ... module=... photo=true` pour les modules qui disposent d’une photo.
