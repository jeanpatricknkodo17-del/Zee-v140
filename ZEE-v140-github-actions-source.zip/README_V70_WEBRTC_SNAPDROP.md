# ZEE v70 — transport WebRTC P2P inspiré de Snapdrop

Cette version n'intègre pas de code GPL de Snapdrop. Elle reprend son architecture
P2P (WebRTC DataChannel + signalisation séparée) avec la bibliothèque Android
WebRTC distribuée sous licence BSD-3-Clause.

## Architecture

- **Découverte** : Wi-Fi Direct / Wi-Fi Aware ZEE existants.
- **Signalisation** : canal TCP ZEE existant (`HELLO`, `READY`, puis `WEBRTC`).
- **Données P2P** : WebRTC DataChannel chiffré par DTLS, utilisant les ICE host
  candidates du réseau local.
- **Fallback** : si WebRTC ne s'établit pas, le transport TCP/mesh ZEE reste
  inchangé.
- **Aucun STUN/TURN par défaut** : cette intégration vise d'abord la connexion
  locale entre utilisateurs ZEE.

Le WebRTC est actuellement un transport secondaire de validation/accélération :
le protocole CHAT et les pièces jointes existants restent sur leurs transports
ZEE afin d'éviter toute régression. Le DataChannel est prêt pour une migration
progressive des paquets binaires.

## Dépendance

`io.github.webrtc-sdk:android:150.7871.01`

## Important

Snapdrop classique est sous GPL-3.0. Ne pas copier son code source dans une
application non compatible GPL sans traiter la licence. Cette version utilise
uniquement une implémentation WebRTC indépendante et l'architecture générale
P2P/signaling.

## V71 — migration CHAT + pièces jointes WebRTC avec fallback TCP

Le transport WebRTC devient maintenant le chemin préféré après `WEBRTC_READY`.

- `CHAT`, `ATTACHMENT` et `ACK` utilisent le DataChannel lorsqu'il est OPEN.
- Le TCP ZEE reste le canal de signalisation WebRTC et le fallback.
- Les pièces jointes WebRTC sont découpées en blocs binaires de 16 KiB pour éviter les messages DataChannel trop gros.
- Si le DataChannel n'est pas disponible ou tombe pendant un transfert, l'envoi du fichier reprend via le canal TCP binaire existant.
- Les routes maillées vers un autre node continuent d'utiliser le TCP lorsqu'aucun DataChannel direct n'est disponible.
- La réception WebRTC réutilise la même interface d'affichage des pièces jointes que le serveur TCP.

La migration est donc progressive : découverte Wi-Fi Direct/Aware → TCP ZEE → signalisation WebRTC → `WEBRTC_READY` → CHAT WebRTC → pièces jointes WebRTC → fallback TCP automatique.
