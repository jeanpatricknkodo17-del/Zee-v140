# ZEE v11 — fiabilité du canal CHAT

Cette version poursuit v10 avec une correction de concurrence et un retry plus sûr.

## Corrections
- `sendChat()` marque désormais le message **in-flight avant** de l'offrir au writer TCP. Le writer pouvant flush immédiatement sur un autre thread, cela supprime une fenêtre de course pouvant provoquer un double envoi.
- Le délai de première nouvelle tentative après un flush passe à **5 secondes**, afin de laisser davantage de temps à l'ACK final avant une retransmission.
- Les logs de relais indiquent explicitement `CHAT_DEFERRED` lorsqu'aucune route ZEE prête n'est disponible.
- Les fermetures d'anciens transports lors d'une reconnexion sont documentées comme volontaires et déclenchent le nettoyage normal des routes.

## Protocole
HELLO/READY reste la condition de disponibilité pour les messages privés. PROFILE peut être envoyé avant READY et reste idempotent.

## Vérification
Le projet n'a pas été compilé dans cet environnement (SDK Android/Gradle complet indisponible). L'archive ZIP est vérifiée séparément avec `unzip -t`.
