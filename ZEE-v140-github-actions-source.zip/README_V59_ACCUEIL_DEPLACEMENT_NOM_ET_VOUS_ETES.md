# ZEE v59 — accueil conservé, « Votre nom » et « Vous êtes » déplacés dans Mon profil

- L’écran d’accueil conserve la présentation de la v57.
- Seuls les éléments « Votre nom » et « Vous êtes » ont été retirés de l’accueil.
- Ces deux réglages sont présents une seule fois dans « Mon profil ».
- Dans « Mon profil », les libellés sont « Votre nom » et « Vous êtes ».
- Le bouton « Enregistrer mon profil » est placé immédiatement sous la carte « À propos de ZEE ».
- Les autres éléments de l’accueil (âge 21+, photo, menus, visibilité, services, paramètres, aide, à propos) sont conservés.
- Les autres fonctions du projet, notamment Wi-Fi Direct, filtres et logique Live Chat, sont conservées.
