# ZEE v63 — accès 21+, autosauvegarde et accueil simplifié

- Suppression du bouton « Enregistrer mon profil » de l’accueil.
- Suppression de la validation « Je confirme avoir 21 ans ou plus » de l’accueil.
- Suppression du titre « Mon profil » et de la carte de paramétrage du profil au-dessus de l’accueil.
- Les données de profil restent enregistrées automatiquement depuis « Mon profil » (nom, actu, sexe, statuts/critères, visibilité et photo selon les réglages déjà présents).
- À l’ouverture de ZEE, si la confirmation 21+ n’est pas encore enregistrée, une boîte de dialogue non contournable demande :
  - « Oui » : enregistre la confirmation et donne accès à l’application.
  - « Non » : ferme l’application.
- Les filtres Live Chat de v62 et la logique de croisement réciproque sont conservés.
