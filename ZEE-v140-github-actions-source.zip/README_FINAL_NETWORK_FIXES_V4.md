# ZEE — corrections V4 profil + chat

- Reprise automatique de MeshMessageStore dès qu'une route nodeId apparaît après PROFILE.
- En Group Owner, la cible du chat reste le pair explicitement sélectionné, pas le premier client retourné par requestGroupInfo().
- Nettoyage de toutes les routes d'un socket lorsqu'un client se déconnecte.
- Le PROFILE peut finaliser l'association du chat et déclencher la reprise des messages en attente.
- Toast Wi-Fi Direct simplifié pour ne plus afficher « Profil ZEE » comme s'il s'agissait de l'identité distante.
