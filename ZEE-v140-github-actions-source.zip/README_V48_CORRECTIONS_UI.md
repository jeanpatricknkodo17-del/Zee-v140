# ZEE v48 — Corrections UI et persistance du profil

- Logo poignée de main BUSINESS recolorisé en blanc opaque/anti-crénelé tout en conservant la transparence.
- Choix SEXE de LIVE CHAT rechargé depuis ProfileStore à l'ouverture et sauvegardé immédiatement lors d'un changement. BUSINESS et JOB ne présentent toujours pas la section SEXE.
- En-tête JOB utilise désormais exactement le même fond bleu que BUSINESS et LIVE CHAT (`bg_header_blue`) afin de supprimer la bande/dégradé sombre visible en haut.
- Les autres règles précédentes (connexions réelles uniquement, profils sans simulation, publicité par module) sont conservées.
