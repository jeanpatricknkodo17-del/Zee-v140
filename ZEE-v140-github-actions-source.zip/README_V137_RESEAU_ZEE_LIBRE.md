# ZEE V137 — réseau ZEE « libre » : connexion automatique pour tous les utilisateurs

Base : `zee-v136-connexion-rapide.zip`.

## Demande
Une connexion pour tous les utilisateurs, sans négociation, sans invitation, sans procédure de sécurité, qui s'établit dès la présence d'un autre utilisateur, comme un téléphone qui rejoint un réseau Wi-Fi à proximité.

## Ce qui est fait
1. **Un seul réseau pour tout le monde** : nom `DIRECT-ZE-ZEEFree`, mot de passe intégré à l'application (constantes `FAST_SSID` / `FAST_PASSPHRASE`). Plus de dérivation par nodeId : tout téléphone ZEE peut rejoindre n'importe quel groupe ZEE, sans rien saisir ni accepter.
2. **Rôles sans négociation** (`fastRoleFor`) :
   - je suis déjà Group Owner : j'attends, le pair rejoint mon groupe ;
   - le pair héberge déjà un groupe : je le rejoins, quel que soit l'ordre des nodeId ;
   - aucun groupe : le nodeId le plus grand crée le groupe, l'autre le rejoint.
3. **Plus de connexion classique sortante vers un pair compatible** : un Group Owner n'envoie plus d'invitation WPS/PBC (qui affichait une boîte « Invitation à se connecter » sur l'autre téléphone).
4. **Détection d'un groupe ZEE existant** : la liste brute des pairs est surveillée pour repérer les appareils qui hébergent un groupe (capacité Group Owner). Un groupe inconnu est sondé une fois (10 s, puis pause de 2 min) en tentant de le rejoindre avec le réseau ZEE libre : c'est le « je vois un réseau Wi-Fi, je m'y connecte ».
5. **Hérité de la V136** : repli automatique sur la connexion classique si la connexion rapide échoue (2 échecs avec un pair, puis on n'insiste plus avec lui) ; un groupe créé sans client est supprimé après 40 s ; un « pas de groupe » du système pendant une tentative n'est plus pris pour une perte de connexion.
6. Interrupteur : `FAST_CONNECT_ENABLED = false` revient à la connexion classique seule.

## Ce qui n'est PAS possible (limites réelles)
- **Pas de réseau sans chiffrement** : Android n'offre aucun moyen de créer un groupe Wi-Fi Direct ouvert ; un mot de passe de 8 à 63 caractères est obligatoire. Il est intégré à l'application et jamais demandé, donc aucune procédure de sécurité n'apparaît pour l'utilisateur, mais ce n'est pas un réseau « sans clé ».
- **Confidentialité** : la clé est identique pour tous les téléphones ZEE et figure dans l'application : toute personne qui a l'application (ou la décompile) peut rejoindre un groupe et lire le trafic non chiffré par ailleurs. Pour des conversations privées, il faudrait chiffrer les messages dans l'application (de bout en bout).
- **Instantané** : la découverte, puis la création du groupe (1 à 3 s) et la jonction prennent quelques secondes ; ce n'est pas aussi immédiat qu'une liste de réseaux Wi-Fi.
- **Android 9 et moins** : l'API de connexion rapide n'existe pas (Android 10 minimum) : ces téléphones gardent la connexion classique avec invitation.
- **Pair absent des listes** : un groupe déjà formé n'est pas toujours détectable comme utilisateur ZEE par la découverte de services ; c'est pourquoi le sondage du groupe par le nom de réseau est ajouté. Non vérifié sur appareil.

## À vérifier au prochain test (v137 sur les téléphones Android 10+)
- `GO_DEVICES count=...` : confirme que la liste brute signale les Group Owners.
- Premier arrivé : `FASTCONNECT start role=GO` puis `group-created`.
- Suivants : `FASTCONNECT start role=JOIN ... peerIsGO=true` ou `FASTCONNECT probe groupe inconnu`, puis `P2P_CONNECTED isGO=false`.
- Sur le Group Owner : `AUTOCONNECT wait ... je-suis-GO-le-pair-me-rejoint` (il n'invite plus personne).
- En cas d'échec : `FASTCONNECT failed ... -> connexion classique`. Envoyer les journaux de tous les téléphones.

Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).
