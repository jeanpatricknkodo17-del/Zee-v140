# ZEE v81 — nouveau logo de l’onglet Job

- Remplacement du pictogramme de la barre d’onglets Job par un porte-documents blanc dans un cercle bleu, conformément à la capture de référence.
- Le logo conserve ses couleurs propres lorsqu’on sélectionne ou quitte l’onglet ; il n’est donc pas recoloré par le tint global des onglets.
- Le pictogramme Job utilisé dans l’en-tête et dans les écrans internes reste inchangé : seule l’icône de l’onglet inférieur est remplacée.
- Les autres onglets et fonctionnalités ne sont pas modifiés.
