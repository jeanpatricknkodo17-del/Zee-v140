# ZEE V140 — compilation GitHub Actions

## 1. Déposer le contenu du dossier `zee` dans un dépôt GitHub

Le workflow `.github/workflows/android-v140.yml` compile automatiquement V140 avec :
- JDK 17
- Gradle 8.7
- `:app:assembleRelease`
- dépôt de l'APK comme artefact `ZEE-v140-release`

## 2. Ajouter les secrets GitHub

Dans le dépôt : **Settings → Secrets and variables → Actions → New repository secret**.

Créer :
- `ZEE_KEYSTORE_B64` : contenu Base64 du fichier `ZEE-v140-release.jks`
- `ZEE_KEYSTORE_PASSWORD` : mot de passe du keystore
- `ZEE_KEY_ALIAS` : alias de la clé
- `ZEE_KEY_PASSWORD` : mot de passe de la clé

Ne jamais mettre le `.jks` ou les mots de passe dans le dépôt.

## 3. Lancer la compilation

Ouvrir **Actions → ZEE V140 APK → Run workflow**.

À la fin : **Artifacts → ZEE-v140-release**.

Le fichier obtenu est `ZEE-v140-release.apk`.
