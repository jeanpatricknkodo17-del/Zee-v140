# ZEE V129 — fusion finale et relecture

Base : `zee-v128-rencontres-accord` + apports de `zee-fusion-final-wifi-avatars-filtres.zip`.

## Comparaison des deux zips
- Le zip fourni contenait déjà `WifiDirectManager.kt` identique à la v126-v128 ; il n'avait pas le heartbeat de MainActivity, le renommage « Rencontres », l'accord des messages favoris ni le correctif d'en-tête de diagnostic.
- Apports du zip fourni intégrés : photos/vidéos du chat au format WhatsApp (250 x 300 dp max, ratio conservé), gabarit des bulles, `avatar_dimensions.xml`.

## Intégré / corrigé
1. `MessageAdapter` : taille des médias recalculée à chaque liaison, avec retour au gabarit par défaut avant (ViewHolder recyclés).
2. `avatar_dimensions.xml` n'était utilisé nulle part : branché sur la liste des profils (`user_avatar_list`, 72 dp conformément à la consigne V116) et sur l'en-tête de chat (`user_avatar_header`, 40 dp au lieu de 36). Passer la liste à 50 dp = changer une seule valeur.
3. Code mort retiré de `PeerListFragment` : `isRoleCompatible` (règle de réciprocité Business/Job contredisant les filtres de visibilité de la V56) et `isChatEligibleForDisplay` (doublon de `chatSexMatches`, avec une règle de statut différente).

## Contrôles statiques effectués
XML bien formés (88 fichiers) ; aucune ressource référencée manquante ; aucun doublon de ressource ; clés fr/en identiques ; équilibre des accolades ; activités déclarées dans le manifeste ; FileProvider cohérent avec `file_paths.xml`.
Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).

## Estimation du TXT annoncé
Clés courtes : environ 450 caractères au maximum (photo 6x6 comprise). La ligne `TXT_ESTIMATE` du journal donne la valeur réelle.
