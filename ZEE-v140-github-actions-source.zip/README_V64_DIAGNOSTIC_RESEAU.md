# ZEE v64 — diagnostic réseau

Base exacte : `zee-v63-acces-21-autosave.zip`.

Cette version ne remplace pas la logique réseau par une nouvelle technologie : elle instrumente le Wi-Fi Direct existant pour identifier précisément où la connexion entre deux téléphones s’arrête.

## Journal enregistré
- état du Wi-Fi Direct ;
- permissions `NEARBY_WIFI_DEVICES` / localisation ;
- `discoverPeers()` ;
- changements `WIFI_P2P_PEERS_CHANGED_ACTION` + nombre de pairs système ;
- annonce du service ZEE ;
- requête DNS-SD ;
- `discoverServices()` ;
- service ZEE trouvé + TXT (modules, critères, nodeId) ;
- tentative `connect()` et codes d’erreur ;
- `WIFI_P2P_CONNECTION_CHANGED_ACTION` ;
- `groupFormed`, Group Owner et adresse du Group Owner ;
- connexion TCP/handshake déjà journalisés par ZEE.

## Écran
Dans **Paramètres → Diagnostic réseau**, le journal peut être actualisé, copié, partagé ou effacé.

## Test recommandé
Sur les deux téléphones :
1. installer cette v64 ;
2. autoriser **Appareils à proximité** ;
3. activer Wi-Fi et localisation si Android les exige ;
4. ouvrir le diagnostic ;
5. laisser ZEE ouvert sur les deux téléphones pendant 30–60 secondes ;
6. faire **Partager** le diagnostic de chaque téléphone.

Le but de cette version est de déterminer avec des faits si le blocage se situe à la radio P2P, à la découverte DNS-SD, à `connect()`, à la formation du groupe ou au transport TCP.
