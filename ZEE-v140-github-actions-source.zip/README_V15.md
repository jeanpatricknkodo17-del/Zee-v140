# ZEE v15 — correction ACK de relais et tentative TCP

Corrections principales par rapport à v14 :

- Correction d'une erreur Kotlin dans `SessionRegistry.clearReturnSession()` qui référencait un paramètre inexistant.
- Correction critique du routage des ACK : `onDelivered()` nettoie les métadonnées du message, donc la session de retour est désormais capturée avant ce nettoyage. Sans cela, un ACK reçu par un relais pouvait être consommé localement sans repartir vers le saut précédent.
- `markAttempt()` n'est plus appelé deux fois pour un même envoi : la comptabilisation d'une tentative et la mesure `markSent()` sont désormais déclenchées par `onLineFlushed`, c'est-à-dire après écriture et `flush()` réels du TCP.
- Le retry conserve ainsi un backoff cohérent et évite de faire avancer artificiellement le nombre de tentatives.
- Le stockage persistant continue de conserver le CHAT jusqu'à l'ACK final.

Validation effectuée : archive ZIP contrôlée avec `unzip -t`.

Limite : aucun build Android complet n'est exécuté dans cet environnement faute de SDK/Gradle configurés.
