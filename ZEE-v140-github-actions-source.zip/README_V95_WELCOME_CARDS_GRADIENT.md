# ZEE v95 — Cadres de bienvenue

- Cadres Business, Job et Live Chat stabilisés à 96dp de hauteur pour éviter l’effet étiré.
- Illustrations conservées à droite et fondues vers un dégradé bleu-violet à gauche, assorti à la capture de référence (#5C49F0 vers #433CE4).
- Texte de bienvenue blanc et sous-texte lavande clair pour rester lisibles.
- Les autres écrans, logos et fonctionnalités sont conservés.
