# ZEE v54 — Wi-Fi Direct : découverte + connexion automatique + échange local

## Problème corrigé

La version précédente savait publier/découvrir le service DNS-SD ZEE, mais la découverte restait une étape passive : un appareil pouvait apparaître comme pair disponible sans qu’un canal P2P TCP soit réellement établi. Or les profils et les messages ne sont échangés qu’après cette connexion.

## Solution implémentée

1. Chaque téléphone ZEE continue d’annoncer le service `_zee_app_service / _presence._tcp`.
2. Lorsqu’un TXT record ZEE complet est reçu, le `nodeId` du pair est connu.
3. Les deux téléphones appliquent un arbitrage déterministe : le `nodeId` lexicalement supérieur initie `WifiP2pManager.connect()`.
   - cela évite que les deux côtés appellent `connect()` simultanément ;
   - les échecs `ERROR/BUSY` sont toujours retentés par le mécanisme existant.
4. Après formation du groupe Wi-Fi Direct, ZEE attache le processus au réseau P2P avant d’ouvrir le socket TCP.
5. Le Group Owner lance le serveur multi-clients ; le client ouvre le socket vers le Group Owner.
6. Le handshake existant envoie automatiquement `HELLO`, les profils des modules visibles, les publicités actives et les messages persistants en attente.
7. Les messages restent dans `MeshMessageStore` tant qu’un ACK de livraison n’est pas reçu.

## Pourquoi cette approche

Android distingue la découverte des pairs/services de la connexion et du transfert de données. Une vraie transmission nécessite ensuite une connexion P2P puis des sockets TCP.

Référence Android : https://developer.android.com/develop/connectivity/wifi/wifi-direct?hl=fr

## Test réel recommandé

Sur deux téléphones Android compatibles Wi-Fi Direct :

- installer la même APK v54 ;
- ouvrir ZEE sur les deux ;
- autoriser `Appareils à proximité` ;
- si Android le demande pour la découverte, activer la localisation système ;
- garder ZEE ouvert au premier plan sur les deux ;
- attendre la découverte ;
- ne pas appuyer sur un bouton de connexion : la connexion P2P doit maintenant être déclenchée automatiquement ;
- vérifier dans Logcat les marqueurs `Connexion automatique ZEE`, `TCP_CLIENT_CONNECTED`, `PROFILE_RECEIVED` et `READY_RECEIVED` ;
- vérifier ensuite que le vrai nom/photo/profil du téléphone distant apparaît et qu’un message envoyé est reçu et conservé dans le stockage local du destinataire.

## Limite importante

Wi-Fi Direct doit être supporté par les deux appareils et Android/OEM peut imposer des restrictions supplémentaires. Cette version ne simule aucun appareil : si aucun autre téléphone ZEE réel n’est présent, la liste reste vide.
