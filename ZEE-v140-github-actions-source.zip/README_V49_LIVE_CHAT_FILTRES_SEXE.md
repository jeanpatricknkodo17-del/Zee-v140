# ZEE v49 — Filtres LIVE CHAT Homme/Femme

À partir de v48, l'onglet LIVE CHAT reçoit trois filtres en haut de page : Tous, Hommes, Femmes.

## Logique
- Les filtres ne créent ni ne simulent aucun utilisateur.
- Seuls les pairs réellement CONNECTED et ayant annoncé LIVE CHAT sont considérés.
- La compatibilité réciproque SEXE|RENCONTRER déjà définie dans `ProfileStore.areLiveChatCriteriaCompatible()` est appliquée avant le filtre Homme/Femme.
- `Tous` affiche tous les pairs réellement connectés et compatibles.
- `Hommes` n'affiche que les pairs compatibles dont le sexe annoncé est Homme.
- `Femmes` n'affiche que les pairs compatibles dont le sexe annoncé est Femme.
- Le compteur Proximité utilise exactement le même ensemble filtré.
- L'ouverture d'une conversation est bloquée si le pair n'est plus connecté ou si les critères ne sont plus compatibles.
- Une conversation locale n'est jamais affichée si son correspondant n'est pas actuellement connecté et éligible.
