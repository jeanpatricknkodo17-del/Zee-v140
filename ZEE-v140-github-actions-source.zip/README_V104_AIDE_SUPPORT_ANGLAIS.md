# ZEE v104 — Traduction de l’aide et du support

Le message affiché dans la fenêtre « Aide & Support » utilise désormais une ressource Android localisée. En français, le contenu reste en français ; en anglais, la FAQ et les instructions sont affichées en anglais.

Version : 0.46.0 (versionCode 46).
