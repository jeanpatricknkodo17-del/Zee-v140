# ZEE v94 — Logo Job porte-document harmonisé

- Remplacement du pictogramme Job par le porte-document fourni par l'utilisateur.
- Le même drawable est utilisé dans l'onglet inférieur, l'en-tête Job et le cercle de bienvenue, ainsi que dans les autres références existantes du module Job.
- Teinte blanche dans l'en-tête et le cercle de bienvenue ; teinte bleue dans l'onglet inférieur, conformément au code de couleur existant.
- Les photos de profil affichées dans le cercle de bienvenue ne sont pas teintées.
- Les autres logos et fonctionnalités ne sont pas modifiés.

La compilation Android complète doit être effectuée dans l'environnement Gradle du projet.
