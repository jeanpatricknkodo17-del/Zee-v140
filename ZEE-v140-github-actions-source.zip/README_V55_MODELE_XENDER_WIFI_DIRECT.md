# ZEE v55 — modèle de connexion inspiré de Xender

## Ce qui a été comparé

Le code source interne de Xender n'est pas public dans les sources consultées : il n'est donc pas possible de faire une comparaison ligne par ligne avec l'APK Xender sans rétro-ingénierie non fournie. La comparaison repose sur les documentations officielles Xender et Android.

Xender documente un modèle Android fondé sur un groupe Wi-Fi local/hotspot : un appareil crée un groupe, l'autre le rejoint, puis les fichiers sont transférés directement entre appareils. Xender demande officiellement le Wi-Fi/Hotspot et la localisation pour ce flux. Il documente aussi un mode « Direct » lorsque les appareils sont sur le même Wi-Fi.

ZEE conserve le principe demandé par le projet : aucun bouton « Envoyer/Recevoir » ni sélection manuelle de réseau pour l'utilisateur. Après activation du Wi-Fi et de la localisation lorsque Android l'exige, ZEE annonce son service, détecte uniquement les services ZEE, choisit automatiquement l'initiateur, forme le groupe Wi-Fi Direct et ouvre automatiquement le transport TCP.

## Correction principale v55

La v54 demandait à ConnectivityManager de réserver n'importe quel réseau Wi-Fi sans Internet puis de faire `bindProcessToNetwork()`. Sur certains appareils, ce réseau pouvait ne pas être le groupe Wi-Fi Direct. Le groupe P2P pouvait donc être formé alors que les sockets ZEE étaient routés sur la mauvaise interface.

La v55 supprime ce bind global. Une fois `WifiP2pInfo.groupFormed` reçu, ZEE utilise l'adresse du Group Owner et le routage P2P natif Android pour les sockets. Le Wi-Fi Internet et les VPN ne sont plus remplacés par un bind arbitraire.

## Découverte renforcée

- `discoverPeers()` est amorcé comme pré-scan radio.
- La liste utilisateur reste filtrée par le service DNS-SD `_zee_app_service` de ZEE.
- Les appareils non-ZEE découverts par le pré-scan ne sont jamais affichés comme utilisateurs ZEE.
- Avant `connect()`, ZEE ferme les requêtes DNS-SD et arrête le pré-scan afin d'éviter la concurrence entre découverte et négociation P2P.
- L'arbitrage par `nodeId` empêche les deux téléphones de lancer simultanément `connect()`.
- Le serveur TCP du Group Owner accepte plusieurs clients ZEE.
- Les fichiers/médias passent par le canal binaire existant, avec conservation du stockage local et reprise du routage applicatif.

## Limite Android importante

« Automatique » ne signifie pas que ZEE peut contourner les décisions du système Android. Android exige `NEARBY_WIFI_DEVICES` sur Android 13+ pour `discoverPeers()`/`connect()` et le mode Localisation reste requis par certaines API de découverte. Le Wi-Fi doit être activé. Les comportements OEM peuvent différer.

## Test physique obligatoire

La validation finale doit être faite sur deux téléphones Android physiques, avec la même version de ZEE :

1. Wi-Fi activé sur les deux.
2. Localisation activée lorsque le système l'exige.
3. Permission « Appareils à proximité » accordée.
4. ZEE ouvert sur les deux.
5. Aucun appui de connexion dans ZEE.
6. Vérifier : découverte → formation du groupe → TCP_CONNECTED → HELLO/READY → PROFILE_RECEIVED.
7. Envoyer une photo puis une vidéo et vérifier la réception dans le stockage local.

Marqueurs Logcat : `Pré-scan Wi-Fi Direct actif`, `Connexion automatique ZEE`, `Groupe Wi-Fi Direct formé`, `TCP_CLIENT_CONNECTED`, `HELLO_SENT`, `READY_RECEIVED`, `PROFILE_RECEIVED`.
