# ZEE V131 — connexion fiable (journal itel W6502, Android 10, face à un Infinix SMART 10 HD)

Base : `zee-v130-regles-filtres.zip`.

## Constat dans le journal (18:27 à 18:28, build v126+)
- Photo miniature OK : `DISCOVERY_PHOTO raw565 chars=101`, `TXT_ESTIMATE chars=245`.
- `SERVICE_REFRESH` tourne bien (périodique + `txt-missing`), mais `ZEE_SERVICE_FOUND` revient toujours sans `ZEE_TXT`.
- Le repli sans nodeId fonctionne : `AUTOCONNECT initiate ... ordered=false` environ 3 s après la découverte.
- Les 4 cycles de connexion échouent de la même façon : `CONNECT requested`, puis `CLEAR_SERVICE_REQUESTS`, puis `STOP_PEER_DISCOVERY`, puis `P2P_PEERS count=0` immédiatement, puis 4 x `CONNECT failure code=0`.

## Corrections
1. **Plus de `stopPeerDiscovery` avant `connect()`** : sur ce téléphone, l'arrêt vide la liste des pairs, donc `connect()` visait un pair inconnu. Le framework arrête lui-même la découverte au moment de la connexion. `clearServiceRequests` n'est plus appelé non plus avant la connexion.
2. **Vérification du pair avant chaque essai** (`awaitPeerThenConnect`) : si le pair n'est plus dans la liste, `discoverPeers` est relancé et on attend sa réapparition (8 s maximum, sondage toutes les 600 ms). Les nouveaux essais après échec (code 0 ou BUSY) repassent par cette vérification au lieu de retenter à l'aveugle. Journal : `CONNECT peer-known`, `CONNECT peer-absent`, `CONNECT peer-wait timeout`.
3. **TXT sans clé vide** : un utilisateur sans ACTU annonçait `a=`, `b=`, `j=` avec des valeurs vides. Ces clés ne sont plus annoncées. Hypothèse non vérifiée : certains analyseurs DNS-SD rejettent tout l'enregistrement quand une valeur est vide.

## À vérifier au prochain test (v131 sur les DEUX téléphones)
- `CONNECT peer-known` puis `CONNECT accepted` ; sinon `peer-absent`, puis le pair réapparaît, puis `accepted`.
- `ZEE_TXT` côté itel. S'il manque encore alors que le TXT est maintenant sans clé vide, regarder la version installée sur l'autre téléphone (elle doit aussi être la v131).

Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).
