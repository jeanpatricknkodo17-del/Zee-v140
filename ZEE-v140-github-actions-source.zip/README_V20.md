# ZEE v20 — contrôle d'accès 21+ et suppression des champs âge

Changements par rapport à v19 :

## Contrôle d'accès (nouveau)

- Après l'écran splash, avant l'écran d'onboarding, une pop-up de contrôle d'accès s'affiche désormais : « ZEE est réservé aux personnes de 21 ans et plus. » avec un bouton « Je confirme avoir 21 ans et plus » (poursuit vers l'onboarding) et « Annuler » (ferme l'application).
- Non annulable par un retour arrière ; affichée uniquement lors du tout premier lancement (tant que le profil n'est pas encore configuré) — elle ne réapparaît plus une fois l'onboarding complété (voir `SplashActivity.showAgeGateDialog()`).
- L'âge minimum requis passe ainsi de 18 à 21 ans, appliqué en amont de l'onboarding plutôt que via une saisie d'âge précise.

## Suppression des champs et filtres d'âge

- **Écran d'onboarding** : le champ ÂGE et le bloc « Tranche d'âge autorisée à voir mon profil » (Âge égal/supérieur/inférieur) ont été retirés du formulaire et du code (`OnboardingProfileActivity.kt`, `activity_onboarding_profile.xml`). Le garde-fou lié à l'ancien seuil de 18 ans a été supprimé, devenu obsolète.
- **Écran de profil LIVE CHAT** : le champ ÂGE et le « Filtre d'âge des profils affichés » (Âge égal/supérieur/inférieur) ont été retirés (`ProfileActivity.kt`, `activity_profile.xml`).
- Ces champs n'intervenaient déjà dans aucune logique réseau/de mise en correspondance entre pairs (seuls SEXE et RENCONTRER le sont, voir `ProfileStore.getLiveChatCriteria` / `areLiveChatCriteriaCompatible`) : leur suppression n'affecte donc pas le filtrage des profils affichés entre utilisateurs, uniquement l'affichage/la saisie.
- `ProfileStore.save()` est toujours appelé avec les paramètres `age` et `ageFilter` (chaînes vides désormais) pour rester compatible avec la signature existante, sans plus jamais être renseigné ni affiché nulle part dans l'app.
