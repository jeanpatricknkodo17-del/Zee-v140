# ZEE v9 — handshake TCP applicatif

Cette version poursuit v8 avec un vrai état de disponibilité du canal ZEE.

## Changements
- Ajout des messages `HELLO` et `READY` au protocole JSON.
- `HELLO` annonce le `nodeId` du voisin sur chaque socket.
- `READY` confirme que le canal applicatif ZEE est prêt dans les deux sens.
- Les messages CHAT ne sont routés que vers une session ayant reçu `READY`.
- Les messages saisis avant la fin du handshake restent dans la file persistante et sont envoyés automatiquement dès que `READY` arrive.
- Le handshake est également activé pour Wi-Fi Aware.
- Les logs permettent de suivre `HELLO_SENT`, `HELLO_RECEIVED`, `READY_SENT`, `READY_RECEIVED`.
- Les routes logiques et l'identité physique du voisin restent séparées.

## Validation
- Équilibrage syntaxique des principaux fichiers Kotlin modifiés : OK.
- Archive ZIP générée et testée avec `unzip -t` : OK.
- Build Android complet non exécuté dans cet environnement : Gradle/SDK Android ne sont pas disponibles ici.
