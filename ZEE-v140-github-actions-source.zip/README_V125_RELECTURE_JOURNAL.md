# ZEE V125 — relecture du code d'après le journal de diagnostic (itel W6502, Android 29)

Base : `zee-v124-filtres-visibilite-corriges.zip`.

## Constat dans le journal
- `DISCOVERY_PHOTO failed ... exceeds TXT budget` : ce message n'existe plus dans le code v124, donc le journal a été produit par une version antérieure à V122.
- `ZEE_SERVICE_FOUND` apparaît, jamais `ZEE_TXT`, et aucun `CONNECT requested` pendant plus de 2 minutes.
- Entre `DISCOVERY start` et le résultat de la photo : 300 à 700 ms sur le thread principal.
- Le 2e test (21:20) ne dure que 15 s et ne voit aucun pair (peers=0).

## Corrections
1. **Miniature jamais envoyée en v123/v124** : `R565:` (5) + 96 caractères Base64 = 101 caractères pour un budget de 96. Budget porté à 120.
2. **Décodage photo allégé** : décodage sous-échantillonné (`inSampleSize`) au lieu de la pleine résolution à chaque démarrage de découverte.
3. **Arbitrage de connexion symétrique** : l'ancien code comparait notre nodeId à l'adresse MAC du pair tant que son TXT manquait, alors que l'autre téléphone faisait la comparaison inverse (deux initiateurs ou aucun). Deux nodeId identiques bloquaient les deux côtés. Maintenant : ordre par nodeId seulement s'ils sont connus et distincts, sinon attente du TXT 3 s puis tentative avec délai aléatoire.
4. **Lecture des miniatures 8x8 (v122) et 6x6 (v123+)**.
5. **Diagnostic** : nouvelles lignes `AUTOCONNECT wait/initiate`, `ZEE_TXT_EMPTY`, durée `ms=` de la photo ; en-tête `NEARBY_WIFI_DEVICES` correct sur Android < 13 ; `nearby=n/a` dans le journal.

## À vérifier au prochain test (2 téléphones, ZEE ouvert 60 s)
- `TXT_ESTIMATE chars=...` puis `ZEE_TXT` côté pair. Si `ZEE_SERVICE_FOUND` revient sans `ZEE_TXT` ni `ZEE_TXT_EMPTY`, le TXT n'est pas livré par le firmware : réduire la taille annoncée.
- `AUTOCONNECT initiate` sur un seul des deux téléphones.

Compilation Gradle non exécutée (pas d'accès réseau dans l'environnement de relecture).
