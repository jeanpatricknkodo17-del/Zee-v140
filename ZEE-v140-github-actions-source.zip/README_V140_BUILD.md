# Build V140

1. Ouvrir `zee/` dans Android Studio.
2. Utiliser JDK 17.
3. Compiler `:app:assembleRelease`.
4. Signer l'APK release avec `ZEE-v140-release.jks` (fourni séparément).
5. Conserver exactement le même alias/keystore pour V141, V142, etc.

Paramètres :
- alias: zee-release
- keystore: ZEE-v140-release.jks
- versionCode: 70
- versionName: 0.70.0-v140
