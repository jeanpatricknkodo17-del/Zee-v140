# ZEE v88 — cohérence du logo Job

- L’onglet Job en bas réutilise désormais `ic_job_briefcase_white`, comme l’icône Job de l’en-tête et celle du cercle de bienvenue.
- L’icône du bas est teintée en bleu (`zee_blue`).
- Les icônes du haut et du cercle de bienvenue restent blanches.
- Les autres onglets et fonctionnalités sont inchangés.
