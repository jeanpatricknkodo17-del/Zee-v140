# ZEE v38 — profils réels uniquement

Cette version part de ZEE v37 et supprime toute simulation des listes de proximité.

## Règles appliquées aux trois onglets
- BUSINESS, JOB et LIVE CHAT n'affichent un profil que si une session ZEE est réellement établie (`PeerStatus.CONNECTED`).
- Une simple découverte Wi‑Fi Direct/Aware ne suffit plus à afficher un profil.
- Aucun nom, rôle, distance, statut ou photo fictif n'est injecté dans les listes.
- JOB n'invente plus le rôle : le profil doit avoir annoncé son critère JOB (`A` chercheur d'emploi, `B` recruteur).
- La distance JOB est affichée uniquement lorsqu'elle est réellement disponible ; sinon aucune distance fictive n'est calculée.
- Les anciennes activités BUSINESS de démonstration sont supprimées lors de la migration vers le schéma v2 ; les nouvelles activités doivent provenir d'actions réelles.

L'interface/maquette reste présente, mais les zones de profils restent vides tant qu'aucun autre utilisateur ZEE réel n'est connecté et visible dans le module concerné.
