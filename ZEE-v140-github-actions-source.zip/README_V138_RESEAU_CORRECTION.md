# ZEE v138 — correction connexion TECNO / itel

## Problème observé

Sur TECNO Android 35, le pair `itel S16` était bien visible par la radio Wi‑Fi Direct :

- `P2P_PEERS count=1`
- ancien journal `status=3` = `AVAILABLE` (pas CONNECTED)
- `P2P_CONNECTION_CHANGED` arrivait ensuite avec `groupFormed=false`

La connexion automatique ZEE dépendait alors d'un callback DNS-SD `ZEE_SERVICE_FOUND`.
Quand cet OEM publiait le pair radio avant sa réponse DNS-SD, aucune connexion ZEE ne démarrait.

## Corrections

1. `PTR_PREVIEW_ENABLED=false` par défaut : une seule annonce DNS-SD ZEE au lieu de plusieurs services de prévisualisation. Cela réduit la charge et les incompatibilités DNS-SD sur certains OEM.
2. Fallback radio API 29+ après 4,5 s si un pair `AVAILABLE/INVITED` est visible mais toujours absent des pairs ZEE.
3. Le fallback utilise le réseau ZEE prédéterminé (`DIRECT-ZE-ZEEFree`) et choisit GO/JOIN de façon symétrique à partir des deux adresses P2P.
4. Le fallback ne compare plus un `nodeId` local à une MAC distante : cette ancienne comparaison n'était pas symétrique.
5. Après formation du groupe, le handshake `PROFILE` reste la validation de l'identité ZEE ; la simple présence radio ne crée pas un profil ZEE.
6. Les diagnostics affichent maintenant `AVAILABLE`, `INVITED`, `CONNECTED`, etc. au lieu des numéros bruts.

## Résultat attendu au prochain test

Sur les deux téléphones, on doit voir quelque chose comme :

```text
P2P_PEERS count=1 -> itel S16:AVAILABLE
FASTCONNECT raw-fallback role=GO ...
FASTCONNECT group-created ...
P2P_CONNECTED owner=... isGO=true
```

ou côté opposé :

```text
P2P_PEERS count=1 -> TECNO...:AVAILABLE
FASTCONNECT raw-fallback role=JOIN ...
FASTCONNECT join requested ...
P2P_CONNECTED owner=... isGO=false
```

Si DNS-SD répond avant les 4,5 s, le fallback est annulé et le chemin DNS-SD normal reste utilisé.
