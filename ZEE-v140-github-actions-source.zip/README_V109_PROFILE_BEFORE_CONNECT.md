# ZEE v109 — Profil diffusé avant connexion

Cette version étend l’annonce DNS-SD Wi-Fi Direct pour transmettre avant toute session TCP :
- le nom d’affichage ZEE ;
- l’ACTU de LIVE CHAT ;
- l’ACTU de BUSINESS/MARKET ;
- l’ACTU de JOB.

Les valeurs textuelles sont encodées en Base64 URL-safe et limitées en taille pour rester adaptées aux enregistrements TXT DNS-SD. Les appareils les fusionnent dans le profil du pair découvert, ce qui permet aux listes d’afficher le nom et le texte du profil avant connexion. Les mises à jour de ces valeurs changent la signature d’annonce et provoquent sa reconstruction.

Les photos ne sont pas diffusées dans le TXT DNS-SD : leur contenu peut dépasser largement les limites de taille de ces annonces. Elles continuent d’être échangées via le canal applicatif après connexion. Les critères et modules visibles restent annoncés comme auparavant.
