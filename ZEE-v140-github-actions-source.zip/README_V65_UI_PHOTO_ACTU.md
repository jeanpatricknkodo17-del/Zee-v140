# ZEE v65 — photos d'accueil et ACTU

- Business : le cercle de bienvenue affiche la photo de profil Business de l'utilisateur lorsqu'elle existe, sinon l'icône poignée de main.
- Job : le cercle de bienvenue affiche la photo de profil Job lorsqu'elle existe, sinon l'icône mallette.
- Live Chat : le cercle de bienvenue affiche la photo de profil Live Chat lorsqu'elle existe, sinon l'icône Live Chat.
- Accueil : la photo et l'ACTU du profil Live Chat sont relues à chaque retour sur l'écran, sans redémarrage de l'application.
- Accueil : le texte auparavant utilisé pour « Vendeur/Acheteur » affiche maintenant l'ACTU renseignée dans Mon profil.
- Poignée de main Business : les traits de séparation ont été épaissis pour mieux distinguer les deux mains.
