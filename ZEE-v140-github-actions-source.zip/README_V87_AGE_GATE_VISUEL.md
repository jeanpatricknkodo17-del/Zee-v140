# ZEE v87 — écran de confirmation 21+

- Remplacement de l'ancienne boîte de dialogue textuelle par un écran de confirmation plus visuel.
- Badge 21+ violet avec cadenas, extrait de l'illustration fournie et intégré avec transparence.
- Bouton principal « J’ai 21 ans et plus » : confirme l'âge et mémorise le choix comme auparavant.
- Action secondaire « J’ai moins de 21 ans » : ferme l'application.
- Les pages restent masquées jusqu'à confirmation explicite.
- Le projet reprend ZEE v86 ; les thèmes personnalisables et les autres fonctionnalités sont conservés.

La compilation Android complète n'a pas été exécutée dans cet environnement (pas de Gradle wrapper ni de Gradle système disponibles).
